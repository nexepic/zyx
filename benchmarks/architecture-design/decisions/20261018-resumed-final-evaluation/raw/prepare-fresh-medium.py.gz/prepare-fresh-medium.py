from pathlib import Path
import csv,hashlib,json,os,resource,subprocess,sys,time
ROOT=Path('/workspace/zyx-resume-evaluation-20261018');folder=ROOT/'window/prepared-inputs/medium';database=folder/'current.zyx';failed=folder/'current-continuation-failed-cap.zyx';data=ROOT/'datasets/medium'
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
assert 'continuation failed with -25' in (ROOT/'continue-medium.log').read_text();assert not failed.exists()
previous={'preserved_failure':str(failed),'bytes':database.stat().st_size,'sha256':digest(database),'result':'actual_2GiB_RLIMIT_FSIZE_failure_SIGXFSZ','formal_samples':0}
database.rename(failed);failed.chmod(0o444)
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
binary=Path('/workspace/zyx/buildDir_final/zyx-compare-bench');command=[str(binary),'--dataset',str(data),'--db-path',str(database),'--scale','medium','--profile','scan','--workload','label_scan_filter','--warmup','0','--iterations','1','--threads','1','--load-batch-rows','5000','--emit-result-rows']
registration={'engine':'current','scale':'medium','seed':42,'command':command,'consumer_binary_sha256':digest(binary),'producer_binary_sha256':digest(binary),'dataset_sha256':{p.name:digest(p) for p in data.glob('*.csv')},'previous_failure':previous,'preparation_transaction_rows':5000,'preparation_timeout_seconds':7200,'formal_timing_samples_accepted':0,'per_file_bytes':2*1024**3,'address_space_bytes':6*1024**3,'threshold_changes':False,'reason':'Use previously registered 5000-row fixture transaction granularity to bound COW setup overhead. Same full logical data, same production binary and original limits; not an import performance claim.'}
path=folder/'current-fresh-5000-registration.json';assert not path.exists();path.write_text(json.dumps(registration,indent=2)+'\n');start=time.monotonic()
with (folder/'current-fresh-5000-stdout.jsonl').open('w') as out,(folder/'current-fresh-5000-stderr.log').open('w') as err:result=subprocess.run(command,stdout=out,stderr=err,timeout=7200)
if result.returncode:raise RuntimeError(f'fresh 5000-row preparation failed with {result.returncode}; retain failure')
with (data/'users.csv').open() as stream:expected=sum(row['country']=='CN' for row in csv.DictReader(stream))
observed=[json.loads(v) for v in (folder/'current-fresh-5000-stdout.jsonl').read_text().splitlines() if v.startswith('{')];observed=[v for v in observed if v.get('event')=='result'];assert len(observed)==1 and observed[0]['value']==expected
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison');from runner.workload_preflight import NativeWorker
before=digest(database);reader=NativeWorker(ROOT/'current-readonly-worker',database);checks=[]
try:
 for table,name in [('User','users'),('Post','posts'),('Tag','tags'),('FOLLOWS','follows'),('AUTHORED','authored'),('HAS_TAG','has_tag')]:
  with (data/(name+'.csv')).open() as stream:count=sum(1 for _ in csv.DictReader(stream))
  query=f'MATCH (n:{table}) RETURN count(*) AS count' if table in ['User','Post','Tag'] else f'MATCH ()-[r:{table}]->() RETURN count(*) AS count'
  reader.call('QUERY',query,expected=[[count]]);checks.append({'table':table,'count':count})
finally:reader.close()
assert digest(database)==before
registration.update(status='frozen_prepared_read_input',database_sha256=before,source_bytes_unchanged=True,consumer_counts=checks,elapsed_preparation_seconds=time.monotonic()-start)
Path(str(database)+'.json').write_text(json.dumps(registration,indent=2)+'\n');database.chmod(0o444);print(json.dumps(registration),flush=True)

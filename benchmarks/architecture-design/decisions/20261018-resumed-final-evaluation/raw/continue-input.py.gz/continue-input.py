from pathlib import Path
import argparse,csv,hashlib,json,os,resource,shutil,subprocess,sys,time
ROOT=Path('/workspace/zyx-resume-evaluation-20261018')
p=argparse.ArgumentParser();p.add_argument('--scale',choices=['medium','holdout'],required=True);a=p.parse_args()
assert json.loads((ROOT/'continuation-check.json').read_text())['passed']
folder=ROOT/'window/prepared-inputs'/a.scale;database=folder/'current.zyx';prefix=folder/'current-prefix-1000.zyx';data=ROOT/'datasets'/a.scale
previous=next(v for v in json.loads((ROOT/'committed-prefix-inspection.json').read_text()) if v['scale']==a.scale)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
assert not prefix.exists();assert digest(database)==previous['database_sha256']
database.rename(prefix);prefix.chmod(0o444);shutil.copyfile(prefix,database);assert digest(database)==previous['database_sha256']
cpus=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{cpus[0 if a.scale=='medium' else 1]})
resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
producer=ROOT/'continuation-producer';consumer=Path('/workspace/zyx/buildDir_final/zyx-compare-bench')
command=[str(producer),'--dataset',str(data),'--db-path',str(database),'--scale',a.scale,'--profile','scan','--workload','label_scan_filter','--warmup','0','--iterations','1','--threads','1','--load-batch-rows','5000','--emit-result-rows']
registration={'scale':a.scale,'engine':'current','seed':42 if a.scale=='medium' else 314159,'command':command,'consumer_binary_sha256':digest(consumer),'producer_binary_sha256':digest(producer),'database_sha256_before_continuation':previous['database_sha256'],'preserved_prefix':str(prefix),'prefix_counts':previous['counts'],'dataset_sha256':{f.name:digest(f) for f in data.glob('*.csv')},'preparation_transaction_rows':[1000,5000],'preparation_timeout_seconds':7200,'formal_timing_samples_accepted':0,'per_file_bytes':2*1024**3,'address_space_bytes':6*1024**3,'quota_changes':False,'protocol':'Previously registered committed-prefix continuation; not a fresh-import or import-timing result.'}
record=folder/'current-continuation-registration.json';assert not record.exists();record.write_text(json.dumps(registration,indent=2)+'\n')
start=time.monotonic()
with (folder/'current-continuation-stdout.jsonl').open('w') as out,(folder/'current-continuation-stderr.log').open('w') as err:
 result=subprocess.run(command,stdout=out,stderr=err,timeout=7200,env=dict(os.environ,ZYX_DIAGNOSTIC_RESUME='1'))
if result.returncode:raise RuntimeError(f'continuation failed with {result.returncode}; retain both prefix and candidate')
with (data/'users.csv').open() as stream:expected=sum(row['country']=='CN' for row in csv.DictReader(stream))
events=[json.loads(v) for v in (folder/'current-continuation-stdout.jsonl').read_text().splitlines() if v.startswith('{')];observed=[v for v in events if v.get('event')=='result'];assert len(observed)==1 and observed[0]['value']==expected
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.workload_preflight import NativeWorker
before=digest(database);reader=NativeWorker(ROOT/'current-readonly-worker',database);checks=[]
try:
 for table,name in [('User','users'),('Post','posts'),('Tag','tags'),('FOLLOWS','follows'),('AUTHORED','authored'),('HAS_TAG','has_tag')]:
  with (data/(name+'.csv')).open() as stream:count=sum(1 for _ in csv.DictReader(stream))
  query=f'MATCH (n:{table}) RETURN count(*) AS count' if table in ['User','Post','Tag'] else f'MATCH ()-[r:{table}]->() RETURN count(*) AS count'
  reader.call('QUERY',query,expected=[[count]]);checks.append({'table':table,'count':count})
finally:reader.close()
assert digest(database)==before
registration.update(status='frozen_prepared_read_input',database_sha256=before,source_bytes_unchanged=True,consumer_counts=checks,elapsed_continuation_seconds=time.monotonic()-start)
Path(str(database)+'.json').write_text(json.dumps(registration,indent=2)+'\n');database.chmod(0o444)
print(json.dumps(registration),flush=True)

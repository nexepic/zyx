from pathlib import Path
import argparse,hashlib,json,os,resource,sys
ROOT=Path('/workspace/zyx-resume-evaluation-20261018');sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
p=argparse.ArgumentParser();p.add_argument('--engine',choices=['control','current','kuzu'],required=True);p.add_argument('--round',type=int,choices=[1,2,3],required=True);p.add_argument('--family',required=True);p.add_argument('--cpu',type=int);a=p.parse_args()
assert a.family not in ['dynamic','maintenance'],'Preserve recorded dynamic failure and accepted O6 evidence; no unchanged-source rerun'
eligible=os.sched_getaffinity(0);cpu=max(eligible) if a.cpu is None else a.cpu;assert cpu in eligible;os.sched_setaffinity(0,{cpu});resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3));os.environ['ZYX_CONTRACT_OPERATION_TIMEOUT_SECONDS']='1800'
from runner.workload_preflight import run_native,run_kuzu
output=ROOT/'correctness'/f'round-{a.round}'/a.engine/a.family
registration={'scope':'Full-size final correctness only, not performance sampling. May overlap untimed fixture preparation on a different CPU.','family':a.family,'engine':a.engine,'round':a.round,'profile':'contract','seed':42,'deadline_per_family_seconds':1800,'file_bytes':2*1024**3,'address_space_bytes':6*1024**3,'affinity':sorted(os.sched_getaffinity(0)),'formal_performance_samples':0,'runner_sha256':hashlib.sha256(Path('/workspace/zyx/benchmarks/graphdb-comparison/runner/workload_preflight.py').read_bytes()).hexdigest()}
record=ROOT/'correctness-registration'/f'{a.round}-{a.engine}-{a.family}.json';record.parent.mkdir(exist_ok=True);assert not record.exists();record.write_text(json.dumps(registration,indent=2)+'\n')
if a.engine=='kuzu':
 import kuzu
 original=kuzu.Database
 class Database(original):
  def __init__(self,*args,**kwargs):kwargs['max_db_size']=2*1024**3;super().__init__(*args,**kwargs)
 kuzu.Database=Database
 report=run_kuzu(output,profile='contract',seed=42,family=a.family)
else:
 folder=Path('/workspace/zyx/buildDir_final') if a.engine=='current' else Path('/workspace/zyx-control-d09fc467/build')
 report=run_native(folder/'zyx-workload-contract-worker',output,profile='contract',seed=42,family=a.family)
print(json.dumps({'status':'full_correctness_passed','engine':a.engine,'round':a.round,'family':a.family,'operations':report['operations'],'full_results_checked':report['full_results_checked'],'formal_performance_samples':0}),flush=True)

from pathlib import Path
import hashlib,json,os,platform
ROOT=Path('/workspace/zyx-resume-evaluation-20261018');window=ROOT/'window'
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
assert not (window/'registration.json').exists()
plan=json.loads((ROOT/'preregistration.json').read_text());inputs={};binaries={}
for scale in ['medium','holdout']:
 expected=json.loads((ROOT/'datasets'/scale/'resume-manifest.json').read_text())['csv_sha256'];hashes=[]
 for engine in ['control','current']:
  database=window/'prepared-inputs'/scale/(engine+'.zyx');manifest=json.loads(Path(str(database)+'.json').read_text())
  assert manifest['status']=='frozen_prepared_read_input' and manifest['dataset_sha256']==expected
  assert digest(database)==manifest['database_sha256']
  folder=Path('/workspace/zyx/buildDir_final') if engine=='current' else Path('/workspace/zyx-control-d09fc467/build')
  assert digest(folder/'zyx-compare-bench')==manifest['consumer_binary_sha256']
  assert len(manifest['consumer_counts'])==6 and manifest['source_bytes_unchanged']
  inputs[str(database)]=manifest;hashes.append(manifest['database_sha256'])
  for name in ['zyx-compare-bench','zyx-workload-contract-worker']:binaries[str(folder/name)]=digest(folder/name)
 assert hashes[0]==hashes[1],'consumers must use identical physical prepared input'
plan.update(status='registered_before_independent_measurements_all_inputs_validated',prepared_inputs=inputs,binaries=binaries,current_frozen_worker='/workspace/zyx/buildDir_final/zyx-workload-contract-worker',frozen_harness=str(ROOT/'frozen-workload-preflight.py'),hardware={'platform':platform.platform(),'machine':platform.machine(),'allowed_cpus':sorted(os.sched_getaffinity(0))},harness_sha256={p.name:digest(p) for p in (ROOT/'harness').glob('*.py')},independent_driver_sha256=digest(ROOT/'run-independent-read-write.py'),preflight_runner_sha256=digest(ROOT/'frozen-workload-preflight.py'),old_import_failure_retained=True,preparation_is_not_import_performance_evidence=True)
(window/'logs').mkdir(exist_ok=True)
(window/'registration.json').write_text(json.dumps(plan,indent=2)+'\n');print('Registered frozen native binaries and four validated shared inputs; unchanged performance/resource gates')

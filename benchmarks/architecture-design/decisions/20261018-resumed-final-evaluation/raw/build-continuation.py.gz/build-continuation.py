from pathlib import Path
import difflib,hashlib,json,shlex,subprocess
base=Path('/workspace/zyx-resume-evaluation-20261018');repo=Path('/workspace/zyx');build=repo/'buildDir_final'
legacy=(repo/'benchmarks/architecture-design/decisions/20261016-final-performance-window/bounded-loader-v2/build_fixture_producer.py').read_text()
namespace={};exec(legacy.split("source=Path('/tmp/")[0],namespace)
source=namespace['s'];assert 'else if (!std::getenv("ZYX_DIAGNOSTIC_RESUME"))' in source
needle='if (!options.preparedDbPath.empty()) {\n            auto existing = db.execute("SHOW INDEXES");'
assert source.count(needle)==1
source=source.replace(needle,'if (!options.preparedDbPath.empty() || std::getenv("ZYX_DIAGNOSTIC_RESUME")) {\n            auto existing = db.execute("SHOW INDEXES");')
(base/'continuation-producer.cpp').write_text(source)
(base/'continuation-producer.patch').write_text(''.join(difflib.unified_diff((repo/'apps/compare_benchmark/main.cpp').read_text().splitlines(True),source.splitlines(True),fromfile='apps/compare_benchmark/main.cpp',tofile='preparation-only/continuation-producer.cpp')))
worker=(repo/'benchmarks/graphdb-comparison/workload-contract/native-worker.cpp').read_text().replace('std::filesystem::exists(argv[1])','!std::filesystem::exists(argv[1])',1).replace('worker requires a fresh private database path','worker requires an existing private database path',1).replace('options.open_mode = OpenMode::OPEN_CREATE_NEW_FILE','options.open_mode = OpenMode::OPEN_EXISTING_FILE',1).replace('RelocatableStorageBackend::initializeNew(options)','std::make_shared<RelocatableStorageBackend>(options)',1)
(base/'existing-worker.cpp').write_text(worker)
records=[]
for target,source,name in [('zyx_compare_bench',base/'continuation-producer.cpp','continuation-producer'),('zyx_workload_contract_worker',base/'existing-worker.cpp','existing-worker')]:
 commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],text=True).splitlines()
 original='main.cpp' if target=='zyx_compare_bench' else 'native-worker.cpp'
 compile=shlex.split(next(v for v in commands if ' -c ' in v and original in v));obj=base/(name+'.o');binary=base/name
 for flag,value in [('-o',str(obj)),('-MF',str(obj)+'.d'),('-MT',str(obj))]:
  if flag in compile:compile[compile.index(flag)+1]=value
 compile[compile.index('-c')+1]=str(source)
 link=shlex.split(commands[-1].removeprefix(': && ').removesuffix(' && :'))
 original_obj=next(v for v in link if v.endswith(original+'.o'));link[link.index(original_obj)]=str(obj);link[link.index('-o')+1]=str(binary)
 if '-Xlinker' in link:
  i=link.index('-Xlinker');del link[i:i+2]
 subprocess.run(compile,cwd=build,check=True);subprocess.run(link,cwd=build,check=True)
 records.append({'target':target,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'compile':compile,'link':link})
 print('Built',binary,flush=True)
(base/'continuation-build.json').write_text(json.dumps({'production_core_sha256':hashlib.sha256((build/'libzyx_core.a').read_bytes()).hexdigest(),'production_core_modified':False,'registered_protocol':'20261016-final-performance-window/bounded-loader-v2/build_fixture_producer.py','only_additional_adaptation':'Reuse existing User property indexes when continuing an already loaded input.','preparation_only_no_performance_samples':True,'builds':records},indent=2)+'\n')

from pathlib import Path
import hashlib,json,shlex,subprocess
base=Path('/workspace/zyx-resume-evaluation-20261018')
source=Path('/workspace/zyx/benchmarks/graphdb-comparison/workload-contract/native-worker.cpp').read_text()
source=source.replace('std::filesystem::exists(argv[1])','!std::filesystem::exists(argv[1])',1).replace('worker requires a fresh private database path','reader requires an existing database path',1).replace('options.open_mode = OpenMode::OPEN_CREATE_NEW_FILE','options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE',1).replace('RelocatableStorageBackend::initializeNew(options)','std::make_shared<RelocatableStorageBackend>(options)',1).replace('std::make_unique<QueryEngine>(backend, backend, limits)','std::make_unique<QueryEngine>(backend, limits)',1)
path=base/'readonly-worker.cpp';path.write_text(source)
for engine,build in [('current',Path('/workspace/zyx/buildDir_final')),('control',Path('/workspace/zyx-control-d09fc467/build'))]:
    commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','zyx_workload_contract_worker'],text=True).splitlines()
    compile=shlex.split(next(v for v in commands if ' -c ' in v and 'native-worker.cpp' in v))
    obj=base/f'{engine}-readonly-worker.o';binary=base/f'{engine}-readonly-worker'
    for flag,value in [('-o',str(obj)),('-MF',str(obj)+'.d'),('-MT',str(obj))]:
        if flag in compile:compile[compile.index(flag)+1]=value
    compile[compile.index('-c')+1]=str(path)
    link=shlex.split(commands[-1].removeprefix(': && ').removesuffix(' && :'))
    original_obj=next(v for v in link if v.endswith('native-worker.cpp.o'));link[link.index(original_obj)]=str(obj)
    link[link.index('-o')+1]=str(binary)
    if '-Xlinker' in link:
        index=link.index('-Xlinker');del link[index:index+2]
    subprocess.run(compile,cwd=build,check=True)
    subprocess.run(link,cwd=build,check=True)
    (base/f'{engine}-readonly-provenance.json').write_text(json.dumps({'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'core_sha256':hashlib.sha256((build/'libzyx_core.a').read_bytes()).hexdigest(),'compile':compile,'link':link,'physical_readonly':True},indent=2)+'\n')
    print('Built',binary,flush=True)

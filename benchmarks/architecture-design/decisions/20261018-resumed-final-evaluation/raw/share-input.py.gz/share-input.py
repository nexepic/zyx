from pathlib import Path
import argparse,csv,hashlib,json,shutil,sys,os,resource
ROOT=Path('/workspace/zyx-resume-evaluation-20261018')
p=argparse.ArgumentParser();p.add_argument('--scale',choices=['medium','holdout'],required=True);a=p.parse_args()
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
folder=ROOT/'window/prepared-inputs'/a.scale;source=folder/'current.zyx';target=folder/'control.zyx'
assert not target.exists(),'do not overwrite a previous control input'
original=json.loads(Path(str(source)+'.json').read_text());assert original['status']=='frozen_prepared_read_input'
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
assert digest(source)==original['database_sha256']
shutil.copyfile(source,target);assert digest(target)==original['database_sha256']
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.workload_preflight import NativeWorker
checks=[];reader=NativeWorker(ROOT/'control-readonly-worker',target)
try:
 for item in original['consumer_counts']:
  table=item['table'];edge=table in ['FOLLOWS','AUTHORED','HAS_TAG']
  query=f'MATCH ()-[r:{table}]->() RETURN count(*) AS count' if edge else f'MATCH (n:{table}) RETURN count(*) AS count'
  reader.call('QUERY',query,expected=[[item['count']]])
  checks.append(item)
finally:reader.close()
assert digest(target)==original['database_sha256'];assert digest(source)==original['database_sha256']
manifest=dict(original);manifest.update(engine='control',consumer_binary_sha256=digest(Path('/workspace/zyx-control-d09fc467/build/zyx-compare-bench')),producer_binary_sha256=original['consumer_binary_sha256'],shared_input_source=str(source),shared_read_policy='identical current-producer input, old import failure retained separately, no import timing or writer performance inferred',consumer_counts=checks,source_bytes_unchanged=True)
Path(str(target)+'.json').write_text(json.dumps(manifest,indent=2)+'\n');target.chmod(0o444)
print(json.dumps({'scale':a.scale,'database_sha256':manifest['database_sha256'],'old_consumer_six_exact_counts':checks,'source_bytes_unchanged':True}),flush=True)

from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/workspace/zyx-resume-evaluation-20261018');cpu=sorted(os.sched_getaffinity(0))[2];outcomes=[]
for number,engines in enumerate([['control','current','kuzu'],['current','kuzu','control'],['kuzu','control','current']],1):
 for engine in engines:
  output=root/'correctness'/f'round-{number}'/engine/'point';report=output/'report.json'
  if report.exists():
   value=json.loads(report.read_text());assert value['full_results_checked'];outcomes.append({'engine':engine,'round':number,'status':'existing_exact_correctness_pass','operations':value['operations']});continue
  log=root/f'correctness-{engine}-point-{number}.log';command=[sys.executable,str(root/'run-correctness-slot.py'),'--engine',engine,'--round',str(number),'--family','point','--cpu',str(cpu)]
  with log.open('w') as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
  if result.returncode:raise RuntimeError(f'correctness failed: {engine}/{number}; no unchanged-source retry')
  value=json.loads(report.read_text());assert value['full_results_checked'];entry={'engine':engine,'round':number,'status':'full_correctness_pass','operations':value['operations']};outcomes.append(entry);print(json.dumps(entry),flush=True)
(root/'point-full-correctness-summary.json').write_text(json.dumps({'cases':outcomes,'all_nine_cases_passed':True,'formal_performance_samples':0,'source_binaries_frozen_before_cases':True},indent=2)+'\n')

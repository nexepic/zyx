# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 477.334 | 474.384 | 481.11769999999996 | 479.716 | 489.513 | 489.513 | 489.513 | 2.078493474673661 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 501.113 | 463.453 | 486.2553 | 488.133 | 501.113 | 501.113 | 501.113 | 2.05653285424344 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 761.529 | 743.081 | 774.1022 | 767.968 | 800.839 | 800.839 | 800.839 | 1.291819090554193 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 461.191 | 459.226 | 473.6635 | 462.195 | 499.253 | 499.253 | 499.253 | 2.1112034176160925 | ok | api |
| zyx | label_scan_filter | medium | 10 | 411.968 | 411.968 | 442.7058 | 446.383 | 454.644 | 454.644 | 454.644 | 2.258836455271198 | ok | api |
| zyx | one_hop_expand | medium | 10 | 2.74709 | 2.43743 | 2.610284 | 2.565 | 2.79687 | 2.79687 | 2.79687 | 383.10007646677525 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 966.589 | 966.589 | 1017.26 | 1003.7 | 1085.77 | 1085.77 | 1085.77 | 0.9830328529579458 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 335.026 | 335.026 | 343.5867 | 344.346 | 350.652 | 350.652 | 350.652 | 2.9104735427768302 | ok | api |
| zyx | topk_property_sort | medium | 10 | 766.706 | 507.886 | 540.697 | 513.011 | 766.706 | 766.706 | 766.706 | 1.849464672450559 | ok | api |
| zyx | two_hop_expand | medium | 10 | 3.27335 | 2.94138 | 3.108009 | 3.03845 | 3.44703 | 3.44703 | 3.44703 | 321.74939004359385 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.4593659832607955 | 0.4445440135896206 | 0.4641147970687598 | 0.45343698002398014 | 0.5062650016043335 | 0.5062650016043335 | 0.5062650016043335 | 2154.639339912809 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.5783099913969636 | 0.5277159798424691 | 0.5668846948537976 | 0.5458729865495116 | 0.6884719769004732 | 0.6884719769004732 | 0.6884719769004732 | 1764.0271629804806 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.6661399966105819 | 0.6225850083865225 | 0.6649668008321896 | 0.6661399966105819 | 0.7156420033425093 | 0.7156420033425093 | 0.7156420033425093 | 1503.8344752678247 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.3995669831056148 | 0.393198017263785 | 0.4995785973733291 | 0.4223309806548059 | 0.7592669862788171 | 0.7592669862788171 | 0.7592669862788171 | 2001.6870323464077 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.22883599740453064 | 0.21241200738586485 | 0.2306188951479271 | 0.2180500014219433 | 0.2742829965427518 | 0.2742829965427518 | 0.2742829965427518 | 4336.158142456474 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

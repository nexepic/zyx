# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 503.817 | 487.333 | 506.73249999999996 | 503.764 | 529.609 | 529.609 | 529.609 | 1.973427794743775 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 463.267 | 463.267 | 484.20140000000004 | 475.915 | 516.13 | 516.13 | 516.13 | 2.0652563168962335 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 784.559 | 773.814 | 783.0337999999999 | 781.502 | 792.562 | 792.562 | 792.562 | 1.2770840798954017 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 479.117 | 463.013 | 477.0991 | 479.117 | 484.52 | 484.52 | 484.52 | 2.096000600294572 | ok | api |
| zyx | label_scan_filter | medium | 10 | 422.474 | 406.315 | 423.88620000000003 | 418.397 | 467.314 | 467.314 | 467.314 | 2.3591237459487946 | ok | api |
| zyx | one_hop_expand | medium | 10 | 2.42212 | 2.39001 | 2.4403379999999997 | 2.40895 | 2.67813 | 2.67813 | 2.67813 | 409.77930106403295 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 967.688 | 948.217 | 968.4592 | 966.955 | 1015.37 | 1015.37 | 1015.37 | 1.0325680214509811 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 330.23 | 330.23 | 354.6997 | 351.724 | 397.652 | 397.652 | 397.652 | 2.819286286399453 | ok | api |
| zyx | topk_property_sort | medium | 10 | 539.579 | 509.705 | 526.5552 | 520.802 | 565.582 | 565.582 | 565.582 | 1.8991361209612971 | ok | api |
| zyx | two_hop_expand | medium | 10 | 2.86692 | 2.86692 | 3.027514 | 2.99008 | 3.30359 | 3.30359 | 3.30359 | 330.3040052003063 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

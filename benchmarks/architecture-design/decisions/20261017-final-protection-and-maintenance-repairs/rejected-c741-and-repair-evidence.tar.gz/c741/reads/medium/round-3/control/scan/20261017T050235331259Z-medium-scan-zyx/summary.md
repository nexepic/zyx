# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 2841.79 | 2785.38 | 2890.718 | 2863.76 | 3008.89 | 3008.89 | 3008.89 | 0.3459348161944541 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 2890.39 | 2783.74 | 2883.279 | 2871.31 | 3003.86 | 3003.86 | 3003.86 | 0.34682734483898364 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5438.83 | 5170.81 | 5418.018 | 5384.85 | 5664.93 | 5664.93 | 5664.93 | 0.1845693388246403 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 2831.57 | 2733.94 | 2843.083 | 2831.57 | 2952.97 | 2952.97 | 2952.97 | 0.35173084992594306 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2710.68 | 2710.68 | 2796.439 | 2757.28 | 2875.86 | 2875.86 | 2875.86 | 0.35759764471887284 | ok | api |
| zyx | one_hop_expand | medium | 10 | 15.5491 | 15.5491 | 16.03603 | 15.8609 | 16.5817 | 16.5817 | 16.5817 | 62.35957403422169 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6335.54 | 6225.04 | 6350.921 | 6332.1 | 6559.93 | 6559.93 | 6559.93 | 0.1574574774272897 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 580.189 | 549.248 | 572.5388 | 572.783 | 587.744 | 587.744 | 587.744 | 1.7466065181957975 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3568.37 | 3478.72 | 3620.6459999999997 | 3605.52 | 3798.63 | 3798.63 | 3798.63 | 0.276193806298655 | ok | api |
| zyx | two_hop_expand | medium | 10 | 20.759 | 20.2944 | 20.64913 | 20.4291 | 21.1682 | 21.1682 | 21.1682 | 48.428190437078946 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

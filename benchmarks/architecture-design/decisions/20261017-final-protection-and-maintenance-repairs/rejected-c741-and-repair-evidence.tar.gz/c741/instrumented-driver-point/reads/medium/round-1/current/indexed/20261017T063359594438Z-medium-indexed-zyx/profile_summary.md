# Benchmark Profile Breakdown

## Phase Summary

| database | workload | scale | profile | phase | samples | total_calls | avg_calls | total_value | total_value_calls | avg_value | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | indexed | warm.operation | 1 | 1 | 1 | 0 | 0 | 0 | 12.8542 | 12.8542 | 12.8542 | 12.8542 | 12.8542 | 12.8542 | 12.8542 | api |
| zyx | point_lookup_indexed | medium | indexed | api.execute_plan | 1 | 1 | 1 | 0 | 0 | 0 | 12.8154 | 12.8154 | 12.8154 | 12.8154 | 12.8154 | 12.8154 | 12.8154 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.radix | 1 | 1111 | 1111 | 0 | 0 | 0 | 7.49033 | 7.49033 | 7.49033 | 7.49033 | 7.49033 | 7.49033 | 7.49033 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.checksum.crc | 1 | 3774 | 3774 | 0 | 0 | 0 | 2.47986 | 2.47986 | 2.47986 | 2.47986 | 2.47986 | 2.47986 | 2.47986 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_acquisition | 1 | 1772 | 1772 | 0 | 0 | 0 | 1.41938 | 1.41938 | 1.41938 | 1.41938 | 1.41938 | 1.41938 | 1.41938 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.route_leaf | 1 | 302 | 302 | 0 | 0 | 0 | 1.0387 | 1.0387 | 1.0387 | 1.0387 | 1.0387 | 1.0387 | 1.0387 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.bootstrap | 1 | 291 | 291 | 0 | 0 | 0 | 0.722072 | 0.722072 | 0.722072 | 0.722072 | 0.722072 | 0.722072 | 0.722072 | api |
| zyx | point_lookup_indexed | medium | indexed | storage_io.file_size | 1 | 1802 | 1802 | 0 | 0 | 0 | 0.502932 | 0.502932 | 0.502932 | 0.502932 | 0.502932 | 0.502932 | 0.502932 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.load_locked | 1 | 1789 | 1789 | 0 | 0 | 0 | 0.194028 | 0.194028 | 0.194028 | 0.194028 | 0.194028 | 0.194028 | 0.194028 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.location | 1 | 38 | 38 | 0 | 0 | 0 | 0.175186 | 0.175186 | 0.175186 | 0.175186 | 0.175186 | 0.175186 | 0.175186 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.catalog | 1 | 15 | 15 | 0 | 0 | 0 | 0.174113 | 0.174113 | 0.174113 | 0.174113 | 0.174113 | 0.174113 | 0.174113 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.allocator | 1 | 15 | 15 | 0 | 0 | 0 | 0.100962 | 0.100962 | 0.100962 | 0.100962 | 0.100962 | 0.100962 | 0.100962 | api |
| zyx | point_lookup_indexed | medium | indexed | api.build_plan | 1 | 1 | 1 | 0 | 0 | 0 | 0.020511 | 0.020511 | 0.020511 | 0.020511 | 0.020511 | 0.020511 | 0.020511 | api |
| zyx | point_lookup_indexed | medium | indexed | api.detect_txn_statement | 1 | 1 | 1 | 0 | 0 | 0 | 0.000601 | 0.000601 | 0.000601 | 0.000601 | 0.000601 | 0.000601 | 0.000601 | api |
| zyx | point_lookup_indexed | medium | indexed | api.result_wrap | 1 | 1 | 1 | 0 | 0 | 0 | 0.000521 | 0.000521 | 0.000521 | 0.000521 | 0.000521 | 0.000521 | 0.000521 | api |
| zyx | point_lookup_indexed | medium | indexed | api.ensure_open | 1 | 1 | 1 | 0 | 0 | 0 | 0.00047 | 0.00047 | 0.00047 | 0.00047 | 0.00047 | 0.00047 | 0.00047 | api |
| zyx | point_lookup_indexed | medium | indexed | api.get_query_engine | 1 | 1 | 1 | 0 | 0 | 0 | 8e-05 | 8e-05 | 8e-05 | 8e-05 | 8e-05 | 8e-05 | 8e-05 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.pin_lock_wait | 1 | 2 | 2 | 0 | 0 | 0 | 6e-05 | 6e-05 | 6e-05 | 6e-05 | 6e-05 | 6e-05 | 6e-05 | api |
| zyx | point_lookup_indexed | medium | indexed | api.to_query_context | 1 | 1 | 1 | 0 | 0 | 0 | 5e-05 | 5e-05 | 5e-05 | 5e-05 | 5e-05 | 5e-05 | 5e-05 | api |
| zyx | point_lookup_indexed | medium | indexed | logical_plan.bound_expression.slot_reads | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | logical_plan.index_candidate.materialized_bytes | 1 | 0 | 0 | 194 | 1 | 194 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | logical_plan.two_hop.aggregate_child_type | 1 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_btree.read.packed_page_decodes | 1 | 0 | 0 | 19 | 19 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_btree.read.range_cursor_root_descent | 1 | 0 | 0 | 5 | 5 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.decoded_metadata_cache_hits | 1 | 0 | 0 | 15 | 15 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.directory_range_calls | 1 | 0 | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.directory_range_cursor_metadata_pages | 1 | 0 | 0 | 12 | 12 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.directory_range_cursor_root_descents | 1 | 0 | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.distinct_page_pins | 1 | 0 | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.distinct_page_pins_incomplete | 1 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.entity_directory_batch_ids | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.entity_directory_batch_requests | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.exact_candidate_source_bytes | 1 | 0 | 0 | 25 | 1 | 25 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_batches | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_constraint_definition_read | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_definition_read | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_emitted_rows | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_label_token_resolution | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_property_token_resolution | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_root_descent | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_verified_rows | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.label_token_resolution | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.materialized_bytes | 1 | 0 | 0 | 21 | 1 | 21 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.allocator | 1 | 0 | 0 | 15 | 15 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.bootstrap | 1 | 0 | 0 | 291 | 291 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.catalog | 1 | 0 | 0 | 15 | 15 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.location | 1 | 0 | 0 | 38 | 38 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.radix | 1 | 0 | 0 | 1111 | 1111 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.route_leaf | 1 | 0 | 0 | 302 | 302 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_pages_read | 1 | 0 | 0 | 1772 | 1772 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_calls | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_directory_range_calls | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_entity_page_pins | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_entries | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_unique_io_ids | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_combined_batch_owners | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_combined_page_acquisition | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_directory_metadata_pages | 1 | 0 | 0 | 9 | 1 | 9 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_directory_refill | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_selected_batch_owners | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_selected_column_batch_owners | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_selected_column_decode | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_selected_decode | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_token_resolution | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.radix_requested_children | 1 | 0 | 0 | 1968 | 223 | 8.82511 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.radix_resolved_children | 1 | 0 | 0 | 480 | 223 | 2.15247 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.records_decoded | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.root_descents | 1 | 0 | 0 | 7 | 7 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.selected_values_decoded | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.shared_page_known_location_copy | 1 | 0 | 0 | 13 | 13 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.shared_page_known_location_pin | 1 | 0 | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.shared_page_route_resolution | 1 | 0 | 0 | 15 | 15 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.hits | 1 | 0 | 0 | 1787 | 1787 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.misses | 1 | 0 | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.physical_read_bytes | 1 | 0 | 0 | 24576 | 6 | 4096 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.checksum.bytes | 1 | 0 | 0 | 7633728 | 3774 | 2022.72 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.checksum.incremental_bytes | 1 | 0 | 0 | 4032 | 3 | 1344 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage_io.file_size_calls | 1 | 0 | 0 | 1802 | 1802 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |

## Reading Guide

- Each row aggregates one emitted profile phase across measured iterations.
- Rows are ordered by database, scale, profile, workload, and descending `p50_ms` so the slowest phases appear first within each workload.
- `first_ms` helps diagnose cold-ish first-iteration costs; `p50_ms` and `p95_ms` highlight steady-state and tail behavior.
- `total_calls` and `avg_calls` distinguish expensive phases from frequently repeated small operations.
- ZYX currently emits internal profile phases; other databases may only have top-level sample latency unless their adapters add phase events.

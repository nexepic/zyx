# Benchmark Profile Breakdown

## Phase Summary

| database | workload | scale | profile | phase | samples | total_calls | avg_calls | total_value | total_value_calls | avg_value | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | indexed | warm.operation | 1 | 1 | 1 | 0 | 0 | 0 | 14.0333 | 14.0333 | 14.0333 | 14.0333 | 14.0333 | 14.0333 | 14.0333 | api |
| zyx | point_lookup_indexed | medium | indexed | api.execute_plan | 1 | 1 | 1 | 0 | 0 | 0 | 14.0102 | 14.0102 | 14.0102 | 14.0102 | 14.0102 | 14.0102 | 14.0102 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.route_leaf | 1 | 2109 | 2109 | 0 | 0 | 0 | 6.27817 | 6.27817 | 6.27817 | 6.27817 | 6.27817 | 6.27817 | 6.27817 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.checksum.crc | 1 | 5275 | 5275 | 0 | 0 | 0 | 3.69716 | 3.69716 | 3.69716 | 3.69716 | 3.69716 | 3.69716 | 3.69716 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_acquisition | 1 | 2508 | 2508 | 0 | 0 | 0 | 3.30102 | 3.30102 | 3.30102 | 3.30102 | 3.30102 | 3.30102 | 3.30102 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.radix | 1 | 315 | 315 | 0 | 0 | 0 | 1.1639 | 1.1639 | 1.1639 | 1.1639 | 1.1639 | 1.1639 | 1.1639 | api |
| zyx | point_lookup_indexed | medium | indexed | storage_io.file_size | 1 | 5072 | 5072 | 0 | 0 | 0 | 1.1451 | 1.1451 | 1.1451 | 1.1451 | 1.1451 | 1.1451 | 1.1451 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.load_locked | 1 | 2538 | 2538 | 0 | 0 | 0 | 0.406141 | 0.406141 | 0.406141 | 0.406141 | 0.406141 | 0.406141 | 0.406141 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.catalog | 1 | 15 | 15 | 0 | 0 | 0 | 0.124063 | 0.124063 | 0.124063 | 0.124063 | 0.124063 | 0.124063 | 0.124063 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.location | 1 | 29 | 29 | 0 | 0 | 0 | 0.102684 | 0.102684 | 0.102684 | 0.102684 | 0.102684 | 0.102684 | 0.102684 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.bootstrap | 1 | 25 | 25 | 0 | 0 | 0 | 0.083492 | 0.083492 | 0.083492 | 0.083492 | 0.083492 | 0.083492 | 0.083492 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.pin_lock_wait | 1 | 2538 | 2538 | 0 | 0 | 0 | 0.063114 | 0.063114 | 0.063114 | 0.063114 | 0.063114 | 0.063114 | 0.063114 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decode.allocator | 1 | 15 | 15 | 0 | 0 | 0 | 0.058425 | 0.058425 | 0.058425 | 0.058425 | 0.058425 | 0.058425 | 0.058425 | api |
| zyx | point_lookup_indexed | medium | indexed | api.build_plan | 1 | 1 | 1 | 0 | 0 | 0 | 0.012378 | 0.012378 | 0.012378 | 0.012378 | 0.012378 | 0.012378 | 0.012378 | api |
| zyx | point_lookup_indexed | medium | indexed | api.result_wrap | 1 | 1 | 1 | 0 | 0 | 0 | 0.000851 | 0.000851 | 0.000851 | 0.000851 | 0.000851 | 0.000851 | 0.000851 | api |
| zyx | point_lookup_indexed | medium | indexed | api.ensure_open | 1 | 1 | 1 | 0 | 0 | 0 | 0.000521 | 0.000521 | 0.000521 | 0.000521 | 0.000521 | 0.000521 | 0.000521 | api |
| zyx | point_lookup_indexed | medium | indexed | api.detect_txn_statement | 1 | 1 | 1 | 0 | 0 | 0 | 0.00049 | 0.00049 | 0.00049 | 0.00049 | 0.00049 | 0.00049 | 0.00049 | api |
| zyx | point_lookup_indexed | medium | indexed | api.to_query_context | 1 | 1 | 1 | 0 | 0 | 0 | 0.000291 | 0.000291 | 0.000291 | 0.000291 | 0.000291 | 0.000291 | 0.000291 | api |
| zyx | point_lookup_indexed | medium | indexed | api.get_query_engine | 1 | 1 | 1 | 0 | 0 | 0 | 7e-05 | 7e-05 | 7e-05 | 7e-05 | 7e-05 | 7e-05 | 7e-05 | api |
| zyx | point_lookup_indexed | medium | indexed | logical_plan.bound_expression.slot_reads | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | logical_plan.index_candidate.materialized_bytes | 1 | 0 | 0 | 194 | 1 | 194 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | logical_plan.two_hop.aggregate_child_type | 1 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_btree.read.packed_page_decodes | 1 | 0 | 0 | 19 | 19 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_btree.read.range_cursor_root_descent | 1 | 0 | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.decoded_metadata_cache_evictions | 1 | 0 | 0 | 2315 | 2315 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.decoded_metadata_cache_hits | 1 | 0 | 0 | 1499 | 1499 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.directory_range_calls | 1 | 0 | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.directory_range_cursor_metadata_pages | 1 | 0 | 0 | 12 | 12 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.directory_range_cursor_root_descents | 1 | 0 | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.distinct_page_pins | 1 | 0 | 0 | 211 | 1 | 211 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.distinct_page_pins_incomplete | 1 | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.entity_directory_batch_ids | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.entity_directory_batch_requests | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.exact_candidate_source_bytes | 1 | 0 | 0 | 25 | 1 | 25 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_batches | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_constraint_definition_read | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_definition_read | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_emitted_rows | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_label_token_resolution | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_property_token_resolution | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_root_descent | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.index_candidate_verified_rows | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.label_token_resolution | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.materialized_bytes | 1 | 0 | 0 | 21 | 1 | 21 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.allocator | 1 | 0 | 0 | 15 | 15 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.bootstrap | 1 | 0 | 0 | 25 | 25 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.catalog | 1 | 0 | 0 | 15 | 15 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.location | 1 | 0 | 0 | 29 | 29 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.radix | 1 | 0 | 0 | 315 | 315 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_decodes.route_leaf | 1 | 0 | 0 | 2109 | 2109 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.metadata_pages_read | 1 | 0 | 0 | 2508 | 2508 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_calls | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_directory_range_calls | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_entity_page_pins | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_entries | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.node_sorted_batch_unique_io_ids | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_combined_batch_owners | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_combined_page_acquisition | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_directory_metadata_pages | 1 | 0 | 0 | 9 | 1 | 9 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_directory_refill | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_selected_batch_owners | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_selected_column_batch_owners | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_selected_column_decode | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_selected_decode | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.property_token_resolution | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.radix_requested_children | 1 | 0 | 0 | 1953 | 208 | 9.38942 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.radix_resolved_children | 1 | 0 | 0 | 465 | 208 | 2.23558 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.records_decoded | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.root_descents | 1 | 0 | 0 | 7 | 7 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.selected_values_decoded | 1 | 0 | 0 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.shared_page_known_location_copy | 1 | 0 | 0 | 13 | 13 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.shared_page_known_location_pin | 1 | 0 | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | native_graph.read.shared_page_route_resolution | 1 | 0 | 0 | 15 | 15 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.hits | 1 | 0 | 0 | 2532 | 2532 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.misses | 1 | 0 | 0 | 6 | 6 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.buffer_pool.physical_read_bytes | 1 | 0 | 0 | 24576 | 6 | 4096 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.checksum.bytes | 1 | 0 | 0 | 10733568 | 5275 | 2034.8 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage.checksum.incremental_bytes | 1 | 0 | 0 | 4032 | 3 | 1344 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |
| zyx | point_lookup_indexed | medium | indexed | storage_io.file_size_calls | 1 | 0 | 0 | 5072 | 5072 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | api |

## Reading Guide

- Each row aggregates one emitted profile phase across measured iterations.
- Rows are ordered by database, scale, profile, workload, and descending `p50_ms` so the slowest phases appear first within each workload.
- `first_ms` helps diagnose cold-ish first-iteration costs; `p50_ms` and `p95_ms` highlight steady-state and tail behavior.
- `total_calls` and `avg_calls` distinguish expensive phases from frequently repeated small operations.
- ZYX currently emits internal profile phases; other databases may only have top-level sample latency unless their adapters add phase events.

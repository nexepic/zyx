# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | point_lookup_indexed | medium | 10 | 0.25922100007846893 | 0.2173089999359945 | 0.25889239999514757 | 0.24597200001608144 | 0.38496499996654165 | 0.38496499996654165 | 0.38496499996654165 | 3862.6085586859367 | ok | cypher |
| zyx | point_lookup_indexed | medium | 10 | 1.31918 | 1.29526 | 1.309726 | 1.30735 | 1.33064 | 1.33064 | 1.33064 | 763.5184763836099 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 186.127 | 171.779 | 182.66320000000002 | 182.515 | 192.712 | 192.712 | 192.712 | 5.474556451436304 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1043.34 | 1022.07 | 1056.096 | 1043.34 | 1112.11 | 1112.11 | 1112.11 | 0.9468836166409114 | ok | api |
| kuzu | property_equality_indexed | medium | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | unsupported | cypher |
| kuzu | property_range_indexed | medium | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | unsupported | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.581466000085129 | 0.5420479999429517 | 0.6019161000040185 | 0.5766489998677571 | 0.7160239999848272 | 0.7160239999848272 | 0.7160239999848272 | 1661.3611099509114 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.7255179998537642 | 0.666851999994833 | 0.7182504000184053 | 0.7117680002011184 | 0.8000479999736854 | 0.8000479999736854 | 0.8000479999736854 | 1392.2721100807946 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.8495310000853351 | 0.768451000112691 | 0.8531683000001067 | 0.8473169998524099 | 0.9399690000009286 | 0.9399690000009286 | 0.9399690000009286 | 1172.101682633866 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.5438709999907587 | 0.5048630000601406 | 0.5686750999757351 | 0.5438709999907587 | 0.6879630000184989 | 0.6879630000184989 | 0.6879630000184989 | 1758.4733357283785 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.29927099990345596 | 0.25324299986095866 | 0.3087784999934229 | 0.2806429999964166 | 0.4907630000161589 | 0.4907630000161589 | 0.4907630000161589 | 3238.567452142233 | ok | cypher |
| zyx | batch_node_fetch_100 | medium | 10 | 3.1711 | 3.13072 | 3.271324 | 3.24922 | 3.51764 | 3.51764 | 3.51764 | 305.6866271882577 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 3.6155 | 2.35977 | 2.652917 | 2.54018 | 3.6155 | 3.6155 | 3.6155 | 376.943568155355 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 3.4127 | 3.35756 | 3.612785 | 3.47133 | 4.76764 | 4.76764 | 4.76764 | 276.79477190034834 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 2.58317 | 2.53594 | 2.592709 | 2.57724 | 2.69392 | 2.69392 | 2.69392 | 385.6969679204261 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 3.2385 | 2.84776 | 3.038347 | 2.98532 | 3.26815 | 3.26815 | 3.26815 | 329.12633086345966 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

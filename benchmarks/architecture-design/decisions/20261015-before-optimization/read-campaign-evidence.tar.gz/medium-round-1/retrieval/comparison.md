# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | kuzu | 0.576649 | 3.24922 | 3.1711 | 2 | 5.63466 | kuzu | 5.63466 | 3.51764 | 1.08261 | 0.975957 |
| one_hop_fetch_neighbor_ids | medium | kuzu | 0.711768 | 2.54018 | 3.6155 | 2 | 3.56883 | kuzu | 3.56883 | 3.6155 | 1.42332 | 1.42332 |
| one_hop_fetch_neighbor_records | medium | kuzu | 0.847317 | 3.47133 | 3.4127 | 2 | 4.09685 | kuzu | 4.09685 | 4.76764 | 1.37343 | 0.98311 |
| point_edge_fetch_by_endpoints | medium | kuzu | 0.543871 | 2.57724 | 2.58317 | 2 | 4.7387 | kuzu | 4.7387 | 2.69392 | 1.04527 | 1.0023 |
| point_node_fetch_by_id | medium | kuzu | 0.280643 | 2.98532 | 3.2385 | 2 | 10.6374 | kuzu | 10.6374 | 3.26815 | 1.09474 | 1.08481 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

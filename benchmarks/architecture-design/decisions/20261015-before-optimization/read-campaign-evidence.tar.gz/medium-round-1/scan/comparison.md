# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | kuzu | 3.56063 | 457.797 | 493.647 | 2 | 128.572 | kuzu | 128.572 | 493.647 | 1.07831 | 1.07831 |
| aggregation_group_by | medium | kuzu | 3.09722 | 457.295 | 513.399 | 2 | 147.647 | kuzu | 147.647 | 539.863 | 1.18056 | 1.12269 |
| all_nodes_property_filter | medium | kuzu | 0.952888 | 715.522 | 732.714 | 2 | 750.898 | kuzu | 750.898 | 771.793 | 1.07864 | 1.02403 |
| label_multi_property_filter | medium | kuzu | 2.35065 | 413.291 | 428.004 | 2 | 175.82 | kuzu | 175.82 | 456.09 | 1.10356 | 1.0356 |
| label_scan_filter | medium | kuzu | 2.3937 | 379.091 | 376.947 | 2 | 158.37 | kuzu | 158.37 | 400.624 | 1.0568 | 0.994344 |
| one_hop_expand | medium | kuzu | 0.468227 | 1.82101 | 1.81202 | 2 | 3.88916 | kuzu | 3.88916 | 2.10378 | 1.15528 | 0.995063 |
| relationship_property_filter | medium | kuzu | 10.5617 | 850.305 | 836.18 | 2 | 80.5084 | kuzu | 80.5084 | 942.043 | 1.10789 | 0.983388 |
| relationship_type_scan | medium | kuzu | 6.38592 | 251.673 | 255.913 | 2 | 39.4106 | kuzu | 39.4106 | 274.62 | 1.09118 | 1.01685 |
| topk_property_sort | medium | kuzu | 3.89764 | 1210.6 | 1233.14 | 2 | 310.598 | kuzu | 310.598 | 1236.02 | 1.021 | 1.01862 |
| two_hop_expand | medium | kuzu | 1.01765 | 2.17411 | 2.17411 | 2 | 2.13639 | kuzu | 2.13639 | 5.82769 | 2.68049 | 1 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

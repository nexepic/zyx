# Operation Type Summary

Rows group benchmark workloads by database operation family. Unit: ms; lower p50-derived values are better.

| operation_type | database | scale | workload_count | workloads | ok_workloads | unsupported_workloads | failed_workloads | samples | geomean_p50_ms | avg_p50_ms | min_p50_ms | max_p50_ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| adjacency expand | kuzu | medium | 2 | one_hop_expand;two_hop_expand | 2 | 0 | 0 | 20 | 0.756032 | 0.817067 | 0.507206 | 1.12693 |
| adjacency expand | zyx | medium | 2 | one_hop_expand;two_hop_expand | 2 | 0 | 0 | 20 | 1.98279 | 1.98554 | 1.88104 | 2.09004 |
| property filter | kuzu | medium | 4 | all_nodes_property_filter;label_multi_property_filter;label_scan_filter;relationship_property_filter | 4 | 0 | 0 | 40 | 2.59146 | 3.95424 | 0.91771 | 10.5867 |
| property filter | zyx | medium | 4 | all_nodes_property_filter;label_multi_property_filter;label_scan_filter;relationship_property_filter | 4 | 0 | 0 | 40 | 550.946 | 585.745 | 367.385 | 861.832 |
| read scan | kuzu | medium | 1 | relationship_type_scan | 1 | 0 | 0 | 10 | 6.09482 | 6.09482 | 6.09482 | 6.09482 |
| read scan | zyx | medium | 1 | relationship_type_scan | 1 | 0 | 0 | 10 | 251.54 | 251.54 | 251.54 | 251.54 |
| topk/group | kuzu | medium | 3 | aggregation_count_by_group;aggregation_group_by;topk_property_sort | 3 | 0 | 0 | 30 | 3.88536 | 3.90163 | 3.4696 | 4.34137 |
| topk/group | zyx | medium | 3 | aggregation_count_by_group;aggregation_group_by;topk_property_sort | 3 | 0 | 0 | 30 | 635.374 | 714.729 | 443.227 | 1230.75 |

## Operation Families

- `read scan`: scans without scalar property predicates, such as relationship type counts.
- `adjacency expand`: fixed-hop, bounded-reachability, and write-then-local-traversal workloads.
- `property filter`: node/relationship property predicates and indexed scalar lookup workloads.
- `topk/group`: sort/TopK and aggregation/grouping workloads.
- `point write`, `batch write`, `load/index build`: mutation and ingest phases kept separate from read latency.

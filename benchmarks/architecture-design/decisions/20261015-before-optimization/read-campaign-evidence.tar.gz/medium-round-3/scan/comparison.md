# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | kuzu | 3.89393 | 443.227 | 447.918 | 2 | 113.825 | kuzu | 113.825 | 474.481 | 1.07051 | 1.01058 |
| aggregation_group_by | medium | kuzu | 3.4696 | 470.21 | 429.223 | 2 | 135.523 | kuzu | 135.523 | 516.663 | 1.09879 | 0.912833 |
| all_nodes_property_filter | medium | kuzu | 0.91771 | 695.148 | 737.686 | 2 | 757.481 | kuzu | 757.481 | 737.686 | 1.06119 | 1.06119 |
| label_multi_property_filter | medium | kuzu | 2.24217 | 418.616 | 472.061 | 2 | 186.701 | kuzu | 186.701 | 482.3 | 1.15213 | 1.12767 |
| label_scan_filter | medium | kuzu | 2.07034 | 367.385 | 350.82 | 2 | 177.452 | kuzu | 177.452 | 378.367 | 1.02989 | 0.954911 |
| one_hop_expand | medium | kuzu | 0.507206 | 1.88104 | 2.55052 | 2 | 3.70863 | kuzu | 3.70863 | 2.55052 | 1.35591 | 1.35591 |
| relationship_property_filter | medium | kuzu | 10.5867 | 861.832 | 870.198 | 2 | 81.4067 | kuzu | 81.4067 | 943.806 | 1.09512 | 1.00971 |
| relationship_type_scan | medium | kuzu | 6.09482 | 251.54 | 265.089 | 2 | 41.2711 | kuzu | 41.2711 | 275.436 | 1.095 | 1.05386 |
| topk_property_sort | medium | kuzu | 4.34137 | 1230.75 | 1217.76 | 2 | 283.494 | kuzu | 283.494 | 1292.5 | 1.05017 | 0.989445 |
| two_hop_expand | medium | kuzu | 1.12693 | 2.09004 | 2.14953 | 2 | 1.85463 | kuzu | 1.85463 | 2.17275 | 1.03957 | 1.02846 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | kuzu | 0.678818 | 3.08113 | 3.34873 | 2 | 4.53896 | kuzu | 4.53896 | 3.34873 | 1.08685 | 1.08685 |
| one_hop_fetch_neighbor_ids | medium | kuzu | 0.715872 | 2.38834 | 2.38276 | 2 | 3.33627 | kuzu | 3.33627 | 2.81782 | 1.17982 | 0.997664 |
| one_hop_fetch_neighbor_records | medium | kuzu | 0.807256 | 3.4144 | 3.49254 | 2 | 4.22964 | kuzu | 4.22964 | 5.15083 | 1.50856 | 1.02289 |
| point_edge_fetch_by_endpoints | medium | kuzu | 0.459295 | 2.82669 | 2.92649 | 2 | 6.15441 | kuzu | 6.15441 | 3.15308 | 1.11547 | 1.03531 |
| point_node_fetch_by_id | medium | kuzu | 0.246843 | 2.87388 | 2.88284 | 2 | 11.6425 | kuzu | 11.6425 | 3.02358 | 1.05209 | 1.00312 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

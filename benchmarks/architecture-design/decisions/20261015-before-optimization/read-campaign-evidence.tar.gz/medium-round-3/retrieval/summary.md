# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.7399380001515965 | 0.5524829998648784 | 0.6682013000045117 | 0.6788180003240996 | 0.7561110001006455 | 0.7561110001006455 | 0.7561110001006455 | 1496.5550051956618 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.729022000086843 | 0.6682919997729186 | 0.7470341999578523 | 0.7158720000006724 | 0.9454910000386008 | 0.9454910000386008 | 0.9454910000386008 | 1338.626799223409 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.8020190002753225 | 0.7666469996365777 | 0.8180024000012054 | 0.8072559999163786 | 0.9367669999846839 | 0.9367669999846839 | 0.9367669999846839 | 1222.4903007601524 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.5799619998470007 | 0.439165999978286 | 0.4950623000240739 | 0.45929500038255355 | 0.5942090001553879 | 0.5942090001553879 | 0.5942090001553879 | 2019.9477923311308 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.27498400004333234 | 0.22461000025941757 | 0.25384829996255576 | 0.246843000240915 | 0.328393000017968 | 0.328393000017968 | 0.328393000017968 | 3939.360634471479 | ok | cypher |
| zyx | batch_node_fetch_100 | medium | 10 | 3.34873 | 3.01548 | 3.135373 | 3.08113 | 3.34873 | 3.34873 | 3.34873 | 318.94131894355155 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 2.38276 | 2.33417 | 2.483828 | 2.38834 | 2.81782 | 2.81782 | 2.81782 | 402.60436713009113 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 3.49254 | 3.33628 | 3.63851 | 3.4144 | 5.15083 | 5.15083 | 5.15083 | 274.8377770021245 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 2.92649 | 2.70155 | 2.860446 | 2.82669 | 3.15308 | 3.15308 | 3.15308 | 349.59583225832614 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 2.88284 | 2.83347 | 2.882554 | 2.87388 | 3.02358 | 3.02358 | 3.02358 | 346.9145764485245 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | point_lookup_indexed | medium | 10 | 0.24992799990286585 | 0.22260799960349686 | 0.25003890004882123 | 0.24142500024026958 | 0.2964760001304967 | 0.2964760001304967 | 0.2964760001304967 | 3999.3776960494765 | ok | cypher |
| zyx | point_lookup_indexed | medium | 10 | 1.43472 | 1.33839 | 1.491393 | 1.4681 | 1.68011 | 1.68011 | 1.68011 | 670.5140764372636 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 177.949 | 170.214 | 189.9914 | 179.825 | 222.984 | 222.984 | 222.984 | 5.263396132667058 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1037.97 | 1023.52 | 1061.534 | 1047.97 | 1108.86 | 1108.86 | 1108.86 | 0.9420329447761447 | ok | api |
| kuzu | property_equality_indexed | medium | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | unsupported | cypher |
| kuzu | property_range_indexed | medium | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | unsupported | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

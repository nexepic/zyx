# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| point_lookup_indexed | medium | kuzu | 0.241425 | 1.4681 | 1.43472 | 2 | 6.08098 | kuzu | 6.08098 | 1.68011 | 1.14441 | 0.977263 |
| property_equality_indexed | medium | zyx | 179.825 | 179.825 | 177.949 | 1 | 1 |  |  | 222.984 | 1.24001 | 0.989568 |
| property_range_indexed | medium | zyx | 1047.97 | 1047.97 | 1037.97 | 1 | 1 |  |  | 1108.86 | 1.0581 | 0.990458 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.6100370001149713 | 0.5211269999563228 | 0.5659593000245877 | 0.5626770000617398 | 0.6382890001077612 | 0.6382890001077612 | 0.6382890001077612 | 1766.9115075175118 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.6734900000537891 | 0.6464099999448081 | 0.7035723999933907 | 0.6898839999394113 | 0.7786850001139101 | 0.7786850001139101 | 0.7786850001139101 | 1421.3178345389813 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.8056450001276971 | 0.743222999972204 | 0.8573266000439617 | 0.8068259999163274 | 1.0589270000309625 | 1.0589270000309625 | 1.0589270000309625 | 1166.4166257628335 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.5302489998939564 | 0.5009060000702448 | 0.5440709000140487 | 0.5302489998939564 | 0.5993110000872548 | 0.5993110000872548 | 0.5993110000872548 | 1837.9957464627837 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.3011230000993237 | 0.22684300006403646 | 0.29213840000466007 | 0.2611339998566109 | 0.5137550001563795 | 0.5137550001563795 | 0.5137550001563795 | 3423.0351093319073 | ok | cypher |
| zyx | batch_node_fetch_100 | medium | 10 | 3.06581 | 3.01902 | 3.228312 | 3.17251 | 3.58256 | 3.58256 | 3.58256 | 309.75940367597684 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 2.42231 | 2.25857 | 2.405395 | 2.34047 | 2.76316 | 2.76316 | 2.76316 | 415.7321354704737 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 3.61509 | 3.42104 | 4.005850000000001 | 3.87776 | 5.22586 | 5.22586 | 5.22586 | 249.63490894566695 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 2.68033 | 2.58676 | 2.662394 | 2.62002 | 2.77634 | 2.77634 | 2.77634 | 375.60180799686293 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 3.13532 | 2.87891 | 3.020067 | 2.96566 | 3.20578 | 3.20578 | 3.20578 | 331.1184818085162 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | kuzu | 0.562677 | 3.17251 | 3.06581 | 2 | 5.63824 | kuzu | 5.63824 | 3.58256 | 1.12925 | 0.966367 |
| one_hop_fetch_neighbor_ids | medium | kuzu | 0.689884 | 2.34047 | 2.42231 | 2 | 3.39256 | kuzu | 3.39256 | 2.76316 | 1.1806 | 1.03497 |
| one_hop_fetch_neighbor_records | medium | kuzu | 0.806826 | 3.87776 | 3.61509 | 2 | 4.80619 | kuzu | 4.80619 | 5.22586 | 1.34765 | 0.932262 |
| point_edge_fetch_by_endpoints | medium | kuzu | 0.530249 | 2.62002 | 2.68033 | 2 | 4.94111 | kuzu | 4.94111 | 2.77634 | 1.05966 | 1.02302 |
| point_node_fetch_by_id | medium | kuzu | 0.261134 | 2.96566 | 3.13532 | 2 | 11.3569 | kuzu | 11.3569 | 3.20578 | 1.08097 | 1.05721 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

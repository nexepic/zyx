# Operation Type Summary

Rows group benchmark workloads by database operation family. Unit: ms; lower p50-derived values are better.

| operation_type | database | scale | workload_count | workloads | ok_workloads | unsupported_workloads | failed_workloads | samples | geomean_p50_ms | avg_p50_ms | min_p50_ms | max_p50_ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| adjacency expand | kuzu | medium | 2 | one_hop_expand;two_hop_expand | 2 | 0 | 0 | 20 | 0.746435 | 0.789341 | 0.532643 | 1.04604 |
| adjacency expand | zyx | medium | 2 | one_hop_expand;two_hop_expand | 2 | 0 | 0 | 20 | 2.03351 | 2.04418 | 1.83561 | 2.25275 |
| property filter | kuzu | medium | 4 | all_nodes_property_filter;label_multi_property_filter;label_scan_filter;relationship_property_filter | 4 | 0 | 0 | 40 | 2.71398 | 4.19948 | 0.913614 | 11.2896 |
| property filter | zyx | medium | 4 | all_nodes_property_filter;label_multi_property_filter;label_scan_filter;relationship_property_filter | 4 | 0 | 0 | 40 | 565.555 | 600.663 | 362.191 | 856.112 |
| read scan | kuzu | medium | 1 | relationship_type_scan | 1 | 0 | 0 | 10 | 6.34076 | 6.34076 | 6.34076 | 6.34076 |
| read scan | zyx | medium | 1 | relationship_type_scan | 1 | 0 | 0 | 10 | 256.792 | 256.792 | 256.792 | 256.792 |
| topk/group | kuzu | medium | 3 | aggregation_count_by_group;aggregation_group_by;topk_property_sort | 3 | 0 | 0 | 30 | 4.06724 | 4.13819 | 3.43085 | 5.24416 |
| topk/group | zyx | medium | 3 | aggregation_count_by_group;aggregation_group_by;topk_property_sort | 3 | 0 | 0 | 30 | 603.263 | 677.612 | 427.83 | 1164.24 |

## Operation Families

- `read scan`: scans without scalar property predicates, such as relationship type counts.
- `adjacency expand`: fixed-hop, bounded-reachability, and write-then-local-traversal workloads.
- `property filter`: node/relationship property predicates and indexed scalar lookup workloads.
- `topk/group`: sort/TopK and aggregation/grouping workloads.
- `point write`, `batch write`, `load/index build`: mutation and ingest phases kept separate from read latency.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | kuzu | 3.73957 | 440.765 | 434.747 | 2 | 117.865 | kuzu | 117.865 | 474.367 | 1.07624 | 0.986346 |
| aggregation_group_by | medium | kuzu | 3.43085 | 427.83 | 424.158 | 2 | 124.701 | kuzu | 124.701 | 447.862 | 1.04682 | 0.991417 |
| all_nodes_property_filter | medium | kuzu | 0.913614 | 736.168 | 731.904 | 2 | 805.776 | kuzu | 805.776 | 777.541 | 1.0562 | 0.994208 |
| label_multi_property_filter | medium | kuzu | 2.43125 | 448.182 | 459.64 | 2 | 184.343 | kuzu | 184.343 | 478.379 | 1.06738 | 1.02557 |
| label_scan_filter | medium | kuzu | 2.16349 | 362.191 | 362.607 | 2 | 167.41 | kuzu | 167.41 | 378.148 | 1.04406 | 1.00115 |
| one_hop_expand | medium | kuzu | 0.532643 | 1.83561 | 1.81187 | 2 | 3.44623 | kuzu | 3.44623 | 2.20337 | 1.20035 | 0.987067 |
| relationship_property_filter | medium | kuzu | 11.2896 | 856.112 | 856.112 | 2 | 75.8322 | kuzu | 75.8322 | 936.535 | 1.09394 | 1 |
| relationship_type_scan | medium | kuzu | 6.34076 | 256.792 | 269.772 | 2 | 40.4986 | kuzu | 40.4986 | 269.772 | 1.05055 | 1.05055 |
| topk_property_sort | medium | kuzu | 5.24416 | 1164.24 | 1235.27 | 2 | 222.007 | kuzu | 222.007 | 1235.27 | 1.06101 | 1.06101 |
| two_hop_expand | medium | kuzu | 1.04604 | 2.25275 | 2.22476 | 2 | 2.1536 | kuzu | 2.1536 | 2.85109 | 1.2656 | 0.987575 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

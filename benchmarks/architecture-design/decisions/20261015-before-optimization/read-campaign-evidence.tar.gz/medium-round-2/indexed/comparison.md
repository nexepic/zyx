# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| point_lookup_indexed | medium | kuzu | 0.361464 | 1.34648 | 1.35758 | 2 | 3.72507 | kuzu | 3.72507 | 1.36311 | 1.01235 | 1.00824 |
| property_equality_indexed | medium | zyx | 181.3 | 181.3 | 190.428 | 1 | 1 |  |  | 190.428 | 1.05035 | 1.05035 |
| property_range_indexed | medium | zyx | 1038.86 | 1038.86 | 1010.82 | 1 | 1 |  |  | 1093.88 | 1.05296 | 0.973009 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | point_lookup_indexed | medium | 10 | 0.5994440000449686 | 0.30098399997768865 | 0.4381345000183501 | 0.36146399997960543 | 0.6216480001057789 | 0.6216480001057789 | 0.6216480001057789 | 2282.4041474892247 | ok | cypher |
| zyx | point_lookup_indexed | medium | 10 | 1.35758 | 1.32627 | 1.345725 | 1.34648 | 1.36311 | 1.36311 | 1.36311 | 743.0938713332962 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 190.428 | 178.829 | 182.59859999999998 | 181.3 | 190.428 | 190.428 | 190.428 | 5.476493248031475 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1010.82 | 1000.08 | 1045.153 | 1038.86 | 1093.88 | 1093.88 | 1093.88 | 0.9567977128707471 | ok | api |
| kuzu | property_equality_indexed | medium | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | unsupported | cypher |
| kuzu | property_range_indexed | medium | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | unsupported | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

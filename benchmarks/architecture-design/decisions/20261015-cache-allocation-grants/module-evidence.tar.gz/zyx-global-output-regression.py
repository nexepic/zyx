import pathlib, subprocess, shlex, os
root=pathlib.Path('/workspace/zyx')
sources=[
 'tests/src/query/execution/test_CoordinatedMaterializedBudget.cpp',
 'tests/src/query/execution/test_ResourceCoordinator.cpp',
 'tests/src/query/execution/test_ProcessResourceDomains.cpp',
 'tests/src/query/execution/test_PrepaidMemoryResource.cpp',
 'tests/src/storage/relocatable/cache/test_BufferPool.cpp',
 'tests/src/query/cache/test_PlanCache.cpp',
 'tests/src/storage/relocatable/backend/test_RelocatableQueryResources.cpp',
 'tests/src/storage/relocatable/backend/test_RelocatableQueryScratch.cpp',
 'tests/src/storage/relocatable/backend/test_RelocatableStorageBackendIsolation.cpp',
 'tests/src/query/execution/test_MaterializedReservationEmbedded.cpp',
 'tests/src/query/api/test_QueryResult.cpp',
 'tests/src/query/api/test_QueryResultResources.cpp',
 'tests/src/query/execution/test_LogicalGraphReadExecutor_RuntimeContracts.cpp',
 'tests/src/query/execution/test_LogicalPlanSortGrowth.cpp',
 'tests/src/query/execution/test_ExternalQuerySort.cpp',
 'tests/src/query/execution/test_QuerySpillRowCodec.cpp',
 'tests/src/query/execution/test_BudgetMemoryResource.cpp',
 'tests/src/query/execution/test_DynamicValueArena.cpp']
objects=['CMakeFiles/zyx_test_suite.dir/'+s+'.o' for s in sources]
subprocess.run(['cmake','--build','buildDir','--target','zyx_core',*objects,'-j','4'],cwd=root,check=True)
lines=(root/'buildDir/build.ninja').read_text().splitlines()
start=next(i for i,v in enumerate(lines) if v.startswith('build zyx_test_suite:'))
libs=next(v.split(' = ',1)[1] for v in lines[start:start+14] if v.strip().startswith('LINK_LIBRARIES = '))
command=['/workspace/zyx-sysroot/usr/bin/clang++-19','-fprofile-instr-generate','-fcoverage-mapping','-pthread',*[str(root/'buildDir'/o) for o in objects],'/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libgtest_main.a',*shlex.split(libs),'-o','/tmp/zyx-global-output-regression-tests']
(root/'buildDir/global-output-link-command.txt').write_text(shlex.join(command)+'\n')
subprocess.run(command,cwd=root/'buildDir',check=True)
subprocess.run(['/tmp/zyx-global-output-regression-tests','--gtest_output=xml:/tmp/zyx-global-output-regression-tests.xml','--gtest_filter='+os.environ.get('ZYX_TARGETED_GTEST_FILTER','*')],cwd=root,check=True)

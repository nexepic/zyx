#include "storage/relocatable/property/HybridPropertyColdRowRoutingTestFixture.hpp"
#include "graph/storage/relocatable/metadata/HybridPropertyDemotionPreparation.hpp"
#include "graph/storage/relocatable/metadata/HybridPropertyRowPreparation.hpp"
#include <algorithm>
#if ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT
using namespace graph::storage;
using graph::PropertyValue;
using graph::query::execution::MaterializedByteBudget;
namespace {
class RejectColdHotPhysicalAllocation final : public MetadataPageAllocator {
    MetadataPageId allocateMetadataPageId() override { throw std::logic_error("hot preparation allocated metadata"); }
    MetadataPageAllocation allocatePage(Generation, LogSequenceNumber, std::span<const PhysicalSlotId>) override {
        throw std::logic_error("hot preparation allocated physical storage");
    }
    void abandonPage(PhysicalPageRef) noexcept override {}
};
class HybridPropertyColdCompatibleHotTest : public graph::storage::test::HybridPropertyColdRowRoutingTest {
protected:
    const HybridPropertyPageImage &image(const HybridPropertyDemotionPreparation &prepared, PageId id) {
        for (const auto &page : prepared.pages()) if (page.pageId() == id) return page;
        throw std::logic_error("hot preparation lost its page");
    }
};
}
TEST_F(HybridPropertyColdCompatibleHotTest, CompatibleHotValuePreservesUnvisitedColdBytesAndPublicMutationGuard) {
    bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock();
    const auto epoch = io_->dataMutationEpoch(); int64_t decodes = 0;
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        EXPECT_THROW(context.groupRecord({NODE, 1}), FormatException);
        EXPECT_THROW(context.visitField({NODE, 1}, 1, [](const auto &) {}, [](const auto &) {}, {}, {},
            [](const auto &, const auto &, const auto &, const auto &) {}), FormatException);
        graph::debug::PerfTrace::ScopedObserver observer(&decodes, [](void *p, std::string_view key, int64_t value, bool) noexcept {
            if (key == "native_graph.hybrid.cold_block_decodes") *static_cast<int64_t *>(p) += value;
        });
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const PropertyValue replacement(int64_t(444));
        auto change = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, batch.generation(), memory, &replacement);
        ASSERT_TRUE(change); EXPECT_EQ(change->action(), HybridPropertyColumnDelta::Action::HCD_REPLACE_COLUMN);
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const HybridPropertyDemotionPreparation prepared(batch, pin, fields, *change, memory);
        ASSERT_EQ(prepared.pages().size(), 1U); EXPECT_TRUE(prepared.owners().empty()); EXPECT_TRUE(prepared.extensions().empty());
        EXPECT_TRUE(prepared.erasedOwners().empty());
        const auto &page = image(prepared, change->groupReference().page_id);
        const auto group = page.readGroup(change->groupReference(), NODE, 1, batch.generation());
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        const auto column = image(prepared, change->columnReference().page_id).readColumn(change->columnReference(),
            change->replacementColumn().identity, group, batch.generation());
        EXPECT_EQ(column.words[0], 444U); EXPECT_EQ(group.memberships, 51U); EXPECT_EQ(matrix.cold_fields, 3U);
        EXPECT_EQ(matrix.cold_rows.roots[0], cold_reference_);
        EXPECT_TRUE(std::ranges::equal(image(prepared, cold_reference_.page_id).readRecord(cold_reference_), cold_encoded_bytes_));
        const auto location = metadata_->findPageLocation(pin, field_page_id_);
        const auto pool = metadata_->findCatalog(pin, location.segment_id);
        const PageOwnerHeader owner{field_page_id_, pool.owner_id, PageOwnerKind::POK_HYBRID_PROPERTY, 0,
            RSS_PAGE_OWNER_MAX_PAYLOAD_BYTES, pool.generation, batch.checkpointLsn()};
        // Only an actual FieldPageStore clone carries source provenance. A
        // public serialized reopen cannot use it to bypass corrupt cold bytes.
        auto untrusted = HybridPropertyPageImage::open(page.serialize(), field_page_id_, pool.generation, batch.generation(), memory);
        EXPECT_THROW(std::move(untrusted).bindPrivateOwner(owner, pool, batch.checkpointLsn()), FormatException);
        auto trusted = page.clone(batch.generation(), memory);
        const auto bound = std::move(trusted).bindPrivateOwner(owner, pool, batch.checkpointLsn());
        EXPECT_TRUE(std::ranges::equal(bound.read(cold_reference_), cold_encoded_bytes_));
        EXPECT_THROW(HybridPropertyColdRowBlock::decode(bound.read(cold_reference_), NODE, 1, batch.generation(), memory), FormatException);
        EXPECT_EQ(batch.candidate().next_logical_page_id, before.next_logical_page_id); EXPECT_EQ(batch.allocatedPageCount(), 0U);
        EXPECT_EQ(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 1).value->value, PropertyValue(int64_t(100)));
    }
    EXPECT_EQ(decodes, 0); EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before);
    EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, MissingHotNullInsertionOnEdgeKeepsColdBindingAndExactTotals) {
    owner_kind_ = EntityPropertyOwnerKind::EPOK_EDGE; raw_cold_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const PropertyValue null;
        auto change = HybridPropertyColumnDelta::planMissingColumnMember(context, pin, {owner_kind_, 64}, 1, batch.generation(), memory, null);
        ASSERT_TRUE(change); EXPECT_EQ(change->effects().memberships, 1);
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const HybridPropertyDemotionPreparation prepared(batch, pin, fields, *change, memory);
        const auto &page = image(prepared, change->groupReference().page_id);
        const auto group = page.readGroup(change->groupReference(), owner_kind_, 1, batch.generation());
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        const auto column = image(prepared, change->columnReference().page_id).readColumn(change->columnReference(),
            change->replacementColumn().identity, group, batch.generation());
        EXPECT_EQ(group.memberships, 52U); EXPECT_EQ(matrix.totalMemberships(), 52U); EXPECT_EQ(matrix.cold_fields, 3U);
        EXPECT_TRUE(matrix.contains({owner_kind_, 64}, 1)); EXPECT_TRUE(column.nulls & (UINT64_C(1) << 63)); EXPECT_EQ(column.words[63], 0U);
        EXPECT_EQ(matrix.cold_rows.roots[0], cold_reference_);
        EXPECT_TRUE(std::ranges::equal(image(prepared, cold_reference_.page_id).readRecord(cold_reference_), cold_encoded_bytes_));
        EXPECT_TRUE(prepared.owners().empty()); EXPECT_TRUE(prepared.erasedOwners().empty()); EXPECT_TRUE(prepared.extensions().empty());
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, NoopAndColdOrUnsupportedChangesCannotEscapeAsMutationAuthority) {
    bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const Generation next(before.generation.value() + 1); const PropertyValue same(int64_t(100)), text("incompatible-hot");
        auto unchanged = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, &same);
        ASSERT_TRUE(unchanged); EXPECT_EQ(unchanged->action(), HybridPropertyColumnDelta::Action::HCD_NO_CHANGE);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const HybridPropertyDemotionPreparation prepared(batch, pin, fields, *unchanged, memory); EXPECT_TRUE(prepared.pages().empty());
        EXPECT_THROW(HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, &text), FormatException);
        EXPECT_THROW(HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, nullptr), FormatException);
        EXPECT_THROW(HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, nullptr, true), FormatException);
        EXPECT_FALSE(HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 2, next, memory, &same));
        EXPECT_FALSE(HybridPropertyColumnDelta::planMissingColumnMember(context, pin, {NODE, 1}, 9, next, memory, same));
        EXPECT_EQ(batch.candidate().next_logical_page_id, before.next_logical_page_id);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, MergedIndividuallyCompatibleRemovalsCannotBecomeUnsupportedDemotion) {
    hot_owner_count_ = 64; seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const Generation next(before.generation.value() + 1);
        std::vector<HybridPropertyColumnDelta> plans; plans.reserve(17);
        for (uint64_t id = 1; id <= 17; ++id) {
            auto change = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, id}, 1, next, memory, nullptr);
            ASSERT_TRUE(change); EXPECT_EQ(change->action(), HybridPropertyColumnDelta::Action::HCD_REPLACE_COLUMN);
            plans.push_back(std::move(*change));
        }
        std::array<const HybridPropertyColumnDelta *, 17> inputs{};
        for (size_t i = 0; i < plans.size(); ++i) inputs[i] = &plans[i];
        auto merged = HybridPropertyColumnDelta::mergeExistingColumnChanges(std::span(inputs).first(16), memory);
        EXPECT_EQ(merged.action(), HybridPropertyColumnDelta::Action::HCD_REPLACE_COLUMN);
        EXPECT_EQ(std::popcount(merged.replacementColumn().presence), 48);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const HybridPropertyDemotionPreparation prepared(batch, pin, fields, merged, memory);
        const auto &page = image(prepared, merged.groupReference().page_id);
        const auto group = page.readGroup(merged.groupReference(), NODE, 1, batch.generation());
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.memberships, 51U); EXPECT_EQ(matrix.totalMemberships(), 51U); EXPECT_EQ(matrix.cold_fields, 3U);
        EXPECT_TRUE(prepared.owners().empty()); EXPECT_TRUE(prepared.erasedOwners().empty());
        EXPECT_TRUE(std::ranges::equal(image(prepared, cold_reference_.page_id).readRecord(cold_reference_), cold_encoded_bytes_));
        const auto retained = memory->used();
        EXPECT_THROW(HybridPropertyColumnDelta::mergeExistingColumnChanges(inputs, memory), FormatException);
        EXPECT_EQ(memory->used(), retained);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before);
}
TEST_F(HybridPropertyColdCompatibleHotTest, FreshAndReusedColdSlotsCannotInheritUnchangedSourceProof) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch(); int64_t skipped = 0;
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const Generation next(before.generation.value() + 1); const PropertyValue same(int64_t(100));
        const auto change = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, &same);
        ASSERT_TRUE(change);
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        for (const bool fresh : {false, true}) {
        auto page = fields.cloneForMutation(pin, field_page_id_, next, memory);
        const auto previous = change->sourceGroup(); auto replacement = previous; replacement.semantic_generation = next;
        auto matrix = page.readColumnMembership(previous.column_membership, previous, next); matrix.semantic_generation = next;
        if (!fresh) page.erase(cold_reference_);
        const auto inserted = page.appendColdRows(cold_encoded_bytes_, NODE, 1);
        if (fresh) page.erase(cold_reference_);
        EXPECT_NE(inserted, cold_reference_);
        matrix.cold_rows.roots[0] = matrix.cold_rows.roots[63] = inserted;
        page.replaceColumnMembership(previous.column_membership, matrix, previous, replacement, next);
        page.replaceGroup(change->groupReference(), replacement, next);
        const auto location = metadata_->findPageLocation(pin, field_page_id_); const auto pool = metadata_->findCatalog(pin, location.segment_id);
        const LogSequenceNumber lsn(before.checkpoint_lsn.value() + 1);
        const PageOwnerHeader owner{field_page_id_, pool.owner_id, PageOwnerKind::POK_HYBRID_PROPERTY, 0,
            RSS_PAGE_OWNER_MAX_PAYLOAD_BYTES, pool.generation, lsn};
        graph::debug::PerfTrace::ScopedObserver observer(&skipped, [](void *p, std::string_view key, int64_t value, bool) noexcept {
            if (key == "native_graph.hybrid.unchanged_cold_bindings") *static_cast<int64_t *>(p) += value;
        });
        const auto bound = std::move(page).bindPrivateOwner(owner, pool, lsn);
        const auto block = HybridPropertyFieldView::decodeColdRows(bound.read(inserted), inserted, replacement, matrix, next, next, memory);
        EXPECT_EQ(block.fields, 3U); EXPECT_EQ(block.owners, UINT64_C(1) | (UINT64_C(1) << 63));
        }
    }
    EXPECT_EQ(skipped, 0); EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before);
    EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}

TEST_F(HybridPropertyColdCompatibleHotTest, ColdBlockReplacementUpdatesExactMatrixAndRetainsOtherOwnerBytes) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const auto root = EntityPropertyCollectionRootCodec::encode({1, graph::Node::typeId, {{2, PropertyValue("replaced")}}});
        const std::array<HybridColdRowInput, 1> changes{{{0, 1, false, root}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, cold_reference_, changes, memory);
        ASSERT_EQ(prepared.pages().size(), 1U); const auto group = prepared.group();
        const auto &page = image(prepared, field_page_id_);
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.memberships, 50U); EXPECT_EQ(matrix.cold_fields, 2U); EXPECT_EQ(matrix.live, UINT64_MAX);
        EXPECT_EQ(matrix.cold_rows.roots[0], cold_reference_); EXPECT_EQ(matrix.cold_rows.roots[63], cold_reference_);
        const auto block = HybridPropertyFieldView::decodeColdRows(page.readRecord(cold_reference_), cold_reference_, group, matrix,
            batch.generation(), batch.generation(), memory);
        EXPECT_TRUE(std::ranges::equal(block.row(0)->root, root));
        const auto old = HybridPropertyColdRowBlock::decode(cold_encoded_bytes_, NODE, 1, before.generation, memory);
        EXPECT_TRUE(std::ranges::equal(block.row(63)->root, old.row(63)->root));
        const auto location = metadata_->findPageLocation(pin, field_page_id_);
        const auto pool = metadata_->findCatalog(pin, location.segment_id);
        const PageOwnerHeader owner{field_page_id_, pool.owner_id, PageOwnerKind::POK_HYBRID_PROPERTY, 0,
            RSS_PAGE_OWNER_MAX_PAYLOAD_BYTES, pool.generation, batch.checkpointLsn()};
        const auto bound = std::move(page.clone(batch.generation(), memory)).bindPrivateOwner(owner, pool, batch.checkpointLsn());
        EXPECT_TRUE(std::ranges::equal(bound.read(cold_reference_), page.readRecord(cold_reference_)));
        EXPECT_TRUE(prepared.owners().empty()); EXPECT_TRUE(prepared.extensions().empty());
        EXPECT_EQ(batch.allocatedPageCount(), 0U); EXPECT_EQ(batch.candidate().next_logical_page_id, before.next_logical_page_id);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ClearingAllColdRowsErasesBlockWithoutChangingOwnerLiveness) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const std::array<HybridColdRowInput, 2> changes{{{0, 0, false, {}}, {63, 0, false, {}}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, cold_reference_, changes, memory);
        const auto group = prepared.group(); const auto &page = image(prepared, field_page_id_);
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.memberships, 48U); EXPECT_EQ(group.live, UINT64_MAX);
        EXPECT_EQ(matrix.cold_fields, 0U); EXPECT_EQ(matrix.cold_rows.owners, 0U);
        EXPECT_EQ(matrix.cold_rows.roots[0], SlottedSlotReference{});
        EXPECT_EQ(matrix.cold_rows.roots[63], SlottedSlotReference{});
        EXPECT_THROW((void)page.readRecord(cold_reference_), FormatException);
        EXPECT_TRUE(prepared.erasedGroups(NODE).empty());
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ColdBlockPreparationDoesNotDecodeUnrelatedDamagedBlock) {
    split_cold_ = true; bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const PropertyValue same(int64_t(100));
        const auto hot = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, batch.generation(), memory, &same);
        ASSERT_TRUE(hot); HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const auto original = fields.cloneForMutation(pin, field_page_id_, batch.generation(), memory);
        const auto matrix = original.readColumnMembership(hot->sourceGroup().column_membership, hot->sourceGroup(), batch.generation());
        const auto target = matrix.cold_rows.roots[63];
        const auto root = EntityPropertyCollectionRootCodec::encode({64, graph::Node::typeId, {{2, PropertyValue()}}});
        const std::array<HybridColdRowInput, 1> changes{{{63, 1, false, root}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 64}, target, changes, memory);
        const auto &page = image(prepared, field_page_id_);
        EXPECT_TRUE(std::ranges::equal(page.readRecord(cold_reference_), cold_encoded_bytes_));
        EXPECT_THROW(HybridPropertyColdRowBlock::decode(page.readRecord(cold_reference_), NODE, 1, batch.generation(), memory), FormatException);
        EXPECT_EQ(prepared.group().memberships, 51U);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ColdBlockPreparationRejectsHotTokenAndDuplicateChangesWithoutWrites) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const auto root = EntityPropertyCollectionRootCodec::encode({1, graph::Node::typeId, {{1, PropertyValue(int64_t(9))}}});
        const std::array<HybridColdRowInput, 1> changes{{{0, 1, false, root}}};
        EXPECT_THROW((void)HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, cold_reference_, changes, memory), FormatException);
        const std::array<HybridColdRowInput, 2> duplicate{{{0, 0, false, {}}, {0, 0, false, {}}}};
        EXPECT_THROW((void)HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, cold_reference_, duplicate, memory), FormatException);
        EXPECT_EQ(batch.candidate().next_logical_page_id, before.next_logical_page_id);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ColdBlockPreparationAuthenticatesExistingActualLargeRootBeforeReplacement) {
    seed(true); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const auto root = EntityPropertyCollectionRootCodec::encode({1, graph::Node::typeId, {{2, PropertyValue()}}});
        const std::array<HybridColdRowInput, 1> changes{{{0, 1, false, root}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, cold_reference_, changes, memory, values_.get());
        EXPECT_EQ(prepared.group().memberships, 50U);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}

TEST_F(HybridPropertyColdCompatibleHotTest, ColdBlockInsertionOnExistingEdgePreservesEntityLivenessAndHotNull) {
    owner_kind_ = EntityPropertyOwnerKind::EPOK_EDGE; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const auto root = EntityPropertyCollectionRootCodec::encode({2, graph::Edge::typeId, {{2, PropertyValue()}}});
        const std::array<HybridColdRowInput, 1> changes{{{1, 1, false, root}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {owner_kind_, 1}, cold_reference_, changes, memory);
        const auto group = prepared.group(); const auto &page = image(prepared, field_page_id_);
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.live, UINT64_MAX); EXPECT_EQ(group.memberships, 52U); EXPECT_EQ(matrix.cold_fields, 4U);
        EXPECT_EQ(matrix.cold_rows.owners, UINT64_C(3) | (UINT64_C(1) << 63));
        const auto block = HybridPropertyFieldView::decodeColdRows(page.readRecord(cold_reference_), cold_reference_, group, matrix,
            batch.generation(), batch.generation(), memory);
        ASSERT_TRUE(block.row(1)); EXPECT_TRUE(std::ranges::equal(block.row(1)->root, root));
        EXPECT_EQ(batch.allocatedPageCount(), 0U);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ColdOnlyClearRetainsPropertylessLiveOwners) {
    cold_only_ = true; seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const std::array<HybridColdRowInput, 2> changes{{{0, 0, false, {}}, {63, 0, false, {}}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, cold_reference_, changes, memory);
        const auto group = prepared.group(); const auto &page = image(prepared, field_page_id_);
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.memberships, 0U); EXPECT_EQ(group.columns, 0U); EXPECT_EQ(group.live, UINT64_MAX);
        EXPECT_EQ(matrix.cold_rows.owners, 0U); EXPECT_TRUE(prepared.erasedGroups(NODE).empty());
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ColdBlockPreparationRejectsCompetingOrdinaryRow) {
    competing_row_ = true; seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const std::array<HybridColdRowInput, 1> changes{{{0, 0, false, {}}}};
        EXPECT_THROW((void)HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, cold_reference_, changes, memory), FormatException);
        EXPECT_EQ(batch.allocatedPageCount(), 0U);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}

TEST_F(HybridPropertyColdCompatibleHotTest, SameBatchColdReplacementRetainsHotValueAndPresenceChangesOnSharedPage) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        for (const bool addPresence : {false, true}) {
            RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
            const PropertyValue value(int64_t(444)), null;
            auto hot = addPresence ? HybridPropertyColumnDelta::planMissingColumnMember(context, pin, {NODE, 64}, 1, batch.generation(), memory, null) :
                HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, batch.generation(), memory, &value);
            ASSERT_TRUE(hot); const std::array<const HybridPropertyColumnDelta *, 1> hotChanges{&*hot};
            const auto root = EntityPropertyCollectionRootCodec::encode({1, graph::Node::typeId, {{2, PropertyValue()}}});
            const std::array<HybridColdRowInput, 1> changes{{{0, 1, false, root}}};
            const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlockWithHot(batch, context, hotChanges,
                {NODE, 1}, cold_reference_, changes, memory);
            ASSERT_EQ(prepared.pages().size(), 1U); const auto group = prepared.group(); const auto &page = image(prepared, field_page_id_);
            const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
            EXPECT_EQ(group.memberships, addPresence ? 51U : 50U); EXPECT_EQ(matrix.cold_fields, 2U);
            EXPECT_EQ(group.live, UINT64_MAX); EXPECT_EQ(matrix.totalMemberships(), group.memberships);
            const auto column = page.readColumn(hot->columnReference(), hot->replacementColumn().identity, group, batch.generation());
            if (addPresence) {
                EXPECT_TRUE(column.presence & (UINT64_C(1) << 63)); EXPECT_TRUE(column.nulls & (UINT64_C(1) << 63));
                EXPECT_TRUE(matrix.contains({NODE, 64}, 1)); EXPECT_EQ(column.words[0], 100U);
            } else EXPECT_EQ(column.words[0], 444U);
            const auto block = HybridPropertyFieldView::decodeColdRows(page.readRecord(cold_reference_), cold_reference_, group, matrix,
                batch.generation(), batch.generation(), memory);
            EXPECT_TRUE(std::ranges::equal(block.row(0)->root, root));
            EXPECT_EQ(matrix.cold_rows.roots[0], cold_reference_); EXPECT_EQ(batch.allocatedPageCount(), 0U);
        }
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}

TEST_F(HybridPropertyColdCompatibleHotTest, ColdGrowthSplitsAndRelocatesMatrixWithGroupDirectoryEdit) {
    split_cold_ = true; raw_cold_ = true; last_cold_text_bytes_ = 2200; seed();
    auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    std::vector<std::vector<std::byte>> roots; std::vector<HybridColdRowInput> changes;
    roots.reserve(63); changes.reserve(63);
    for (unsigned slot = 0; slot < 63; ++slot) {
        std::string text(2100, 'x'); uint32_t state = 17321 + slot;
        for (auto &c : text) { state ^= state << 13; state ^= state >> 17; state ^= state << 5; c = char(33 + state % 90); }
        roots.push_back(EntityPropertyCollectionRootCodec::encode({slot + 1U, graph::Node::typeId, {{2, PropertyValue(text)}}}));
        changes.push_back({uint8_t(slot), 1, false, roots.back()});
    }
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const PropertyValue same(int64_t(100)); const Generation next(before.generation.value() + 1);
        const auto probe = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, &same);
        ASSERT_TRUE(probe); HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const auto initialImage = fields.cloneForMutation(pin, field_page_id_, next, memory);
        const auto initialMatrix = initialImage.readColumnMembership(probe->sourceGroup().column_membership, probe->sourceGroup(), next);
        const auto lastRoot = EntityPropertyCollectionRootCodec::encode({64, graph::Node::typeId, {{2, PropertyValue()}}});
        const std::array<HybridColdRowInput, 1> lastChange{{{63, 1, false, lastRoot}}};
        for (const bool modifySecond : {false, true}) {
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const auto prepared = [&] {
            if (!modifySecond) return HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, cold_reference_, changes, memory);
            const std::array<HybridPropertyDemotionPreparation::ColdBlockChange, 2> blocks{{
                {{NODE, 1}, cold_reference_, changes}, {{NODE, 64}, initialMatrix.cold_rows.roots[63], lastChange}}};
            return HybridPropertyDemotionPreparation::prepareColdBlocks(batch, context, blocks, memory);
        }();
        const auto group = prepared.group();
        ASSERT_EQ(prepared.groups(NODE).size(), 1U); EXPECT_TRUE(prepared.groups(EntityPropertyOwnerKind::EPOK_EDGE).empty());
        EXPECT_NE(group.column_membership.page_id, field_page_id_);
        const auto groupReference = HybridPropertyDirectoryCodec::decodeLocator(prepared.groups(NODE).front().value);
        EXPECT_EQ(groupReference.page_id, group.column_membership.page_id);
        const auto &groupPage = image(prepared, groupReference.page_id);
        EXPECT_EQ(groupPage.readGroup(groupReference, NODE, 1, batch.generation()), group);
        const auto matrix = groupPage.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(matrix.cold_fields, 64U); EXPECT_EQ(matrix.cold_rows.owners, UINT64_MAX);
        EXPECT_EQ(group.memberships, 112U); EXPECT_EQ(group.live, UINT64_MAX);
        for (unsigned slot = 0; slot < 63; ++slot) {
            const auto reference = matrix.cold_rows.roots[slot]; EXPECT_NE(reference.page_id, field_page_id_);
            const auto &page = image(prepared, reference.page_id);
            const auto block = HybridPropertyFieldView::decodeColdRows(page.readRecord(reference), reference, group, matrix,
                batch.generation(), batch.generation(), memory);
            ASSERT_TRUE(block.row(slot)); EXPECT_TRUE(std::ranges::equal(block.row(slot)->root, roots[slot]));
        }
        EXPECT_EQ(matrix.cold_rows.roots[63].page_id, field_page_id_);
        if (modifySecond) {
            const auto reference = matrix.cold_rows.roots[63];
            const auto block = HybridPropertyFieldView::decodeColdRows(image(prepared, reference.page_id).readRecord(reference), reference,
                group, matrix, batch.generation(), batch.generation(), memory);
            EXPECT_TRUE(std::ranges::equal(block.row(63)->root, lastRoot));
        }
        EXPECT_THROW((void)image(prepared, field_page_id_).readRecord(cold_reference_), FormatException);
        EXPECT_EQ(batch.allocatedPageCount(), 0U);
        EXPECT_GT(batch.candidate().next_logical_page_id, before.next_logical_page_id);
        }
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}

TEST_F(HybridPropertyColdCompatibleHotTest, MultipleColdBlocksAndHotPresenceShareOneFinalMatrix) {
    split_cold_ = true; seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const PropertyValue null;
        auto hot = HybridPropertyColumnDelta::planMissingColumnMember(context, pin, {NODE, 64}, 1, batch.generation(), memory, null);
        ASSERT_TRUE(hot); const std::array<const HybridPropertyColumnDelta *, 1> hotChanges{&*hot};
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const auto initial = fields.cloneForMutation(pin, field_page_id_, batch.generation(), memory);
        const auto sourceMatrix = initial.readColumnMembership(hot->sourceGroup().column_membership, hot->sourceGroup(), batch.generation());
        const std::array<HybridColdRowInput, 1> first{{{0, 0, false, {}}}}, last{{{63, 0, false, {}}}};
        const std::array<HybridPropertyDemotionPreparation::ColdBlockChange, 2> blocks{{
            {{NODE, 1}, cold_reference_, first}, {{NODE, 64}, sourceMatrix.cold_rows.roots[63], last}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlocks(batch, context, blocks, memory, hotChanges);
        const auto group = prepared.group(); const auto &page = image(prepared, field_page_id_);
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.memberships, 49U); EXPECT_EQ(matrix.totalMemberships(), 49U);
        EXPECT_EQ(matrix.cold_fields, 0U); EXPECT_EQ(matrix.cold_rows.owners, 0U); EXPECT_TRUE(matrix.contains({NODE, 64}, 1));
        EXPECT_EQ(group.live, UINT64_MAX); EXPECT_EQ(prepared.pages().size(), 1U);
        const std::array duplicate{blocks[0], blocks[0]};
        EXPECT_THROW((void)HybridPropertyDemotionPreparation::prepareColdBlocks(batch, context, duplicate, memory), FormatException);
        EXPECT_EQ(batch.allocatedPageCount(), 0U);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}

TEST_F(HybridPropertyColdCompatibleHotTest, FreshColdBlockInsertionRetainsExistingColdOwnersAndHotAuthority) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const auto root = EntityPropertyCollectionRootCodec::encode({2, graph::Node::typeId, {{2, PropertyValue()}}});
        const std::array<HybridColdRowInput, 1> changes{{{1, 1, false, root}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 2}, {}, changes, memory);
        const auto group = prepared.group();
        const auto &groupPage = image(prepared, group.column_membership.page_id);
        const auto matrix = groupPage.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.memberships, 52U); EXPECT_EQ(matrix.cold_fields, 4U); EXPECT_EQ(group.live, UINT64_MAX);
        EXPECT_EQ(matrix.cold_rows.roots[0], cold_reference_); EXPECT_EQ(matrix.cold_rows.roots[63], cold_reference_);
        EXPECT_TRUE(matrix.contains({NODE, 2}, 1)); const auto reference = matrix.cold_rows.roots[1];
        EXPECT_NE(reference.page_id, field_page_id_);
        const auto block = HybridPropertyFieldView::decodeColdRows(image(prepared, reference.page_id).readRecord(reference), reference,
            group, matrix, batch.generation(), batch.generation(), memory);
        EXPECT_EQ(block.owners, 2U); EXPECT_TRUE(std::ranges::equal(block.row(1)->root, root));
        EXPECT_TRUE(std::ranges::equal(image(prepared, field_page_id_).readRecord(cold_reference_), cold_encoded_bytes_));
        const std::array<HybridColdRowInput, 1> overwrite{{{0, 1, false, root}}};
        EXPECT_THROW((void)HybridPropertyDemotionPreparation::prepareColdBlock(batch, context, {NODE, 1}, {}, overwrite, memory), FormatException);
        EXPECT_EQ(batch.allocatedPageCount(), 0U);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}

TEST_F(HybridPropertyColdCompatibleHotTest, FirstColdFieldOnPropertylessLiveGroupNeedsNoFabricatedSourceBlock) {
    omit_cold_ = true; cold_only_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const auto root = EntityPropertyCollectionRootCodec::encode({2, graph::Node::typeId, {{7, PropertyValue()}}});
        const std::array<HybridColdRowInput, 1> changes{{{1, 1, false, root}}};
        const std::array<HybridPropertyDemotionPreparation::ColdBlockChange, 1> blocks{{{{NODE, 2}, {}, changes}}};
        const auto prepared = HybridPropertyDemotionPreparation::prepareColdBlocks(batch, context, blocks, memory);
        const auto group = prepared.group(); const auto &page = image(prepared, group.column_membership.page_id);
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.memberships, 1U); EXPECT_EQ(group.columns, 0U); EXPECT_EQ(group.live, UINT64_MAX);
        EXPECT_EQ(matrix.cold_rows.owners, 2U); EXPECT_EQ(matrix.cold_fields, 1U);
        EXPECT_EQ(context.hasFields({NODE, 2}), std::optional<bool>(false)); EXPECT_EQ(batch.allocatedPageCount(), 0U);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}

TEST_F(HybridPropertyColdCompatibleHotTest, ColdInverseProjectionRetainsActualLargeNullAndPropertylessNodeRows) {
    seed(true); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const HybridPropertyRowPreparation projection(context, pin, *metadata_, *entities_, NODE, 1, memory, values_.get());
        ASSERT_EQ(projection.rows().size(), 64U); EXPECT_EQ(projection.sourceGroup().memberships, 51U);
        size_t fields = 0;
        for (size_t i = 0; i < projection.rows().size(); ++i) {
            const auto &row = projection.rows()[i]; EXPECT_EQ(row.owner_entity_id, i + 1U);
            EXPECT_EQ(row.owner_entity_type, graph::Node::typeId); fields += row.entries.size();
        }
        EXPECT_EQ(fields, 51U); ASSERT_EQ(projection.rows()[0].entries.size(), 3U);
        EXPECT_EQ(projection.rows()[0].entries[2].key_token, 4U);
        EXPECT_EQ(std::get<std::string>(projection.rows()[0].entries[2].value.getVariant()).size(), 8193U);
        ASSERT_EQ(projection.rows()[2].entries.size(), 1U);
        EXPECT_TRUE(std::holds_alternative<std::monostate>(projection.rows()[2].entries[0].value.getVariant()));
        EXPECT_TRUE(projection.rows()[48].entries.empty());
        EXPECT_THROW((void)context.groupRecord({NODE, 1}), FormatException);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ColdInverseProjectionPreservesEdgeOwnerNamespaceAndExactCounts) {
    owner_kind_ = EntityPropertyOwnerKind::EPOK_EDGE; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const HybridPropertyRowPreparation projection(context, pin, *metadata_, *entities_, owner_kind_, 1, memory);
        ASSERT_EQ(projection.rows().size(), 64U); size_t fields = 0;
        for (const auto &row : projection.rows()) { EXPECT_EQ(row.owner_entity_type, graph::Edge::typeId); fields += row.entries.size(); }
        EXPECT_EQ(fields, 51U); EXPECT_EQ(projection.rows().back().owner_entity_id, 64U);
        EXPECT_EQ(projection.sourceGroup().owner_kind, owner_kind_);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ColdInverseProjectionRetainsAllPropertylessLiveOwners) {
    cold_only_ = true; omit_cold_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const HybridPropertyRowPreparation projection(context, pin, *metadata_, *entities_, NODE, 1, memory);
        ASSERT_EQ(projection.rows().size(), 64U);
        for (const auto &row : projection.rows()) EXPECT_TRUE(row.entries.empty());
        EXPECT_EQ(projection.sourceGroup().memberships, 0U); EXPECT_EQ(projection.sourceGroup().live, UINT64_MAX);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, ColdInverseProjectionRejectsAccessedCorruptionAndRefunds) {
    bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        EXPECT_THROW((void)HybridPropertyRowPreparation(context, pin, *metadata_, *entities_, NODE, 1, memory), FormatException);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
#endif

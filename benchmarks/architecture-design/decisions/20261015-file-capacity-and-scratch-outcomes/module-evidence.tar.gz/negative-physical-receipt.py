from pathlib import Path
import subprocess,shlex,json,tempfile,os
root=Path('/workspace/zyx');build=root/'buildDir'
original=root/'src/storage/relocatable/allocation/PhysicalSegmentAllocator.cpp'
old=Path('/tmp/zyx-const-physical-allocation-receipt.cpp')
s=original.read_text().replace('std::optional<CatalogSlotReservations> reservations =','const std::optional<CatalogSlotReservations> reservations =').replace('std::move(reservations->entries)','reservations->entries')
old.write_text(s)
target='CMakeFiles/zyx_core.dir/src/storage/relocatable/allocation/PhysicalSegmentAllocator.cpp.o'
command=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],cwd=root,text=True).strip().splitlines()[-1])
for flag,value in [('-o','/tmp/zyx-const-physical-allocation-receipt.o'),('-MF','/tmp/zyx-const-physical-allocation-receipt.d')]:command[command.index(flag)+1]=value
command[command.index(str(original))]=str(old)
subprocess.run(command,cwd=build,check=True)
tokens=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','zyx_transaction_resource_fault_worker'],cwd=root,text=True).strip().splitlines()[-1]);start=tokens.index('&&')+1;end=tokens.index('&&',start) if '&&' in tokens[start:] else len(tokens);link=tokens[start:end]
index=0
while index<len(link):
 if link[index]=='-Xlinker' and index+1<len(link) and link[index+1].startswith('--dependency-file='):del link[index:index+2]
 else:index+=1
link.insert(link.index('libzyx_core.a'),'/tmp/zyx-const-physical-allocation-receipt.o');link[link.index('-o')+1]='/tmp/zyx-const-physical-receipt-worker';subprocess.run(link,cwd=build,check=True)
environment=dict(os.environ,LLVM_PROFILE_FILE='/dev/null')
with tempfile.TemporaryDirectory(prefix='zyx-physical-receipt-') as temporary:
 def run(binary,name,fault=None):
  args=[binary,'scratch-write-allocation-fault',str(Path(temporary)/(name+'.zyx'))]
  if fault is not None:args.append(str(fault))
  r=subprocess.run(args,cwd=root,env=environment,capture_output=True,text=True,check=True)
  return json.loads(r.stdout)
 current='/tmp/zyx-safe-scratch-worker';previous='/tmp/zyx-const-physical-receipt-worker'
 newProbe=run(current,'new-probe');oldProbe=run(previous,'old-probe')
 if oldProbe['allocation_attempts'] != newProbe['allocation_attempts']+1:raise RuntimeError('physical receipt control did not isolate exactly one copy allocation')
 fault=newProbe['allocation_attempts']
 oldFault=run(previous,'old-fault',fault);newFault=run(current,'new-fault',fault)
 if not(oldFault['fault_triggered'] and oldFault['operation_threw'] and oldFault['requires_recovery']):raise RuntimeError('old physical receipt did not require recovery after its post-publication copy failure')
 if newFault['fault_triggered'] or newFault['operation_threw'] or newFault['requires_recovery']:raise RuntimeError('fixed physical receipt allocated after returning from metadata publication')
 report={'new_probe':newProbe,'old_probe':oldProbe,'selected_fault':fault,'old_fault':oldFault,'fixed_at_same_fault':newFault,'isolated_copy_allocations_removed':1,'passed':True}
 Path('/tmp/zyx-negative-physical-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

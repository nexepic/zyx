from pathlib import Path
import gzip,json,subprocess,hashlib
r=Path('/workspace/zyx'); out=Path(__file__).parent
p=next((r/'benchmarks/architecture-design/decisions/20261017-bounded-property-name-batches/raw').glob('*regression-provenance*')); prior=json.loads(gzip.decompress(p.read_bytes())); modules=prior['modules']
extra=['metadata/test_MetadataPublicationReclaimBatch','metadata/test_MetadataPagePool','metadata/test_MetadataPagePoolRecovery','metadata/test_MetadataPagePoolEmergencyReserve','metadata/test_MetadataPagePool_AllocationAvailability','metadata/test_MetadataSnapshotRegistry','metadata/test_MetadataPoolReclaimHeadroom','metadata/test_MetadataDirectoryEvacuation','metadata/test_LocationDirectory','metadata/test_LocationDirectory_RouteValidation','entity/test_NativeGraphWritePlanner','entity/test_NativeGraphWritePlanner_Durability','entity/test_NativeGraphWritePlanner_LeaseRecovery','entity/test_NativeGraphWritePlanner_FreshPoolReplacement','entity/test_NativeGraphWritePlanner_SharedPoolFallback','backend/test_RelocatablePropertyRowChunkFaults','backend/test_RelocatablePropertyRowChunkLifecycle','backend/test_RelocatableLogicalGraphReadSnapshot','backend/test_RelocatableBoundProgramAdmission','metadata/test_RelocatableMetadataStoreValidation','metadata/test_RelocatableMetadataStoreGraphMutation_Deferred','metadata/test_RelocatableMetadataStoreGraphMutation','metadata/test_RelocatableMetadataStore']
modules+=['tests/src/storage/relocatable/'+s+'.cpp' for s in extra]
modules+=['tests/src/query/execution/test_'+s+'.cpp' for s in ['BoundExecutionProgram','BoundSlotRegistry','BoundNodeColumnPredicates','BoundExpressionInputs','BoundNodeScanBatch','BoundProjectionReferences','BoundColumnLayout','BoundPropertyBindings','LogicalPlanMutationRuntime','LogicalPlanMutationRuntime_Atomicity']]
modules=sorted(set(modules));assert len(modules)==48,len(modules);objects=['CMakeFiles/zyx_test_suite.dir/'+s+'.o' for s in modules]
subprocess.run(['cmake','--build','buildDir','--target','zyx_core',*objects,'-j','2'],cwd=r,check=True)
link=prior['link'];start=next(i for i,s in enumerate(link) if 'CMakeFiles/zyx_test_suite.dir/' in s);end=start
while end<len(link) and 'CMakeFiles/zyx_test_suite.dir/' in link[end]:end+=1
link[start:end]=[str(r/'buildDir'/s) for s in objects];binary=Path('/tmp/zyx-final-publication-tests');link[link.index('-o')+1]=str(binary);subprocess.run(link,cwd=r/'buildDir',check=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
(out/'provenance.json').write_text(json.dumps({'modules':modules,'module_count':48,'full_suite':False,'binary':str(binary),'binary_sha256':sha(binary),'core_sha256':sha(r/'buildDir/libzyx_core.a'),'link':link},indent=2)+'\n')
subprocess.run([str(binary),'--gtest_output=xml:'+str(out/'tests.xml')],cwd=r,check=True)

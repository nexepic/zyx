#include "storage/relocatable/backend/RelocatableStorageBackendTestFixture.hpp"
#include "graph/storage/relocatable/entity/NativeGraphWritePlanner.hpp"
#include "graph/query/execution/MaterializedByteBudget.hpp"
#include "CypherParserImpl.hpp"
#include "graph/storage/relocatable/schema/SystemCatalog.hpp"
#include "graph/storage/relocatable/schema/ConstraintSupportTree.hpp"
#include "graph/storage/relocatable/adjacency/CoveredAdjacencyCandidate.hpp"
#include "graph/storage/relocatable/vector/VectorPageStore.hpp"
#include "graph/storage/relocatable/property/LargeValueStore.hpp"
#include "graph/storage/relocatable/vector/VectorManifestStore.hpp"
#include "graph/storage/relocatable/vector/VectorSemanticCodec.hpp"
#include "graph/storage/LogicalGraphTransactionOverlay.hpp"
#include "graph/storage/LogicalGraphTransactionMemoryProvider.hpp"
#include <iostream>
#include "graph/storage/relocatable/index/IndexKeyCodec.hpp"
#include "graph/storage/relocatable/index/BulkBTreeBuilder.hpp"
#include "graph/storage/relocatable/index/NativeBulkRun.hpp"
#include "graph/storage/relocatable/maintenance/RelocatableIntegrityScanner.hpp"
#include "graph/storage/relocatable/maintenance/NativeStorageAllocationCensus.hpp"
#include "graph/storage/relocatable/property/HybridPropertyDirectoryIntegrity.hpp"

using namespace graph;
using namespace graph::storage;
namespace {
// Test-only transaction: the real overlay owns staged final states. It cannot
// publish to the read-only file and carries the same retained private account.
class ReadControlOverlayTransaction final : public LogicalGraphTransaction, public LogicalGraphTransactionMemoryProvider {
    std::unique_ptr<LogicalGraphReadSnapshot> source_;
    std::shared_ptr<std::pmr::memory_resource> memory_;
    uint64_t next_node_ = 1000, next_edge_ = 10000; bool active_ = true;
public:
    ReadControlOverlayTransaction(std::unique_ptr<LogicalGraphReadSnapshot> source, std::shared_ptr<std::pmr::memory_resource> memory)
        : source_(std::move(source)), memory_(std::move(memory)) {}
    LogicalGraphTransactionState state() const override { return active_ ? LogicalGraphTransactionState::LGTTS_ACTIVE : LogicalGraphTransactionState::LGTTS_ROLLED_BACK; }
    bool isReadOnly() const override { return false; }
    LogicalGraphReadSnapshot &readSnapshot() override { return *source_; }
    std::shared_ptr<std::pmr::memory_resource> retainedWriteMemory() const override { return memory_; }
    LogicalGraphMutationBatchResult previewMutationBatch(const LogicalGraphMutationBatch &batch) const override {
        if (!active_) throw std::logic_error("test overlay transaction has ended");
        LogicalGraphMutationBatchResult result;
        for (size_t i = 0; i < batch.node_creates.size(); ++i) result.created_node_ids.push_back(next_node_ + i);
        for (size_t i = 0; i < batch.edge_creates.size(); ++i) result.created_edge_ids.push_back(next_edge_ + i);
        return result;
    }
    LogicalGraphMutationBatchResult stageMutationBatch(LogicalGraphMutationBatch batch) override {
        auto result = previewMutationBatch(batch); next_node_ += batch.node_creates.size(); next_edge_ += batch.edge_creates.size(); return result;
    }
    LogicalGraphMutationBatchResult commit() override { throw std::logic_error("read control overlay cannot publish"); }
    void rollback() override { active_ = false; }
};
class HybridPropertyQueryParityTest : public relocatable_storage_backend_test::RelocatableStorageBackendTest {
protected:
    using Rows = std::vector<std::vector<PropertyValue>>;
    const std::array<std::string, 7> queries{{
        "MATCH (n:Person) WHERE n.age >= 20 AND n.age < 25 RETURN n.age AS age ORDER BY age",
        "MATCH (n:Person) RETURN count(n) AS count, sum(n.age) AS total",
        "MATCH (n:Person) WHERE n.age = 7 RETURN n.note AS note, n.missing AS missing",
        "MATCH (n:Person) WHERE n.age < 3 OPTIONAL MATCH (n)-[r:KNOWS]->(m) RETURN n.age AS age, count(r) AS edges ORDER BY age",
        "MATCH (n)-[r:KNOWS]->(m) WHERE n.age < 4 RETURN n.age AS source, r.weight AS weight, m.age AS target ORDER BY source, weight, target",
        "MATCH (n:Person) RETURN n.age AS age ORDER BY age DESC LIMIT 3",
        "MATCH (n)-[r:KNOWS]->(m) RETURN r.weight AS weight, m.age AS age, m.note AS note, m.missing AS missing ORDER BY weight"
    }};
    void seed(bool propertyIndex = true, bool constraint = false, bool firstSolo = false, bool interleavedEdges = false, size_t edgeCount = 64, bool hotSource = false, bool mixedUntyped = false, bool vectors = false, size_t nodeCount = 64) {
        materializeNativeDatabase(); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        std::vector<LogicalGraphNodeCreateRequest> nodes;
        for (int64_t i = 0; i < int64_t(nodeCount); ++i)
            nodes.push_back({{firstSolo && i == 0 ? "Solo" : "Person"}, {{"age", PropertyValue(i)}, {"note", PropertyValue(i == 7 ? "seven" : "person")}}});
        if (vectors) for (size_t i = 0; i < nodes.size(); ++i)
            nodes[i].properties.emplace_back("embedding", PropertyValue(std::vector<PropertyValue>{PropertyValue(int64_t(i)), PropertyValue(int64_t(1))}));
        const auto ids = backend.createLogicalNodes(nodes); ASSERT_EQ(ids.size(), nodeCount);
        std::vector<LogicalGraphEdgeCreateRequest> edges;
        for (size_t i = 0; i < edgeCount; ++i)
            edges.push_back({ids[hotSource ? 0U : i / 2U], ids[interleavedEdges ? ((i % 32U) * 13U) % 32U : (i / 2U + 1U) % ids.size()], mixedUntyped && i % 3U == 0U ? "" : "KNOWS", {{"weight", PropertyValue(int64_t(i))}}});
        ASSERT_EQ(backend.createLogicalEdges(edges).size(), edgeCount);
        if (propertyIndex) static_cast<void>(backend.createLogicalNodeIndex({"person_age", "Person", {"age"}}));
        if (vectors) static_cast<void>(backend.createLogicalNodeVectorIndex({"person_embedding", "Person", "embedding", 2, "l2"}));
        if (constraint) static_cast<void>(backend.createLogicalConstraint({"person_age_required",
            LogicalGraphConstraintEntityKind::LGCEK_NODE, LogicalGraphConstraintKind::LGCK_NOT_NULL,
            "Person", {"age"}, LogicalGraphConstraintPropertyType::LGCPT_NONE}));
        backend.close();
    }
    std::array<Rows, 7> read() {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        query::execution::LogicalPlanReadRuntime runtime(backend);
        query::execution::LogicalPlanReadRuntimeBounds bounds;
        bounds.maximum_node_records = 128; bounds.maximum_edge_records = 256; bounds.maximum_edges_per_node = 128;
        bounds.maximum_node_page_records = 16; bounds.maximum_metadata_pages_per_node_page = 8192;
        bounds.maximum_adjacency_page_records = 16; bounds.maximum_property_entries = 16; bounds.maximum_rows = 1024; bounds.maximum_distinct_rows = 1024;
        parser::cypher::CypherParserImpl parser; std::array<Rows, 7> output;
        for (size_t i = 0; i < queries.size(); ++i) {
            auto plan = parser.parseToLogical(queries[i]);
            const auto result = runtime.executeToQueryResult(*plan.root, bounds);
            for (const auto &row : result.getRows()) {
                std::vector<PropertyValue> values;
                for (const auto &column : result.getColumns()) values.push_back(row.at(column).asPrimitive());
                output[i].push_back(std::move(values));
            }
        }
        backend.close(); return output;
    }
    static constexpr uint64_t COVERED_INDEX = 700;
    void buildCovered(bool removeOne = false, bool wrongNeighbor = false, size_t edgeCount = 64) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); EntityPageStore entities(io, *metadata);
        SlottedPagePool pages(io, *metadata); BTreePageStore trees(pages, *metadata);
        EntityLabelSetStore labels(io, *metadata, pages); PropertyCollectionRootStore roots(pages, *metadata);
        NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
        options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), 902};
        NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options); auto tx = planner.beginTransaction();
        std::vector<BTreePageEntry> entries;
        for (uint64_t id = 1; id <= edgeCount; ++id) {
            const auto edge = entities.readEdge(tx.baseSnapshot(), id);
            for (const auto direction : {GlobalAdjacencyDirection::GAD_OUT, GlobalAdjacencyDirection::GAD_IN}) {
                if (removeOne && id == 1 && direction == GlobalAdjacencyDirection::GAD_IN) continue;
                auto record = CoveredAdjacencyCandidate::entry(direction, id, edge.source_node_id, edge.target_node_id, edge.type_id);
                if (wrongNeighbor && id == 1 && direction == GlobalAdjacencyDirection::GAD_OUT) LittleEndianCodec::writeU64(record.value, 0, 64);
                const auto encoded = CoveredAdjacencyCandidate::Map::encode(record.key, record.value);
                entries.push_back({std::vector<std::byte>(encoded.begin(), encoded.end()), 0});
            }
        }
        std::sort(entries.begin(), entries.end(), [](const auto &a, const auto &b) { return a.key < b.key; });
        const OrderedBTreeEntrySource source = [&]() -> OrderedBTreeEntryCursor {
            return [&, ordinal = size_t{0}]() mutable -> std::optional<BTreePageEntry> {
                if (ordinal == entries.size()) return {}; return entries[ordinal++];
            };
        };
        const BulkBTreeBuildOptions build{PhysicalSlotId(40), PhysicalSlotId(180), COVERED_INDEX, entries.size(), 32, BTreeLeafValueLayout::BLVL_EMPTY};
        tx.stageScalarIndexCreate(trees, BulkBTreeBuilder::planNativeTree(trees, *metadata, tx.baseSnapshot(), COVERED_INDEX, source, build));
        ASSERT_TRUE(tx.commit().committed()); io->flushStream();
    }
    std::array<Rows, 7> controlRows(bool covered, std::shared_ptr<query::execution::MaterializedByteBudget> memory, bool boundExpansion = false, bool multiHop = false) {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        auto snapshot = covered ? backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory) : backend.openLogicalGraphReadSnapshot();
        query::execution::LogicalPlanReadRuntime runtime(backend);
        query::execution::LogicalPlanReadRuntimeBounds bounds;
        bounds.maximum_node_records = 128; bounds.maximum_edge_records = 256; bounds.maximum_edges_per_node = 128;
        bounds.maximum_node_page_records = 16; bounds.maximum_metadata_pages_per_node_page = 8192;
        bounds.maximum_adjacency_page_records = 16; bounds.maximum_property_entries = 16; bounds.maximum_rows = 1024; bounds.maximum_distinct_rows = 1024;
        const std::array<std::vector<std::string>, 7> columns{{{"age"}, {"count", "total"}, {"note", "missing"}, {"age", "edges"},
            {"source", "weight", "target"}, {"age"}, {"weight", "age", "note", "missing"}}};
        parser::cypher::CypherParserImpl parser; std::array<Rows, 7> output;
        for (size_t i = 0; i < queries.size(); ++i) {
            const auto text = multiHop && i == 6 ?
                "MATCH (n:Person) WHERE n.age = 0 WITH n MATCH (n)-[:KNOWS*2]->(m) RETURN 0 AS weight, m.age AS age, m.note AS note, m.missing AS missing ORDER BY age" : boundExpansion && i == 6 ?
                "MATCH (n:Person) WHERE n.age = 0 WITH n MATCH (n)-[r:KNOWS]->(m) RETURN r.weight AS weight, m.age AS age, m.note AS note, m.missing AS missing ORDER BY weight" : queries[i];
            auto plan = parser.parseToLogical(text);
            (void)runtime.executeWithSnapshot(*snapshot, *plan.root, bounds, [&](const auto &row) {
                std::vector<PropertyValue> values;
                for (const auto &column : columns[i]) values.push_back(std::get<PropertyValue>(row.values.at(column)));
                output[i].push_back(std::move(values)); return true;
            }, {});
        }
        snapshot.reset(); EXPECT_EQ(memory->used(), 0U); backend.close(); return output;
    }
    NativeStorageAllocationFootprint wholeCost() {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::openReadOnly(io); auto pin = metadata->openSnapshot();
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        const auto epoch = io->dataMutationEpoch(); const auto cost = NativeStorageAllocationCensus(io, *metadata, memory).inspect(pin);
        if (!cost || !cost->fullyAttributed()) throw std::runtime_error("incomplete whole allocation proof");
        EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(io->dataMutationEpoch(), epoch); return *cost;
    }
    void addCatalogControl(bool unknown, size_t unusedTokens = 0, uint32_t vectorDimensions = 0, bool vectorToken = true) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io);
        EntityPageStore entities(io, *metadata); SlottedPagePool pages(io, *metadata);
        BTreePageStore trees(pages, *metadata); EntityLabelSetStore labels(io, *metadata, pages);
        PropertyCollectionRootStore roots(pages, *metadata); SystemCatalog catalog(trees, *metadata);
        NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
        options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), 902};
        NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options);
        auto tx = planner.beginTransaction(); auto session = catalog.beginWrite(tx);
        for (size_t i = 0; i < unusedTokens; ++i) (void)session.ensurePropertyToken("unused_" + std::to_string(i));
        if (vectorDimensions) {
            IndexDefinition definition; definition.name = "vector_control"; definition.kind = IndexDefinitionKind::IDK_VECTOR;
            definition.entity_kind = IndexDefinitionEntityKind::IDEK_NODE;
            definition.label_token_id = session.ensureSchemaToken(SystemCatalogSchemaTokenKind::SCSTK_LABEL, "Person");
            definition.property_names = {"embedding"}; definition.vector_dimensions = vectorDimensions; definition.vector_metric = "l2";
            if (vectorToken) (void)session.ensurePropertyToken("embedding");
            (void)session.createIndexDefinition(definition);
        }
        session.setConfiguration("read_hint", PropertyValue(int64_t(7))); session.finish();
        if (unknown) {
            const std::array<std::byte, 2> key{std::byte{254}, std::byte{1}};
            tx.stageScalarIndexUpsert(trees, RSS_SYSTEM_CATALOG_INDEX_ID, key, 1);
        }
        ASSERT_TRUE(tx.commit().committed()); io->flushStream();
    }
    void setAge(int64_t value, bool expectRefusal = false, bool eraseOwner = false, uint64_t ownerOverride = 0) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        ASSERT_TRUE(file->is_open()); auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io);
        // Writable-open recovery may repair pool bitmaps before the first
        // writer. Complete it through an independently checked metadata-only
        // lease before asserting that schema refusal does no private IO.
        if (expectRefusal) (void)metadata->reserveNativeGraphLogicalIds(1, 0);
        auto old = metadata->openSnapshot();
        const uint64_t owner = ownerOverride ? ownerOverride : eraseOwner ? 64 : 1;
        SlottedPagePool pages(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        BTreePageStore trees(pages, *metadata); SystemCatalog catalog(trees, *metadata);
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto catalogRoot = metadata->findIndexRoot(old, RSS_SYSTEM_CATALOG_INDEX_ID);
        const auto catalogLocation = metadata->findPageLocation(old, catalogRoot.root_page_id);
        const auto statistics = catalog.readGraphCardinalityStatistics(old);
        PropertyCollectionRootStore roots(pages, *metadata); const auto beforeRoot = roots.readEntity(old, {EntityPropertyOwnerKind::EPOK_NODE, owner});
        std::vector<uint64_t> ageIndexes;
        for (const auto &definition : catalog.readIndexDefinitions(old, 128))
            if (definition.entity_kind == IndexDefinitionEntityKind::IDEK_NODE && definition.kind == IndexDefinitionKind::IDK_PROPERTY &&
                definition.property_names.size() == 1 && definition.property_names.front() == "age") ageIndexes.push_back(definition.index_id);
        const auto age = std::ranges::find(beforeRoot.entries, *token, &PropertyCollectionRootEntry::key_token);
        ASSERT_NE(age, beforeRoot.entries.end());
        const auto oldKey = IndexKeyCodec::encodeEntryKey(age->value, owner);
        const auto newKey = IndexKeyCodec::encodeEntryKey(PropertyValue(value), owner);
        const auto before = old.superblock(); const auto epoch = io->dataMutationEpoch();
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        const std::array<NativeHybridPropertyColumnReplacement, 1> cells{{
            {{EntityPropertyOwnerKind::EPOK_NODE, owner}, *token, value, false}}};
        const std::array<EntityPropertyKey, 1> deleted{{{EntityPropertyOwnerKind::EPOK_NODE, owner}}};
        NativeHybridPropertyColumnWrite change{before.database_id, before.generation, before.hybrid_property_descriptor_root,
            eraseOwner ? std::span<const NativeHybridPropertyColumnReplacement>{} : std::span(cells),
            memory, PhysicalSlotId(40), PhysicalSlotId(180), 903, nullptr, true,
            eraseOwner ? std::span(deleted) : std::span<const EntityPropertyKey>{}};
        if (expectRefusal) {
            EXPECT_THROW((void)metadata->mutateHybridPropertyColumns(change, LogSequenceNumber(before.checkpoint_lsn.value() + 1)), FormatException);
            EXPECT_EQ(metadata->openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        } else {
            EXPECT_NO_THROW((void)metadata->mutateHybridPropertyColumns(change, LogSequenceNumber(before.checkpoint_lsn.value() + 1)));
            auto current = metadata->openSnapshot();
            if (eraseOwner) {
                EXPECT_NE(metadata->findPageLocation(current, metadata->findIndexRoot(current, RSS_SYSTEM_CATALOG_INDEX_ID).root_page_id), catalogLocation);
                ASSERT_TRUE(statistics); const auto counts = catalog.readGraphCardinalityStatistics(current); ASSERT_TRUE(counts);
                EXPECT_EQ(counts->node_count, statistics->node_count - 1); EXPECT_EQ(counts->edge_count, statistics->edge_count);
                EXPECT_FALSE(metadata->findNodePageLocationOptional(current, owner));
            } else {
                EXPECT_EQ(metadata->findIndexRoot(current, RSS_SYSTEM_CATALOG_INDEX_ID), catalogRoot);
                EXPECT_EQ(catalog.readGraphCardinalityStatistics(current), statistics);
                const auto cell = roots.readEntityPropertyOptional(current, {EntityPropertyOwnerKind::EPOK_NODE, owner}, *token);
                ASSERT_TRUE(cell); EXPECT_EQ(cell->value, PropertyValue(value));
            }
            for (const auto index : ageIndexes) {
                BTreeIndex tree(index, trees, *metadata);
                if (eraseOwner) EXPECT_FALSE(tree.find(current, newKey));
                else EXPECT_EQ(tree.find(current, newKey), std::optional<uint64_t>(owner));
                if (eraseOwner || oldKey != newKey) EXPECT_FALSE(tree.find(current, oldKey));
                EXPECT_EQ(tree.find(old, oldKey), std::optional<uint64_t>(owner));
            }
        }
        EXPECT_EQ(roots.readEntity(old, {EntityPropertyOwnerKind::EPOK_NODE, owner}), beforeRoot);
        EXPECT_EQ(memory->used(), 0U); io->flushStream();
    }
    void setEmbedding(const PropertyValue &value, bool refuse) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); (void)metadata->reserveNativeGraphLogicalIds(1, 0);
        auto old = metadata->openSnapshot();
        SlottedPagePool pages(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        BTreePageStore trees(pages, *metadata); SystemCatalog catalog(trees, *metadata);
        const auto token = catalog.findPropertyToken(old, "embedding"); ASSERT_TRUE(token);
        const auto definitions = catalog.readIndexDefinitions(old, 128);
        const auto definition = std::ranges::find(definitions, IndexDefinitionKind::IDK_VECTOR, &IndexDefinition::kind);
        ASSERT_NE(definition, definitions.end()); const auto index = definition->index_id;
        const auto mapping = metadata->findIndexRoot(old, index);
        const auto manifest = metadata->findVectorManifest(old, index);
        const auto mappingPage = metadata->findPageLocation(old, mapping.root_page_id);
        const auto manifestPage = metadata->findPageLocation(old, manifest.manifest_page_id);
        PropertyCollectionRootStore roots(pages, *metadata);
        const EntityPropertyKey owner{EntityPropertyOwnerKind::EPOK_NODE, 1};
        const auto previous = roots.readEntityPropertyOptional(old, owner, *token); ASSERT_TRUE(previous);
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        const std::array<NativeHybridPropertyColumnReplacement, 1> cells{{{owner, *token, OwnedPropertyValue(value), false}}};
        const auto before = old.superblock(); const auto epoch = io->dataMutationEpoch();
        NativeHybridPropertyColumnWrite request{before.database_id, before.generation, before.hybrid_property_descriptor_root,
            cells, memory, PhysicalSlotId(40), PhysicalSlotId(180), 903, nullptr, true};
        if (refuse) {
            EXPECT_THROW((void)metadata->mutateHybridPropertyColumns(request, LogSequenceNumber(before.checkpoint_lsn.value() + 1)), FormatException);
            EXPECT_EQ(metadata->openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        } else {
            EXPECT_NO_THROW((void)metadata->mutateHybridPropertyColumns(request, LogSequenceNumber(before.checkpoint_lsn.value() + 1)));
            auto current = metadata->openSnapshot();
            EXPECT_EQ(metadata->findIndexRoot(current, index), mapping); EXPECT_EQ(metadata->findVectorManifest(current, index), manifest);
            EXPECT_EQ(metadata->findPageLocation(current, mapping.root_page_id), mappingPage);
            EXPECT_EQ(metadata->findPageLocation(current, manifest.manifest_page_id), manifestPage);
            const auto final = roots.readEntityPropertyOptional(current, owner, *token); ASSERT_TRUE(final); EXPECT_EQ(final->value, value);
        }
        const auto retained = roots.readEntityPropertyOptional(old, owner, *token); ASSERT_TRUE(retained);
        EXPECT_EQ(retained->value, previous->value); EXPECT_EQ(memory->used(), 0U); io->flushStream();
    }
    enum class NativeVectorTestAction { NVTA_NONE, NVTA_CANCEL, NVTA_ALL_OWNERS, NVTA_PROBE_STAGING, NVTA_CONSTRAINT_FAILURE, NVTA_SECOND_OWNER, NVTA_ROW_NOOP };
    void coordinateVectorField(const PropertyValue &value, bool erase = false, bool eraseOwner = false,
        bool preparationFailure = false, size_t maximumBytes = 1024 * 1024, MetadataPublishOptions publishOptions = {},
        NativeVectorTestAction action = NativeVectorTestAction::NVTA_NONE) {
        const bool cancelBeforeCommit = action == NativeVectorTestAction::NVTA_CANCEL;
        const bool allOwners = action == NativeVectorTestAction::NVTA_ALL_OWNERS;
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); (void)metadata->reserveNativeGraphLogicalIds(1, 0);
        SlottedPagePool pages(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        BTreePageStore trees(pages, *metadata); SystemCatalog catalog(trees, *metadata);
        EntityPageStore entities(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        EntityLabelSetStore labels(io, *metadata, pages, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        VectorPageStore raw(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        VectorManifestStore manifests(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        LargeValueStore values(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        PropertyCollectionRootStore roots(pages, values, *metadata); auto old = metadata->openSnapshot();
        const auto token = catalog.findPropertyToken(old, "embedding"); ASSERT_TRUE(token);
        const auto definitions = catalog.readIndexDefinitions(old, 128);
        const auto definition = std::ranges::find(definitions, IndexDefinitionKind::IDK_VECTOR, &IndexDefinition::kind);
        ASSERT_NE(definition, definitions.end()); const auto index = definition->index_id;
        const uint64_t id = eraseOwner ? 64 : action == NativeVectorTestAction::NVTA_SECOND_OWNER ? 2 : 1; const EntityPropertyKey owner{EntityPropertyOwnerKind::EPOK_NODE, id};
        const auto before = roots.readEntityPropertyOptional(old, owner, *token);
        const auto previousCounts = catalog.readGraphCardinalityStatistics(old);
        const auto oldVector = metadata->findIndexRootOptional(old, index) ?
            BTreeIndex(index, trees, *metadata).find(old, VectorSemanticCodec::nodeMappingKey(id)) : std::nullopt;
        std::vector<std::byte> oldRaw;
        if (oldVector) {
            const auto route = metadata->findVectorLocation(old, *oldVector);
            oldRaw = raw.read(old, route.page_id).read(route.slot_id, route.slot_generation);
        }
        struct Cancel final : CancellationCheckpoint {
            bool armed = false, probe = false; NativeGraphWriteTransaction *transaction = nullptr;
            BTreePageStore *trees = nullptr; uint64_t index = 0; mutable size_t rejected = 0, unexpected = 0;
            void check() const override {
                if (armed) throw std::runtime_error("Vector commit cancelled");
                if (probe && transaction) {
                    try { transaction->stageScalarIndexUpsert(*trees, index, VectorSemanticCodec::nodeMappingKey(999), 1); ++unexpected; }
                    catch (const FormatException &) { ++rejected; }
                }
            }
        } cancellation;
        cancellation.probe = action == NativeVectorTestAction::NVTA_PROBE_STAGING;
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(maximumBytes);
        {
            NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
            options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), 903};
            NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options); auto tx = planner.beginTransaction();
            std::vector<NativeHybridPropertyColumnReplacement> cells;
            for (uint64_t target = 1; target <= (allOwners ? 64U : 1U); ++target)
                cells.push_back({allOwners ? EntityPropertyKey{EntityPropertyOwnerKind::EPOK_NODE, target} : owner, *token, OwnedPropertyValue(value), erase});
            const std::array<EntityPropertyKey, 1> deleted{owner};
            if (eraseOwner) tx.stageHybridPropertyOwnerDeletion(deleted, memory, &cancellation);
            else tx.stageHybridPropertyColumns(cells, memory, &cancellation, true);
            cancellation.transaction = &tx; cancellation.trees = &trees; cancellation.index = index;
            const auto epoch = io->dataMutationEpoch();
            const NativeGraphVectorDeltaOptions vectorOptions{PhysicalSlotId(40), PhysicalSlotId(180), 128, 64, 1024, 4096, 64};
            if (preparationFailure) {
                if (maximumBytes < 1024 * 1024)
                    EXPECT_THROW(tx.coordinateHybridPropertyVectors(raw, manifests, vectorOptions), query::execution::MaterializedByteLimitExceeded);
                else EXPECT_THROW(tx.coordinateHybridPropertyVectors(raw, manifests, vectorOptions), std::invalid_argument);
                EXPECT_THROW((void)tx.commit(), FormatException);
                auto moved = std::move(tx); NativeGraphWriteTransaction assigned; assigned = std::move(moved);
                EXPECT_THROW((void)assigned.commit(), FormatException); assigned.rollback();
                EXPECT_EQ(metadata->openSnapshot().superblock(), old.superblock()); EXPECT_EQ(io->dataMutationEpoch(), epoch);
                EXPECT_EQ(memory->used(), 0U); return;
            }
            tx.coordinateHybridPropertyVectors(raw, manifests, vectorOptions);
            if (cancelBeforeCommit) {
                cancellation.armed = true; EXPECT_THROW((void)tx.commit(), std::runtime_error);
                EXPECT_EQ(tx.state(), NativeGraphWriteTransactionState::NGWTS_ACTIVE);
                EXPECT_EQ(metadata->openSnapshot().superblock(), old.superblock()); EXPECT_EQ(io->dataMutationEpoch(), epoch);
                cancellation.armed = false;
            }
            // A successful coordinator must retain its account and typed store
            // bindings across both move construction and move assignment.
            auto moved = std::move(tx); NativeGraphWriteTransaction ready; ready = std::move(moved);
            cancellation.transaction = &ready;
            if (action == NativeVectorTestAction::NVTA_CONSTRAINT_FAILURE) {
                bool rejected = false;
                try { (void)ready.commit(); }
                catch (const std::runtime_error &error) {
                    rejected = true; EXPECT_NE(std::string_view(error.what()).find("duplicate key"), std::string_view::npos);
                }
                EXPECT_TRUE(rejected);
                EXPECT_EQ(metadata->openSnapshot().superblock(), old.superblock()); EXPECT_EQ(io->dataMutationEpoch(), epoch);
                EXPECT_EQ(memory->used(), 0U); return;
            }
            if (publishOptions.bootstrap_failpoint != BootstrapPublishFailpoint::BPF_NONE) {
                EXPECT_THROW((void)ready.commit(publishOptions), BootstrapPublishInterrupted);
                EXPECT_EQ(ready.state(), NativeGraphWriteTransactionState::NGWTS_INDETERMINATE);
                const auto retained = roots.readEntityPropertyOptional(old, owner, *token);
                ASSERT_EQ(bool(retained), bool(before)); if (before) EXPECT_EQ(retained->value, before->value);
                if (oldVector) {
                    const auto route = metadata->findVectorLocation(old, *oldVector);
                    EXPECT_EQ(raw.read(old, route.page_id).read(route.slot_id, route.slot_generation), oldRaw);
                }
                EXPECT_EQ(memory->used(), 0U); io->flushStream(); return;
            }
            const auto result = ready.commit(); ASSERT_TRUE(result.committed());
            if (action == NativeVectorTestAction::NVTA_ROW_NOOP) {
                EXPECT_EQ(result.superblock, old.superblock()); EXPECT_EQ(io->dataMutationEpoch(), epoch);
            } else EXPECT_EQ(result.superblock.generation.value(), old.superblock().generation.value() + 1);
            if (cancellation.probe) { EXPECT_GT(cancellation.rejected, 0U); EXPECT_EQ(cancellation.unexpected, 0U); }
        }
        auto current = metadata->openSnapshot();
        const auto after = roots.readEntityPropertyOptional(current, owner, *token);
        if (eraseOwner || erase) EXPECT_FALSE(after); else { ASSERT_TRUE(after); EXPECT_EQ(after->value, value); }
        if (eraseOwner) EXPECT_FALSE(metadata->findNodePageLocationOptional(current, id));
        const auto vector = BTreeIndex(index, trees, *metadata).find(current, VectorSemanticCodec::nodeMappingKey(id));
        if (eraseOwner || erase) EXPECT_FALSE(vector); else {
            ASSERT_TRUE(vector); if (oldVector) {
                if (action == NativeVectorTestAction::NVTA_ROW_NOOP) EXPECT_EQ(vector, oldVector);
                else EXPECT_NE(vector, oldVector);
            }
            const auto location = metadata->findVectorLocation(current, *vector);
            EXPECT_NO_THROW((void)raw.read(current, location.page_id).read(location.slot_id, location.slot_generation));
        }
        if (oldVector) {
            EXPECT_EQ(bool(metadata->findVectorLocationOptional(current, *oldVector)), action == NativeVectorTestAction::NVTA_ROW_NOOP);
            const auto route = metadata->findVectorLocation(old, *oldVector);
            EXPECT_EQ(raw.read(old, route.page_id).read(route.slot_id, route.slot_generation), oldRaw);
        }
        if (action == NativeVectorTestAction::NVTA_SECOND_OWNER && erase) {
            const auto previousDelta = manifests.read(old, index).manifest().delta_mapping_index_id;
            ASSERT_NE(previousDelta, 0U); EXPECT_TRUE(metadata->findIndexRootOptional(old, previousDelta));
            EXPECT_FALSE(metadata->findIndexRootOptional(current, previousDelta));
            EXPECT_EQ(manifests.read(current, index).manifest().delta_mapping_index_id, 0U);
        }
        const auto retained = roots.readEntityPropertyOptional(old, owner, *token);
        ASSERT_EQ(bool(retained), bool(before)); if (before) EXPECT_EQ(retained->value, before->value);
        if (previousCounts) {
            const auto counts = catalog.readGraphCardinalityStatistics(current); ASSERT_TRUE(counts);
            EXPECT_EQ(counts->node_count, previousCounts->node_count - size_t(eraseOwner)); EXPECT_EQ(counts->edge_count, previousCounts->edge_count);
        }
        if (allOwners) for (uint64_t target = 1; target <= 64; ++target) {
            const EntityPropertyKey key{EntityPropertyOwnerKind::EPOK_NODE, target};
            const auto cell = roots.readEntityPropertyOptional(current, key, *token); ASSERT_TRUE(cell); EXPECT_EQ(cell->value, value);
            const auto retained = roots.readEntityPropertyOptional(old, key, *token); ASSERT_TRUE(retained);
            EXPECT_EQ(retained->value, PropertyValue(std::vector<PropertyValue>{PropertyValue(int64_t(target - 1)), PropertyValue(int64_t(1))}));
            const auto oldId = BTreeIndex(index, trees, *metadata).find(old, VectorSemanticCodec::nodeMappingKey(target)); ASSERT_TRUE(oldId);
            EXPECT_FALSE(metadata->findVectorLocationOptional(current, *oldId));
        }
        EXPECT_EQ(memory->used(), 0U);
        auto inspection = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, *metadata, inspection).scan()); EXPECT_EQ(inspection->used(), 0U);
        io->flushStream();
    }
    NativeBulkRunFragmentLocation makeOrphanScratch(SegmentKind kind) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); PhysicalSegmentAllocator physical(io, *metadata);
        NativeBulkRunStoreOptions options{PhysicalSlotId(40), PhysicalSlotId(180)}; options.scratch_kind = kind;
        NativeBulkRunStore store(physical, *metadata, options);
        const auto before = metadata->openSnapshot().superblock();
        const auto location = store.writeOpaquePayload(71, {std::byte{0x11}}, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        io->flushStream(); return location;
    }
    void applyPublicNativePatch(RelocatableStorageBackend &backend, std::vector<LogicalGraphWriteProperty> sets,
        std::vector<std::string> removals = {}) {
        auto source = backend.openLogicalGraphReadSnapshot(); const auto fence = source->mutationFence(); ASSERT_TRUE(fence);
        const std::array<LogicalGraphPropertyPatchRequest, 1> patches{{{
            {LogicalGraphMutationEntityKind::LGMK_NODE, LogicalGraphMutationReferenceKind::LGRK_PERSISTED, 1},
            std::move(sets), std::move(removals)}}};
        (void)backend.executeLogicalGraphMutationBatchWithPropertyPatches(*source, {}, patches, 4096, *fence);
    }
    void inspectPublicNativeState() {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::openReadOnly(io);
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        const auto epoch = io->dataMutationEpoch();
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, *metadata, memory).scan());
        EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(io->dataMutationEpoch(), epoch);
    }
    std::vector<std::pair<uint64_t, float>> exactVectorSearch(std::vector<float> query = {0.0F, 1.0F}) {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open(); auto snapshot = backend.openLogicalGraphVectorSearchSnapshot();
        LogicalGraphVectorSearchRequest request; request.index_name = "person_embedding"; request.query_vector = std::move(query);
        request.top_k = 4; request.mode = LogicalGraphVectorSearchMode::LGVSM_EXACT;
        request.maximum_mapping_entries = 128; request.maximum_raw_vector_reads = 128;
        const auto result = snapshot->searchLogicalVector(request); std::vector<std::pair<uint64_t, float>> hits;
        for (const auto &hit : result.hits) hits.emplace_back(hit.node_id, hit.score);
        return hits;
    }
    void convert(EntityPropertyOwnerKind kind, bool inverse = false) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        ASSERT_TRUE(file->is_open()); auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); const auto before = metadata->openSnapshot().superblock();
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        NativeGraphHybridPropertyConversion conversion{kind, 1, memory, nullptr, PhysicalSlotId(40), PhysicalSlotId(180), 903};
        conversion.publish_candidate = true;
        if (inverse) conversion.direction = NativeHybridPropertyConversionDirection::NHPCD_HYBRID_TO_ROW;
        NativeGraphHybridPropertyRootMutation request{before.database_id, before.hybrid_property_descriptor_root,
            NativeHybridPropertyRootMode::NHPRM_REPLACE, {}, conversion};
        NativeGraphDerivedStateMutation derived;
        static_cast<void>(metadata->mutateNativeGraphPagesWithLargeValues({}, {}, {}, {}, {}, {}, derived,
            LogSequenceNumber(before.checkpoint_lsn.value() + 1), [](auto, auto, auto, auto, auto, auto) {},
            [](auto &) {}, {}, {}, {}, {}, {}, {}, {}, before.generation, {}, {}, {}, {}, {}, request));
        EXPECT_EQ(memory->used(), 0U); io->flushStream();
    }
};
}
TEST_F(HybridPropertyQueryParityTest, ExplicitReadOnlyCoveredControlUsesSameExecutorAndPreservesDuplicateGatherResults) {
    seed(true, false, false, true); buildCovered();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    const auto baseline = controlRows(false, memory, true); int64_t pages = 0;
    std::array<Rows, 7> candidate;
    {
        debug::PerfTrace::ScopedObserver observe(&pages, [](void *context, std::string_view key, int64_t value, bool) noexcept {
            if (key == "logical_graph.covered_candidate.reference_pages") *static_cast<int64_t *>(context) += value;
        });
        candidate = controlRows(true, memory, true);
    }
    EXPECT_EQ(candidate, baseline); EXPECT_GT(pages, 0);
    EXPECT_EQ(candidate[6], (Rows{{PropertyValue(int64_t(0)), PropertyValue(int64_t(0)), PropertyValue("person"), PropertyValue()},
        {PropertyValue(int64_t(1)), PropertyValue(int64_t(13)), PropertyValue("person"), PropertyValue()}}));
    EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredControlRefusesIncompleteCandidateInsteadOfFallingBack) {
    seed(); buildCovered(true); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    EXPECT_THROW((void)backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory), std::exception);
    EXPECT_EQ(memory->used(), 0U); backend.close(); EXPECT_EQ(read()[1][0][0], PropertyValue(int64_t(64)));
}
TEST_F(HybridPropertyQueryParityTest, CoveredControlRefusesCrcValidWrongEndpointAndReturnsItsBudget) {
    seed(); buildCovered(false, true); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    EXPECT_THROW((void)backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory), std::exception);
    EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredControlAuthenticatesExactContinuationsAndReturnsAdmittedBuffers) {
    seed(); buildCovered(); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    auto snapshot = backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory);
    query::execution::MaterializedByteReservation output(memory.get());
    const auto admission = [&](size_t bytes) { output.set(bytes); };
    auto first = snapshot->scanAdjacentEdgeRefsWithBufferAdmission(1, LogicalGraphReadDirection::LGRD_OUTGOING, {}, 1, admission);
    ASSERT_EQ(first.edges.size(), 1U); EXPECT_EQ(first.edges[0].entity_id, 1U); ASSERT_TRUE(first.continuation);
    EXPECT_EQ(output.bytes(), first.edges.capacity() * sizeof(EntityRef));
    const auto continuation = first.continuation; first = {}; output.reset();
    auto second = snapshot->scanAdjacentEdgeRefsWithBufferAdmission(1, LogicalGraphReadDirection::LGRD_OUTGOING, continuation, 1, admission);
    ASSERT_EQ(second.edges.size(), 1U); EXPECT_EQ(second.edges[0].entity_id, 2U); EXPECT_FALSE(second.continuation);
    second = {}; output.reset();
    EXPECT_THROW((void)snapshot->scanAdjacentEdgeRefs(2, LogicalGraphReadDirection::LGRD_OUTGOING, continuation, 1), std::exception);
    EXPECT_THROW((void)snapshot->scanAdjacentEdgeRefs(1, LogicalGraphReadDirection::LGRD_OUTGOING, LogicalGraphAdjacencyContinuation{2, 3}, 1), std::exception);
    EXPECT_THROW((void)snapshot->scanAdjacentEdgeRefs(1, LogicalGraphReadDirection::LGRD_OUTGOING, LogicalGraphAdjacencyContinuation{0, 1}, 1), std::invalid_argument);
    snapshot.reset(); EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredBatchKeepsOrderTotalBoundAndVisitorStopWithoutSourceBufferLeaks) {
    seed(); buildCovered(); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    auto snapshot = backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory);
    query::execution::MaterializedByteReservation output(memory.get());
    const auto admission = [&](size_t bytes) { output.set(bytes); };
    const std::array<uint64_t, 2> nodes{1, 2}; std::vector<uint64_t> ids;
    snapshot->visitAdjacentEdgeRefsForNodesWithBufferAdmission(nodes, LogicalGraphReadDirection::LGRD_OUTGOING, 4,
        [&](const auto &edge) { ids.push_back(edge.entity_id); return true; }, admission);
    EXPECT_EQ(ids, (std::vector<uint64_t>{1, 2, 3, 4})); EXPECT_EQ(output.bytes(), 0U);
    size_t calls = 0;
    snapshot->visitAdjacentEdgeRefsForNodesWithBufferAdmission(nodes, LogicalGraphReadDirection::LGRD_OUTGOING, 4,
        [&](const auto &) { ++calls; return false; }, admission);
    EXPECT_EQ(calls, 1U); EXPECT_EQ(output.bytes(), 0U);
    const std::array<uint64_t, 2> duplicate{1, 1}; calls = 0;
    EXPECT_THROW(snapshot->visitAdjacentEdgeRefsForNodes(duplicate, LogicalGraphReadDirection::LGRD_OUTGOING, 4,
        [&](const auto &) { ++calls; return true; }), FormatException); EXPECT_EQ(calls, 0U);
    EXPECT_THROW(snapshot->visitAdjacentEdgeRefsForNodes(nodes, LogicalGraphReadDirection::LGRD_OUTGOING, 1,
        [&](const auto &) { return true; }), FormatException);
    snapshot.reset(); EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredControlSetupCancellationQuotaAndGraphBoundsRefundTheirAccounts) {
    seed(); buildCovered(); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    struct Cancel final : CancellationCheckpoint { mutable size_t calls = 0; void check() const override { if (++calls == 10) throw std::runtime_error("covered setup cancelled"); } } cancellation;
    try { (void)backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory, &cancellation); FAIL(); }
    catch (const std::runtime_error &error) { EXPECT_EQ(std::string(error.what()), "covered setup cancelled"); }
    EXPECT_EQ(memory->used(), 0U);
    EXPECT_THROW((void)backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 63, 8192, memory), std::exception);
    EXPECT_EQ(memory->used(), 0U);
    auto tiny = std::make_shared<query::execution::MaterializedByteBudget>(65536);
    EXPECT_THROW((void)backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, tiny), query::execution::MaterializedByteLimitExceeded);
    EXPECT_EQ(tiny->used(), 0U);
    EXPECT_THROW((void)backend.openCoveredAdjacencyCandidateReadSnapshot(0, 64, 8192, memory), FormatException);
    EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredReadControlDoesNotGrantAuthorityToAWritableBackend) {
    seed(); buildCovered(); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    EXPECT_THROW((void)backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory), std::invalid_argument);
    EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredSupernodeUsesBoundedPagesAndExactLogicalContinuation) {
    seed(false, false, false, true, 90, true); buildCovered(false, false, 90);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    auto snapshot = backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 90, 8192, memory);
    auto first = snapshot->scanAdjacentEdgeRefs(1, LogicalGraphReadDirection::LGRD_OUTGOING, {}, 80);
    ASSERT_EQ(first.edges.size(), 64U); ASSERT_TRUE(first.continuation);
    EXPECT_EQ(first.continuation->previous_edge_id, 64U); EXPECT_EQ(first.continuation->next_edge_id, 65U);
    auto second = snapshot->scanAdjacentEdgeRefs(1, LogicalGraphReadDirection::LGRD_OUTGOING, first.continuation, 80);
    ASSERT_EQ(second.edges.size(), 26U); EXPECT_FALSE(second.continuation);
    for (size_t i = 0; i < first.edges.size(); ++i) EXPECT_EQ(first.edges[i].entity_id, i + 1);
    for (size_t i = 0; i < second.edges.size(); ++i) EXPECT_EQ(second.edges[i].entity_id, i + 65);
    std::vector<uint64_t> ids; const std::array<uint64_t, 2> nodes{1, 2};
    snapshot->visitAdjacentEdgeRefsForNodes(nodes, LogicalGraphReadDirection::LGRD_OUTGOING, 90,
        [&](const auto &edge) { ids.push_back(edge.entity_id); return true; });
    ASSERT_EQ(ids.size(), 90U); for (size_t i = 0; i < ids.size(); ++i) EXPECT_EQ(ids[i], i + 1);
    snapshot.reset(); EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredEmptyGraphControlProvesAbsentTreeAndStillAuthenticatesTheNode) {
    seed(false, false, false, false, 0);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    auto snapshot = backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 1, 8192, memory);
    EXPECT_TRUE(snapshot->scanAdjacentEdgeRefs(1, LogicalGraphReadDirection::LGRD_OUTGOING, {}, 64).edges.empty());
    EXPECT_THROW((void)snapshot->scanAdjacentEdgeRefs(999, LogicalGraphReadDirection::LGRD_OUTGOING, {}, 64), FormatException);
    EXPECT_THROW((void)snapshot->scanAdjacentEdgeRefs(1, LogicalGraphReadDirection::LGRD_OUTGOING, LogicalGraphAdjacencyContinuation{1, 2}, 64), std::invalid_argument);
    snapshot.reset(); EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredPrototypeCountsBothCanonicalAndCandidatePoolsInWholeAllocation) {
    seed(false, false, false, true, 90, true); const auto baseline = wholeCost();
    buildCovered(false, false, 90); const auto candidate = wholeCost();
    const auto indexes = size_t(NativeStorageAllocationKind::NSAK_QUERY_INDEX);
    EXPECT_EQ(candidate.database_id, baseline.database_id);
    EXPECT_GE(candidate.sealed_pool_bytes[indexes], baseline.sealed_pool_bytes[indexes] + RSS_SEGMENT_SIZE);
    EXPECT_GE(candidate.steadyAllocatedBytes(), baseline.steadyAllocatedBytes() + RSS_SEGMENT_SIZE);
    EXPECT_GE(candidate.totalAllocatedBytes(), candidate.steadyAllocatedBytes() + candidate.retired_catalog_bytes);
    std::cout << "COVERED_CONTROL_COST edges=90 key_only=" << baseline.steadyAllocatedBytes()
        << " candidate=" << candidate.steadyAllocatedBytes() << " retired=" << candidate.retired_catalog_bytes
        << " allocated_peak=" << candidate.totalAllocatedBytes() << " file=" << candidate.file_bytes << '\n';
}
TEST_F(HybridPropertyQueryParityTest, CoveredReferenceControlPreservesRealOverlayDeletesCreatesAndPropertyChanges) {
    seed(true, false, false, true); buildCovered();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    const auto execute = [&](bool covered) {
        Rows result;
        {
            auto source = covered ? backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory) : backend.openLogicalGraphReadSnapshot();
            ReadControlOverlayTransaction transaction(std::move(source), memory);
            {
                LogicalGraphTransactionOverlay overlay(transaction);
                overlay.replaceLogicalNodeProperties({{1, {{"age", PropertyValue(int64_t(100))}, {"note", PropertyValue("overlay")}}}});
                overlay.deleteLogicalEdges({{1}});
                const auto created = overlay.createLogicalEdges({{1, 14, "KNOWS", {{"weight", PropertyValue(int64_t(99))}}}});
                EXPECT_EQ(created, (std::vector<uint64_t>{10000}));
                query::execution::LogicalPlanReadRuntime runtime(overlay); auto snapshot = overlay.openLogicalGraphReadSnapshot();
                parser::cypher::CypherParserImpl parser;
                auto plan = parser.parseToLogical("MATCH (n:Person) WHERE n.age = 100 WITH n MATCH (n)-[r:KNOWS]->(m) RETURN r.weight AS weight, m.age AS age ORDER BY weight");
                query::execution::LogicalPlanReadRuntimeBounds bounds;
                bounds.maximum_node_records = 128; bounds.maximum_edge_records = 256; bounds.maximum_edges_per_node = 128;
                bounds.maximum_node_page_records = 16; bounds.maximum_metadata_pages_per_node_page = 8192;
                bounds.maximum_adjacency_page_records = 16; bounds.maximum_property_entries = 16; bounds.maximum_rows = 1024; bounds.maximum_distinct_rows = 1024;
                (void)runtime.executeWithSnapshot(*snapshot, *plan.root, bounds, [&](const auto &row) {
                    result.push_back({std::get<PropertyValue>(row.values.at("weight")), std::get<PropertyValue>(row.values.at("age"))}); return true;
                }, {});
                EXPECT_THROW((void)transaction.commit(), std::logic_error);
            }
            transaction.rollback();
        }
        EXPECT_EQ(memory->used(), 0U); return result;
    };
    const auto baseline = execute(false); int64_t pages = 0; Rows candidate;
    {
        debug::PerfTrace::ScopedObserver observer(&pages, [](void *context, std::string_view key, int64_t value, bool) noexcept {
            if (key == "logical_graph.covered_candidate.reference_pages") *static_cast<int64_t *>(context) += value;
        });
        candidate = execute(true);
    }
    EXPECT_EQ(candidate, baseline); EXPECT_GT(pages, 0);
    EXPECT_EQ(candidate, (Rows{{PropertyValue(int64_t(1)), PropertyValue(int64_t(13))}, {PropertyValue(int64_t(99)), PropertyValue(int64_t(13))}}));
    backend.close(); EXPECT_EQ(read()[1], (Rows{{PropertyValue(int64_t(64)), PropertyValue(int64_t(2016))}}));
}
TEST_F(HybridPropertyQueryParityTest, CoveredTopologyAdapterPreservesUntypedNamesAndAdmittedBufferLifetime) {
    seed(false, false, false, false, 64, false, true); buildCovered();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    auto baseline = backend.openLogicalGraphReadSnapshot();
    auto candidate = backend.openCoveredAdjacencyCandidateReadSnapshot(COVERED_INDEX, 64, 8192, memory);
    const auto expected = baseline->scanAdjacentEdgeTopologies(1, LogicalGraphReadDirection::LGRD_OUTGOING, {}, 2);
    query::execution::MaterializedByteReservation output(memory.get());
    auto actual = candidate->scanAdjacentEdgeTopologiesWithBufferAdmission(1, LogicalGraphReadDirection::LGRD_OUTGOING, {}, 2,
        [&](size_t bytes) { output.set(bytes); });
    EXPECT_EQ(actual, expected); ASSERT_EQ(actual.edges.size(), 2U);
    EXPECT_TRUE(actual.edges[0].type.empty()); EXPECT_EQ(actual.edges[1].type, "KNOWS");
    size_t retained = actual.edges.capacity() * sizeof(LogicalGraphEdgeTopology);
    for (const auto &edge : actual.edges) retained += edge.type.capacity();
    EXPECT_EQ(output.bytes(), retained); actual = {}; output.reset();
    const auto used = memory->used();
    EXPECT_THROW((void)candidate->scanAdjacentEdgeTopologiesWithBufferAdmission(1, LogicalGraphReadDirection::LGRD_OUTGOING, {}, 2,
        [&](size_t bytes) { if (bytes >= 2U * (sizeof(EntityRef) + sizeof(LogicalGraphEdgeTopology))) throw std::length_error("deny topology conversion"); }), std::length_error);
    EXPECT_EQ(memory->used(), used); candidate.reset(); baseline.reset(); EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, CoveredSameExecutorMultiHopRetainsAllParallelEdgePaths) {
    seed(); buildCovered(); auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    const auto baseline = controlRows(false, memory, false, true); int64_t pages = 0; std::array<Rows, 7> candidate;
    {
        debug::PerfTrace::ScopedObserver observer(&pages, [](void *context, std::string_view key, int64_t value, bool) noexcept {
            if (key == "logical_graph.covered_candidate.reference_pages") *static_cast<int64_t *>(context) += value;
        });
        candidate = controlRows(true, memory, false, true);
    }
    EXPECT_EQ(candidate, baseline); EXPECT_GT(pages, 0);
    EXPECT_EQ(candidate[6], (Rows(4, std::vector<PropertyValue>{PropertyValue(int64_t(0)), PropertyValue(int64_t(2)), PropertyValue("person"), PropertyValue()})));
    EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyQueryParityTest, DefaultProfileRemainsRow) {
#if !ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT
    seed(); const auto rows = read();
    EXPECT_EQ(rows[1], (Rows{{PropertyValue(int64_t(64)), PropertyValue(int64_t(2016))}}));
    EXPECT_THROW(convert(EntityPropertyOwnerKind::EPOK_NODE), FormatException);
    EXPECT_EQ(read(), rows);
#endif
}
#if ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT
TEST_F(HybridPropertyQueryParityTest, SameExecutorPreservesIndexedFilterAggregateOptionalMultiedgesAndLimitAcrossBothLayouts) {
    seed(); const auto row = read();
    ASSERT_EQ(row[1], (Rows{{PropertyValue(int64_t(64)), PropertyValue(int64_t(2016))}}));
    ASSERT_EQ(row[0].size(), 5U); ASSERT_EQ(row[4].size(), 8U); ASSERT_EQ(row[5].size(), 3U);
    convert(EntityPropertyOwnerKind::EPOK_NODE); EXPECT_EQ(read(), row);
    convert(EntityPropertyOwnerKind::EPOK_EDGE); EXPECT_EQ(read(), row);
    convert(EntityPropertyOwnerKind::EPOK_NODE, true); EXPECT_EQ(read(), row);
    convert(EntityPropertyOwnerKind::EPOK_EDGE, true); EXPECT_EQ(read(), row);
}
TEST_F(HybridPropertyQueryParityTest, FieldUpdatesPreserveNonPropertyCatalogStateAndSameExecutorResults) {
    seed(false); addCatalogControl(false); const auto baseline = read(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100); auto expected = baseline;
    expected[1] = Rows{{PropertyValue(int64_t(64)), PropertyValue(int64_t(2116))}};
    for (size_t query : {size_t(3), size_t(4)})
        std::erase_if(expected[query], [](const auto &row) { return row[0] == PropertyValue(int64_t(0)); });
    expected[5] = Rows{{PropertyValue(int64_t(100))}, {PropertyValue(int64_t(63))}, {PropertyValue(int64_t(62))}};
    EXPECT_EQ(read(), expected);
    setAge(0); EXPECT_EQ(read(), baseline);
}
TEST_F(HybridPropertyQueryParityTest, ScalarIndexAndNativeFieldPublishTogetherWithOldPinAndSameExecutorResults) {
    seed(); const auto baseline = read(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100); const auto changed = read();
    EXPECT_EQ(changed[1], (Rows{{PropertyValue(int64_t(64)), PropertyValue(int64_t(2116))}}));
    EXPECT_EQ(changed[5], (Rows{{PropertyValue(int64_t(100))}, {PropertyValue(int64_t(63))}, {PropertyValue(int64_t(62))}}));
    setAge(0); EXPECT_EQ(read(), baseline);
}
TEST_F(HybridPropertyQueryParityTest, UnrelatedFieldPreservesLiveVectorStateAndIndexedOwnerDeletionRefuses) {
    seed(false, false, false, false, 64, false, false, true);
    const auto search = [&] {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        auto snapshot = backend.openLogicalGraphVectorSearchSnapshot();
        LogicalGraphVectorSearchRequest request; request.index_name = "person_embedding";
        request.query_vector = {0.0F, 1.0F}; request.top_k = 4;
        request.mode = LogicalGraphVectorSearchMode::LGVSM_EXACT;
        request.maximum_mapping_entries = 128; request.maximum_raw_vector_reads = 128;
        const auto result = snapshot->searchLogicalVector(request);
        std::vector<std::pair<uint64_t, float>> hits;
        for (const auto &hit : result.hits) hits.emplace_back(hit.node_id, hit.score);
        return hits;
    };
    const auto before = search(); ASSERT_EQ(before.size(), 4U); EXPECT_EQ(before.front().first, 1U);
    convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100); EXPECT_EQ(search(), before);
    setAge(0); EXPECT_EQ(search(), before);
    setEmbedding(PropertyValue(std::vector<PropertyValue>{PropertyValue(0.0), PropertyValue(1.0001)}), false);
    EXPECT_EQ(search(), before);
    setEmbedding(PropertyValue(std::vector<PropertyValue>{PropertyValue(0.0), PropertyValue(2.0)}), true);
    EXPECT_EQ(search(), before);
    setAge(0, true, true); EXPECT_EQ(search(), before);
}
TEST_F(HybridPropertyQueryParityTest, VectorDefinitionWithoutPopulationAllowsUnrelatedFieldAndIsolatedDeletion) {
    seed(false);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    (void)backend.createLogicalNodeVectorIndex({"person_embedding", "Person", "embedding", 2, "l2"}); backend.close();
    convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100); setAge(0); setAge(0, false, true);
    EXPECT_EQ(read()[1], (Rows{{PropertyValue(int64_t(63)), PropertyValue(int64_t(1953))}}));
}
TEST_F(HybridPropertyQueryParityTest, IncompleteVectorPublicationRefusesUnrelatedFieldWithoutPrivateIo) {
    seed(false, false, false, false, 64, false, false, true);
    {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); EntityPageStore entities(io, *metadata);
        SlottedPagePool pages(io, *metadata); BTreePageStore trees(pages, *metadata);
        EntityLabelSetStore labels(io, *metadata, pages); PropertyCollectionRootStore roots(pages, *metadata);
        SystemCatalog catalog(trees, *metadata); auto pin = metadata->openSnapshot();
        const auto definitions = catalog.readIndexDefinitions(pin, 128);
        const auto definition = std::ranges::find(definitions, IndexDefinitionKind::IDK_VECTOR, &IndexDefinition::kind);
        ASSERT_NE(definition, definitions.end()); const auto index = definition->index_id; pin.release();
        NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
        options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), 902};
        NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options); auto tx = planner.beginTransaction();
        tx.stageScalarIndexDrop(trees, index, 128); ASSERT_TRUE(tx.commit().committed()); io->flushStream();
    }
    convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100, true);
}
TEST_F(HybridPropertyQueryParityTest, MissingVectorPropertyTokenCannotBeTreatedAsAnEmptyIndex) {
    seed(false); addCatalogControl(false, 0, 2, false);
    convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100, true);
}
TEST_F(HybridPropertyQueryParityTest, OversizedVectorDimensionsRefuseBeforeWorkspaceOrPhysicalPublication) {
    seed(false); addCatalogControl(false, 0, UINT32_MAX);
    convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100, true);
}
TEST_F(HybridPropertyQueryParityTest, OwnerDeletionRefusesAStaleVectorMappingEvenWhenItsPropertyIsMissing) {
    seed(false, false, false, false, 64, false, false, true);
    {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); EntityPageStore entities(io, *metadata);
        SlottedPagePool pages(io, *metadata); BTreePageStore trees(pages, *metadata);
        EntityLabelSetStore labels(io, *metadata, pages); PropertyCollectionRootStore roots(pages, *metadata);
        SystemCatalog catalog(trees, *metadata); auto pin = metadata->openSnapshot();
        auto properties = roots.readEntity(pin, {EntityPropertyOwnerKind::EPOK_NODE, 64});
        const auto token = catalog.findPropertyToken(pin, "embedding"); ASSERT_TRUE(token);
        ASSERT_EQ(std::erase_if(properties.entries, [&](const auto &entry) { return entry.key_token == *token; }), 1U);
        const auto route = metadata->findEntityPropertyLocationOptional(pin, {EntityPropertyOwnerKind::EPOK_NODE, 64});
        ASSERT_TRUE(route);
        const auto propertyOwner = metadata->findCatalog(pin, metadata->findPageLocation(pin, route->page_id).segment_id).owner_id;
        pin.release();
        NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
        options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), propertyOwner};
        NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options); auto tx = planner.beginTransaction();
        // Deliberately use the low-level property primitive without its semantic
        // Vector coordinator to leave a well-formed but stale mapping.
        tx.replaceNodeProperty(properties); ASSERT_TRUE(tx.commit().committed()); io->flushStream();
    }
    convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(0, true, true);
}
TEST_F(HybridPropertyQueryParityTest, OwnerOutsideVectorLabelScopeCanDeleteWhileOtherOwnersKeepLiveVectors) {
    seed(false, false, true, false, 0, false, false, true);
    const auto before = read(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(0, false, true, 1); EXPECT_EQ(read(), before);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorDeltaAndFieldPublishInOneGenerationWithPinnedOldRawAndExactReopen) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(100.0), PropertyValue(100.0)}));
    const auto result = exactVectorSearch(); ASSERT_EQ(result.size(), 4U); EXPECT_EQ(result.front().first, 2U); EXPECT_FLOAT_EQ(result.front().second, 1.0F);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorBootstrapThenLastFieldEraseAndRecreateRemainAtomic) {
    seed(false); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    (void)backend.createLogicalNodeVectorIndex({"person_embedding", "Person", "embedding", 2, "l2"}); backend.close();
    convert(EntityPropertyOwnerKind::EPOK_NODE);
    const PropertyValue value(std::vector<PropertyValue>{PropertyValue(0.0), PropertyValue(1.0)});
    coordinateVectorField(value); ASSERT_EQ(exactVectorSearch().size(), 1U);
    coordinateVectorField(PropertyValue(), true); EXPECT_TRUE(exactVectorSearch().empty());
    coordinateVectorField(value); const auto result = exactVectorSearch(); ASSERT_EQ(result.size(), 1U); EXPECT_EQ(result.front().first, 1U);
}
TEST_F(HybridPropertyQueryParityTest, NativeIndexedOwnerDeletionPublishesVectorRemovalFieldsAndCountsTogether) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(), false, true);
    const auto result = exactVectorSearch({63.0F, 1.0F}); ASSERT_EQ(result.size(), 4U); EXPECT_EQ(result.front().first, 63U);
    EXPECT_EQ(read()[1], (Rows{{PropertyValue(int64_t(63)), PropertyValue(int64_t(1953))}}));
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorInvalidValueSealsCommitAcrossMovesAndRefundsOnRollback) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(1.0)}), false, false, true);
    const auto result = exactVectorSearch(); ASSERT_FALSE(result.empty()); EXPECT_EQ(result.front().first, 1U);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorQuotaRefusalSealsCommitWithoutWritingAndRefundsOnRollback) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(100.0), PropertyValue(100.0)}), false, false, true, 65536);
    const auto result = exactVectorSearch(); ASSERT_FALSE(result.empty()); EXPECT_EQ(result.front().first, 1U);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorAndPropertyRecoverTogetherAtBothBootstrapInterruptionBoundaries) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    const PropertyValue previous(std::vector<PropertyValue>{PropertyValue(int64_t(0)), PropertyValue(int64_t(1))});
    const PropertyValue replacement(std::vector<PropertyValue>{PropertyValue(100.0), PropertyValue(100.0)});
    for (const auto point : {BootstrapPublishFailpoint::BPF_AFTER_PARTIAL_INACTIVE_WRITE, BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE}) {
        MetadataPublishOptions publish; publish.bootstrap_failpoint = point;
        coordinateVectorField(replacement, false, false, false, 1024 * 1024, publish);
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open(); auto snapshot = backend.openLogicalGraphReadSnapshot();
        EXPECT_EQ(snapshot->readNodeProperty(1, "embedding"), point == BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE ? replacement : previous);
        snapshot.reset(); backend.close();
        const auto result = exactVectorSearch(); ASSERT_FALSE(result.empty());
        EXPECT_EQ(result.front().first, point == BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE ? 2U : 1U);
    }
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorKnownPrepublicationCancellationPreservesPlanForRetryAcrossMoves) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(100.0), PropertyValue(100.0)}), false, false, false, 1024 * 1024, {}, NativeVectorTestAction::NVTA_CANCEL);
    const auto result = exactVectorSearch(); ASSERT_FALSE(result.empty()); EXPECT_EQ(result.front().first, 2U);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorMaximum64OwnerBatchKeepsOldPinsAndFitsTheOriginalOneMiBAccount) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(100.0), PropertyValue(100.0)}), false, false, false, 1024 * 1024, {}, NativeVectorTestAction::NVTA_ALL_OWNERS);
    const auto result = exactVectorSearch(); ASSERT_EQ(result.size(), 4U);
    for (size_t i = 0; i < result.size(); ++i) { EXPECT_EQ(result[i].first, i + 1U); EXPECT_FLOAT_EQ(result[i].second, 19801.0F); }
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorCoordinationCallbacksCannotAppendUnrelatedScalarWork) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(100.0), PropertyValue(100.0)}), false, false, false,
        1024 * 1024, {}, NativeVectorTestAction::NVTA_PROBE_STAGING);
    const auto result = exactVectorSearch(); ASSERT_FALSE(result.empty()); EXPECT_EQ(result.front().first, 2U);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorLargeArrayAndIndependentValueManifestShareTheAtomicPublication) {
    seed(false); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    (void)backend.createLogicalNodeVectorIndex({"person_embedding", "Person", "embedding", 512, "l2"}); backend.close();
    convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>(512, PropertyValue(1.0))));
    auto result = exactVectorSearch(std::vector<float>(512, 1.0F)); ASSERT_EQ(result.size(), 1U); EXPECT_FLOAT_EQ(result.front().second, 0.0F);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>(512, PropertyValue(2.0))));
    result = exactVectorSearch(std::vector<float>(512, 1.0F)); ASSERT_EQ(result.size(), 1U); EXPECT_FLOAT_EQ(result.front().second, 512.0F);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorUniqueSupportPublishesTogetherAndDuplicateRefusesBeforePrivateIo) {
    seed(false, false, false, false, 64, false, false, true);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    (void)backend.createLogicalConstraint({"unique_embedding", LogicalGraphConstraintEntityKind::LGCEK_NODE,
        LogicalGraphConstraintKind::LGCK_UNIQUE, "Person", {"embedding"}, LogicalGraphConstraintPropertyType::LGCPT_NONE}); backend.close();
    convert(EntityPropertyOwnerKind::EPOK_NODE);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(100.0), PropertyValue(100.0)}));
    const auto before = exactVectorSearch(); ASSERT_FALSE(before.empty()); EXPECT_EQ(before.front().first, 2U);
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(int64_t(1)), PropertyValue(int64_t(1))}), false, false,
        false, 1024 * 1024, {}, NativeVectorTestAction::NVTA_CONSTRAINT_FAILURE);
    EXPECT_EQ(exactVectorSearch(), before);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorLastInsertOnlyDeltaRetiresItsRootAndKeepsTheBaseAndOldPin) {
    seed(false); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    (void)backend.createLogicalNodeVectorIndex({"person_embedding", "Person", "embedding", 2, "l2"}); backend.close();
    convert(EntityPropertyOwnerKind::EPOK_NODE);
    const PropertyValue value(std::vector<PropertyValue>{PropertyValue(0.0), PropertyValue(1.0)});
    coordinateVectorField(value);
    coordinateVectorField(value, false, false, false, 1024 * 1024, {}, NativeVectorTestAction::NVTA_SECOND_OWNER);
    ASSERT_EQ(exactVectorSearch().size(), 2U);
    coordinateVectorField(PropertyValue(), true, false, false, 1024 * 1024, {}, NativeVectorTestAction::NVTA_SECOND_OWNER);
    const auto result = exactVectorSearch(); ASSERT_EQ(result.size(), 1U); EXPECT_EQ(result.front().first, 1U); EXPECT_FLOAT_EQ(result.front().second, 0.0F);
}
TEST_F(HybridPropertyQueryParityTest, NativeVectorSignedZeroRowNoopKeepsBothAuthoritiesAndPerformsNoPrivateIo) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setEmbedding(PropertyValue(std::vector<PropertyValue>{PropertyValue(0.0), PropertyValue(1.0)}), false);
    const auto before = exactVectorSearch();
    coordinateVectorField(PropertyValue(std::vector<PropertyValue>{PropertyValue(-0.0), PropertyValue(1.0)}), false, false, false,
        1024 * 1024, {}, NativeVectorTestAction::NVTA_ROW_NOOP);
    EXPECT_EQ(exactVectorSearch(), before);
}
TEST_F(HybridPropertyQueryParityTest, OrdinaryTopologyCreatesAndDeletesRowOwnersOutsideNativeGroups) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); ASSERT_NO_THROW(backend.open()); auto old = backend.openLogicalGraphReadSnapshot();
    const auto nodes = backend.createLogicalNodes({{{"Person"}, {{"age", PropertyValue(int64_t(75))}}}});
    ASSERT_EQ(nodes.size(), 1U); ASSERT_GT(nodes.front(), 64U);
    const auto edges = backend.createLogicalEdges({{1, nodes.front(), "KNOWS", {{"weight", PropertyValue(int64_t(1000))}}}});
    ASSERT_EQ(edges.size(), 1U);
    auto current = backend.openLogicalGraphReadSnapshot(); EXPECT_EQ(current->readNodeProperty(nodes.front(), "age"), PropertyValue(int64_t(75)));
    EXPECT_EQ(current->readNodeProperty(1, "age"), PropertyValue(int64_t(0)));
    EXPECT_EQ(old->readNodeProperty(1, "age"), PropertyValue(int64_t(0))); current.reset();
    backend.deleteLogicalEdges({{edges.front()}}); backend.deleteLogicalNodes({{nodes.front(), false, 0}});
    old.reset(); backend.close(); EXPECT_EQ(read(), baseline);
}
TEST_F(HybridPropertyQueryParityTest, OrdinaryTopologyRelabelPreservesNativeValuesAndMaintainsScalarMembership) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); ASSERT_NO_THROW(backend.open()); auto old = backend.openLogicalGraphReadSnapshot();
    LogicalGraphMutationBatch batch;
    batch.node_label_replacements.push_back({{LogicalGraphMutationEntityKind::LGMK_NODE, LogicalGraphMutationReferenceKind::LGRK_PERSISTED, 1}, {"Solo"}});
    (void)backend.executeLogicalGraphMutationBatch(batch);
    auto current = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(current->readNodeProperty(1, "age"), PropertyValue(int64_t(0))); EXPECT_EQ(old->readNodeProperty(1, "age"), PropertyValue(int64_t(0)));
    current.reset(); batch.node_label_replacements.front().labels = {"Person"}; (void)backend.executeLogicalGraphMutationBatch(batch);
    old.reset(); backend.close(); EXPECT_EQ(read(), baseline);
}
TEST_F(HybridPropertyQueryParityTest, OrdinaryTopologyRelabelCoordinatesVectorScopeWithoutChangingItsNativeField) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); ASSERT_NO_THROW(backend.open());
    LogicalGraphMutationBatch batch;
    batch.node_label_replacements.push_back({{LogicalGraphMutationEntityKind::LGMK_NODE, LogicalGraphMutationReferenceKind::LGRK_PERSISTED, 1}, {"Solo"}});
    (void)backend.executeLogicalGraphMutationBatch(batch); backend.close();
    auto result = exactVectorSearch(); ASSERT_FALSE(result.empty()); EXPECT_EQ(result.front().first, 2U);
    backend.open(); auto snapshot = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(snapshot->readNodeProperty(1, "embedding"), PropertyValue(std::vector<PropertyValue>{PropertyValue(int64_t(0)), PropertyValue(int64_t(1))}));
    snapshot.reset(); batch.node_label_replacements.front().labels = {"Person"}; (void)backend.executeLogicalGraphMutationBatch(batch); backend.close();
    result = exactVectorSearch(); ASSERT_FALSE(result.empty()); EXPECT_EQ(result.front().first, 1U);
}
TEST_F(HybridPropertyQueryParityTest, OrdinaryTopologyReopenSkipsUnusedNativeGroupIdsWithoutChangingItsLiveness) {
    seed(false, false, false, false, 64, false, false, false, 48); convert(EntityPropertyOwnerKind::EPOK_NODE);
    const auto before = read(); auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    const auto ids = backend.createLogicalNodes({{{"Person"}, {{"age", PropertyValue(int64_t(75))}}}});
    ASSERT_EQ(ids.size(), 1U); EXPECT_GT(ids.front(), 64U);
    auto snapshot = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(snapshot->readNodeProperty(1, "age"), PropertyValue(int64_t(0)));
    EXPECT_EQ(snapshot->readNodeProperty(ids.front(), "age"), PropertyValue(int64_t(75)));
    snapshot.reset(); backend.deleteLogicalNodes({{ids.front(), false, 0}});
    backend.close(); EXPECT_EQ(read(), before);
}
TEST_F(HybridPropertyQueryParityTest, PublicNativePropertyReplacementMaintainsScalarIndexAndPinnedValues) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); auto old = backend.openLogicalGraphReadSnapshot();
    backend.replaceLogicalNodeProperties({{1, {{"age", PropertyValue(int64_t(100))}, {"note", PropertyValue("updated")}}}});
    auto current = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(current->readNodeProperty(1, "age"), PropertyValue(int64_t(100)));
    EXPECT_EQ(current->readNodeProperty(1, "note"), PropertyValue("updated"));
    EXPECT_EQ(old->readNodeProperty(1, "age"), PropertyValue(int64_t(0)));
    current.reset(); old.reset(); backend.close();
    EXPECT_NE(read(), baseline); backend.open();
    backend.replaceLogicalNodeProperties({{1, {{"age", PropertyValue(int64_t(0))}, {"note", PropertyValue("person")}}}});
    backend.close(); EXPECT_EQ(read(), baseline); inspectPublicNativeState();
}
TEST_F(HybridPropertyQueryParityTest, PublicNativePropertyReplacementCoordinatesVectorAndPreservesOldSnapshot) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); auto old = backend.openLogicalGraphReadSnapshot();
    const PropertyValue previous(std::vector<PropertyValue>{PropertyValue(int64_t(0)), PropertyValue(int64_t(1))});
    backend.replaceLogicalNodeProperties({{1, {{"age", PropertyValue(int64_t(0))}, {"note", PropertyValue("person")},
        {"embedding", PropertyValue(std::vector<PropertyValue>{PropertyValue(int64_t(1000)), PropertyValue(int64_t(1))})}}}});
    EXPECT_EQ(old->readNodeProperty(1, "embedding"), previous); old.reset(); backend.close();
    auto result = exactVectorSearch(); ASSERT_FALSE(result.empty()); EXPECT_EQ(result.front().first, 2U);
    backend.open(); backend.replaceLogicalNodeProperties({{1, {{"age", PropertyValue(int64_t(0))},
        {"note", PropertyValue("person")}, {"embedding", previous}}}}); backend.close();
    result = exactVectorSearch(); ASSERT_FALSE(result.empty()); EXPECT_EQ(result.front().first, 1U); inspectPublicNativeState();
}
TEST_F(HybridPropertyQueryParityTest, PublicNativePropertyReplacementEnforcesRequiredFieldsAndExistingTokens) {
    seed(true, true); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    try {
        backend.replaceLogicalNodeProperties({{1, {{"note", PropertyValue("missing age")}}}});
        FAIL() << "required native field was removed";
    } catch (const std::runtime_error &error) {
        EXPECT_NE(std::string(error.what()).find("Constraint violation"), std::string::npos);
    }
    EXPECT_THROW(backend.replaceLogicalNodeProperties({{1, {{"new_field", PropertyValue(int64_t(1))}}}}), FormatException);
    backend.close(); EXPECT_EQ(read(), baseline);
}
TEST_F(HybridPropertyQueryParityTest, PublicNativePropertyReplacementAccepts64OwnersAndPreservesNoopGeneration) {
    seed(false); convert(EntityPropertyOwnerKind::EPOK_NODE);
    const auto generation = [&] {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::openReadOnly(io); return metadata->openSnapshot().superblock().generation;
    };
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    std::vector<LogicalGraphPropertyReplaceRequest> replacements;
    for (uint64_t id = 1; id <= 64; ++id)
        replacements.push_back({id, {{"age", PropertyValue(int64_t(id))}, {"note", PropertyValue(id == 8 ? "seven" : "person")}}});
    backend.replaceLogicalNodeProperties(replacements); const auto after = generation();
    backend.replaceLogicalNodeProperties(replacements); EXPECT_EQ(generation(), after);
    auto snapshot = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(snapshot->readNodeProperty(1, "age"), PropertyValue(int64_t(1)));
    EXPECT_EQ(snapshot->readNodeProperty(64, "age"), PropertyValue(int64_t(64)));
    snapshot.reset(); backend.close();
}
TEST_F(HybridPropertyQueryParityTest, PublicNativePropertyReplacementRefusesMixedRoutesWithoutChangingEitherOwner) {
    seed(false); convert(EntityPropertyOwnerKind::EPOK_NODE);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    const auto ids = backend.createLogicalNodes({{{"Person"}, {{"age", PropertyValue(int64_t(75))}}}});
    ASSERT_EQ(ids.size(), 1U); ASSERT_GT(ids.front(), 64U);
    EXPECT_THROW(backend.replaceLogicalNodeProperties({{1, {{"age", PropertyValue(int64_t(100))}}},
        {ids.front(), {{"age", PropertyValue(int64_t(101))}}}}), FormatException);
    auto snapshot = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(snapshot->readNodeProperty(1, "age"), PropertyValue(int64_t(0)));
    EXPECT_EQ(snapshot->readNodeProperty(ids.front(), "age"), PropertyValue(int64_t(75)));
    snapshot.reset(); backend.close(); inspectPublicNativeState();
}
TEST_F(HybridPropertyQueryParityTest, NativeWritableReopenReclaimsOrphanQueryScratchAndPreservesFields) {
    seed(false); const auto scratch = makeOrphanScratch(SegmentKind::SGK_QUERY_SCRATCH).segment_id;
    convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); ASSERT_NO_THROW(backend.open()); backend.close();
    EXPECT_EQ(read(), baseline); inspectPublicNativeState();
    auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::binary);
    auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
    auto metadata = RelocatableMetadataStore::openReadOnly(io); auto pin = metadata->openSnapshot();
    EXPECT_EQ(metadata->findCatalog(pin, scratch).state, SegmentState::SGS_OBSOLETE);
}
TEST_F(HybridPropertyQueryParityTest, NativeWritableReopenReclaimsOrphanBulkScratchAndPreservesFields) {
    seed(false); const auto scratch = makeOrphanScratch(SegmentKind::SGK_BULK_SCRATCH);
    convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); ASSERT_NO_THROW(backend.open()); backend.close();
    EXPECT_EQ(read(), baseline); inspectPublicNativeState();
    auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::binary);
    auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
    auto metadata = RelocatableMetadataStore::openReadOnly(io); auto pin = metadata->openSnapshot(); bool found = false;
    metadata->visitCatalogEntries(pin, [&](const auto &entry) { found |= entry.segment_id == scratch.segment_id; }); EXPECT_FALSE(found);
}
TEST_F(HybridPropertyQueryParityTest, NativeBulkScratchRetirementWaitsForOldPinThenRecoversWithoutChangingFields) {
    seed(false); const auto scratch = makeOrphanScratch(SegmentKind::SGK_BULK_SCRATCH); convert(EntityPropertyOwnerKind::EPOK_NODE);
    {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); PhysicalSegmentAllocator physical(io, *metadata);
        NativeBulkRunStore store(physical, *metadata, {PhysicalSlotId(40), PhysicalSlotId(180)});
        auto old = metadata->openSnapshot(); const auto slot = metadata->findCatalog(old, scratch.segment_id).physical_slot;
        store.release(scratch, LogSequenceNumber(old.superblock().checkpoint_lsn.value() + 1));
        auto current = metadata->openSnapshot(); EXPECT_EQ(metadata->findCatalog(current, scratch.segment_id).state, SegmentState::SGS_RETIRED);
        EXPECT_TRUE(metadata->isPhysicalSlotAllocated(current, slot));
        EXPECT_EQ(store.readOpaquePayload(old, scratch), std::vector<std::byte>{std::byte{0x11}});
        const auto lsn = LogSequenceNumber(current.superblock().checkpoint_lsn.value() + 1); current.release(); old.release();
        store.reclaimUnpublishedOnOpen(lsn); auto reclaimed = metadata->openSnapshot(); EXPECT_FALSE(metadata->isPhysicalSlotAllocated(reclaimed, slot)); io->flushStream();
    }
    inspectPublicNativeState(); EXPECT_EQ(read()[0].size(), 5U);
}
TEST_F(HybridPropertyQueryParityTest, NativeActiveLayoutAllowsFreshPrivateScratchWithoutChangingGraphValues) {
    seed(false); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    for (const auto kind : {SegmentKind::SGK_QUERY_SCRATCH, SegmentKind::SGK_BULK_SCRATCH}) {
        const auto scratch = makeOrphanScratch(kind); EXPECT_TRUE(scratch.isValid());
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
        RelocatableStorageBackend backend(options); ASSERT_NO_THROW(backend.open()); backend.close();
        EXPECT_EQ(read(), baseline); inspectPublicNativeState();
    }
}
TEST_F(HybridPropertyQueryParityTest, NativeSegmentNamespaceReservationPreservesFieldsAcrossBothBootstrapFaults) {
    seed(false); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    for (const auto point : {BootstrapPublishFailpoint::BPF_AFTER_PARTIAL_INACTIVE_WRITE, BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE}) {
        uint64_t beforeId;
        {
            auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
            auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
            auto metadata = RelocatableMetadataStore::open(io); const auto before = metadata->openSnapshot().superblock(); beforeId = before.next_logical_segment_id;
            MetadataPublishOptions options; options.bootstrap_failpoint = point;
            EXPECT_THROW((void)metadata->allocateLogicalSegmentIds(1, LogSequenceNumber(before.checkpoint_lsn.value() + 1), options), std::runtime_error); io->flushStream();
        }
        {
            auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::binary);
            auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
            auto metadata = RelocatableMetadataStore::openReadOnly(io);
            EXPECT_EQ(metadata->openSnapshot().superblock().next_logical_segment_id,
                beforeId + (point == BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE ? 1U : 0U));
        }
        EXPECT_EQ(read(), baseline); inspectPublicNativeState();
    }
}
TEST_F(HybridPropertyQueryParityTest, PublicNativePatchUpdatesScalarAndRemovesFieldWithoutChangingOldSnapshot) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); auto old = backend.openLogicalGraphReadSnapshot();
    applyPublicNativePatch(backend, {{"age", PropertyValue(int64_t(100))}}, {"note"});
    auto current = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(current->readNodeProperty(1, "age"), PropertyValue(int64_t(100)));
    EXPECT_EQ(current->readNodeProperty(1, "note"), PropertyValue());
    EXPECT_EQ(old->readNodeProperty(1, "note"), PropertyValue("person")); old.reset(); current.reset();
    applyPublicNativePatch(backend, {{"age", PropertyValue(int64_t(0))}, {"note", PropertyValue("person")}});
    backend.close(); EXPECT_EQ(read(), baseline); inspectPublicNativeState();
}
TEST_F(HybridPropertyQueryParityTest, PublicNativePatchErasesAndRecreatesVectorFieldAtomically) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    applyPublicNativePatch(backend, {}, {"embedding"}); backend.close();
    auto results = exactVectorSearch(); ASSERT_FALSE(results.empty()); EXPECT_EQ(results.front().first, 2U);
    backend.open(); applyPublicNativePatch(backend, {{"embedding", PropertyValue(std::vector<PropertyValue>{PropertyValue(int64_t(0)), PropertyValue(int64_t(1))})}});
    backend.close(); results = exactVectorSearch(); ASSERT_FALSE(results.empty()); EXPECT_EQ(results.front().first, 1U); inspectPublicNativeState();
}
TEST_F(HybridPropertyQueryParityTest, PublicNativePatchPreservesUnknownRemovalNoopAndRejectsRequiredFieldRemoval) {
    seed(true, true); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto baseline = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); auto old = backend.openLogicalGraphReadSnapshot();
    const auto fence = old->mutationFence(); applyPublicNativePatch(backend, {}, {"unknown_field"});
    auto current = backend.openLogicalGraphReadSnapshot(); EXPECT_EQ(current->mutationFence(), fence); current.reset(); old.reset();
    try { applyPublicNativePatch(backend, {}, {"age"}); FAIL() << "required field was removed"; }
    catch (const std::runtime_error &error) { EXPECT_NE(std::string(error.what()).find("Constraint violation"), std::string::npos); }
    backend.close(); EXPECT_EQ(read(), baseline); inspectPublicNativeState();
}
TEST_F(HybridPropertyQueryParityTest, PublicNativeOwnerDeletionRemovesIsolatedNodeAndKeepsOldPins) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); auto old = backend.openLogicalGraphReadSnapshot();
    backend.deleteLogicalNodes({{64, false, 0}});
    EXPECT_EQ(old->readNodeProperty(64, "age"), PropertyValue(int64_t(63)));
    auto current = backend.openLogicalGraphReadSnapshot(); EXPECT_EQ(current->readNodeProperty(1, "age"), PropertyValue(int64_t(0)));
    old.reset(); current.reset(); backend.close(); inspectPublicNativeState();
    auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::binary);
    auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
    auto metadata = RelocatableMetadataStore::openReadOnly(io); auto pin = metadata->openSnapshot();
    EXPECT_FALSE(metadata->findNodePageLocationOptional(pin, 64));
}
TEST_F(HybridPropertyQueryParityTest, PublicNativeOwnerDeletionMaintainsConvertedEdgeAdjacencyAndCounts) {
    seed(false); convert(EntityPropertyOwnerKind::EPOK_EDGE);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); auto old = backend.openLogicalGraphReadSnapshot();
    backend.deleteLogicalEdges({{1}}); EXPECT_EQ(old->readEdgeProperty(1, "weight"), PropertyValue(int64_t(0)));
    old.reset(); backend.close(); inspectPublicNativeState();
    const auto rows = read()[6]; ASSERT_EQ(rows.size(), 63U); EXPECT_EQ(rows.front()[0], PropertyValue(int64_t(1)));
}
TEST_F(HybridPropertyQueryParityTest, PublicNativeOwnerDeletionRemovesVectorMembershipAndPreservesOldEmbedding) {
    seed(false, false, false, false, 64, false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); auto old = backend.openLogicalGraphReadSnapshot();
    backend.deleteLogicalNodes({{64, false, 0}});
    EXPECT_EQ(old->readNodeProperty(64, "embedding"), PropertyValue(std::vector<PropertyValue>{PropertyValue(int64_t(63)), PropertyValue(int64_t(1))}));
    old.reset(); backend.close(); inspectPublicNativeState();
    const auto results = exactVectorSearch({63.0F, 1.0F}); ASSERT_FALSE(results.empty()); EXPECT_EQ(results.front().first, 63U);
    for (const auto &result : results) EXPECT_NE(result.first, 64U);
}
TEST_F(HybridPropertyQueryParityTest, PublicNativeOwnerDeletionRemovesComplete64EdgeGroupAndPreservesPinnedRows) {
    seed(false); convert(EntityPropertyOwnerKind::EPOK_EDGE);
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); auto old = backend.openLogicalGraphReadSnapshot();
    std::vector<LogicalGraphEdgeDeleteRequest> requests;
    for (uint64_t id = 1; id <= 64; ++id) requests.push_back({id});
    backend.deleteLogicalEdges(requests);
    EXPECT_EQ(old->readEdgeProperty(1, "weight"), PropertyValue(int64_t(0)));
    EXPECT_EQ(old->readEdgeProperty(64, "weight"), PropertyValue(int64_t(63)));
    old.reset(); backend.close(); inspectPublicNativeState(); EXPECT_TRUE(read()[6].empty());
}
TEST_F(HybridPropertyQueryParityTest, PublicNativeOwnerDeletionRejectsIncidentNodesAndUnsupportedDetachWithoutChangingFields) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto before = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    EXPECT_THROW(backend.deleteLogicalNodes({{1, false, 0}}), FormatException);
    EXPECT_THROW(backend.deleteLogicalNodes({{1, true, 64}}), FormatException);
    backend.close(); EXPECT_EQ(read(), before); inspectPublicNativeState();
}
TEST_F(HybridPropertyQueryParityTest, OrdinaryTopologyRefusesUnknownCatalogControlsBeforeChangingLabels) {
    seed(false); addCatalogControl(true); convert(EntityPropertyOwnerKind::EPOK_NODE); const auto before = read();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); LogicalGraphMutationBatch batch;
    batch.node_label_replacements.push_back({{LogicalGraphMutationEntityKind::LGMK_NODE, LogicalGraphMutationReferenceKind::LGRK_PERSISTED, 1}, {"Solo"}});
    EXPECT_THROW((void)backend.executeLogicalGraphMutationBatch(batch), FormatException); backend.close(); EXPECT_EQ(read(), before);
}
TEST_F(HybridPropertyQueryParityTest, OrdinaryTopologyProofIsNotGrantedToUncoordinatedNativeTransactions) {
    seed(false); convert(EntityPropertyOwnerKind::EPOK_NODE);
    auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
    auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
    auto metadata = RelocatableMetadataStore::open(io); (void)metadata->reserveNativeGraphLogicalIds(1, 0);
    EntityPageStore entities(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
    SlottedPagePool pages(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY); BTreePageStore trees(pages, *metadata);
    EntityLabelSetStore labels(io, *metadata, pages, SharedPagePoolOpenMode::SPPOM_READ_ONLY); PropertyCollectionRootStore roots(pages, *metadata);
    NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
    options.entity_pool_owner_id = 1; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), 1};
    NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options); auto old = metadata->openSnapshot();
    const auto before = old.superblock(); const auto epoch = io->dataMutationEpoch(); auto tx = planner.beginTransaction();
    tx.replaceNodeLabels(1, {}); EXPECT_THROW((void)tx.commit(), FormatException);
    EXPECT_EQ(metadata->openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
    EXPECT_EQ(roots.readEntityPropertyOptional(old, {EntityPropertyOwnerKind::EPOK_NODE, 1}, 1)->value, PropertyValue(int64_t(0)));
}
TEST_F(HybridPropertyQueryParityTest, NonNullConstraintAllowsValidFieldPublication) {
    seed(false, true); const auto baseline = read(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100); setAge(0); EXPECT_EQ(read(), baseline);
}
TEST_F(HybridPropertyQueryParityTest, IsolatedOwnerDeletionCoordinatesCatalogCountsAndLabelPropertyIndexes) {
    seed(true, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100, false, true);
    EXPECT_EQ(read()[1], (Rows{{PropertyValue(int64_t(63)), PropertyValue(int64_t(1953))}}));
}
TEST_F(HybridPropertyQueryParityTest, UnknownCatalogControlNamespaceCannotBypassFieldCoordination) {
    seed(false); addCatalogControl(true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100, true);
}
TEST_F(HybridPropertyQueryParityTest, UnrelatedTokenDictionarySizeIsNotAFieldMutationLifetimeCap) {
    seed(false); addCatalogControl(false, 4097); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100); const auto result = read();
    EXPECT_EQ(result[1], (Rows{{PropertyValue(int64_t(64)), PropertyValue(int64_t(2116))}}));
}

namespace {
class HybridPropertyIndexedLifecycleTest : public HybridPropertyQueryParityTest {
protected:
    void compositeIndex() {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        (void)backend.createLogicalNodeIndex({"person_age_note", "Person", {"age", "note"}}); backend.close();
    }
    void edgeIndex() {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); EntityPageStore entities(io, *metadata);
        SlottedPagePool pages(io, *metadata); BTreePageStore trees(pages, *metadata);
        EntityLabelSetStore labels(io, *metadata, pages); PropertyCollectionRootStore roots(pages, *metadata);
        SystemCatalog catalog(trees, *metadata);
        NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
        options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), 902};
        NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options);
        auto tx = planner.beginTransaction(); auto session = catalog.beginWrite(tx);
        IndexDefinition definition; definition.name = "edge_weight"; definition.entity_kind = IndexDefinitionEntityKind::IDEK_EDGE;
        definition.kind = IndexDefinitionKind::IDK_PROPERTY; definition.property_names = {"weight"};
        definition = session.createIndexDefinition(definition); session.finish();
        std::vector<BTreePageEntry> records;
        for (uint64_t edge = 1; edge <= 64; ++edge) records.push_back({IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(edge - 1)), edge), edge});
        std::sort(records.begin(), records.end(), [](const auto &a, const auto &b) { return a.key < b.key; });
        const OrderedBTreeEntrySource source = [&]() -> OrderedBTreeEntryCursor {
            return [&, next = size_t(0)]() mutable -> std::optional<BTreePageEntry> { if (next == records.size()) return {}; return records[next++]; };
        };
        const BulkBTreeBuildOptions build{PhysicalSlotId(40), PhysicalSlotId(180), definition.index_id, records.size(), 32, BTreeLeafValueLayout::BLVL_U64};
        tx.stageScalarIndexCreate(trees, BulkBTreeBuilder::planNativeTree(trees, *metadata, tx.baseSnapshot(), definition.index_id, source, build));
        ASSERT_TRUE(tx.commit().committed()); io->flushStream();
    }
    void soloIndex() {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        (void)backend.createLogicalNodeIndex({"solo_age", "Solo", {"age"}}); backend.close();
    }
    void corruptDerivedIndex(bool ghost, bool constraint = false) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); EntityPageStore entities(io, *metadata);
        SlottedPagePool pages(io, *metadata); BTreePageStore trees(pages, *metadata);
        EntityLabelSetStore labels(io, *metadata, pages); PropertyCollectionRootStore roots(pages, *metadata);
        SystemCatalog catalog(trees, *metadata); auto pin = metadata->openSnapshot();
        const auto index = constraint ? supportId(catalog, pin) : indexId(catalog, pin, "person_age"); pin.release();
        NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
        options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), 902};
        NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options);
        auto tx = planner.beginTransaction();
        const auto key = constraint ? supportKey(PropertyValue(int64_t(ghost ? 100 : 0)), 1) :
            IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(ghost ? 100 : 0)), 1);
        if (ghost) tx.stageScalarIndexUpsert(trees, index, key, 1); else tx.stageScalarIndexErase(trees, index, key);
        ASSERT_TRUE(tx.commit().committed()); io->flushStream();
    }
    void changeStatistics(bool unknown, bool labelUnderflow = false) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io); EntityPageStore entities(io, *metadata);
        SlottedPagePool pages(io, *metadata); BTreePageStore trees(pages, *metadata);
        EntityLabelSetStore labels(io, *metadata, pages); PropertyCollectionRootStore roots(pages, *metadata);
        SystemCatalog catalog(trees, *metadata); auto pin = metadata->openSnapshot();
        const auto label = catalog.findSchemaToken(pin, SystemCatalogSchemaTokenKind::SCSTK_LABEL, "Person"); ASSERT_TRUE(label); pin.release();
        NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(180);
        options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(180), 902};
        NativeGraphWritePlanner planner(*metadata, entities, labels, roots, trees, options); auto tx = planner.beginTransaction();
        if (unknown) {
            tx.stageScalarIndexErase(trees, RSS_SYSTEM_CATALOG_INDEX_ID, SystemCatalogGraphCardinalityCodec::nodeCountKey());
            tx.stageScalarIndexErase(trees, RSS_SYSTEM_CATALOG_INDEX_ID, SystemCatalogGraphCardinalityCodec::edgeCountKey());
            for (const auto kind : {SystemCatalogSchemaTokenKind::SCSTK_LABEL, SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE})
                tx.stageScalarIndexErase(trees, RSS_SYSTEM_CATALOG_INDEX_ID, SystemCatalogTokenCardinalityCodec::completeKey(kind));
        } else {
            const auto key = labelUnderflow ? SystemCatalogTokenCardinalityCodec::countKey(SystemCatalogSchemaTokenKind::SCSTK_LABEL, *label) :
                SystemCatalogGraphCardinalityCodec::nodeCountKey();
            tx.stageScalarIndexUpsert(trees, RSS_SYSTEM_CATALOG_INDEX_ID, key, SystemCatalogGraphCardinalityCodec::encodeCount(0));
        }
        ASSERT_TRUE(tx.commit().committed()); io->flushStream();
    }
    void uniqueConstraint(bool nodeKey = false, bool edge = false, bool solo = false) {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        (void)backend.createLogicalConstraint({"unique_value", edge ? LogicalGraphConstraintEntityKind::LGCEK_EDGE : LogicalGraphConstraintEntityKind::LGCEK_NODE,
            nodeKey ? LogicalGraphConstraintKind::LGCK_NODE_KEY : LogicalGraphConstraintKind::LGCK_UNIQUE,
            edge ? "KNOWS" : solo ? "Solo" : "Person", nodeKey ? std::vector<std::string>{"age", "note"} : std::vector<std::string>{edge ? "weight" : "age"},
            LogicalGraphConstraintPropertyType::LGCPT_NONE});
        backend.close();
    }
    uint64_t supportId(SystemCatalog &catalog, const MetadataSnapshotPin &pin) {
        for (const auto &definition : catalog.readConstraintDefinitions(pin, 128)) if (definition.name == "unique_value") return definition.constraint_id;
        ADD_FAILURE() << "missing support definition"; return 0;
    }
    std::vector<std::byte> supportKey(const PropertyValue &value, uint64_t owner) {
        const std::array<PropertyValue, 1> values{value};
        return ConstraintSupportTree::entryKey(ConstraintSupportTree::canonicalKey(values), owner);
    }
    void withStore(const std::function<void(RelocatableMetadataStore &, PropertyCollectionRootStore &, BTreePageStore &,
        SystemCatalog &, const MetadataSnapshotPin &, const std::shared_ptr<StorageIO> &)> &action) {
        auto file = std::make_shared<std::fstream>(data_path_, std::ios::in | std::ios::out | std::ios::binary);
        auto io = std::make_shared<StorageIO>(file, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
        auto metadata = RelocatableMetadataStore::open(io);
        SlottedPagePool pages(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        LargeValueStore values(io, *metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        PropertyCollectionRootStore roots(pages, values, *metadata); BTreePageStore trees(pages, *metadata);
        SystemCatalog catalog(trees, *metadata); auto pin = metadata->openSnapshot();
        action(*metadata, roots, trees, catalog, pin, io); io->flushStream();
    }
    Superblock writeCell(RelocatableMetadataStore &metadata, EntityPropertyOwnerKind kind, uint64_t owner,
        uint32_t token, const PropertyValue &value, bool erase = false, MetadataPublishOptions options = {},
        const CancellationCheckpoint *cancellation = nullptr) {
        const auto before = metadata.openSnapshot().superblock();
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        const std::array<NativeHybridPropertyColumnReplacement, 1> cells{{{{kind, owner}, token, OwnedPropertyValue(value), erase}}};
        NativeHybridPropertyColumnWrite request{before.database_id, before.generation, before.hybrid_property_descriptor_root,
            cells, memory, PhysicalSlotId(40), PhysicalSlotId(180), 903, cancellation, true, {}};
        try {
            auto result = metadata.mutateHybridPropertyColumns(request, LogSequenceNumber(before.checkpoint_lsn.value() + 1), options);
            EXPECT_EQ(memory->used(), 0U); return result;
        } catch (...) { EXPECT_EQ(memory->used(), 0U); throw; }
    }
    Superblock deleteOwner(RelocatableMetadataStore &metadata, EntityPropertyOwnerKind kind, uint64_t id,
        const MetadataPublishOptions &options = {}, const CancellationCheckpoint *cancellation = nullptr) {
        const auto before = metadata.openSnapshot().superblock();
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        const std::array<EntityPropertyKey, 1> owners{{{kind, id}}};
        NativeHybridPropertyColumnWrite request{before.database_id, before.generation, before.hybrid_property_descriptor_root,
            {}, memory, PhysicalSlotId(40), PhysicalSlotId(180), 903, cancellation, true, owners};
        try {
            auto result = metadata.mutateHybridPropertyColumns(request, LogSequenceNumber(before.checkpoint_lsn.value() + 1), options);
            EXPECT_EQ(memory->used(), 0U); return result;
        } catch (...) { EXPECT_EQ(memory->used(), 0U); throw; }
    }
    uint64_t indexId(SystemCatalog &catalog, const MetadataSnapshotPin &pin, std::string_view name) {
        for (const auto &definition : catalog.readIndexDefinitions(pin, 128)) if (definition.name == name) return definition.index_id;
        ADD_FAILURE() << "missing index " << name; return 0;
    }
};
}
TEST_F(HybridPropertyIndexedLifecycleTest, CompositeAndScalarKeysFollowFieldRemovalAndReinsertion) {
    seed(); compositeIndex(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &) {
        const auto age = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(age);
        const auto single = indexId(catalog, old, "person_age"), composite = indexId(catalog, old, "person_age_note");
        const std::array beforeTuple{PropertyValue(int64_t(0)), PropertyValue("person")};
        const auto beforeKey = IndexKeyCodec::encodeCompositeEntryKey(beforeTuple, 1);
        ASSERT_TRUE(BTreeIndex(composite, trees, metadata).find(old, beforeKey));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *age, PropertyValue(), true);
        auto missing = metadata.openSnapshot();
        EXPECT_FALSE(roots.readEntityPropertyOptional(missing, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *age));
        EXPECT_FALSE(BTreeIndex(single, trees, metadata).find(missing, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(0)), 1)));
        EXPECT_FALSE(BTreeIndex(composite, trees, metadata).find(missing, beforeKey));
        EXPECT_TRUE(BTreeIndex(composite, trees, metadata).find(old, beforeKey));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *age, PropertyValue(int64_t(100)));
        auto current = metadata.openSnapshot(); const std::array afterTuple{PropertyValue(int64_t(100)), PropertyValue("person")};
        EXPECT_EQ(BTreeIndex(single, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(100)), 1)), std::optional<uint64_t>(1));
        EXPECT_EQ(BTreeIndex(composite, trees, metadata).find(current, IndexKeyCodec::encodeCompositeEntryKey(afterTuple, 1)), std::optional<uint64_t>(1));
    });
    EXPECT_EQ(read()[1], (Rows{{PropertyValue(int64_t(64)), PropertyValue(int64_t(2116))}}));
}
TEST_F(HybridPropertyIndexedLifecycleTest, UnindexedFieldChangeDoesNotCopyAnUnchangedScalarIndexRoot) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &trees, auto &catalog, const auto &old, auto &) {
        const auto note = catalog.findPropertyToken(old, "note"); ASSERT_TRUE(note);
        const auto index = indexId(catalog, old, "person_age"); const auto root = metadata.findIndexRoot(old, index);
        const auto location = metadata.findPageLocation(old, root.root_page_id);
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 8, *note, PropertyValue("changed"));
        auto current = metadata.openSnapshot(); EXPECT_EQ(metadata.findIndexRoot(current, index), root);
        EXPECT_EQ(metadata.findPageLocation(current, root.root_page_id), location);
        EXPECT_TRUE(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(7)), 8)));
    });
    EXPECT_EQ(read()[2], (Rows{{PropertyValue("changed"), PropertyValue()}}));
}
TEST_F(HybridPropertyIndexedLifecycleTest, ScalarIndexTracksCanonicalNumericTypeChange) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &) {
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto index = indexId(catalog, old, "person_age");
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(100.0));
        auto current = metadata.openSnapshot();
        const auto value = roots.readEntityPropertyOptional(current, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *token);
        ASSERT_TRUE(value); EXPECT_EQ(value->value, PropertyValue(100.0));
        EXPECT_FALSE(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(0)), 1)));
        EXPECT_EQ(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(100.0), 1)), std::optional<uint64_t>(1));
        EXPECT_TRUE(BTreeIndex(index, trees, metadata).find(old, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(0)), 1)));
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, BootstrapFaultKeepsScalarIndexAndFieldInTheSameRecoveredVersion) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100);
    for (const auto point : {BootstrapPublishFailpoint::BPF_AFTER_PARTIAL_INACTIVE_WRITE, BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE}) {
        withStore([&](auto &metadata, auto &, auto &, auto &catalog, const auto &pin, auto &) {
            const auto token = catalog.findPropertyToken(pin, "age"); ASSERT_TRUE(token);
            MetadataPublishOptions options; options.bootstrap_failpoint = point;
            EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(101)), false, options), BootstrapPublishInterrupted);
        });
        withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &pin, auto &) {
            const auto token = catalog.findPropertyToken(pin, "age"); ASSERT_TRUE(token);
            const int64_t expected = point == BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE ? 101 : 100;
            const int64_t absent = expected == 101 ? 100 : 101;
            const auto value = roots.readEntityPropertyOptional(pin, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *token);
            ASSERT_TRUE(value); EXPECT_EQ(value->value, PropertyValue(expected));
            const auto index = indexId(catalog, pin, "person_age");
            EXPECT_EQ(BTreeIndex(index, trees, metadata).find(pin, IndexKeyCodec::encodeEntryKey(PropertyValue(expected), 1)), std::optional<uint64_t>(1));
            EXPECT_FALSE(BTreeIndex(index, trees, metadata).find(pin, IndexKeyCodec::encodeEntryKey(PropertyValue(absent), 1)));
        });
    }
}

TEST_F(HybridPropertyIndexedLifecycleTest, EmptyPartialIndexKeepsItsRootAndAcceptsReinsertion) {
    seed(false, false, true); soloIndex(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &trees, auto &catalog, const auto &old, auto &) {
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto index = indexId(catalog, old, "solo_age");
        const auto key = IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(0)), 1);
        ASSERT_EQ(BTreeIndex(index, trees, metadata).find(old, key), std::optional<uint64_t>(1));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(), true);
        auto empty = metadata.openSnapshot(); ASSERT_TRUE(metadata.findIndexRootOptional(empty, index));
        EXPECT_FALSE(BTreeIndex(index, trees, metadata).find(empty, key));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)));
        auto current = metadata.openSnapshot();
        EXPECT_EQ(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(100)), 1)), std::optional<uint64_t>(1));
        EXPECT_TRUE(BTreeIndex(index, trees, metadata).find(old, key));
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, UnmatchedPartialIndexDoesNotCopyItsRootWhenItsPropertyChanges) {
    seed(true, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &, auto &catalog, const auto &old, auto &) {
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto index = indexId(catalog, old, "person_age"); const auto root = metadata.findIndexRoot(old, index);
        const auto location = metadata.findPageLocation(old, root.root_page_id);
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)));
        auto current = metadata.openSnapshot(); EXPECT_EQ(metadata.findIndexRoot(current, index), root);
        EXPECT_EQ(metadata.findPageLocation(current, root.root_page_id), location);
    });
    EXPECT_EQ(read()[1], (Rows{{PropertyValue(int64_t(63)), PropertyValue(int64_t(2016))}}));
}
TEST_F(HybridPropertyIndexedLifecycleTest, MissingOldIndexKeyRefusesFieldPublicationInsteadOfRepairingItSilently) {
    seed(); corruptDerivedIndex(false); convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100, true);
}
TEST_F(HybridPropertyIndexedLifecycleTest, ExistingNewGhostKeyRefusesFieldPublication) {
    seed(); corruptDerivedIndex(true); convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100, true);
}
TEST_F(HybridPropertyIndexedLifecycleTest, CancellationAfterIndexImagePreparationPublishesNeitherRootAndAllowsRetry) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &pin, auto &io) {
        const auto token = catalog.findPropertyToken(pin, "age"); ASSERT_TRUE(token);
        (void)metadata.reserveNativeGraphLogicalIds(1, 0); // complete writable-open recovery
        const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        struct Cancel final : CancellationCheckpoint { bool armed = false; void check() const override { if (armed) throw std::runtime_error("indexed mutation cancelled"); } } cancellation;
        {
            debug::PerfTrace::ScopedObserver observer(&cancellation, [](void *context, std::string_view key, int64_t value, bool) noexcept {
                if (key == "native_graph.hybrid.private_scalar_index_images" && value > 0) static_cast<Cancel *>(context)->armed = true;
            });
            try { (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)), false, {}, &cancellation); FAIL(); }
            catch (const std::runtime_error &error) { EXPECT_EQ(std::string(error.what()), "indexed mutation cancelled"); }
            EXPECT_TRUE(cancellation.armed);
        }
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        auto unchanged = metadata.openSnapshot(); const auto value = roots.readEntityPropertyOptional(unchanged, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *token);
        ASSERT_TRUE(value); EXPECT_EQ(value->value, PropertyValue(int64_t(0)));
        const auto index = indexId(catalog, unchanged, "person_age");
        EXPECT_TRUE(BTreeIndex(index, trees, metadata).find(unchanged, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(0)), 1)));
        EXPECT_FALSE(BTreeIndex(index, trees, metadata).find(unchanged, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(100)), 1)));
        EXPECT_NO_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100))));
    });
}

TEST_F(HybridPropertyIndexedLifecycleTest, MultipleOwnersShareOneScalarLeafPreparationAndPreserveAllOldKeys) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &) {
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto before = metadata.openSnapshot().superblock();
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        const std::array<NativeHybridPropertyColumnReplacement, 2> cells{{
            {{EntityPropertyOwnerKind::EPOK_NODE, 1}, *token, int64_t(100)},
            {{EntityPropertyOwnerKind::EPOK_NODE, 2}, *token, int64_t(101)}}};
        NativeHybridPropertyColumnWrite request{before.database_id, before.generation, before.hybrid_property_descriptor_root,
            cells, memory, PhysicalSlotId(40), PhysicalSlotId(180), 903, nullptr, true, {}};
        int64_t frames = 0;
        {
            debug::PerfTrace::ScopedObserver observe(&frames, [](void *context, std::string_view key, int64_t value, bool) noexcept {
                if (key == "native_graph.hybrid.pool_frames_prepared") *static_cast<int64_t *>(context) += value;
            });
            EXPECT_NO_THROW((void)metadata.mutateHybridPropertyColumns(request, LogSequenceNumber(before.checkpoint_lsn.value() + 1)));
        }
        EXPECT_GT(frames, 0); EXPECT_LE(frames, 3); EXPECT_EQ(memory->used(), 0U);
        const auto index = indexId(catalog, old, "person_age"); auto current = metadata.openSnapshot();
        for (uint64_t owner = 1; owner <= 2; ++owner) {
            const auto value = roots.readEntityPropertyOptional(current, {EntityPropertyOwnerKind::EPOK_NODE, owner}, *token);
            ASSERT_TRUE(value); EXPECT_EQ(value->value, PropertyValue(int64_t(owner + 99)));
            const auto oldKey = IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(owner - 1)), owner);
            EXPECT_FALSE(BTreeIndex(index, trees, metadata).find(current, oldKey)); EXPECT_TRUE(BTreeIndex(index, trees, metadata).find(old, oldKey));
            EXPECT_TRUE(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(owner + 99)), owner)));
        }

    });
    EXPECT_EQ(read()[1], (Rows{{PropertyValue(int64_t(64)), PropertyValue(int64_t(2216))}}));
}
TEST_F(HybridPropertyIndexedLifecycleTest, EdgePropertyIndexAndCanonicalTopologyRemainConsistentAfterFieldUpdate) {
    seed(); edgeIndex(); convert(EntityPropertyOwnerKind::EPOK_EDGE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &io) {
        const auto token = catalog.findPropertyToken(old, "weight"); ASSERT_TRUE(token);
        const auto index = indexId(catalog, old, "edge_weight");
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_EDGE, 1, *token, PropertyValue(int64_t(100)));
        auto current = metadata.openSnapshot();
        EXPECT_EQ(current.superblock().edge_entity_directory_root, old.superblock().edge_entity_directory_root);
        EXPECT_EQ(current.superblock().node_entity_directory_root, old.superblock().node_entity_directory_root);
        const auto value = roots.readEntityPropertyOptional(current, {EntityPropertyOwnerKind::EPOK_EDGE, 1}, *token);
        ASSERT_TRUE(value); EXPECT_EQ(value->value, PropertyValue(int64_t(100)));
        const auto oldKey = IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(0)), 1);
        EXPECT_FALSE(BTreeIndex(index, trees, metadata).find(current, oldKey)); EXPECT_TRUE(BTreeIndex(index, trees, metadata).find(old, oldKey));
        EXPECT_EQ(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(100)), 1)), std::optional<uint64_t>(1));
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, metadata, memory).scan());
    });
    const auto rows = read()[4]; ASSERT_EQ(rows.size(), 8U);
    EXPECT_EQ(rows[0][1], PropertyValue(int64_t(1))); EXPECT_EQ(rows[1][1], PropertyValue(int64_t(100)));
}

TEST_F(HybridPropertyIndexedLifecycleTest, OversizedIndexedValueIsStoredAndOnlyItsAccelerationEntryIsOmitted) {
    seed(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &io) {
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto index = indexId(catalog, old, "person_age"); const PropertyValue large(std::string(8192, 'x'));
        ASSERT_FALSE(IndexKeyCodec::tryEncodeEntryKey(large, 1));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, large);
        auto big = metadata.openSnapshot(); const auto actual = roots.readEntityPropertyOptional(big, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *token);
        ASSERT_TRUE(actual); EXPECT_EQ(actual->value, large);
        const auto oldKey = IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(0)), 1);
        EXPECT_FALSE(BTreeIndex(index, trees, metadata).find(big, oldKey)); EXPECT_TRUE(BTreeIndex(index, trees, metadata).find(old, oldKey));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)));
        auto current = metadata.openSnapshot();
        EXPECT_EQ(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(100)), 1)), std::optional<uint64_t>(1));
        EXPECT_EQ(roots.readEntityPropertyOptional(big, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *token)->value, large);
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, metadata, memory).scan());
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, NonNullViolationRefusesBeforePrivateIoAndKeepsIndexAndOldPin) {
    seed(true, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        for (bool erase : {false, true}) {
            EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(), erase), std::runtime_error);
            EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        }
        const auto index = indexId(catalog, old, "person_age");
        EXPECT_EQ(BTreeIndex(index, trees, metadata).find(old, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(0)), 1)), std::optional<uint64_t>(1));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)));
        auto current = metadata.openSnapshot();
        EXPECT_EQ(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(100)), 1)), std::optional<uint64_t>(1));
        EXPECT_EQ(roots.readEntityPropertyOptional(old, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *token)->value, PropertyValue(int64_t(0)));
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, IntegerConstraintRejectsDoubleButAllowsValidChangeAndMissingValue) {
    seed();
    {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        (void)backend.createLogicalConstraint({"person_age_integer", LogicalGraphConstraintEntityKind::LGCEK_NODE,
            LogicalGraphConstraintKind::LGCK_PROPERTY_TYPE, "Person", {"age"}, LogicalGraphConstraintPropertyType::LGCPT_INTEGER});
        backend.close();
    }
    convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &trees, auto &catalog, const auto &old, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(100.0)), std::runtime_error);
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(), true);
        const auto current = metadata.openSnapshot(); const auto index = indexId(catalog, old, "person_age");
        EXPECT_FALSE(BTreeIndex(index, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(100)), 1)));
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, RelationshipTypeConstraintChecksFinalNativeEdgeValue) {
    seed(false);
    {
        auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
        RelocatableStorageBackend backend(options); backend.open();
        (void)backend.createLogicalConstraint({"knows_weight_integer", LogicalGraphConstraintEntityKind::LGCEK_EDGE,
            LogicalGraphConstraintKind::LGCK_PROPERTY_TYPE, "KNOWS", {"weight"}, LogicalGraphConstraintPropertyType::LGCPT_INTEGER});
        backend.close();
    }
    edgeIndex(); convert(EntityPropertyOwnerKind::EPOK_EDGE);
    withStore([&](auto &metadata, auto &roots, auto &, auto &catalog, const auto &old, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto token = catalog.findPropertyToken(old, "weight"); ASSERT_TRUE(token);
        const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_EDGE, 1, *token, PropertyValue("bad")), std::runtime_error);
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_EDGE, 1, *token, PropertyValue(int64_t(100)));
        EXPECT_EQ(roots.readEntityPropertyOptional(metadata.openSnapshot(), {EntityPropertyOwnerKind::EPOK_EDGE, 1}, *token)->value, PropertyValue(int64_t(100)));
        EXPECT_EQ(roots.readEntityPropertyOptional(old, {EntityPropertyOwnerKind::EPOK_EDGE, 1}, *token)->value, PropertyValue(int64_t(0)));
    });
}

TEST_F(HybridPropertyIndexedLifecycleTest, UniqueSupportAndScalarIndexFollowValidWritesAndRefuseDuplicates) {
    seed(); uniqueConstraint(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto support = supportId(catalog, old); const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(1))), std::runtime_error);
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)));
        auto current = metadata.openSnapshot(); BTreeIndex tree(support, trees, metadata);
        EXPECT_EQ(tree.find(current, supportKey(PropertyValue(int64_t(100)), 1)), std::optional<uint64_t>(1));
        EXPECT_FALSE(tree.find(current, supportKey(PropertyValue(int64_t(0)), 1)));
        EXPECT_EQ(tree.find(old, supportKey(PropertyValue(int64_t(0)), 1)), std::optional<uint64_t>(1));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(), true);
        EXPECT_FALSE(tree.find(metadata.openSnapshot(), supportKey(PropertyValue(int64_t(100)), 1)));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(101)));
        EXPECT_EQ(roots.readEntityPropertyOptional(old, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *token)->value, PropertyValue(int64_t(0)));
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, metadata, memory).scan());
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, CompositeNodeKeyAllowsAtomicSwapAndRefusesMissingOrBatchDuplicate) {
    seed(); uniqueConstraint(true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(), true), std::runtime_error);
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        for (const bool duplicate : {true, false}) {
            before = metadata.openSnapshot().superblock();
            auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
            const std::array<NativeHybridPropertyColumnReplacement, 2> cells{{
                {{EntityPropertyOwnerKind::EPOK_NODE, 1}, *token, int64_t(duplicate ? 100 : 1)},
                {{EntityPropertyOwnerKind::EPOK_NODE, 2}, *token, int64_t(duplicate ? 100 : 0)}}};
            NativeHybridPropertyColumnWrite request{before.database_id, before.generation, before.hybrid_property_descriptor_root,
                cells, memory, PhysicalSlotId(40), PhysicalSlotId(180), 903, nullptr, true, {}};
            if (duplicate) {
                EXPECT_THROW((void)metadata.mutateHybridPropertyColumns(request, LogSequenceNumber(before.checkpoint_lsn.value() + 1)), std::runtime_error);
                EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
            } else EXPECT_NO_THROW((void)metadata.mutateHybridPropertyColumns(request, LogSequenceNumber(before.checkpoint_lsn.value() + 1)));
            EXPECT_EQ(memory->used(), 0U);
        }
        const auto current = metadata.openSnapshot(); const auto support = supportId(catalog, old);
        for (uint64_t owner : {1U, 2U}) {
            const int64_t value = owner == 1 ? 1 : 0;
            const std::array<PropertyValue, 2> values{PropertyValue(value), PropertyValue("person")};
            EXPECT_EQ(BTreeIndex(support, trees, metadata).find(current,
                ConstraintSupportTree::entryKey(ConstraintSupportTree::canonicalKey(values), owner)), std::optional(owner));
            EXPECT_EQ(roots.readEntityPropertyOptional(current, {EntityPropertyOwnerKind::EPOK_NODE, owner}, *token)->value, PropertyValue(value));
        }
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, EdgeUniqueSupportSurvivesBothBootstrapInterruptionBoundaries) {
    seed(false); uniqueConstraint(false, true); edgeIndex(); convert(EntityPropertyOwnerKind::EPOK_EDGE);
    withStore([&](auto &metadata, auto &, auto &, auto &catalog, const auto &pin, auto &) {
        const auto token = catalog.findPropertyToken(pin, "weight"); ASSERT_TRUE(token);
        EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_EDGE, 1, *token, PropertyValue(int64_t(1))), std::runtime_error);
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_EDGE, 1, *token, PropertyValue(int64_t(100)));
    });
    for (const auto point : {BootstrapPublishFailpoint::BPF_AFTER_PARTIAL_INACTIVE_WRITE, BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE}) {
        withStore([&](auto &metadata, auto &, auto &, auto &catalog, const auto &pin, auto &) {
            const auto token = catalog.findPropertyToken(pin, "weight"); ASSERT_TRUE(token);
            MetadataPublishOptions options; options.bootstrap_failpoint = point;
            EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_EDGE, 1, *token, PropertyValue(int64_t(101)), false, options), BootstrapPublishInterrupted);
        });
        withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &pin, auto &io) {
            const auto expected = point == BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE ? int64_t(101) : int64_t(100);
            const auto token = catalog.findPropertyToken(pin, "weight"); ASSERT_TRUE(token);
            EXPECT_EQ(roots.readEntityPropertyOptional(pin, {EntityPropertyOwnerKind::EPOK_EDGE, 1}, *token)->value, PropertyValue(expected));
            const auto support = supportId(catalog, pin);
            EXPECT_EQ(BTreeIndex(support, trees, metadata).find(pin, supportKey(PropertyValue(expected), 1)), std::optional<uint64_t>(1));
            EXPECT_FALSE(BTreeIndex(support, trees, metadata).find(pin, supportKey(PropertyValue(expected == 100 ? int64_t(101) : int64_t(100)), 1)));
            auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
            EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, metadata, memory).scan());
        });
    }
}
TEST_F(HybridPropertyIndexedLifecycleTest, UniqueConstraintStillChecksValuesBeyondScalarIndexKeyLimit) {
    seed(); uniqueConstraint(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &trees, auto &catalog, const auto &old, auto &io) {
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const PropertyValue large(std::string(8192, 'u'));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, large);
        const auto support = supportId(catalog, old); const auto pin = metadata.openSnapshot();
        EXPECT_EQ(BTreeIndex(support, trees, metadata).find(pin, supportKey(large, 1)), std::optional<uint64_t>(1));
        const auto before = pin.superblock(); const auto epoch = io->dataMutationEpoch();
        EXPECT_THROW((void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 2, *token, large), std::runtime_error);
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
    });
}

TEST_F(HybridPropertyIndexedLifecycleTest, MissingConstraintSupportEntryRefusesWithoutRepairOrPrivateIo) {
    seed(false); uniqueConstraint(); corruptDerivedIndex(false, true);
    convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100, true);
}
TEST_F(HybridPropertyIndexedLifecycleTest, GhostConstraintSupportEntryRefusesWithoutRepairOrPrivateIo) {
    seed(false); uniqueConstraint(); corruptDerivedIndex(true, true);
    convert(EntityPropertyOwnerKind::EPOK_NODE); setAge(100, true);
}

TEST_F(HybridPropertyIndexedLifecycleTest, LastUniqueSupportKeyKeepsActiveEmptyRootAndCanBeReinserted) {
    seed(false, false, true); uniqueConstraint(false, false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &trees, auto &catalog, const auto &old, auto &) {
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto support = supportId(catalog, old);
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(), true);
        const auto empty = metadata.openSnapshot(); EXPECT_TRUE(metadata.findIndexRootOptional(empty, support));
        EXPECT_TRUE(BTreeIndex(support, trees, metadata).scan(empty, {}, 2).empty());
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)));
        EXPECT_EQ(BTreeIndex(support, trees, metadata).find(metadata.openSnapshot(), supportKey(PropertyValue(int64_t(100)), 1)), std::optional<uint64_t>(1));
        EXPECT_EQ(BTreeIndex(support, trees, metadata).find(old, supportKey(PropertyValue(int64_t(0)), 1)), std::optional<uint64_t>(1));
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, UnchangedUniqueKeyAndNonmatchingOwnerKeepSupportPhysicalRoot) {
    seed(false, false, true); uniqueConstraint(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &, auto &catalog, const auto &old, auto &) {
        const auto age = catalog.findPropertyToken(old, "age"), note = catalog.findPropertyToken(old, "note"); ASSERT_TRUE(age); ASSERT_TRUE(note);
        const auto support = supportId(catalog, old); const auto root = metadata.findIndexRoot(old, support);
        const auto location = metadata.findPageLocation(old, root.root_page_id);
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 2, *note, PropertyValue("new"));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *age, PropertyValue(), true);
        const auto current = metadata.openSnapshot(); EXPECT_EQ(metadata.findIndexRoot(current, support), root);
        EXPECT_EQ(metadata.findPageLocation(current, root.root_page_id), location);
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, CancellationAfterConstraintImagesKeepsBothVersionsAndAllowsRetry) {
    seed(); uniqueConstraint(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &trees, auto &catalog, const auto &old, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto token = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(token);
        const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        struct Cancel final : CancellationCheckpoint { bool armed = false; void check() const override { if (armed) throw std::runtime_error("constraint cancelled"); } } cancellation;
        {
            debug::PerfTrace::ScopedObserver observer(&cancellation, [](void *context, std::string_view key, int64_t value, bool) noexcept {
                if (key == "native_graph.hybrid.private_constraint_index_images" && value > 0) static_cast<Cancel *>(context)->armed = true;
            });
            try { (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)), false, {}, &cancellation); FAIL(); }
            catch (const std::runtime_error &error) { EXPECT_EQ(std::string(error.what()), "constraint cancelled"); }
            EXPECT_TRUE(cancellation.armed);
        }
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        const auto support = supportId(catalog, old);
        EXPECT_EQ(BTreeIndex(support, trees, metadata).find(old, supportKey(PropertyValue(int64_t(0)), 1)), std::optional<uint64_t>(1));
        (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *token, PropertyValue(int64_t(100)));
        EXPECT_EQ(BTreeIndex(support, trees, metadata).find(metadata.openSnapshot(), supportKey(PropertyValue(int64_t(100)), 1)), std::optional<uint64_t>(1));
    });
}

TEST_F(HybridPropertyIndexedLifecycleTest, IsolatedNodeDeletionRemovesAllDerivedKeysAndUpdatesKnownCounts) {
    seed(); uniqueConstraint(); compositeIndex(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &io) {
        const auto age = catalog.findPropertyToken(old, "age"); ASSERT_TRUE(age);
        const auto support = supportId(catalog, old);
        const auto label = catalog.findSchemaToken(old, SystemCatalogSchemaTokenKind::SCSTK_LABEL, "Person"); ASSERT_TRUE(label);
        const auto labelCount = catalog.readTokenCardinality(old, SystemCatalogSchemaTokenKind::SCSTK_LABEL, *label);
        ASSERT_TRUE(labelCount); EXPECT_EQ(*labelCount, 64U);
        (void)deleteOwner(metadata, EntityPropertyOwnerKind::EPOK_NODE, 64);
        const auto current = metadata.openSnapshot(); EXPECT_FALSE(metadata.findNodePageLocationOptional(current, 64));
        EXPECT_TRUE(metadata.findNodePageLocationOptional(old, 64));
        EXPECT_EQ(catalog.readGraphCardinalityStatistics(current), (std::optional<NativeGraphCardinalityStatistics>{{63, 64}}));
        EXPECT_EQ(catalog.readTokenCardinality(current, SystemCatalogSchemaTokenKind::SCSTK_LABEL, *label), std::optional<uint64_t>(63));
        EXPECT_EQ(catalog.readTokenCardinality(old, SystemCatalogSchemaTokenKind::SCSTK_LABEL, *label), std::optional<uint64_t>(64));
        EXPECT_FALSE(BTreeIndex(support, trees, metadata).find(current, supportKey(PropertyValue(int64_t(63)), 64)));
        EXPECT_TRUE(BTreeIndex(support, trees, metadata).find(old, supportKey(PropertyValue(int64_t(63)), 64)));
        const auto scalar = indexId(catalog, old, "person_age");
        EXPECT_FALSE(BTreeIndex(scalar, trees, metadata).find(current, IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(63)), 64)));
        EXPECT_EQ(roots.readEntityPropertyOptional(old, {EntityPropertyOwnerKind::EPOK_NODE, 64}, *age)->value, PropertyValue(int64_t(63)));
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, metadata, memory).scan());
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, IncidentNodeRefusalKeepsCatalogIndexesAndPhysicalEpoch) {
    seed(); uniqueConstraint(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &, auto &, const auto &, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        EXPECT_THROW((void)deleteOwner(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1), FormatException);
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, EdgeDeletionPublishesTopologySupportAndCountsAcrossBootstrapFaults) {
    seed(false); uniqueConstraint(false, true); edgeIndex(); convert(EntityPropertyOwnerKind::EPOK_EDGE);
    for (const auto point : {BootstrapPublishFailpoint::BPF_AFTER_PARTIAL_INACTIVE_WRITE, BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE}) {
        withStore([&](auto &metadata, auto &, auto &, auto &, const auto &, auto &) {
            MetadataPublishOptions options; options.bootstrap_failpoint = point;
            EXPECT_THROW((void)deleteOwner(metadata, EntityPropertyOwnerKind::EPOK_EDGE, 64, options), BootstrapPublishInterrupted);
        });
        withStore([&](auto &metadata, auto &, auto &trees, auto &catalog, const auto &pin, auto &io) {
            const bool committed = point == BootstrapPublishFailpoint::BPF_AFTER_INACTIVE_WRITE;
            EXPECT_EQ(bool(metadata.findEdgePageLocationOptional(pin, 64)), !committed);
            const auto counts = catalog.readGraphCardinalityStatistics(pin); ASSERT_TRUE(counts);
            EXPECT_EQ(counts->node_count, 64U); EXPECT_EQ(counts->edge_count, committed ? 63U : 64U);
            const auto type = catalog.findSchemaToken(pin, SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE, "KNOWS"); ASSERT_TRUE(type);
            EXPECT_EQ(catalog.readTokenCardinality(pin, SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE, *type), std::optional<uint64_t>(committed ? 63 : 64));
            const auto support = supportId(catalog, pin);
            EXPECT_EQ(bool(BTreeIndex(support, trees, metadata).find(pin, supportKey(PropertyValue(int64_t(63)), 64))), !committed);
            auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
            EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, metadata, memory).scan());
        });
    }
}

TEST_F(HybridPropertyIndexedLifecycleTest, OwnerDeletionPreservesUnknownStatisticsAndDoesNotRewriteCatalog) {
    seed(); uniqueConstraint(); changeStatistics(true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &trees, auto &catalog, const auto &old, auto &) {
        EXPECT_FALSE(catalog.readGraphCardinalityStatistics(old));
        const auto label = catalog.findSchemaToken(old, SystemCatalogSchemaTokenKind::SCSTK_LABEL, "Person"); ASSERT_TRUE(label);
        EXPECT_FALSE(catalog.readTokenCardinality(old, SystemCatalogSchemaTokenKind::SCSTK_LABEL, *label));
        const auto root = metadata.findIndexRoot(old, RSS_SYSTEM_CATALOG_INDEX_ID); const auto location = metadata.findPageLocation(old, root.root_page_id);
        const auto counterKey = SystemCatalogTokenCardinalityCodec::countKey(SystemCatalogSchemaTokenKind::SCSTK_LABEL, *label);
        const auto incomplete = BTreeIndex(RSS_SYSTEM_CATALOG_INDEX_ID, trees, metadata).find(old, counterKey);
        (void)deleteOwner(metadata, EntityPropertyOwnerKind::EPOK_NODE, 64);
        const auto current = metadata.openSnapshot(); EXPECT_FALSE(metadata.findNodePageLocationOptional(current, 64));
        EXPECT_FALSE(catalog.readGraphCardinalityStatistics(current));
        EXPECT_FALSE(catalog.readTokenCardinality(current, SystemCatalogSchemaTokenKind::SCSTK_LABEL, *label));
        EXPECT_EQ(metadata.findIndexRoot(current, RSS_SYSTEM_CATALOG_INDEX_ID), root);
        EXPECT_EQ(metadata.findPageLocation(current, root.root_page_id), location);
        EXPECT_EQ(BTreeIndex(RSS_SYSTEM_CATALOG_INDEX_ID, trees, metadata).find(current, counterKey), incomplete);
    });
}
TEST_F(HybridPropertyIndexedLifecycleTest, OwnerDeletionRefusesGraphCountUnderflowBeforePhysicalIo) {
    seed(); changeStatistics(false); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100, true, true);
}
TEST_F(HybridPropertyIndexedLifecycleTest, OwnerDeletionRefusesCompleteLabelCountUnderflowBeforePhysicalIo) {
    seed(); changeStatistics(false, true); convert(EntityPropertyOwnerKind::EPOK_NODE);
    setAge(100, true, true);
}
TEST_F(HybridPropertyIndexedLifecycleTest, CancellationAfterCatalogImagesKeepsEntityIndexesCountsAndOldPin) {
    seed(); uniqueConstraint(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &, auto &catalog, const auto &old, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        struct Cancel final : CancellationCheckpoint { bool armed = false; void check() const override { if (armed) throw std::runtime_error("catalog cancelled"); } } cancellation;
        {
            debug::PerfTrace::ScopedObserver observer(&cancellation, [](void *context, std::string_view key, int64_t value, bool) noexcept {
                if (key == "native_graph.hybrid.private_catalog_index_images" && value > 0) static_cast<Cancel *>(context)->armed = true;
            });
            try { (void)deleteOwner(metadata, EntityPropertyOwnerKind::EPOK_NODE, 64, {}, &cancellation); FAIL(); }
            catch (const std::runtime_error &error) { EXPECT_EQ(std::string(error.what()), "catalog cancelled"); }
            EXPECT_TRUE(cancellation.armed);
        }
        EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        (void)deleteOwner(metadata, EntityPropertyOwnerKind::EPOK_NODE, 64);
        EXPECT_EQ(catalog.readGraphCardinalityStatistics(metadata.openSnapshot()), (std::optional<NativeGraphCardinalityStatistics>{{63, 64}}));
        EXPECT_TRUE(metadata.findNodePageLocationOptional(old, 64)); EXPECT_FALSE(metadata.findNodePageLocationOptional(metadata.openSnapshot(), 64));
    });
}

TEST_F(HybridPropertyIndexedLifecycleTest, CatalogDeletionQuotaFailureRefundsAndPreservesAllPublishedRoots) {
    seed(); uniqueConstraint(); compositeIndex(); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &, auto &, auto &, const auto &, auto &io) {
        (void)metadata.reserveNativeGraphLogicalIds(1, 0);
        const auto before = metadata.openSnapshot().superblock(); const auto epoch = io->dataMutationEpoch();
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(64 * 1024);
        const std::array<EntityPropertyKey, 1> owners{{{EntityPropertyOwnerKind::EPOK_NODE, 64}}};
        NativeHybridPropertyColumnWrite request{before.database_id, before.generation, before.hybrid_property_descriptor_root,
            {}, memory, PhysicalSlotId(40), PhysicalSlotId(180), 903, nullptr, true, owners};
        EXPECT_THROW((void)metadata.mutateHybridPropertyColumns(request, LogSequenceNumber(before.checkpoint_lsn.value() + 1)), query::execution::MaterializedByteLimitExceeded);
        EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata.openSnapshot().superblock(), before); EXPECT_EQ(io->dataMutationEpoch(), epoch);
        EXPECT_NO_THROW((void)deleteOwner(metadata, EntityPropertyOwnerKind::EPOK_NODE, 64));
    });
}

TEST_F(HybridPropertyIndexedLifecycleTest, SameExecutorPreservesUnsortedDuplicateNeighborGathersAcrossBothLayouts) {
    seed(true, false, false, true); const auto baseline = read();
    ASSERT_EQ(baseline[6].size(), 64U);
    for (size_t i = 0; i < 64; ++i) {
        const auto target = int64_t(((i % 32U) * 13U) % 32U);
        EXPECT_EQ(baseline[6][i], (std::vector<PropertyValue>{PropertyValue(int64_t(i)), PropertyValue(target),
            PropertyValue(target == 7 ? "seven" : "person"), PropertyValue()}));
    }
    convert(EntityPropertyOwnerKind::EPOK_NODE); EXPECT_EQ(read(), baseline);
    convert(EntityPropertyOwnerKind::EPOK_EDGE); EXPECT_EQ(read(), baseline);
    convert(EntityPropertyOwnerKind::EPOK_NODE, true); EXPECT_EQ(read(), baseline);
    convert(EntityPropertyOwnerKind::EPOK_EDGE, true); EXPECT_EQ(read(), baseline);
}

TEST_F(HybridPropertyIndexedLifecycleTest, SustainedTypeChangesStayFieldLocalWithoutAutomaticRepromotion) {
    seed(false); convert(EntityPropertyOwnerKind::EPOK_NODE);
    withStore([&](auto &metadata, auto &roots, auto &trees, auto &catalog, const auto &old, auto &io) {
        const auto age = catalog.findPropertyToken(old, "age"), note = catalog.findPropertyToken(old, "note"); ASSERT_TRUE(age); ASSERT_TRUE(note);
        const auto catalogRoot = metadata.findIndexRoot(old, RSS_SYSTEM_CATALOG_INDEX_ID);
        const auto catalogLocation = metadata.findPageLocation(old, catalogRoot.root_page_id);
        const std::array<PropertyValue, 6> values{PropertyValue(100.0), PropertyValue(int64_t(100)), PropertyValue(),
            PropertyValue(true), PropertyValue(std::string(8192, 'm')), PropertyValue(int64_t(101))};
        auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
        for (size_t cycle = 0; cycle < 2; ++cycle) {
            for (const auto &value : values) {
                (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *age, value);
                const auto current = metadata.openSnapshot();
                EXPECT_EQ(roots.readEntityPropertyOptional(current, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *age)->value, value);
                EXPECT_EQ(roots.readEntityPropertyOptional(current, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *note)->value, PropertyValue("person"));
                EXPECT_EQ(roots.readEntityPropertyOptional(current, {EntityPropertyOwnerKind::EPOK_NODE, 2}, *age)->value, PropertyValue(int64_t(1)));
                SlottedPagePool pages(io, metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
                LargeValueStore large(io, metadata, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
                HybridPropertyReadContext context(io, pages, metadata, current);
                const auto directory = HybridPropertyDirectoryIntegrity::verify(context, current, memory, &large);
                EXPECT_EQ(directory.columns, 0U); EXPECT_EQ(directory.memberships, 128U);
                EXPECT_EQ(directory.extensions, 128U);
                EXPECT_EQ(roots.readEntityPropertyOptional(old, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *age)->value, PropertyValue(int64_t(0)));
                EXPECT_EQ(memory->used(), 0U);
            }
            (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *age, PropertyValue(), true);
            const auto missing = metadata.openSnapshot();
            EXPECT_FALSE(roots.readEntityPropertyOptional(missing, {EntityPropertyOwnerKind::EPOK_NODE, 1}, *age));
            (void)writeCell(metadata, EntityPropertyOwnerKind::EPOK_NODE, 1, *age, PropertyValue(int64_t(102)));
        }
        const auto current = metadata.openSnapshot();
        EXPECT_EQ(metadata.findIndexRoot(current, RSS_SYSTEM_CATALOG_INDEX_ID), catalogRoot);
        EXPECT_EQ(metadata.findPageLocation(current, catalogRoot.root_page_id), catalogLocation);
        const auto costs = NativeStorageAllocationCensus(io, metadata, memory).inspect(current);
        ASSERT_TRUE(costs); EXPECT_TRUE(costs->fullyAttributed());
        EXPECT_GE(costs->totalAllocatedBytes(), costs->steadyAllocatedBytes() + costs->retired_catalog_bytes);
        EXPECT_GT(costs->retired_catalog_bytes, 0U);
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io, metadata, memory).scan()); EXPECT_EQ(memory->used(), 0U);
    });
    convert(EntityPropertyOwnerKind::EPOK_NODE, true);
    EXPECT_EQ(read()[5].front(), (std::vector<PropertyValue>{PropertyValue(int64_t(102))}));
}

TEST_F(HybridPropertyIndexedLifecycleTest, CoveredReferenceControlAndHybridPropertiesShareTheSameExecutorSnapshot) {
    seed(true, false, false, true); buildCovered(); const auto baseline = read();
    convert(EntityPropertyOwnerKind::EPOK_NODE); convert(EntityPropertyOwnerKind::EPOK_EDGE);
    auto memory = std::make_shared<query::execution::MaterializedByteBudget>(1024 * 1024);
    EXPECT_EQ(controlRows(true, memory), baseline);
    setAge(100); EXPECT_EQ(controlRows(true, memory), controlRows(false, memory));
}

#endif

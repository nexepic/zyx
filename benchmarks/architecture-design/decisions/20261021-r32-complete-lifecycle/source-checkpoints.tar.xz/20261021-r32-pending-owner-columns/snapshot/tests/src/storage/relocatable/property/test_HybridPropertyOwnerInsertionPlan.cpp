#include "storage/relocatable/property/HybridPropertyOrdinaryConversionTestFixture.hpp"
#include "graph/storage/relocatable/property/HybridPropertyColumnDelta.hpp"
#include "graph/storage/relocatable/metadata/HybridPropertyColumnWritePreparation.hpp"

using namespace graph::storage;
using graph::PropertyValue;
using graph::query::execution::MaterializedByteBudget;
namespace {
class HybridPropertyOwnerInsertionPlanTest : public graph::storage::test::HybridPropertyOrdinaryConversionTestFixture {
protected:
    void install(const std::shared_ptr<MaterializedByteBudget> &memory) {
        auto conversion = request(NODE, memory); conversion.conversion->publish_candidate = true; run(conversion);
    }
};
}
TEST_F(HybridPropertyOwnerInsertionPlanTest, DisabledOrRowOwnerCannotAcquirePendingColumnImages) {
    seed(NODE, 63, 1); auto memory = std::make_shared<MaterializedByteBudget>(1024 * 1024);
    const auto source = metadata_->openSnapshot(); const auto epoch = io_->dataMutationEpoch();
    HybridPropertyReadContext context(io_, *slotted_pages_, *metadata_, source); const PropertyValue value(int64_t(64));
    EXPECT_THROW((void)HybridPropertyColumnDelta::planPendingOwnerColumnMember(context, source, {NODE, 64}, 1,
        Generation(source.superblock().generation.value() + 1), memory, value), FormatException);
    EXPECT_EQ(io_->dataMutationEpoch(), epoch); EXPECT_EQ(memory->used(), 0U);
}
#if ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT
TEST_F(HybridPropertyOwnerInsertionPlanTest, PendingOwnerColumnCarriesSeparateLivenessWithoutPublishingAnEntity) {
    seed(NODE, 63, 1); auto memory = std::make_shared<MaterializedByteBudget>(1024 * 1024); install(memory);
    const auto before = metadata_->openSnapshot().superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        const auto source = metadata_->openSnapshot(); HybridPropertyReadContext context(io_, *slotted_pages_, *metadata_, source);
        const PropertyValue value(int64_t(64));
        auto plan = HybridPropertyColumnDelta::planPendingOwnerColumnMember(context, source, {NODE, 64}, 1,
            Generation(before.generation.value() + 1), memory, value); ASSERT_TRUE(plan);
        EXPECT_EQ(plan->action(), HybridPropertyColumnDelta::Action::HCD_REPLACE_COLUMN);
        EXPECT_EQ(plan->effects().memberships, 1); EXPECT_EQ(plan->effects().set_live, UINT64_C(1) << 63);
        EXPECT_EQ(plan->replacementColumn().presence, UINT64_MAX); EXPECT_EQ(plan->replacementColumn().live, UINT64_MAX);
        EXPECT_EQ(plan->replacementColumn().words[63], 64U); EXPECT_FALSE(plan->sourceGroup().live & (UINT64_C(1) << 63));
        EXPECT_FALSE(metadata_->findNodePageLocationOptional(source, 64));
        EXPECT_EQ(context.visitField({NODE, 64}, 1, [](const auto &) {}, [](const auto &) {}), HybridPropertyReadContext::FieldRoute::HFR_MISSING);
    }
    EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch); EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyOwnerInsertionPlanTest, NetZeroMembershipMergeCannotBypassTheExistingLivenessPublicationGuard) {
    seed(NODE, 63, 1); auto memory = std::make_shared<MaterializedByteBudget>(1024 * 1024); install(memory);
    const auto before = metadata_->openSnapshot().superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        const auto source = metadata_->openSnapshot(); HybridPropertyReadContext context(io_, *slotted_pages_, *metadata_, source);
        const auto next = Generation(before.generation.value() + 1); const PropertyValue value(int64_t(64));
        auto inserted = HybridPropertyColumnDelta::planPendingOwnerColumnMember(context, source, {NODE, 64}, 1, next, memory, value);
        auto erased = HybridPropertyColumnDelta::planExistingColumn(context, source, {NODE, 1}, 1, next, memory, nullptr);
        ASSERT_TRUE(inserted); ASSERT_TRUE(erased);
        const std::array<const HybridPropertyColumnDelta *, 2> changes{&*inserted, &*erased};
        auto merged = HybridPropertyColumnDelta::mergeExistingColumnChanges(changes, memory);
        EXPECT_EQ(merged.effects().memberships, 0); EXPECT_EQ(merged.effects().set_live, UINT64_C(1) << 63);
        EXPECT_EQ(merged.replacementColumn().live, UINT64_MAX); EXPECT_FALSE(merged.replacementColumn().presence & 1U);
        HybridPropertyFieldPageStore fields(io_, *metadata_, source);
        const std::array<const HybridPropertyColumnDelta *, 1> final{&merged};
        EXPECT_THROW((void)HybridPropertyColumnWritePreparation(source, fields, final, memory), FormatException);
    }
    EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch); EXPECT_EQ(memory->used(), 0U);
}
TEST_F(HybridPropertyOwnerInsertionPlanTest, IncompatiblePendingValueDemotesOnlyItsFieldAndKeepsBorrowedValuesAlive) {
    seed(NODE, 63, 2); auto memory = std::make_shared<MaterializedByteBudget>(1024 * 1024); install(memory);
    const auto before = metadata_->openSnapshot().superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        const auto source = metadata_->openSnapshot(); HybridPropertyReadContext context(io_, *slotted_pages_, *metadata_, source);
        const auto next = Generation(before.generation.value() + 1); const PropertyValue value("pending"), changed(int64_t(999));
        auto inserted = HybridPropertyColumnDelta::planPendingOwnerColumnMember(context, source, {NODE, 64}, 1, next, memory, value);
        auto updated = HybridPropertyColumnDelta::planExistingColumn(context, source, {NODE, 1}, 1, next, memory, &changed);
        ASSERT_TRUE(inserted); ASSERT_TRUE(updated);
        const std::array<const HybridPropertyColumnDelta *, 2> changes{&*inserted, &*updated};
        auto merged = HybridPropertyColumnDelta::mergeExistingColumnChanges(changes, memory);
        EXPECT_EQ(merged.action(), HybridPropertyColumnDelta::Action::HCD_DEMOTE_FIELD);
        EXPECT_EQ(merged.effects().columns, -1); EXPECT_EQ(merged.effects().memberships, 1);
        EXPECT_EQ(merged.effects().set_live, UINT64_C(1) << 63); EXPECT_EQ(merged.demotedCells()[63].extension, &value);
        EXPECT_EQ(merged.demotedCells()[0].bits, 999U); EXPECT_EQ(properties_->readEntityPropertyOptional(source, {NODE, 1}, 2)->value, PropertyValue(int64_t(2)));
        EXPECT_THROW((void)HybridPropertyColumnDelta::planPendingOwnerColumnMember(context, source, {NODE, 1}, 1, next, memory, value), FormatException);
        auto tiny = std::make_shared<MaterializedByteBudget>(1024);
        EXPECT_THROW((void)HybridPropertyColumnDelta::planPendingOwnerColumnMember(context, source, {NODE, 64}, 1, next, tiny, value), graph::query::execution::MaterializedByteLimitExceeded);
        EXPECT_EQ(tiny->used(), 0U);
    }
    EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch); EXPECT_EQ(memory->used(), 0U);
}
#endif

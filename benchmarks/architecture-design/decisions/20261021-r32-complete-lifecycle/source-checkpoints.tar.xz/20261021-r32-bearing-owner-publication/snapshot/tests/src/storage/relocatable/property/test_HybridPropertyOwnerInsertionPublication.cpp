#include "storage/relocatable/property/HybridPropertyOrdinaryConversionTestFixture.hpp"
#include "graph/storage/relocatable/entity/NativeGraphMutationExecutor.hpp"
#include "graph/storage/relocatable/entity/PageBackedGraphReadAdapter.hpp"
#include "graph/storage/PwriteHelper.hpp"
#include "graph/storage/relocatable/index/IndexKeyCodec.hpp"
#include "graph/storage/relocatable/index/BTreeIndex.hpp"

using namespace graph::storage;
using graph::PropertyValue;
using graph::query::execution::MaterializedByteBudget;
namespace {
class HybridPropertyOwnerInsertionPublicationTest : public graph::storage::test::HybridPropertyOrdinaryConversionTestFixture {
protected:
    file_handle_t native_handle_ = INVALID_FILE_HANDLE;
    std::unique_ptr<LargeValueStore> large_values_;
    void resetStores() {
        vector_manifests_.reset(); vector_pages_.reset(); properties_.reset(); large_values_.reset(); labels_.reset();
        btree_pages_.reset(); slotted_pages_.reset(); entities_.reset(); metadata_.reset(); io_.reset();
    }
    void SetUp() override {
        HybridPropertyOrdinaryConversionTestFixture::SetUp();
        resetStores(); native_handle_ = portable_open_rw(path_.string().c_str());
        ASSERT_NE(native_handle_, INVALID_FILE_HANDLE);
        io_ = std::make_shared<StorageIO>(file_, native_handle_, native_handle_);
        metadata_ = RelocatableMetadataStore::open(io_);
        entities_ = std::make_unique<EntityPageStore>(io_, *metadata_);
        slotted_pages_ = std::make_unique<SlottedPagePool>(io_, *metadata_);
        btree_pages_ = std::make_unique<BTreePageStore>(*slotted_pages_, *metadata_);
        labels_ = std::make_unique<EntityLabelSetStore>(io_, *metadata_, *slotted_pages_);
        properties_ = std::make_unique<PropertyCollectionRootStore>(*slotted_pages_, *metadata_);
        vector_pages_ = std::make_unique<VectorPageStore>(io_, *metadata_);
        vector_manifests_ = std::make_unique<VectorManifestStore>(io_, *metadata_);
    }
    void TearDown() override {
        resetStores();
        if (native_handle_ != INVALID_FILE_HANDLE) { portable_close_rw(native_handle_); native_handle_ = INVALID_FILE_HANDLE; }
        HybridPropertyOrdinaryConversionTestFixture::TearDown();
    }
    void exercise(EntityPropertyOwnerKind kind, std::optional<bool> completeFault = {}, bool withProperties = false, PropertyValue initial = PropertyValue(int64_t(100)), size_t owners = 63, bool extensionField = false, bool withCatalog = false, bool allocateName = false, bool withIndex = false) {
        seed(kind, owners, 1); auto memory = std::make_shared<MaterializedByteBudget>(1024 * 1024);
        uint64_t propertyIndex = 0;
        if (withCatalog) {
            NativeGraphWritePlannerOptions options; options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(80);
            options.entity_pool_owner_id = 901; options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(80), 902};
            NativeGraphWritePlanner writer(*metadata_, *entities_, *labels_, *properties_, *btree_pages_, options);
            SystemCatalog catalog(*btree_pages_, *metadata_); auto tx = writer.beginTransaction(); auto session = catalog.beginWrite(tx);
            ASSERT_EQ(session.ensurePropertyToken("p"), 1U);
            if (!allocateName) ASSERT_EQ(session.ensurePropertyToken("q"), 2U);
            if (kind == EDGE) {
                for (size_t token = 1; token < 7; ++token) (void)session.ensureSchemaToken(SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE, "unused" + std::to_string(token));
                ASSERT_EQ(session.ensureSchemaToken(SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE, "KNOWS"), 7U);
                session.setTokenCardinality(SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE, 7, owners);
                session.markTokenCardinalityComplete(SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE);
            }
            if (withIndex) {
                IndexDefinition definition; definition.name = "owner_p"; definition.kind = IndexDefinitionKind::IDK_PROPERTY;
                definition.entity_kind = kind == NODE ? IndexDefinitionEntityKind::IDEK_NODE : IndexDefinitionEntityKind::IDEK_EDGE;
                definition.label_token_id = kind == NODE ? session.ensureSchemaToken(SystemCatalogSchemaTokenKind::SCSTK_LABEL, "Indexed") : 0;
                definition.property_names = {"p"}; definition = session.createIndexDefinition(definition); propertyIndex = definition.index_id;
                std::vector<BTreePageEntry> entries;
                if (kind == EDGE) for (uint64_t id = 1; id <= owners; ++id) {
                    const auto key = IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(id)), id); BTreePageEntry entry;
                    entry.key.assign(key.begin(), key.end()); entry.value_or_child = id; entries.push_back(std::move(entry));
                }
                tx.stageScalarIndexCreate(*btree_pages_, propertyIndex, entries);
            }
            session.setGraphCardinalityStatistics({kind == NODE ? owners : 2U, kind == EDGE ? owners : 0U});
            session.finish(); ASSERT_TRUE(tx.commit().committed());
        }
        auto conversion = request(kind, memory); conversion.conversion->publish_candidate = true; run(conversion);
        properties_.reset(); labels_.reset(); btree_pages_.reset(); slotted_pages_.reset(); entities_.reset();
        entities_ = std::make_unique<EntityPageStore>(io_, *metadata_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        slotted_pages_ = std::make_unique<SlottedPagePool>(io_, *metadata_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        btree_pages_ = std::make_unique<BTreePageStore>(*slotted_pages_, *metadata_);
        labels_ = std::make_unique<EntityLabelSetStore>(io_, *metadata_, *slotted_pages_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        large_values_ = std::make_unique<LargeValueStore>(io_, *metadata_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        properties_ = std::make_unique<PropertyCollectionRootStore>(*slotted_pages_, *large_values_, *metadata_);
        NativeGraphWritePlannerOptions placement; placement.first_slot = PhysicalSlotId(40); placement.last_slot = PhysicalSlotId(80);
        placement.entity_pool_owner_id = 901; placement.logical_id_lease_block_size = 1;
        placement.property_roots = {PhysicalSlotId(40), PhysicalSlotId(80), 903};
        NativeGraphWritePlanner planner(*metadata_, *entities_, *labels_, *properties_, *btree_pages_, placement);
        PageBackedGraphReadAdapter graph(*metadata_, *entities_, *labels_, *properties_, *btree_pages_);
        NativeGraphMutationTokenResolvers tokens;
        tokens.schema_token = [](const MetadataSnapshotPin &, SystemCatalogSchemaTokenKind type, std::string_view name) -> std::optional<uint64_t> {
            if (type == SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE && name == "KNOWS") return 7; return {};
        };
        tokens.property_key_token = [](const MetadataSnapshotPin &, std::string_view name) -> std::optional<uint32_t> { return name == "p" ? std::optional<uint32_t>(1) : name == "q" ? std::optional<uint32_t>(2) : std::nullopt; };
        tokens.property_key_name = [](const MetadataSnapshotPin &, uint32_t token) -> std::optional<std::string> { return token == 1 ? std::optional<std::string>("p") : token == 2 ? std::optional<std::string>("q") : std::nullopt; };
        SystemCatalog catalog(*btree_pages_, *metadata_);
        NativeGraphMutationExecutor executor(planner, graph, *btree_pages_, *vector_pages_, *vector_manifests_, *metadata_, tokens,
            [&](const MetadataSnapshotPin &pin) { return withCatalog ? catalog.readIndexDefinitions(pin, 64) : ::graph::utils::OwnedStdVector<IndexDefinition>{}; },
            [&](const MetadataSnapshotPin &pin) { return withCatalog ? catalog.readConstraintDefinitions(pin, 64) : ::graph::utils::OwnedStdVector<ConstraintDefinition>{}; },
            {64, 64, 128, 64, 128, 128, 64, 128, 4}, withCatalog ? &catalog : nullptr);
        const auto old = metadata_->openSnapshot(); LogicalGraphMutationBatch batch;
        for (size_t index = owners; index < 64U; ++index) {
            if (kind == NODE) {
                batch.node_creates.push_back({withIndex ? std::vector<std::string>{"Indexed"} : std::vector<std::string>{}, {}});
                if (withProperties) batch.node_creates.back().properties.push_back({extensionField ? "q" : "p", initial});
            } else {
                batch.edge_creates.push_back({{LogicalGraphMutationEntityKind::LGMK_NODE, LogicalGraphMutationReferenceKind::LGRK_PERSISTED, 1},
                    {LogicalGraphMutationEntityKind::LGMK_NODE, LogicalGraphMutationReferenceKind::LGRK_PERSISTED, 2}, "KNOWS", {}});
                if (withProperties) batch.edge_creates.back().properties.push_back({extensionField ? "q" : "p", initial});
            }
        }
        const uint32_t birthToken = extensionField ? 2U : 1U;
        if (completeFault) {
            size_t headers = 0; bool injected = false;
            {
                StorageIO::ScopedNativeWriteHookForTesting hook([&](file_handle_t fd, const void *bytes, size_t count, pwrite_off_t offset) -> pwrite_ssize_t {
                    // One durable lease publication precedes the graph publication.
                    if (offset >= 0 && uint64_t(offset) < 2U * RSS_SUPERBLOCK_BYTES && count == RSS_SUPERBLOCK_BYTES && ++headers == 2U) {
                        injected = true;
                        if (!*completeFault) return portable_pwrite(fd, bytes, RSS_SUPERBLOCK_HEADER_BYTES / 2U, offset);
                        (void)portable_pwrite(fd, bytes, count, offset);
                        throw std::runtime_error("injected owner publication interruption");
                    }
                    return portable_pwrite(fd, bytes, count, offset);
                });
                EXPECT_THROW((void)executor.execute(batch), std::runtime_error);
            }
            ASSERT_TRUE(injected); EXPECT_FALSE(properties_->isHybridPropertyOwner(old, {kind, 64}));
            auto reopened = RelocatableMetadataStore::openReadOnly(io_);
            SlottedPagePool pages(io_, *reopened, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
            LargeValueStore values(io_, *reopened, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
            PropertyCollectionRootStore roots(pages, values, *reopened); auto recovered = reopened->openSnapshot();
            HybridPropertyReadContext recoveredFields(io_, pages, *reopened, recovered);
            if (allocateName) {
                BTreePageStore trees(pages, *reopened); SystemCatalog recoveredCatalog(trees, *reopened);
                EXPECT_EQ(recoveredCatalog.findPropertyToken(recovered, "q"), *completeFault ? std::optional<uint32_t>(2) : std::nullopt);
                EXPECT_FALSE(catalog.findPropertyToken(old, "q"));
            }
            EXPECT_EQ(roots.isHybridPropertyOwner(recovered, {kind, 64}), *completeFault);
            EXPECT_EQ(bool(kind == NODE ? reopened->findNodePageLocationOptional(recovered, 64) :
                reopened->findEdgePageLocationOptional(recovered, 64)), *completeFault);
            EXPECT_EQ(bool(recoveredFields.groupRecord({kind, 64})->live & (UINT64_C(1) << 63)), *completeFault);
            if (withProperties && *completeFault) EXPECT_EQ(roots.readEntityPropertyOptional(recovered, {kind, 64}, birthToken)->value, initial);
            else EXPECT_FALSE(roots.readEntityOptional(recovered, {kind, 64}));
            if (withIndex) {
                BTreePageStore trees(pages, *reopened); const auto key = IndexKeyCodec::encodeEntryKey(initial, 64);
                EXPECT_EQ(BTreeIndex(propertyIndex, trees, *reopened).find(recovered, key), *completeFault ? std::optional<uint64_t>(64) : std::nullopt);
            }
            EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io_, *reopened, memory).scan());
            recovered.release();
            // The same writable handle must recover candidate frames and make
            // progress after either publication interruption, with old pins held.
            for (auto &node : batch.node_creates) node.properties.clear();
            for (auto &edge : batch.edge_creates) edge.properties.clear();
            EXPECT_TRUE(executor.execute(batch).committed());
            EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io_, *metadata_, memory).scan());
            return;
        }
        const auto created = executor.execute(batch); ASSERT_TRUE(created.committed());
        const auto &ids = kind == NODE ? created.result.created_node_ids : created.result.created_edge_ids;
        ASSERT_EQ(ids.size(), 64U - owners); ASSERT_EQ(ids.front(), owners + 1U); ASSERT_EQ(ids.back(), 64U);
        const auto born = metadata_->openSnapshot(); HybridPropertyReadContext context(io_, *slotted_pages_, *metadata_, born);
        ASSERT_TRUE(context.groupRecord({kind, 64})); EXPECT_EQ(context.groupRecord({kind, 64})->live, UINT64_MAX);
        EXPECT_TRUE(properties_->isHybridPropertyOwner(born, {kind, 64}));
        if (withProperties) EXPECT_EQ(properties_->readEntityPropertyOptional(born, {kind, 64}, birthToken)->value, initial);
        else EXPECT_FALSE(properties_->readEntityOptional(born, {kind, 64}));
        EXPECT_FALSE(properties_->isHybridPropertyOwner(old, {kind, 64}));
        if (withIndex) {
            const auto key = IndexKeyCodec::encodeEntryKey(initial, 64);
            EXPECT_EQ(BTreeIndex(propertyIndex, *btree_pages_, *metadata_).find(born, key), std::optional<uint64_t>(64));
            EXPECT_FALSE(BTreeIndex(propertyIndex, *btree_pages_, *metadata_).find(old, key));
        }
        if (allocateName) {
            EXPECT_EQ(catalog.findPropertyToken(born, "q"), std::optional<uint32_t>(2));
            EXPECT_EQ(catalog.findPropertyName(born, 2), std::optional<std::string>("q"));
            EXPECT_FALSE(catalog.findPropertyToken(old, "q"));
        }
        if (withCatalog) {
            const auto stats = catalog.readGraphCardinalityStatistics(born); ASSERT_TRUE(stats);
            EXPECT_EQ(stats->node_count, kind == NODE ? 64U : 2U); EXPECT_EQ(stats->edge_count, kind == EDGE ? 64U : 0U);
            const auto oldStats = catalog.readGraphCardinalityStatistics(old); ASSERT_TRUE(oldStats);
            EXPECT_EQ(oldStats->node_count, kind == NODE ? owners : 2U); EXPECT_EQ(oldStats->edge_count, kind == EDGE ? owners : 0U);
            if (kind == EDGE) EXPECT_EQ(catalog.readTokenCardinality(born, SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE, 7), std::optional<uint64_t>(64));
        }
        if (kind == NODE) { EXPECT_TRUE(metadata_->findNodePageLocationOptional(born, 64)); EXPECT_FALSE(metadata_->findNodePageLocationOptional(old, 64)); }
        else { EXPECT_TRUE(metadata_->findEdgePageLocationOptional(born, 64)); EXPECT_FALSE(metadata_->findEdgePageLocationOptional(old, 64)); }
        const NativeHybridPropertyColumnReplacement cell{{kind, 64}, 1, int64_t(64)};
        auto update = planner.beginTransaction(); update.stageHybridPropertyColumns(std::span(&cell, 1), memory, nullptr, true);
        ASSERT_TRUE(update.commit().committed()); const auto current = metadata_->openSnapshot();
        EXPECT_EQ(properties_->readEntityPropertyOptional(current, {kind, 64}, 1)->value, PropertyValue(int64_t(64)));
        if (withIndex) {
            const auto key = IndexKeyCodec::encodeEntryKey(PropertyValue(int64_t(64)), 64);
            EXPECT_EQ(BTreeIndex(propertyIndex, *btree_pages_, *metadata_).find(current, key), std::optional<uint64_t>(64));
        }
        if (withProperties) EXPECT_EQ(properties_->readEntityPropertyOptional(born, {kind, 64}, birthToken)->value, initial);
        else EXPECT_FALSE(properties_->readEntityPropertyOptional(born, {kind, 64}, 1));
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io_, *metadata_, memory).scan()); EXPECT_EQ(memory->used(), 0U);
        auto reopened = RelocatableMetadataStore::openReadOnly(io_); SlottedPagePool pages(io_, *reopened, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        LargeValueStore values(io_, *reopened, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
            PropertyCollectionRootStore roots(pages, values, *reopened); auto source = reopened->openSnapshot();
        EXPECT_EQ(roots.readEntityPropertyOptional(source, {kind, 64}, 1)->value, PropertyValue(int64_t(64)));
    }
};
}
#if ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PropertylessNodePublishesEntityAndLiveBitThenAcceptsItsFirstColumnField) { exercise(NODE); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PropertylessEdgePublishesEntityAdjacencyAndLiveBitThenAcceptsItsFirstColumnField) { exercise(EDGE); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialNodePublicationRecoversNeitherEntityNorLiveBit) { exercise(NODE, false); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteNodePublicationRecoversEntityAndLiveBitTogether) { exercise(NODE, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialEdgePublicationRecoversNeitherEntityNorLiveBit) { exercise(EDGE, false); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteEdgePublicationRecoversEntityAndLiveBitTogether) { exercise(EDGE, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PropertyBearingNodePublishesItsColumnAndEntityTogether) { exercise(NODE, {}, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PropertyBearingEdgePublishesItsColumnAndEntityTogether) { exercise(EDGE, {}, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewNodeValueCanDemoteOnlyItsExistingField) { exercise(NODE, {}, true, PropertyValue("new string")); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewEdgeValueCanDemoteOnlyItsExistingField) { exercise(EDGE, {}, true, PropertyValue("new string")); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialNodeFieldPublicationRecoversNeitherEntityNorField) { exercise(NODE, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteNodeFieldPublicationRecoversEntityAndFieldTogether) { exercise(NODE, true, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialEdgeFieldPublicationRecoversNeitherEntityNorField) { exercise(EDGE, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteEdgeFieldPublicationRecoversEntityAndFieldTogether) { exercise(EDGE, true, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, SixteenNewNodesMergeTheirColumnBitsInOnePublication) { exercise(NODE, {}, true, PropertyValue(int64_t(100)), 48); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, SixteenNewEdgesMergeTheirColumnBitsAndAdjacencyTogether) { exercise(EDGE, {}, true, PropertyValue(int64_t(100)), 48); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewNodeFieldWithoutAColumnUsesAnExtension) { exercise(NODE, {}, true, PropertyValue("extension"), 63, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewEdgeFieldWithoutAColumnUsesAnExtension) { exercise(EDGE, {}, true, PropertyValue("extension"), 63, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CatalogNodeCountAndNewNativeFieldPublishTogether) { exercise(NODE, {}, true, PropertyValue(int64_t(100)), 63, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CatalogEdgeTypeCountAndNativeFieldPublishTogether) { exercise(EDGE, {}, true, PropertyValue(int64_t(100)), 63, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewNodeLargeFieldPublishesItsValueAndEntityTogether) { exercise(NODE, {}, true, PropertyValue(std::string(70000, 'x')), 63, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewEdgeLargeFieldPublishesItsValueAndEntityTogether) { exercise(EDGE, {}, true, PropertyValue(std::string(70000, 'x')), 63, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewNodeLargeValueCanDemoteItsExistingColumn) { exercise(NODE, {}, true, PropertyValue(std::string(70000, 'x'))); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewEdgeLargeValueCanDemoteItsExistingColumn) { exercise(EDGE, {}, true, PropertyValue(std::string(70000, 'x'))); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewNodeFieldNameAndValuePublishWithItsCatalogIdentity) { exercise(NODE, {}, true, PropertyValue("new name"), 63, true, true, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewEdgeFieldNameAndValuePublishWithItsCatalogIdentity) { exercise(EDGE, {}, true, PropertyValue("new name"), 63, true, true, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialNodeNamePublicationLeavesNoCatalogTokenOrEntity) { exercise(NODE, false, true, PropertyValue("new name"), 63, true, true, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteNodeNamePublicationRecoversCatalogTokenAndEntity) { exercise(NODE, true, true, PropertyValue("new name"), 63, true, true, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialEdgeNamePublicationLeavesNoCatalogTokenOrEntity) { exercise(EDGE, false, true, PropertyValue("new name"), 63, true, true, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteEdgeNamePublicationRecoversCatalogTokenAndEntity) { exercise(EDGE, true, true, PropertyValue("new name"), 63, true, true, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewNativeNodeAndScalarIndexPublishTogether) { exercise(NODE, {}, true, PropertyValue(int64_t(100)), 63, false, true, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, NewNativeEdgeAndScalarIndexPublishTogether) { exercise(EDGE, {}, true, PropertyValue(int64_t(100)), 63, false, true, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialNodeIndexPublicationRecoversAllOldRoots) { exercise(NODE, false, true, PropertyValue(int64_t(100)), 63, false, true, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteNodeIndexPublicationRecoversAllNewRoots) { exercise(NODE, true, true, PropertyValue(int64_t(100)), 63, false, true, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialEdgeIndexPublicationRecoversAllOldRoots) { exercise(EDGE, false, true, PropertyValue(int64_t(100)), 63, false, true, false, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteEdgeIndexPublicationRecoversAllNewRoots) { exercise(EDGE, true, true, PropertyValue(int64_t(100)), 63, false, true, false, true); }
#endif

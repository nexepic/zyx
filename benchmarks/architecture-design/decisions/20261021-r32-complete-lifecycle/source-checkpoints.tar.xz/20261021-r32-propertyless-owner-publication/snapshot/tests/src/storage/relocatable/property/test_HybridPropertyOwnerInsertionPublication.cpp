#include "storage/relocatable/property/HybridPropertyOrdinaryConversionTestFixture.hpp"
#include "graph/storage/relocatable/entity/NativeGraphMutationExecutor.hpp"
#include "graph/storage/relocatable/entity/PageBackedGraphReadAdapter.hpp"
#include "graph/storage/PwriteHelper.hpp"

using namespace graph::storage;
using graph::PropertyValue;
using graph::query::execution::MaterializedByteBudget;
namespace {
class HybridPropertyOwnerInsertionPublicationTest : public graph::storage::test::HybridPropertyOrdinaryConversionTestFixture {
protected:
    file_handle_t native_handle_ = INVALID_FILE_HANDLE;
    void resetStores() {
        vector_manifests_.reset(); vector_pages_.reset(); properties_.reset(); labels_.reset();
        btree_pages_.reset(); slotted_pages_.reset(); entities_.reset(); metadata_.reset(); io_.reset();
    }
    void SetUp() override {
        HybridPropertyOrdinaryConversionTestFixture::SetUp();
        resetStores(); native_handle_ = portable_open_rw(path_.string().c_str());
        ASSERT_NE(native_handle_, INVALID_FILE_HANDLE);
        io_ = std::make_shared<StorageIO>(file_, native_handle_, native_handle_);
        metadata_ = RelocatableMetadataStore::open(io_);
        entities_ = std::make_unique<EntityPageStore>(io_, *metadata_);
        slotted_pages_ = std::make_unique<SlottedPagePool>(io_, *metadata_);
        btree_pages_ = std::make_unique<BTreePageStore>(*slotted_pages_, *metadata_);
        labels_ = std::make_unique<EntityLabelSetStore>(io_, *metadata_, *slotted_pages_);
        properties_ = std::make_unique<PropertyCollectionRootStore>(*slotted_pages_, *metadata_);
        vector_pages_ = std::make_unique<VectorPageStore>(io_, *metadata_);
        vector_manifests_ = std::make_unique<VectorManifestStore>(io_, *metadata_);
    }
    void TearDown() override {
        resetStores();
        if (native_handle_ != INVALID_FILE_HANDLE) { portable_close_rw(native_handle_); native_handle_ = INVALID_FILE_HANDLE; }
        HybridPropertyOrdinaryConversionTestFixture::TearDown();
    }
    void exercise(EntityPropertyOwnerKind kind, std::optional<bool> completeFault = {}, bool withProperties = false) {
        seed(kind, 63, 1); auto memory = std::make_shared<MaterializedByteBudget>(1024 * 1024);
        auto conversion = request(kind, memory); conversion.conversion->publish_candidate = true; run(conversion);
        properties_.reset(); labels_.reset(); btree_pages_.reset(); slotted_pages_.reset(); entities_.reset();
        entities_ = std::make_unique<EntityPageStore>(io_, *metadata_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        slotted_pages_ = std::make_unique<SlottedPagePool>(io_, *metadata_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        btree_pages_ = std::make_unique<BTreePageStore>(*slotted_pages_, *metadata_);
        labels_ = std::make_unique<EntityLabelSetStore>(io_, *metadata_, *slotted_pages_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        properties_ = std::make_unique<PropertyCollectionRootStore>(*slotted_pages_, *metadata_);
        NativeGraphWritePlannerOptions placement; placement.first_slot = PhysicalSlotId(40); placement.last_slot = PhysicalSlotId(80);
        placement.entity_pool_owner_id = 901; placement.logical_id_lease_block_size = 1;
        placement.property_roots = {PhysicalSlotId(40), PhysicalSlotId(80), 903};
        NativeGraphWritePlanner planner(*metadata_, *entities_, *labels_, *properties_, *btree_pages_, placement);
        PageBackedGraphReadAdapter graph(*metadata_, *entities_, *labels_, *properties_, *btree_pages_);
        NativeGraphMutationTokenResolvers tokens;
        tokens.schema_token = [](const MetadataSnapshotPin &, SystemCatalogSchemaTokenKind type, std::string_view name) -> std::optional<uint64_t> {
            if (type == SystemCatalogSchemaTokenKind::SCSTK_RELATIONSHIP_TYPE && name == "KNOWS") return 7; return {};
        };
        tokens.property_key_token = [](const MetadataSnapshotPin &, std::string_view name) -> std::optional<uint32_t> { return name == "p" ? std::optional<uint32_t>(1) : std::nullopt; };
        tokens.property_key_name = [](const MetadataSnapshotPin &, uint32_t token) -> std::optional<std::string> { return token == 1 ? std::optional<std::string>("p") : std::nullopt; };
        NativeGraphMutationExecutor executor(planner, graph, *btree_pages_, *vector_pages_, *vector_manifests_, *metadata_, tokens,
            [](const MetadataSnapshotPin &) { return ::graph::utils::OwnedStdVector<IndexDefinition>{}; },
            [](const MetadataSnapshotPin &) { return ::graph::utils::OwnedStdVector<ConstraintDefinition>{}; },
            {64, 64, 128, 64, 128, 128, 64, 128, 4});
        const auto old = metadata_->openSnapshot(); LogicalGraphMutationBatch batch;
        if (kind == NODE) batch.node_creates.push_back({{}, {}});
        else batch.edge_creates.push_back({{LogicalGraphMutationEntityKind::LGMK_NODE, LogicalGraphMutationReferenceKind::LGRK_PERSISTED, 1},
            {LogicalGraphMutationEntityKind::LGMK_NODE, LogicalGraphMutationReferenceKind::LGRK_PERSISTED, 2}, "KNOWS", {}});
        if (withProperties) {
            if (kind == NODE) batch.node_creates.back().properties.push_back({"p", PropertyValue(int64_t(64))});
            else batch.edge_creates.back().properties.push_back({"p", PropertyValue(int64_t(64))});
            try { (void)executor.execute(batch); FAIL() << "property-bearing native creation was published without its field coordinator"; }
            catch (const FormatException &error) { EXPECT_EQ(error.error(), FormatError::FERR_UNSUPPORTED_VERSION) << error.what(); }
            const auto after = metadata_->openSnapshot();
            EXPECT_FALSE(properties_->isHybridPropertyOwner(after, {kind, 64}));
            EXPECT_FALSE(kind == NODE ? bool(metadata_->findNodePageLocationOptional(after, 64)) :
                bool(metadata_->findEdgePageLocationOptional(after, 64)));
            EXPECT_EQ(properties_->readEntityPropertyOptional(after, {kind, 1}, 1)->value, PropertyValue(int64_t(1)));
            EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io_, *metadata_, memory).scan());
            return;
        }
        if (completeFault) {
            size_t headers = 0; bool injected = false;
            {
                StorageIO::ScopedNativeWriteHookForTesting hook([&](file_handle_t fd, const void *bytes, size_t count, pwrite_off_t offset) -> pwrite_ssize_t {
                    // One durable lease publication precedes the graph publication.
                    if (offset >= 0 && uint64_t(offset) < 2U * RSS_SUPERBLOCK_BYTES && count == RSS_SUPERBLOCK_BYTES && ++headers == 2U) {
                        injected = true;
                        if (!*completeFault) return portable_pwrite(fd, bytes, RSS_SUPERBLOCK_HEADER_BYTES / 2U, offset);
                        (void)portable_pwrite(fd, bytes, count, offset);
                        throw std::runtime_error("injected owner publication interruption");
                    }
                    return portable_pwrite(fd, bytes, count, offset);
                });
                EXPECT_THROW((void)executor.execute(batch), std::runtime_error);
            }
            ASSERT_TRUE(injected); EXPECT_FALSE(properties_->isHybridPropertyOwner(old, {kind, 64}));
            auto reopened = RelocatableMetadataStore::openReadOnly(io_);
            SlottedPagePool pages(io_, *reopened, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
            PropertyCollectionRootStore roots(pages, *reopened); auto recovered = reopened->openSnapshot();
            HybridPropertyReadContext recoveredFields(io_, pages, *reopened, recovered);
            EXPECT_EQ(roots.isHybridPropertyOwner(recovered, {kind, 64}), *completeFault);
            EXPECT_EQ(bool(kind == NODE ? reopened->findNodePageLocationOptional(recovered, 64) :
                reopened->findEdgePageLocationOptional(recovered, 64)), *completeFault);
            EXPECT_EQ(bool(recoveredFields.groupRecord({kind, 64})->live & (UINT64_C(1) << 63)), *completeFault);
            EXPECT_FALSE(roots.readEntityOptional(recovered, {kind, 64}));
            EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io_, *reopened, memory).scan());
            return;
        }
        const auto created = executor.execute(batch); ASSERT_TRUE(created.committed());
        const auto &ids = kind == NODE ? created.result.created_node_ids : created.result.created_edge_ids;
        ASSERT_EQ(ids.size(), 1U); ASSERT_EQ(ids[0], 64U);
        const auto born = metadata_->openSnapshot(); HybridPropertyReadContext context(io_, *slotted_pages_, *metadata_, born);
        ASSERT_TRUE(context.groupRecord({kind, 64})); EXPECT_EQ(context.groupRecord({kind, 64})->live, UINT64_MAX);
        EXPECT_TRUE(properties_->isHybridPropertyOwner(born, {kind, 64})); EXPECT_FALSE(properties_->readEntityOptional(born, {kind, 64}));
        EXPECT_FALSE(properties_->isHybridPropertyOwner(old, {kind, 64}));
        if (kind == NODE) { EXPECT_TRUE(metadata_->findNodePageLocationOptional(born, 64)); EXPECT_FALSE(metadata_->findNodePageLocationOptional(old, 64)); }
        else { EXPECT_TRUE(metadata_->findEdgePageLocationOptional(born, 64)); EXPECT_FALSE(metadata_->findEdgePageLocationOptional(old, 64)); }
        const NativeHybridPropertyColumnReplacement cell{{kind, 64}, 1, int64_t(64)};
        auto update = planner.beginTransaction(); update.stageHybridPropertyColumns(std::span(&cell, 1), memory, nullptr, true);
        ASSERT_TRUE(update.commit().committed()); const auto current = metadata_->openSnapshot();
        EXPECT_EQ(properties_->readEntityPropertyOptional(current, {kind, 64}, 1)->value, PropertyValue(int64_t(64)));
        EXPECT_FALSE(properties_->readEntityPropertyOptional(born, {kind, 64}, 1));
        EXPECT_NO_THROW((void)RelocatableIntegrityScanner(io_, *metadata_, memory).scan()); EXPECT_EQ(memory->used(), 0U);
        auto reopened = RelocatableMetadataStore::openReadOnly(io_); SlottedPagePool pages(io_, *reopened, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        PropertyCollectionRootStore roots(pages, *reopened); auto source = reopened->openSnapshot();
        EXPECT_EQ(roots.readEntityPropertyOptional(source, {kind, 64}, 1)->value, PropertyValue(int64_t(64)));
    }
};
}
#if ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PropertylessNodePublishesEntityAndLiveBitThenAcceptsItsFirstColumnField) { exercise(NODE); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PropertylessEdgePublishesEntityAdjacencyAndLiveBitThenAcceptsItsFirstColumnField) { exercise(EDGE); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialNodePublicationRecoversNeitherEntityNorLiveBit) { exercise(NODE, false); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteNodePublicationRecoversEntityAndLiveBitTogether) { exercise(NODE, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PartialEdgePublicationRecoversNeitherEntityNorLiveBit) { exercise(EDGE, false); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, CompleteEdgePublicationRecoversEntityAndLiveBitTogether) { exercise(EDGE, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PropertyBearingNodeRemainsGuardedUntilItsFieldCoordinatorIsInstalled) { exercise(NODE, {}, true); }
TEST_F(HybridPropertyOwnerInsertionPublicationTest, PropertyBearingEdgeRemainsGuardedUntilItsFieldCoordinatorIsInstalled) { exercise(EDGE, {}, true); }
#endif

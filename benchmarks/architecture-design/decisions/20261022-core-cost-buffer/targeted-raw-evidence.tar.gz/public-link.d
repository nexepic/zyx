/workspace/zyx/benchmarks/architecture-design/results/20261022-core-cost/buffer-targeted/public-baseline: \
  /lib/x86_64-linux-gnu/Scrt1.o \
  /lib/x86_64-linux-gnu/crti.o \
  /usr/lib/gcc/x86_64-linux-gnu/14/crtbeginS.o \
  /workspace/zyx/benchmarks/architecture-design/results/20261022-core-cost/buffer-targeted/public.o \
  libzyx_core.a \
  /workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libz.so \
  /workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/liblz4.so.1.10.0 \
  /workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libxxhash.so.0.8.3 \
  /workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libzstd.a \
  /workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libboost_filesystem.so.1.83.0 \
  /workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libboost_atomic.so.1.83.0 \
  /workspace/antlr4-install/lib/libantlr4-runtime.a \
  libzyx_inputxx.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/libstdc++.so \
  /lib/x86_64-linux-gnu/libm.so \
  /lib/x86_64-linux-gnu/libm.so \
  /lib/x86_64-linux-gnu/libm.so \
  /lib/x86_64-linux-gnu/libm.so.6 \
  /lib/x86_64-linux-gnu/libmvec.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /lib/x86_64-linux-gnu/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a \
  /lib/x86_64-linux-gnu/libc.so \
  /lib/x86_64-linux-gnu/libc.so \
  /lib/x86_64-linux-gnu/libc.so \
  /lib/x86_64-linux-gnu/libc.so.6 \
  /usr/lib/x86_64-linux-gnu/libc_nonshared.a \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so \
  /lib/x86_64-linux-gnu/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a \
  /usr/lib/gcc/x86_64-linux-gnu/14/crtendS.o \
  /lib/x86_64-linux-gnu/crtn.o

/lib/x86_64-linux-gnu/Scrt1.o:

/lib/x86_64-linux-gnu/crti.o:

/usr/lib/gcc/x86_64-linux-gnu/14/crtbeginS.o:

/workspace/zyx/benchmarks/architecture-design/results/20261022-core-cost/buffer-targeted/public.o:

libzyx_core.a:

/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libz.so:

/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/liblz4.so.1.10.0:

/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libxxhash.so.0.8.3:

/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libzstd.a:

/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libboost_filesystem.so.1.83.0:

/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libboost_atomic.so.1.83.0:

/workspace/antlr4-install/lib/libantlr4-runtime.a:

libzyx_inputxx.a:

/usr/lib/gcc/x86_64-linux-gnu/14/libstdc++.so:

/lib/x86_64-linux-gnu/libm.so:

/lib/x86_64-linux-gnu/libm.so:

/lib/x86_64-linux-gnu/libm.so:

/lib/x86_64-linux-gnu/libm.so.6:

/lib/x86_64-linux-gnu/libmvec.so.1:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/lib/x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a:

/lib/x86_64-linux-gnu/libc.so:

/lib/x86_64-linux-gnu/libc.so:

/lib/x86_64-linux-gnu/libc.so:

/lib/x86_64-linux-gnu/libc.so.6:

/usr/lib/x86_64-linux-gnu/libc_nonshared.a:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc_s.so:

/lib/x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/14/libgcc.a:

/usr/lib/gcc/x86_64-linux-gnu/14/crtendS.o:

/lib/x86_64-linux-gnu/crtn.o:

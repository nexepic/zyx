from pathlib import Path
import os,json,hashlib

def configure_native_report(out,engine,scale,profile,number,workloads):
 os.environ.pop('ZYX_COMPARE_PROCESS_MEMORY_REPORT',None)
 if engine=='kuzu':return
 key=hashlib.sha256(json.dumps(list(workloads),separators=(',',':')).encode()).hexdigest()[:16]
 target=out/'native-process-resources'/scale/profile/f'round-{number}'/engine/(key+'.json')
 target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():raise ValueError('Refuse to overwrite prior native memory observation')
 os.environ['ZYX_COMPARE_PROCESS_MEMORY_REPORT']=str(target)

def capture_worker_peak(worker,target):
 # Read after all observations, before worker close; never in an operation timer.
 # VmHWM excludes the forked Python parent's pre-exec memory image.
 status=Path(f'/proc/{worker.process.pid}/status').read_text()
 line=next(line for line in status.splitlines() if line.startswith('VmHWM:'))
 peak=int(line.split()[1])*1024
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_text(json.dumps({'peak_rss_bytes':peak,'source':'linux_post_exec_VmHWM','scope':'native worker high-water through final validation, sampled before close; close peak not covered','capture':'outside operation/query timers','legacy_child_rusage_not_used_as_isolated_engine_peak':True},indent=2)+'\n')

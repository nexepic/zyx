from pathlib import Path
import json,hashlib,ast,os,shutil
r=Path('/workspace/zyx-resume-evaluation-20261018');old=r/'final31fa-harness';h=r/'route-reuse-final-harness';out=r/'route-reuse-final-window';h.mkdir();out.mkdir();(out/'logs').mkdir();source='c28794a7c92434e809f9bbb17d48e8c457a70263'
mapping={str(old):str(h),str(r/'final31fa-window'):str(out),str(r/'frozen-bounded-reclaim-binaries'):str(r/'frozen-route-reuse-binaries'),str(r/'bounded-reclaim-contracts'):str(r/'route-reuse-contracts'),'31faef71':'c28794a7'}
for p in old.glob('*.py'):
 s=p.read_text()
 for a,b in mapping.items():s=s.replace(a,b)
 ast.parse(s);(h/p.name).write_text(s)
# The old resource/semantic control is frozen independently; refresh only
# consumer manifests for new binaries, preserving historical input provenance.
prepared={}
for scale in ['medium','holdout']:
 folder=out/'prepared-inputs'/scale;folder.mkdir(parents=True)
 for engine in ['current','control']:
  src=r/'window/prepared-inputs'/scale/(engine+'.zyx');dst=folder/src.name;os.link(src,dst);m=json.loads(Path(str(src)+'.json').read_text());binary=r/('frozen-route-reuse-binaries' if engine=='current' else 'frozen-control-resource-report-binaries')/'zyx-compare-bench';m.update(consumer_binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),consumer_manifest_refresh_only=True,original_manifest=str(src)+'.json',original_physical_input_unchanged=True);Path(str(dst)+'.json').write_text(json.dumps(m,indent=2)+'\n');prepared[str(dst)]=m
s=(r/'run-final31fa-evaluation.py').read_text()
for a,b in mapping.items():s=s.replace(a,b)
s=s.replace("r/'final31fa-harness/","r/'route-reuse-final-harness/")
s=s.replace('bounded-reclaim-contract-status.json','route-reuse-contract-status.json');s=s.replace("r=Path('/workspace/zyx-resume-evaluation-20261018')","""r=Path('/workspace/zyx-resume-evaluation-20261018')
import hashlib
registered=json.loads((r/'route-reuse-final-window/registration.json').read_text())
frozen=json.loads((r/'route-reuse-freeze.json').read_text())
assert registered['source_commit']==frozen['source_commit']
for name,digest in registered['harness_sha256'].items():
 assert hashlib.sha256((r/'route-reuse-final-harness'/name).read_bytes()).hexdigest()==digest
for name,digest in registered['binaries'].items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest""",1);ast.parse(s);driver=r/'run-route-reuse-final-evaluation.py';driver.write_text(s)
d=json.loads((r/'final31fa-window/registration.json').read_text());d.update(source_commit=source,production_source=source,window='20261018-immutable-route-reuse-final',status='registered_before_measurement_full_required_correctness_running',continuation_reason='31fa actual full-wide1800second failure is retained; its final performance window never started. New immutable branch reuse has mature128-field byte evidence and847distinct necessary checks after targeted fixture isolation rerun. No previous source samples pooled.',current_frozen_worker=str(r/'frozen-route-reuse-binaries/zyx-workload-contract-worker'),frozen_harness=str(h/'frozen-workload-preflight.py'),prepared_inputs=prepared,binaries={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for folder in [r/'frozen-route-reuse-binaries',r/'frozen-control-resource-report-binaries'] for p in folder.iterdir() if p.name in ['zyx-workload-contract-worker','zyx-compare-bench']},harness_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in h.glob('*.py')},independent_driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest(),source_proof='benchmarks/architecture-design/decisions/20261018-immutable-route-branch-reuse/proof.json',performance_start_dependency='All six frozen c287 full wide_large/dynamic correctness cases pass, thenO6resourcecheckpoint before broadmatrix.')
d['maintenance_orders']=d['orders']
for path,m in prepared.items():
 digest=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
 assert digest.hexdigest()==m['database_sha256']
(out/'registration.json').write_text(json.dumps(d,indent=2)+'\n');print('Preregistered repaired-source final window; no performance process started')

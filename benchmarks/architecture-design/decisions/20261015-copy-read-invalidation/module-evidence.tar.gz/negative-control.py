from pathlib import Path
import subprocess,shlex
root=Path('/workspace/zyx');source=Path('/tmp/zyx-trace-pinned-invalidation.cpp')
s=source.read_text().replace(' std::this_thread::sleep_for(std::chrono::milliseconds(2));','')
source.write_text(s)
target='CMakeFiles/zyx_core.dir/src/storage/relocatable/cache/BufferPool.cpp.o'
command=shlex.split(subprocess.check_output(['ninja','-C','buildDir','-t','commands',target],cwd=root,text=True).strip().splitlines()[-1])
for flag,value in [('-o','/tmp/zyx-old-copy-pin.o'),('-MF','/tmp/zyx-old-copy-pin.d')]:command[command.index(flag)+1]=value
command[command.index(str(root/'src/storage/relocatable/cache/BufferPool.cpp'))]=str(source)
subprocess.run(command,cwd=root/'buildDir',check=True)
link=shlex.split((root/'buildDir/global-output-link-command.txt').read_text())
link.insert(link.index('libzyx_core.a'),'/tmp/zyx-old-copy-pin.o');link[link.index('-o')+1]='/tmp/zyx-old-copy-pin-tests'
subprocess.run(link,cwd=root/'buildDir',check=True)
r=subprocess.run(['/tmp/zyx-old-copy-pin-tests','--gtest_filter=BufferPoolTest.TypedCopyReadsSerializeWithInvalidationWithoutExposingTransientPins'],cwd=root)
print('Negative-control exit:',r.returncode)
if r.returncode==0: raise RuntimeError('old implementation did not reproduce')

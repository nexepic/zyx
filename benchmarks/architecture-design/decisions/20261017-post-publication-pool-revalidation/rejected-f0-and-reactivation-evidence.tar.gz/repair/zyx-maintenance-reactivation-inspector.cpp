#include <fstream>
#include <iostream>
#include "graph/storage/StorageIO.hpp"
#include "graph/storage/relocatable/metadata/RelocatableMetadataStore.hpp"
using namespace graph::storage;
int main(int argc,char **argv) {
 if(argc!=2)return 2;
 auto stream=std::make_shared<std::fstream>(argv[1],std::ios::in|std::ios::binary);
 auto io=std::make_shared<StorageIO>(stream,INVALID_FILE_HANDLE,INVALID_FILE_HANDLE,StorageIOAccessMode::SIOAM_READ_ONLY);
 auto metadata=RelocatableMetadataStore::openReadOnly(io);auto snapshot=metadata->openSnapshot();
 std::cout<<"{\"generation\":"<<snapshot.superblock().generation.value()<<",\"catalog\":[";bool first=true;
 metadata->visitCatalogEntries(snapshot,[&](const CatalogEntry &e){if(!first)std::cout<<',';first=false;std::cout<<"{\"id\":"<<e.segment_id.value()<<",\"kind\":"<<unsigned(e.kind)<<",\"owner\":"<<e.owner_id<<",\"state\":"<<unsigned(e.state)<<",\"generation\":"<<e.generation.value()<<'}';});
 std::cout<<"],\"pages\":[";first=true;
 metadata->visitPageLocationsUntil(snapshot,[&](const PageLocation &l){if(!first)std::cout<<',';first=false;std::cout<<"{\"page\":"<<l.page_id.value()<<",\"segment\":"<<l.segment_id.value()<<'}';return true;});
 std::cout<<"]}\n";snapshot.release();
}

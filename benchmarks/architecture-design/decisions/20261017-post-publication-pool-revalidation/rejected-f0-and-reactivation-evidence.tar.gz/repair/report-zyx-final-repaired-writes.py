from pathlib import Path
import json,statistics,csv,math
r=Path('/tmp/zyx-final-five-repaired-window-20261017');groups={}
def pct(v,p):
 s=sorted(v);i=(len(s)-1)*p;a=math.floor(i);b=math.ceil(i);return s[a]+(s[b]-s[a])*(i-a)
for p in (r/'write-protection').glob('round-*/*/completed.json'):
 x=json.loads(p.read_text());e=x['engine'];n=x['round']
 if n not in [1,2,3]:continue
 rows={}
 for s in x['samples']:
  if s['phase']=='measure':rows.setdefault(s['workload'],[]).append(s)
 for name,ss in rows.items():
  if len(ss)!=10 or not all(s['full_poststate_verified_after_reopen'] for s in ss):raise ValueError('incomplete measurement/oracle')
  d={'engine':e,'round':n,'samples':10,'p50_ms':statistics.median([s['elapsed_ns']/1e6 for s in ss]),'p95_ms':pct([s['elapsed_ns']/1e6 for s in ss],.95),'peak_profile_rss_kib':x['rss_max_kib']}
  for field in ['read_bytes','write_bytes','file_bytes']:
   vv=[s['after'][field]-s['before'][field] for s in ss if s['before'] is not None]
   d['median_statement_'+field+'_delta']=statistics.median(vv) if vv else None
  groups.setdefault(name,{}).setdefault(e,[]).append(d)
out=[]
for name,engines in sorted(groups.items()):
 item={'workload':name,'processes':engines,'automatic_acceptance':False,'p95_note':'Ten-sample P95 is descriptive; uncertainty follows original bounded rule.'}
 for e,ds in engines.items():
  item[e+'_processes']=len(ds)
  for f in ['p50_ms','p95_ms','peak_profile_rss_kib','median_statement_read_bytes_delta','median_statement_write_bytes_delta','median_statement_file_bytes_delta']:
   vs=[d[f] for d in ds if d[f] is not None];item[e+'_'+f]=statistics.median(vs) if vs else None
 if 'current' in engines and 'control' in engines:
  for f in ['p50_ms','p95_ms']:
   item['current_'+f+'_change_vs_control']=item['current_'+f]/item['control_'+f]-1
 out.append(item)
(r/'write-comparison-progress.json').write_text(json.dumps({'scope':'Restored identical logical fixture per engine; within-engine immutable baseline; clone/open/reopen/poststate/integrity outside timers; Native IPC versus Kuzu Python entry and nonunique versus PK semantics differ. Not strict cross-engine win evidence.','rows':out,'valid_samples':sum(d['samples'] for es in groups.values() for ds in es.values() for d in ds),'automatic_acceptance':False},indent=2)+'\n')
for i in out:
 print(i['workload'], {e:i.get(e+'_processes',0) for e in ['control','current','kuzu']},'P50%:',round(i.get('current_p50_ms_change_vs_control',0)*100,2),'P95%:',round(i.get('current_p95_ms_change_vs_control',0)*100,2))

from pathlib import Path
import json,sys,importlib.util,tempfile,shutil,os,hashlib
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
spec=importlib.util.spec_from_file_location('window','/tmp/zyx-final-repaired-window.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w);w.restrict()
from runner.workload_preflight import NativeWorker,run_native
r=Path('/tmp/zyx-reactivation-full-untimed-20261017');r.mkdir(exist_ok=False);binary=Path('/workspace/zyx/buildDir_perf_control/zyx-workload-contract-worker');source=Path('/tmp/zyx-maintenance-reactivation-repro-20261017/before-maintenance.zyx');before=w.digest(source);case=r/'retained-file';case.mkdir()
with tempfile.TemporaryDirectory(prefix='zyx-gc-post-publication-') as tmp:
 path=Path(tmp)/'private.zyx';worker=NativeWorker(binary,path,case)
 try:
  worker.call('READONLY');replacement=path.with_suffix('.next');shutil.copyfile(source,replacement);os.replace(replacement,path);worker.call('READWRITE')
  first=worker.call('MAINTAIN');worker.call('INTEGRITY');worker.call('REOPEN');worker.call('INTEGRITY');second=worker.call('MAINTAIN');worker.call('INTEGRITY')
  worker.call('QUERY','MATCH (n:User) RETURN count(n) AS count',expected=[[10000]]);worker.call('QUERY','MATCH (n:Churn) RETURN count(n) AS count',expected=[[0]])
  assert first['retired_values']>0 and second['retired_values']==0,(first,second)
  retained={'first':first,'idempotent_second':second,'source_sha256':before,'reopen_and_integrity':'passed','stats':worker.call('STATS')}
 finally:
  worker.close();(case/'trace.json').write_text(json.dumps(worker.trace,indent=2)+'\n')
assert w.digest(source)==before
(r/'retained-repair.json').write_text(json.dumps(retained,indent=2)+'\n');print(json.dumps({'retained_repair':retained}),flush=True)
report=run_native(binary,r/'full-maintenance',profile='contract',seed=42,family='maintenance')
assert len(report['maintenance_windows'])==10 and report['full_results_checked']
(r/'proof.json').write_text(json.dumps({'scope':'Untimed correctness only; zero formal performance samples; registered full3warmup+10subsequent windows with100durable100node batches/window and full deletion/reopen/integrity, unchanged limits.','binary_sha256':w.digest(binary),'production_source_sha256':w.digest('/workspace/zyx/src/storage/relocatable/maintenance/LargeValueReachabilityReclaimer.cpp'),'retained_file':retained,'full_maintenance':report,'performance_admission':False},indent=2)+'\n');print(json.dumps({'full_maintenance':'passed','windows':13,'performance_samples':0}),flush=True)

from pathlib import Path
import json,subprocess,hashlib,xml.etree.ElementTree as ET,sys
root=Path('/workspace/zyx');mode=sys.argv[1];assert mode in ['negative','positive']
module='tests/src/storage/relocatable/maintenance/test_LargeValueReachabilityReclaimer.cpp';obj='CMakeFiles/zyx_test_suite.dir/'+module+'.o';core=root/'buildDir/libzyx_core.a'
before=hashlib.sha256(core.read_bytes()).hexdigest()
# The negative build deliberately compiles only the test object, never core.
targets=[obj] if mode=='negative' else ['zyx_core',obj]
subprocess.run(['cmake','--build','buildDir','--target',*targets,'-j','2'],cwd=root,check=True)
after=hashlib.sha256(core.read_bytes()).hexdigest()
if mode=='negative':assert before==after,'Negative control core changed'
link=json.loads(Path('/tmp/zyx-final-five-targeted-link.json').read_text());binary='/tmp/zyx-reactivation-'+mode+'-tests';link[link.index('-o')+1]=binary
subprocess.run(link,cwd=root/'buildDir',check=True)
new='RelocatableMetadataStoreTest.LargeValueReclaimerPreservesAnEmptyIndexPoolReactivatedByValueRetirement'
modules=['test_LargeValueReachabilityReclaimer.cpp','test_LargeValueMaintenanceJournal.cpp','test_RelocatableStorageBackendSchema_Maintenance.cpp','test_RelocatableProcessCrash_LargeValueMaintenance.cpp','test_BTreePageStoreOverlayCosts.cpp','test_MetadataRetirement.cpp']
names=[new]
if mode=='positive':
 for t in ET.parse('/tmp/zyx-final-five-targeted-initial-tests.xml').getroot().iter('testcase'):
  if Path(t.attrib.get('file','')).name in modules:names.append(t.attrib['classname']+'.'+t.attrib['name'])
 names=list(dict.fromkeys(names))
Path('/tmp/zyx-reactivation-'+mode+'-provenance.json').write_text(json.dumps({'source_core':'f0e44b78' if mode=='negative' else 'working O6 post-publication revalidation patch','core_sha256':after,'binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'test_source_sha256':hashlib.sha256((root/module).read_bytes()).hexdigest(),'modules':modules if mode=='positive' else [module],'tests_selected':len(names),'full_suite':False,'link':link},indent=2)+'\n')
p=subprocess.run([binary,'--gtest_filter='+':'.join(names),'--gtest_output=xml:/tmp/zyx-reactivation-'+mode+'-tests.xml'],cwd=root)
print(json.dumps({'mode':mode,'returncode':p.returncode,'tests_selected':len(names)}),flush=True)
if mode=='positive' and p.returncode:raise SystemExit(p.returncode)
if mode=='negative' and p.returncode==0:raise SystemExit('Counterexample did not reproduce; inspect fixture before claiming a regression')

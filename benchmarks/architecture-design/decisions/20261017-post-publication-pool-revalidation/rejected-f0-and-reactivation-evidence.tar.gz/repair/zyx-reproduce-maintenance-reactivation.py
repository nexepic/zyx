from pathlib import Path
import sys,json,shutil,os
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.workload_preflight import NativeWorker
r=Path('/tmp/zyx-maintenance-reactivation-repro-20261017');r.mkdir(exist_ok=False)
binary=Path('/workspace/zyx-optimization-final-repairs-20261017/binaries/2/zyx-workload-contract-worker');path=r/'working.zyx';w=NativeWorker(binary,path,r)
try:
 for start in range(0,10000,100):w.call('QUERY','CREATE '+','.join(f"(:User {{id:{i},country:'country-{i%8}',score:{i%7},age:{18+i%53}}})" for i in range(start,start+100)))
 w.call('QUERY','CREATE INDEX contract_base_user_id FOR (n:User) ON (n.id)')
 for start in range(0,10000,100):w.call('PARAM','CREATE '+','.join(f'(:Churn {{id:{i},body:$body}})' for i in range(start,start+100)),'body','string','y'*8192)
 w.call('QUERY','MATCH (n:Churn) DELETE n RETURN 1 AS deleted',expected=[[1]]*10000)
 w.call('READONLY');shutil.copyfile(path,r/'before-maintenance.zyx');w.call('READWRITE')
 error=None
 try:w.call('MAINTAIN')
 except RuntimeError as e:error=str(e)
 assert error=='relocatable shared page pool retirement requires an empty current Page Directory',error
 w.call('READONLY');shutil.copyfile(path,r/'after-rejected-maintenance.zyx');w.call('INTEGRITY')
 (r/'report.json').write_text(json.dumps({'source':'63f65f37/f0e44b78','error':error,'retained_before_and_after':True,'post_failure_integrity':'passed','performance_samples':0,'stats':w.call('STATS')},indent=2)+'\n');print((r/'report.json').read_text(),flush=True)
finally:
 w.close();(r/'trace.json').write_text(json.dumps(w.trace,indent=2)+'\n')

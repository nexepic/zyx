# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 373.187 | 359.083 | 371.8465 | 367.504 | 399.997 | 399.997 | 399.997 | 2.6892817331882912 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 309.423 | 307.662 | 315.6319 | 312.794 | 328.043 | 328.043 | 328.043 | 3.168247569399671 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 373.773 | 372.174 | 398.3464 | 400.745 | 414.888 | 414.888 | 414.888 | 2.510377902247893 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 4.98872 | 2.97899 | 3.502256 | 3.14649 | 4.98872 | 4.98872 | 4.98872 | 285.53024107889314 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

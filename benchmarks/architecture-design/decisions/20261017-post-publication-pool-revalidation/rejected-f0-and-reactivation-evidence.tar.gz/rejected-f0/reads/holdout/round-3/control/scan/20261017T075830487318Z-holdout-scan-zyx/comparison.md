# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 2038.72 | 2038.72 | 2179.6 | 1 | 1 |  |  | 2179.6 | 1.0691 | 1.0691 |
| label_scan_filter | holdout | zyx | 1968.32 | 1968.32 | 2111.27 | 1 | 1 |  |  | 2111.27 | 1.07263 | 1.07263 |
| topk_property_sort | holdout | zyx | 2475.66 | 2475.66 | 2483.64 | 1 | 1 |  |  | 2628.37 | 1.06168 | 1.00322 |
| two_hop_expand | holdout | zyx | 19.3025 | 19.3025 | 19.9243 | 1 | 1 |  |  | 22.945 | 1.18871 | 1.03221 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

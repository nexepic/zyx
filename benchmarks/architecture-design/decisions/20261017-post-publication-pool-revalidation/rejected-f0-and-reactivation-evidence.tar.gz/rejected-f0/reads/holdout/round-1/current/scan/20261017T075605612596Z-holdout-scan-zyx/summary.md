# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 365.695 | 361.751 | 366.8627 | 365.695 | 372.265 | 372.265 | 372.265 | 2.725815407235459 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 299.616 | 299.074 | 303.6533 | 299.88 | 317.343 | 317.343 | 317.343 | 3.2932294824393478 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 379.164 | 370.206 | 378.1323 | 378.375 | 384.747 | 384.747 | 384.747 | 2.6445770435374074 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 3.20997 | 2.8798 | 3.086625 | 3.04497 | 3.31549 | 3.31549 | 3.31549 | 323.9784554327137 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

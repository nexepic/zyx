# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | aggregation_count_by_group | holdout | 10 | 2.954975003376603 | 2.481188013916835 | 2.692961401771754 | 2.6634960086084902 | 2.954975003376603 | 2.954975003376603 | 2.954975003376603 | 371.3384080967814 | ok | cypher |
| kuzu | label_scan_filter | holdout | 10 | 1.5830380143597722 | 1.5821759880054742 | 1.6700294945621863 | 1.6045790107455105 | 1.905961980810389 | 1.905961980810389 | 1.905961980810389 | 598.7918196990643 | ok | cypher |
| kuzu | topk_property_sort | holdout | 10 | 2.9683040047530085 | 2.9683040047530085 | 3.2281581952702254 | 3.1397370039485395 | 3.742431988939643 | 3.742431988939643 | 3.742431988939643 | 309.77416207952945 | ok | cypher |
| kuzu | two_hop_expand | holdout | 10 | 1.054160005878657 | 0.7486009853892028 | 0.8523352007614449 | 0.8116739918477833 | 1.054160005878657 | 1.054160005878657 | 1.054160005878657 | 1173.247331691378 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

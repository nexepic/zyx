# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 2007.12 | 2007.12 | 2046.132 | 2031.77 | 2114.74 | 2114.74 | 2114.74 | 0.4887270224990372 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 2035.51 | 1949.38 | 1993.548 | 1985.2 | 2063.52 | 2063.52 | 2063.52 | 0.5016182203789424 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 2570.34 | 2423.69 | 2470.564 | 2444.4 | 2570.34 | 2570.34 | 2570.34 | 0.40476587532239605 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 39.3789 | 19.9477 | 23.728270000000002 | 20.3632 | 39.3789 | 39.3789 | 39.3789 | 42.143822537420554 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 2061.87 | 1964.69 | 2025.1259999999997 | 2016.5 | 2145.62 | 2145.62 | 2145.62 | 0.4937964353822923 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 1952.98 | 1908.98 | 1972.261 | 1964.33 | 2038.47 | 2038.47 | 2038.47 | 0.507032284266636 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 2548.02 | 2414.1 | 2533.56 | 2540.95 | 2617.22 | 2617.22 | 2617.22 | 0.39470152670550535 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 18.9142 | 18.8821 | 19.08501 | 18.9471 | 19.999 | 19.999 | 19.999 | 52.397143098169714 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

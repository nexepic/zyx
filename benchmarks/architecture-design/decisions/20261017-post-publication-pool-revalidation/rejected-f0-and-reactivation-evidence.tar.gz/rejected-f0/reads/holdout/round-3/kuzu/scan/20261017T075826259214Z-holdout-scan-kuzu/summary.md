# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | aggregation_count_by_group | holdout | 10 | 2.5176709750667214 | 2.5176709750667214 | 2.5922200991772115 | 2.593984012492001 | 2.6739909953903407 | 2.6739909953903407 | 2.6739909953903407 | 385.7697115755745 | ok | cypher |
| kuzu | label_scan_filter | holdout | 10 | 1.5999620081856847 | 1.5355169889517128 | 1.7831303004641086 | 1.6358340217266232 | 2.5252019986510277 | 2.5252019986510277 | 2.5252019986510277 | 560.8115120581612 | ok | cypher |
| kuzu | topk_property_sort | holdout | 10 | 3.1368909985758364 | 2.946252003312111 | 3.150472600827925 | 3.0925959872547537 | 3.47221500123851 | 3.47221500123851 | 3.47221500123851 | 317.41269539598795 | ok | cypher |
| kuzu | two_hop_expand | holdout | 10 | 0.9405929886270314 | 0.7510140130762011 | 0.8366921014385298 | 0.8135859970934689 | 0.9812429780140519 | 0.9812429780140519 | 0.9812429780140519 | 1195.1827897988926 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

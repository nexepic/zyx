# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 2179.6 | 1977.63 | 2051.187 | 2038.72 | 2179.6 | 2179.6 | 2179.6 | 0.4875225905780409 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 2111.27 | 1912.1 | 1991.843 | 1968.32 | 2111.27 | 2111.27 | 2111.27 | 0.5020476011412546 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 2483.64 | 2431.27 | 2496.3129999999996 | 2475.66 | 2628.37 | 2628.37 | 2628.37 | 0.4005907912990078 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 19.9243 | 18.9594 | 19.8016 | 19.3025 | 22.945 | 22.945 | 22.945 | 50.50096961861668 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 395.383 | 354.986 | 366.1326 | 361.089 | 395.383 | 395.383 | 395.383 | 2.7312509183831213 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 312.299 | 310.48 | 314.716 | 312.299 | 323.481 | 323.481 | 323.481 | 3.177467939348492 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 375.302 | 375.302 | 384.2952 | 382.232 | 399.692 | 399.692 | 399.692 | 2.602166251360933 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 3.75135 | 2.97873 | 3.502054 | 3.19671 | 4.92106 | 4.92106 | 4.92106 | 285.5467105875581 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

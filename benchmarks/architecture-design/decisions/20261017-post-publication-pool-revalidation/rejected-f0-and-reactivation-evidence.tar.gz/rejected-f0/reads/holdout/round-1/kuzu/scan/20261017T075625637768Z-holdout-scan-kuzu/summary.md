# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | aggregation_count_by_group | holdout | 10 | 2.5887649971991777 | 2.4595560098532587 | 2.5620962056564167 | 2.5179820077028126 | 2.8457930020522326 | 2.8457930020522326 | 2.8457930020522326 | 390.30540609375635 | ok | cypher |
| kuzu | label_scan_filter | holdout | 10 | 1.6556740156374872 | 1.511201000539586 | 1.620660602930002 | 1.5911599912215024 | 1.9020960025954992 | 1.9020960025954992 | 1.9020960025954992 | 617.0323374259201 | ok | cypher |
| kuzu | topk_property_sort | holdout | 10 | 3.1495300063397735 | 2.8898980235680938 | 3.0212695070076734 | 3.021301992703229 | 3.1495300063397735 | 3.1495300063397735 | 3.1495300063397735 | 330.98669207780154 | ok | cypher |
| kuzu | two_hop_expand | holdout | 10 | 0.9654299938119948 | 0.7517249905504286 | 0.8373630989808589 | 0.7897010073065758 | 0.9710479935165495 | 0.9710479935165495 | 0.9710479935165495 | 1194.2250634367383 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

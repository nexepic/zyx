# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 2016.5 | 2016.5 | 2061.87 | 1 | 1 |  |  | 2145.62 | 1.06403 | 1.0225 |
| label_scan_filter | holdout | zyx | 1964.33 | 1964.33 | 1952.98 | 1 | 1 |  |  | 2038.47 | 1.03774 | 0.994222 |
| topk_property_sort | holdout | zyx | 2540.95 | 2540.95 | 2548.02 | 1 | 1 |  |  | 2617.22 | 1.03002 | 1.00278 |
| two_hop_expand | holdout | zyx | 18.9471 | 18.9471 | 18.9142 | 1 | 1 |  |  | 19.999 | 1.05552 | 0.998264 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

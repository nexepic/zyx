# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 361.089 | 361.089 | 395.383 | 1 | 1 |  |  | 395.383 | 1.09497 | 1.09497 |
| label_scan_filter | holdout | zyx | 312.299 | 312.299 | 312.299 | 1 | 1 |  |  | 323.481 | 1.03581 | 1 |
| topk_property_sort | holdout | zyx | 382.232 | 382.232 | 375.302 | 1 | 1 |  |  | 399.692 | 1.04568 | 0.98187 |
| two_hop_expand | holdout | zyx | 3.19671 | 3.19671 | 3.75135 | 1 | 1 |  |  | 4.92106 | 1.53941 | 1.1735 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

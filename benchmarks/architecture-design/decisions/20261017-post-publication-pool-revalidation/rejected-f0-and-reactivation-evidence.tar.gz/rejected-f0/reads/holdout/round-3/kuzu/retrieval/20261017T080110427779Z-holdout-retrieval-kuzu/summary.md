# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | point_node_fetch_by_id | holdout | 10 | 0.23139998666010797 | 0.2172699896618724 | 0.23328399693127722 | 0.22038398310542107 | 0.26535001234151423 | 0.26535001234151423 | 0.26535001234151423 | 4286.620656172093 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 367.504 | 367.504 | 373.187 | 1 | 1 |  |  | 399.997 | 1.08842 | 1.01546 |
| label_scan_filter | holdout | zyx | 312.794 | 312.794 | 309.423 | 1 | 1 |  |  | 328.043 | 1.04875 | 0.989223 |
| topk_property_sort | holdout | zyx | 400.745 | 400.745 | 373.773 | 1 | 1 |  |  | 414.888 | 1.03529 | 0.932695 |
| two_hop_expand | holdout | zyx | 3.14649 | 3.14649 | 4.98872 | 1 | 1 |  |  | 4.98872 | 1.58549 | 1.58549 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

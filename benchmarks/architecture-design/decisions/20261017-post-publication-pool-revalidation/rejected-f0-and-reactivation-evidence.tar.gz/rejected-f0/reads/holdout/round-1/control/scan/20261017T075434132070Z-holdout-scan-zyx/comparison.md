# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 2031.77 | 2031.77 | 2007.12 | 1 | 1 |  |  | 2114.74 | 1.04084 | 0.987868 |
| label_scan_filter | holdout | zyx | 1985.2 | 1985.2 | 2035.51 | 1 | 1 |  |  | 2063.52 | 1.03945 | 1.02534 |
| topk_property_sort | holdout | zyx | 2444.4 | 2444.4 | 2570.34 | 1 | 1 |  |  | 2570.34 | 1.05152 | 1.05152 |
| two_hop_expand | holdout | zyx | 20.3632 | 20.3632 | 39.3789 | 1 | 1 |  |  | 39.3789 | 1.93383 | 1.93383 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

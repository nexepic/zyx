# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | point_node_fetch_by_id | holdout | 10 | 0.2291770069859922 | 0.21810000180266798 | 0.2317598060471937 | 0.22162601817399263 | 0.2563570160418749 | 0.2563570160418749 | 0.2563570160418749 | 4314.812033439344 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

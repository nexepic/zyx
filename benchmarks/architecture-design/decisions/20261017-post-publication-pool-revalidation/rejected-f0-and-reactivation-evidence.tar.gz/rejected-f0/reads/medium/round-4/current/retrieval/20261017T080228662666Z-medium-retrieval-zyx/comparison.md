# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 3.8745 | 3.8745 | 3.8134 | 1 | 1 |  |  | 4.27587 | 1.10359 | 0.98423 |
| one_hop_fetch_neighbor_ids | medium | zyx | 2.98984 | 2.98984 | 2.96928 | 1 | 1 |  |  | 3.48059 | 1.16414 | 0.993123 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.5724 | 4.5724 | 4.78704 | 1 | 1 |  |  | 4.85975 | 1.06284 | 1.04694 |
| point_edge_fetch_by_endpoints | medium | zyx | 3.50828 | 3.50828 | 3.47417 | 1 | 1 |  |  | 4.21622 | 1.20179 | 0.990277 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | one_hop_expand | medium | 100 | 16.6659 | 15.4773 | 16.188064999999998 | 16.084 | 16.8648 | 19.8255 | 20.2642 | 61.77390565209616 | ok | api |
| zyx | two_hop_expand | medium | 100 | 21.5156 | 19.7981 | 20.782934 | 20.5323 | 21.9232 | 26.2106 | 28.7311 | 48.11640165916901 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

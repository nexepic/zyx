# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | one_hop_expand | medium | 100 | 16.0509 | 15.4892 | 16.688765 | 16.4151 | 18.0688 | 18.8971 | 30.7631 | 59.920551340977 | ok | api |
| zyx | two_hop_expand | medium | 100 | 20.0372 | 19.8721 | 20.851433999999998 | 20.7803 | 21.6464 | 22.2354 | 23.0268 | 47.95833226626044 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

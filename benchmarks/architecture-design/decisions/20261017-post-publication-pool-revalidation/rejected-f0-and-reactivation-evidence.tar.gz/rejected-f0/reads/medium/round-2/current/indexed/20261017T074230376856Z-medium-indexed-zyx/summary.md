# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 1.75597 | 1.64846 | 1.7716439999999998 | 1.71172 | 1.97993 | 1.97993 | 1.97993 | 564.4474849348967 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 197.563 | 194.195 | 199.3493 | 197.563 | 210.619 | 210.619 | 210.619 | 5.016320599069071 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1199.34 | 1138.31 | 1189.23 | 1193.59 | 1261.61 | 1261.61 | 1261.61 | 0.8408802334283528 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 2842.33 | 2783.48 | 2871.013 | 2842.33 | 3058.42 | 3058.42 | 3058.42 | 0.34830911598101433 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 2888.97 | 2754.27 | 2838.011 | 2822.35 | 2931.22 | 2931.22 | 2931.22 | 0.35235945174278743 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5202.48 | 5191.01 | 5262.924 | 5215.12 | 5443.78 | 5443.78 | 5443.78 | 0.19000844397525027 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 2802.79 | 2719.19 | 2754.829 | 2746.05 | 2802.79 | 2802.79 | 2802.79 | 0.36299893750210993 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2812.57 | 2714.94 | 2820.232 | 2803.96 | 2985.58 | 2985.58 | 2985.58 | 0.35458075789509513 | ok | api |
| zyx | one_hop_expand | medium | 10 | 16.6184 | 15.9522 | 16.80433 | 16.6184 | 18.1874 | 18.1874 | 18.1874 | 59.508471923605406 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6202.44 | 6147.33 | 6293.536 | 6212.38 | 6515.38 | 6515.38 | 6515.38 | 0.15889318818546522 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 552.785 | 552.785 | 560.3111 | 559.285 | 569.89 | 569.89 | 569.89 | 1.7847228084540891 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3356.36 | 3341.83 | 3422.996 | 3394.86 | 3638.33 | 3638.33 | 3638.33 | 0.29214173782265596 | ok | api |
| zyx | two_hop_expand | medium | 10 | 21.2682 | 20.8752 | 23.1871 | 21.5801 | 28.7264 | 28.7264 | 28.7264 | 43.12742861332379 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

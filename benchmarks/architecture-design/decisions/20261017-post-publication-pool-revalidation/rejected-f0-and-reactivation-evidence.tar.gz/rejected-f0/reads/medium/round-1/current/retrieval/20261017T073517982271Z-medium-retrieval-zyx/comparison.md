# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 3.97851 | 3.97851 | 4.16646 | 1 | 1 |  |  | 7.201 | 1.80997 | 1.04724 |
| one_hop_fetch_neighbor_ids | medium | zyx | 3.17071 | 3.17071 | 3.00905 | 1 | 1 |  |  | 3.72694 | 1.17543 | 0.949015 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.71978 | 4.71978 | 4.81673 | 1 | 1 |  |  | 4.95735 | 1.05033 | 1.02054 |
| point_edge_fetch_by_endpoints | medium | zyx | 3.52702 | 3.52702 | 3.65335 | 1 | 1 |  |  | 4.18635 | 1.18694 | 1.03582 |
| point_node_fetch_by_id | medium | zyx | 4.04837 | 4.04837 | 4.07301 | 1 | 1 |  |  | 5.54289 | 1.36917 | 1.00609 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 3.96974 | 3.76363 | 3.9430819999999995 | 3.92826 | 4.41215 | 4.41215 | 4.41215 | 253.60872535747419 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 2.96468 | 2.94266 | 3.171514 | 3.06942 | 3.87205 | 3.87205 | 3.87205 | 315.3068219153376 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 4.82518 | 4.5187 | 4.694395999999999 | 4.65503 | 5.00425 | 5.00425 | 5.00425 | 213.01994974433347 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 3.53414 | 3.37167 | 3.520783 | 3.46622 | 3.80762 | 3.80762 | 3.80762 | 284.0277290591326 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 3.66894 | 3.5575 | 3.663009 | 3.58661 | 4.29932 | 4.29932 | 4.29932 | 272.99960223957953 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 494.907 | 488.402 | 496.3148 | 492.197 | 520.78 | 520.78 | 520.78 | 2.0148502522995484 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 492.844 | 485.136 | 494.19449999999995 | 492.844 | 506.943 | 506.943 | 506.943 | 2.023494798100748 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 816.49 | 778.291 | 819.5099 | 816.49 | 866.899 | 866.899 | 866.899 | 1.220241512640665 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 481.971 | 460.415 | 482.82730000000004 | 467.335 | 512.141 | 512.141 | 512.141 | 2.0711339230403913 | ok | api |
| zyx | label_scan_filter | medium | 10 | 415.559 | 408.25 | 447.5129 | 446.57 | 554.388 | 554.388 | 554.388 | 2.234572455900154 | ok | api |
| zyx | one_hop_expand | medium | 10 | 2.38682 | 2.34239 | 2.5104420000000003 | 2.50328 | 2.72858 | 2.72858 | 2.72858 | 398.33622923771986 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 992.964 | 985.384 | 1005.9672 | 997.564 | 1033.75 | 1033.75 | 1033.75 | 0.9940681962592816 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 354.264 | 322.566 | 328.93600000000004 | 326.711 | 354.264 | 354.264 | 354.264 | 3.040105066031082 | ok | api |
| zyx | topk_property_sort | medium | 10 | 541.897 | 501.043 | 524.6573999999999 | 523.295 | 541.897 | 541.897 | 541.897 | 1.906005709630704 | ok | api |
| zyx | two_hop_expand | medium | 10 | 2.88264 | 2.85037 | 3.25445 | 2.90505 | 5.75813 | 5.75813 | 5.75813 | 307.27158198773986 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

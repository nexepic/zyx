# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 2842.33 | 2842.33 | 2842.33 | 1 | 1 |  |  | 3058.42 | 1.07603 | 1 |
| aggregation_group_by | medium | zyx | 2822.35 | 2822.35 | 2888.97 | 1 | 1 |  |  | 2931.22 | 1.03857 | 1.0236 |
| all_nodes_property_filter | medium | zyx | 5215.12 | 5215.12 | 5202.48 | 1 | 1 |  |  | 5443.78 | 1.04385 | 0.997576 |
| label_multi_property_filter | medium | zyx | 2746.05 | 2746.05 | 2802.79 | 1 | 1 |  |  | 2802.79 | 1.02066 | 1.02066 |
| label_scan_filter | medium | zyx | 2803.96 | 2803.96 | 2812.57 | 1 | 1 |  |  | 2985.58 | 1.06477 | 1.00307 |
| one_hop_expand | medium | zyx | 16.6184 | 16.6184 | 16.6184 | 1 | 1 |  |  | 18.1874 | 1.09441 | 1 |
| relationship_property_filter | medium | zyx | 6212.38 | 6212.38 | 6202.44 | 1 | 1 |  |  | 6515.38 | 1.04877 | 0.9984 |
| relationship_type_scan | medium | zyx | 559.285 | 559.285 | 552.785 | 1 | 1 |  |  | 569.89 | 1.01896 | 0.988378 |
| topk_property_sort | medium | zyx | 3394.86 | 3394.86 | 3356.36 | 1 | 1 |  |  | 3638.33 | 1.07172 | 0.988659 |
| two_hop_expand | medium | zyx | 21.5801 | 21.5801 | 21.2682 | 1 | 1 |  |  | 28.7264 | 1.33115 | 0.985547 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

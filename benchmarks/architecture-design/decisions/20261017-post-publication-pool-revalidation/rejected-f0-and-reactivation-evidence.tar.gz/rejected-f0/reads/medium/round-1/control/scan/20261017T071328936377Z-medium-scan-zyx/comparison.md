# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 2883.59 | 2883.59 | 2888.41 | 1 | 1 |  |  | 3001.12 | 1.04076 | 1.00167 |
| aggregation_group_by | medium | zyx | 2862.65 | 2862.65 | 2862.65 | 1 | 1 |  |  | 3003.79 | 1.0493 | 1 |
| all_nodes_property_filter | medium | zyx | 5331.05 | 5331.05 | 5214.04 | 1 | 1 |  |  | 5697.34 | 1.06871 | 0.978051 |
| label_multi_property_filter | medium | zyx | 2736.52 | 2736.52 | 2729.56 | 1 | 1 |  |  | 2850.47 | 1.04164 | 0.997457 |
| label_scan_filter | medium | zyx | 2726.33 | 2726.33 | 2784.32 | 1 | 1 |  |  | 2839.28 | 1.04143 | 1.02127 |
| one_hop_expand | medium | zyx | 15.6544 | 15.6544 | 15.6544 | 1 | 1 |  |  | 16.2112 | 1.03557 | 1 |
| relationship_property_filter | medium | zyx | 6263.31 | 6263.31 | 6105.45 | 1 | 1 |  |  | 6468.39 | 1.03274 | 0.974796 |
| relationship_type_scan | medium | zyx | 582.1 | 582.1 | 629.515 | 1 | 1 |  |  | 629.515 | 1.08146 | 1.08146 |
| topk_property_sort | medium | zyx | 3526.84 | 3526.84 | 3482.64 | 1 | 1 |  |  | 3700.06 | 1.04911 | 0.987468 |
| two_hop_expand | medium | zyx | 19.813 | 19.813 | 20.0919 | 1 | 1 |  |  | 25.3432 | 1.27912 | 1.01408 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

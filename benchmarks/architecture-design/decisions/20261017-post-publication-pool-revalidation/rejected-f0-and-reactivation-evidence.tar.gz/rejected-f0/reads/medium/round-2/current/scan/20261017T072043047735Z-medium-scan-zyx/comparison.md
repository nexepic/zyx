# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 499.321 | 499.321 | 501.499 | 1 | 1 |  |  | 509.845 | 1.02108 | 1.00436 |
| aggregation_group_by | medium | zyx | 491.783 | 491.783 | 496.734 | 1 | 1 |  |  | 507.965 | 1.0329 | 1.01007 |
| all_nodes_property_filter | medium | zyx | 775.504 | 775.504 | 783.087 | 1 | 1 |  |  | 797.587 | 1.02848 | 1.00978 |
| label_multi_property_filter | medium | zyx | 470.431 | 470.431 | 466.088 | 1 | 1 |  |  | 496.904 | 1.05627 | 0.990768 |
| label_scan_filter | medium | zyx | 418.087 | 418.087 | 415.247 | 1 | 1 |  |  | 426.493 | 1.02011 | 0.993207 |
| one_hop_expand | medium | zyx | 2.37052 | 2.37052 | 2.37573 | 1 | 1 |  |  | 2.49939 | 1.05436 | 1.0022 |
| relationship_property_filter | medium | zyx | 1033.29 | 1033.29 | 1034.9 | 1 | 1 |  |  | 1066.9 | 1.03253 | 1.00156 |
| relationship_type_scan | medium | zyx | 332.709 | 332.709 | 330.805 | 1 | 1 |  |  | 340.831 | 1.02441 | 0.994277 |
| topk_property_sort | medium | zyx | 496.621 | 496.621 | 508.644 | 1 | 1 |  |  | 508.644 | 1.02421 | 1.02421 |
| two_hop_expand | medium | zyx | 2.93547 | 2.93547 | 2.8705 | 1 | 1 |  |  | 3.42188 | 1.1657 | 0.977867 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

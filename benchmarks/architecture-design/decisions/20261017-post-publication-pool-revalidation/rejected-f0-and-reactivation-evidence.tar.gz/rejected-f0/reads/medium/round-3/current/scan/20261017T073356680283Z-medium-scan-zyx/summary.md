# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 504.212 | 478.257 | 490.6555 | 485.989 | 505.788 | 505.788 | 505.788 | 2.03808986142008 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 475.785 | 467.24 | 477.12420000000003 | 475.785 | 489.355 | 489.355 | 489.355 | 2.095890336310755 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 788.359 | 745.277 | 761.884 | 757.22 | 788.359 | 788.359 | 788.359 | 1.3125357665996398 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 463.73 | 462.535 | 470.34790000000004 | 465.228 | 514.366 | 514.366 | 514.366 | 2.1260858186036335 | ok | api |
| zyx | label_scan_filter | medium | 10 | 457.418 | 413.157 | 428.17830000000004 | 417.476 | 457.418 | 457.418 | 457.418 | 2.335475665160985 | ok | api |
| zyx | one_hop_expand | medium | 10 | 2.39511 | 2.36655 | 2.395254 | 2.38024 | 2.46209 | 2.46209 | 2.46209 | 417.4922576060827 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 987.787 | 965.187 | 1000.8543 | 987.787 | 1061.16 | 1061.16 | 1061.16 | 0.9991464292055298 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 327.925 | 318.745 | 327.1782 | 327.206 | 339.605 | 339.605 | 339.605 | 3.056438356834288 | ok | api |
| zyx | topk_property_sort | medium | 10 | 508.87 | 504.828 | 513.585 | 511.002 | 527.263 | 527.263 | 527.263 | 1.9470973646037169 | ok | api |
| zyx | two_hop_expand | medium | 10 | 2.8986 | 2.84143 | 2.958835 | 2.9315 | 3.09012 | 3.09012 | 3.09012 | 337.97085677302044 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

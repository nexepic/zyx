# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 492.197 | 492.197 | 494.907 | 1 | 1 |  |  | 520.78 | 1.05807 | 1.00551 |
| aggregation_group_by | medium | zyx | 492.844 | 492.844 | 492.844 | 1 | 1 |  |  | 506.943 | 1.02861 | 1 |
| all_nodes_property_filter | medium | zyx | 816.49 | 816.49 | 816.49 | 1 | 1 |  |  | 866.899 | 1.06174 | 1 |
| label_multi_property_filter | medium | zyx | 467.335 | 467.335 | 481.971 | 1 | 1 |  |  | 512.141 | 1.09588 | 1.03132 |
| label_scan_filter | medium | zyx | 446.57 | 446.57 | 415.559 | 1 | 1 |  |  | 554.388 | 1.24144 | 0.930557 |
| one_hop_expand | medium | zyx | 2.50328 | 2.50328 | 2.38682 | 1 | 1 |  |  | 2.72858 | 1.09 | 0.953477 |
| relationship_property_filter | medium | zyx | 997.564 | 997.564 | 992.964 | 1 | 1 |  |  | 1033.75 | 1.03627 | 0.995389 |
| relationship_type_scan | medium | zyx | 326.711 | 326.711 | 354.264 | 1 | 1 |  |  | 354.264 | 1.08433 | 1.08433 |
| topk_property_sort | medium | zyx | 523.295 | 523.295 | 541.897 | 1 | 1 |  |  | 541.897 | 1.03555 | 1.03555 |
| two_hop_expand | medium | zyx | 2.90505 | 2.90505 | 2.88264 | 1 | 1 |  |  | 5.75813 | 1.98211 | 0.992286 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 23.5349 | 22.7161 | 23.10014 | 22.9122 | 23.5349 | 23.5349 | 23.5349 | 43.28978092773464 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 22.1095 | 20.9356 | 21.92129 | 21.8389 | 22.723 | 22.723 | 22.723 | 45.61775333477181 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 33.2292 | 33.2292 | 34.522059999999996 | 34.1452 | 37.4846 | 37.4846 | 37.4846 | 28.966985168324253 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 22.1794 | 21.1821 | 21.8336 | 21.8274 | 22.4159 | 22.4159 | 22.4159 | 45.80096731642972 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 26.1563 | 25.0898 | 26.731659999999998 | 25.9728 | 33.5314 | 33.5314 | 33.5314 | 37.408825340439016 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 100 | 27.8034 | 22.674 | 24.107035999999997 | 23.9208 | 25.6017 | 26.5511 | 27.8034 | 41.48166535280406 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 100 | 21.7567 | 20.6612 | 22.047338 | 21.9245 | 23.0262 | 24.2258 | 29.8299 | 45.35694966893509 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 100 | 34.4195 | 32.5275 | 34.245688 | 33.9577 | 36.9544 | 38.351 | 38.5585 | 29.200756603283892 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 100 | 22.5861 | 21.1779 | 22.649969000000002 | 22.5947 | 24.0181 | 24.672 | 25.4014 | 44.15017080155827 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

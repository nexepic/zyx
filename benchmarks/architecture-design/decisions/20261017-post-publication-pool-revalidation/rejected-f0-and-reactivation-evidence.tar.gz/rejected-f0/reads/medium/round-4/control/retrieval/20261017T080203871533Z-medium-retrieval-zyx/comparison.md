# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 23.9208 | 23.9208 | 27.8034 | 1 | 1 |  |  | 25.6017 | 1.07027 | 1.16231 |
| one_hop_fetch_neighbor_ids | medium | zyx | 21.9245 | 21.9245 | 21.7567 | 1 | 1 |  |  | 23.0262 | 1.05025 | 0.992346 |
| one_hop_fetch_neighbor_records | medium | zyx | 33.9577 | 33.9577 | 34.4195 | 1 | 1 |  |  | 36.9544 | 1.08825 | 1.0136 |
| point_edge_fetch_by_endpoints | medium | zyx | 22.5947 | 22.5947 | 22.5861 | 1 | 1 |  |  | 24.0181 | 1.063 | 0.999619 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

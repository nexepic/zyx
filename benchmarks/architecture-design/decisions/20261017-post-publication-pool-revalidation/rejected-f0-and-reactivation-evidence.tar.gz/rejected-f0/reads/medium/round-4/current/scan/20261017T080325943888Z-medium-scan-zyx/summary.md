# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | one_hop_expand | medium | 100 | 2.56072 | 2.31881 | 2.4875936999999997 | 2.45408 | 2.76751 | 2.85966 | 3.0553 | 401.9949077697053 | ok | api |
| zyx | two_hop_expand | medium | 100 | 2.8579 | 2.8025 | 2.9335888999999997 | 2.92373 | 3.16176 | 3.21718 | 3.24074 | 340.87939179208104 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

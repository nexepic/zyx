# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 22.4155 | 22.4155 | 22.387 | 1 | 1 |  |  | 23.1269 | 1.03174 | 0.998729 |
| one_hop_fetch_neighbor_ids | medium | zyx | 21.2465 | 21.2465 | 21.054 | 1 | 1 |  |  | 22.9074 | 1.07817 | 0.99094 |
| one_hop_fetch_neighbor_records | medium | zyx | 33.8476 | 33.8476 | 35.2344 | 1 | 1 |  |  | 37.6129 | 1.11124 | 1.04097 |
| point_edge_fetch_by_endpoints | medium | zyx | 21.569 | 21.569 | 21.1093 | 1 | 1 |  |  | 23.205 | 1.07585 | 0.978687 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

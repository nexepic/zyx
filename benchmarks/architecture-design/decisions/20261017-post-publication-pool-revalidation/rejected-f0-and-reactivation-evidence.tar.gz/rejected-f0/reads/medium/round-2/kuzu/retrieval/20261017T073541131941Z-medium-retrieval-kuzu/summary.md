# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.48669599345885217 | 0.4487289988901466 | 0.477270400733687 | 0.4705720057245344 | 0.5473149940371513 | 0.5473149940371513 | 0.5473149940371513 | 2095.248308847026 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.6026160262990743 | 0.5254919815342873 | 0.5991994927171618 | 0.5599729774985462 | 0.9319389937445521 | 0.9319389937445521 | 0.9319389937445521 | 1668.8932686931141 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.7078500057104975 | 0.7045360107440501 | 1.0462405945872888 | 0.8949449984356761 | 2.388720982708037 | 2.388720982708037 | 2.388720982708037 | 955.8030965090497 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.4399459867272526 | 0.3936879802495241 | 0.4178369970759377 | 0.4212689818814397 | 0.4399459867272526 | 0.4399459867272526 | 0.4399459867272526 | 2393.2777781720943 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.25601600646041334 | 0.21422500140033662 | 0.22964849486015737 | 0.21919197752140462 | 0.25601600646041334 | 0.25601600646041334 | 0.25601600646041334 | 4354.480967136066 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

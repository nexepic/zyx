# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 11.1911 | 10.1575 | 10.56572 | 10.2977 | 11.1911 | 11.1911 | 11.1911 | 94.64570327436275 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 3263.01 | 3051.96 | 3178.256 | 3182.08 | 3263.01 | 3263.01 | 3263.01 | 0.31463796497198465 | ok | api |
| zyx | property_range_indexed | medium | 10 | 21120.7 | 20489.4 | 21022.079999999998 | 21120.7 | 21411.2 | 21411.2 | 21411.2 | 0.04756903217949889 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

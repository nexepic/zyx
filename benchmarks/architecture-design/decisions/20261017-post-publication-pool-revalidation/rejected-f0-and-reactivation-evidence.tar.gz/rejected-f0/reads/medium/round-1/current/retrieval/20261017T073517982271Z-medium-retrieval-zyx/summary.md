# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 4.16646 | 3.87798 | 4.315403 | 3.97851 | 7.201 | 7.201 | 7.201 | 231.72806803906843 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 3.00905 | 2.95369 | 3.178988 | 3.17071 | 3.72694 | 3.72694 | 3.72694 | 314.5655158182415 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 4.81673 | 4.54489 | 4.734284000000001 | 4.71978 | 4.95735 | 4.95735 | 4.95735 | 211.22518209722946 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 3.65335 | 3.3799 | 3.606343 | 3.52702 | 4.18635 | 4.18635 | 4.18635 | 277.28920959542677 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 4.07301 | 3.80078 | 4.180533 | 4.04837 | 5.54289 | 5.54289 | 5.54289 | 239.20394839605382 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

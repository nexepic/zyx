# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 3.94088 | 3.79999 | 3.9507890000000003 | 3.90387 | 4.14719 | 4.14719 | 4.14719 | 253.11399824187015 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 2.94997 | 2.91242 | 3.0386990000000003 | 2.97427 | 3.31723 | 3.31723 | 3.31723 | 329.08820518254686 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 4.86709 | 4.49493 | 4.715165000000001 | 4.69638 | 5.10623 | 5.10623 | 5.10623 | 212.08165567906954 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 3.42749 | 3.31789 | 3.4318530000000003 | 3.41289 | 3.56428 | 3.56428 | 3.56428 | 291.38777214525214 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 3.55565 | 3.55565 | 3.7571719999999997 | 3.60285 | 4.75277 | 4.75277 | 4.75277 | 266.15763132483687 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 10.8158 | 10.3154 | 10.82383 | 10.8547 | 11.2794 | 11.2794 | 11.2794 | 92.38873855188044 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 3259.99 | 3215.1 | 3312.495 | 3266.81 | 3515.26 | 3515.26 | 3515.26 | 0.3018872481316953 | ok | api |
| zyx | property_range_indexed | medium | 10 | 20869.4 | 20640.5 | 21015.66 | 20789.2 | 22024.8 | 22024.8 | 22024.8 | 0.04758356387570031 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

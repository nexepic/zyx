# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 25.6318 | 25.6318 | 27.5 | 1 | 1 |  |  | 27.5 | 1.07289 | 1.07289 |
| one_hop_fetch_neighbor_ids | medium | zyx | 23.0787 | 23.0787 | 22.7921 | 1 | 1 |  |  | 37.1025 | 1.60765 | 0.987582 |
| one_hop_fetch_neighbor_records | medium | zyx | 36.1729 | 36.1729 | 35.7384 | 1 | 1 |  |  | 40.1969 | 1.11124 | 0.987988 |
| point_edge_fetch_by_endpoints | medium | zyx | 22.0577 | 22.0577 | 21.7071 | 1 | 1 |  |  | 26.7788 | 1.21403 | 0.984105 |
| point_node_fetch_by_id | medium | zyx | 25.3517 | 25.3517 | 26.3784 | 1 | 1 |  |  | 26.3893 | 1.04093 | 1.0405 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

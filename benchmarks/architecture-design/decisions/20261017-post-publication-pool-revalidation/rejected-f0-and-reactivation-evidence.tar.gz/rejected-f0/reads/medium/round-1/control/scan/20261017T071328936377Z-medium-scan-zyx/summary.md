# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 2888.41 | 2784.01 | 2884.715 | 2883.59 | 3001.12 | 3001.12 | 3001.12 | 0.34665469552451456 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 2862.65 | 2793.62 | 2883.008 | 2862.65 | 3003.79 | 3003.79 | 3003.79 | 0.34685994627833155 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5214.04 | 5181.83 | 5367.689 | 5331.05 | 5697.34 | 5697.34 | 5697.34 | 0.18629991417162955 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 2729.56 | 2705.54 | 2774.8 | 2736.52 | 2850.47 | 2850.47 | 2850.47 | 0.36038633415020904 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2784.32 | 2662.59 | 2748.1600000000003 | 2726.33 | 2839.28 | 2839.28 | 2839.28 | 0.36387983232417326 | ok | api |
| zyx | one_hop_expand | medium | 10 | 15.6544 | 15.4809 | 15.76037 | 15.6544 | 16.2112 | 16.2112 | 16.2112 | 63.45028701737332 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6105.45 | 6080.18 | 6292.74 | 6263.31 | 6468.39 | 6468.39 | 6468.39 | 0.1589132873756106 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 629.515 | 577.12 | 592.3665 | 582.1 | 629.515 | 629.515 | 629.515 | 1.688144079720916 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3482.64 | 3426.05 | 3568.9849999999997 | 3526.84 | 3700.06 | 3700.06 | 3700.06 | 0.280191707166043 | ok | api |
| zyx | two_hop_expand | medium | 10 | 20.0919 | 19.6623 | 20.46511 | 19.813 | 25.3432 | 25.3432 | 25.3432 | 48.86365135589303 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

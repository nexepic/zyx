# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 1.69621 | 1.67084 | 1.7401550000000001 | 1.70913 | 1.91433 | 1.91433 | 1.91433 | 574.6614525717537 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 206.925 | 191.123 | 196.5521 | 194.561 | 206.925 | 206.925 | 206.925 | 5.087709569116789 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1150.95 | 1127.78 | 1189.709 | 1174.67 | 1276.05 | 1276.05 | 1276.05 | 0.8405416786794081 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

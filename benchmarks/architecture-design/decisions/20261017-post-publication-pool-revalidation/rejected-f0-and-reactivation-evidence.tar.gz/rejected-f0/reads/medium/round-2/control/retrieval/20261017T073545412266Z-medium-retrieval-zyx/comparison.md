# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 22.949 | 22.949 | 22.7755 | 1 | 1 |  |  | 23.8437 | 1.03899 | 0.99244 |
| one_hop_fetch_neighbor_ids | medium | zyx | 24.0679 | 24.0679 | 24.0679 | 1 | 1 |  |  | 25.81 | 1.07238 | 1 |
| one_hop_fetch_neighbor_records | medium | zyx | 34.1677 | 34.1677 | 33.221 | 1 | 1 |  |  | 36.1373 | 1.05765 | 0.972293 |
| point_edge_fetch_by_endpoints | medium | zyx | 23.4686 | 23.4686 | 23.3209 | 1 | 1 |  |  | 27.5783 | 1.17511 | 0.993706 |
| point_node_fetch_by_id | medium | zyx | 25.8413 | 25.8413 | 26.1532 | 1 | 1 |  |  | 26.7725 | 1.03604 | 1.01207 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

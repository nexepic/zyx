# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 485.989 | 485.989 | 504.212 | 1 | 1 |  |  | 505.788 | 1.04074 | 1.0375 |
| aggregation_group_by | medium | zyx | 475.785 | 475.785 | 475.785 | 1 | 1 |  |  | 489.355 | 1.02852 | 1 |
| all_nodes_property_filter | medium | zyx | 757.22 | 757.22 | 788.359 | 1 | 1 |  |  | 788.359 | 1.04112 | 1.04112 |
| label_multi_property_filter | medium | zyx | 465.228 | 465.228 | 463.73 | 1 | 1 |  |  | 514.366 | 1.10562 | 0.99678 |
| label_scan_filter | medium | zyx | 417.476 | 417.476 | 457.418 | 1 | 1 |  |  | 457.418 | 1.09567 | 1.09567 |
| one_hop_expand | medium | zyx | 2.38024 | 2.38024 | 2.39511 | 1 | 1 |  |  | 2.46209 | 1.03439 | 1.00625 |
| relationship_property_filter | medium | zyx | 987.787 | 987.787 | 987.787 | 1 | 1 |  |  | 1061.16 | 1.07428 | 1 |
| relationship_type_scan | medium | zyx | 327.206 | 327.206 | 327.925 | 1 | 1 |  |  | 339.605 | 1.03789 | 1.0022 |
| topk_property_sort | medium | zyx | 511.002 | 511.002 | 508.87 | 1 | 1 |  |  | 527.263 | 1.03182 | 0.995828 |
| two_hop_expand | medium | zyx | 2.9315 | 2.9315 | 2.8986 | 1 | 1 |  |  | 3.09012 | 1.05411 | 0.988777 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

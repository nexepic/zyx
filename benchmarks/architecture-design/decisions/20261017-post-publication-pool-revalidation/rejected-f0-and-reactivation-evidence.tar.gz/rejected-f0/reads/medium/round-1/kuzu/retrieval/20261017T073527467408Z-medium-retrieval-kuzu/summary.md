# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.5467339942697436 | 0.4451940185390413 | 0.48435170319862664 | 0.47432701103389263 | 0.5467339942697436 | 0.5467339942697436 | 0.5467339942697436 | 2064.615430060566 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.554616010049358 | 0.5188829964026809 | 0.5654029955621809 | 0.554616010049358 | 0.6930289964657277 | 0.6930289964657277 | 0.6930289964657277 | 1768.649985672076 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.6669200083706528 | 0.6251589802559465 | 0.6519201007904485 | 0.648512999759987 | 0.6851159851066768 | 0.6851159851066768 | 0.6851159851066768 | 1533.93030647085 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.43177499901503325 | 0.39895600639283657 | 0.4309483978431672 | 0.4297819978091866 | 0.48039600369520485 | 0.48039600369520485 | 0.48039600369520485 | 2320.463436004987 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.22704398725181818 | 0.2207640209235251 | 0.25229090242646635 | 0.2310599957127124 | 0.2993600210174918 | 0.2993600210174918 | 0.2993600210174918 | 3963.678398159695 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 100 | 3.8134 | 3.74855 | 3.9294114 | 3.8745 | 4.27587 | 4.46343 | 4.69436 | 254.49104158449785 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 100 | 2.96928 | 2.90154 | 3.0644049 | 2.98984 | 3.48059 | 3.662 | 3.71923 | 326.3276337927798 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 100 | 4.78704 | 4.44169 | 4.6061327 | 4.5724 | 4.85975 | 5.02917 | 5.50336 | 217.10186508521562 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 100 | 3.47417 | 3.32973 | 3.6598282 | 3.50828 | 4.21622 | 5.62406 | 6.22148 | 273.2368694246358 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

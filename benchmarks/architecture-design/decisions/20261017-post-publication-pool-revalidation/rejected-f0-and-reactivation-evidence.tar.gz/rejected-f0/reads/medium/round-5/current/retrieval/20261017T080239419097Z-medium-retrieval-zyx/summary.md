# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 100 | 3.88465 | 3.75389 | 4.050139 | 3.94482 | 4.49002 | 4.81703 | 7.68291 | 246.90510621981124 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 100 | 3.22205 | 2.917 | 3.0899052 | 3.06149 | 3.36643 | 3.58496 | 3.64938 | 323.6345244507825 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 100 | 4.72505 | 4.58909 | 5.0308769 | 4.92183 | 5.6019 | 5.82002 | 6.19835 | 198.77250425268804 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 100 | 3.57128 | 3.3403 | 3.5922539 | 3.51946 | 3.98248 | 4.15118 | 4.34696 | 278.37675950466644 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

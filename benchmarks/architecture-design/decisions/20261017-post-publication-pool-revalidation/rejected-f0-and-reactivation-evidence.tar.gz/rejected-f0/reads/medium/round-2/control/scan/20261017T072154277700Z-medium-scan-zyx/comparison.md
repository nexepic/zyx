# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 2858.05 | 2858.05 | 2979.74 | 1 | 1 |  |  | 3133.6 | 1.09641 | 1.04258 |
| aggregation_group_by | medium | zyx | 2875.24 | 2875.24 | 2863.9 | 1 | 1 |  |  | 2976.17 | 1.0351 | 0.996056 |
| all_nodes_property_filter | medium | zyx | 5289.2 | 5289.2 | 5165.46 | 1 | 1 |  |  | 5436.72 | 1.02789 | 0.976605 |
| label_multi_property_filter | medium | zyx | 2809.68 | 2809.68 | 2744.08 | 1 | 1 |  |  | 2951.4 | 1.05044 | 0.976652 |
| label_scan_filter | medium | zyx | 2724.55 | 2724.55 | 2851.61 | 1 | 1 |  |  | 2851.61 | 1.04664 | 1.04664 |
| one_hop_expand | medium | zyx | 15.4832 | 15.4832 | 15.4699 | 1 | 1 |  |  | 48.1655 | 3.11082 | 0.999141 |
| relationship_property_filter | medium | zyx | 6297.35 | 6297.35 | 6287.07 | 1 | 1 |  |  | 6592.78 | 1.04691 | 0.998368 |
| relationship_type_scan | medium | zyx | 577.512 | 577.512 | 574.893 | 1 | 1 |  |  | 615.591 | 1.06594 | 0.995465 |
| topk_property_sort | medium | zyx | 3453.91 | 3453.91 | 3480.6 | 1 | 1 |  |  | 3587 | 1.03853 | 1.00773 |
| two_hop_expand | medium | zyx | 19.7319 | 19.7319 | 20.1696 | 1 | 1 |  |  | 21.4186 | 1.08548 | 1.02218 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

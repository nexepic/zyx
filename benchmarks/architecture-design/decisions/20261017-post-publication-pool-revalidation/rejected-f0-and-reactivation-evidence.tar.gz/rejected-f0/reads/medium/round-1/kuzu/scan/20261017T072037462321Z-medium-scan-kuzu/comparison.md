# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | kuzu | 3.44779 |  |  |  |  | kuzu |  |  |  |  |
| aggregation_group_by | medium | kuzu | 3.0731 |  |  |  |  | kuzu |  |  |  |  |
| all_nodes_property_filter | medium | kuzu | 0.82359 |  |  |  |  | kuzu |  |  |  |  |
| label_multi_property_filter | medium | kuzu | 2.75764 |  |  |  |  | kuzu |  |  |  |  |
| label_scan_filter | medium | kuzu | 2.14844 |  |  |  |  | kuzu |  |  |  |  |
| one_hop_expand | medium | kuzu | 0.37398 |  |  |  |  | kuzu |  |  |  |  |
| relationship_property_filter | medium | kuzu | 11.0328 |  |  |  |  | kuzu |  |  |  |  |
| relationship_type_scan | medium | kuzu | 5.96693 |  |  |  |  | kuzu |  |  |  |  |
| topk_property_sort | medium | kuzu | 3.77647 |  |  |  |  | kuzu |  |  |  |  |
| two_hop_expand | medium | kuzu | 0.78294 |  |  |  |  | kuzu |  |  |  |  |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 1.66412 | 1.66412 | 1.6894759999999998 | 1.67784 | 1.73497 | 1.73497 | 1.73497 | 591.8995002000621 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 192.63 | 192.63 | 198.9954 | 194.844 | 218.231 | 218.231 | 218.231 | 5.025241789508702 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1226.3 | 1134.54 | 1178.337 | 1168.8 | 1262.87 | 1262.87 | 1262.87 | 0.8486536534115453 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

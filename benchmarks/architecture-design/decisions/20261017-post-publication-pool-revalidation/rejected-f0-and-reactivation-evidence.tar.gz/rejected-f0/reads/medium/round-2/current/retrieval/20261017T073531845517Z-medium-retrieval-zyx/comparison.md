# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 3.90387 | 3.90387 | 3.94088 | 1 | 1 |  |  | 4.14719 | 1.06233 | 1.00948 |
| one_hop_fetch_neighbor_ids | medium | zyx | 2.97427 | 2.97427 | 2.94997 | 1 | 1 |  |  | 3.31723 | 1.11531 | 0.99183 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.69638 | 4.69638 | 4.86709 | 1 | 1 |  |  | 5.10623 | 1.08727 | 1.03635 |
| point_edge_fetch_by_endpoints | medium | zyx | 3.41289 | 3.41289 | 3.42749 | 1 | 1 |  |  | 3.56428 | 1.04436 | 1.00428 |
| point_node_fetch_by_id | medium | zyx | 3.60285 | 3.60285 | 3.55565 | 1 | 1 |  |  | 4.75277 | 1.31917 | 0.986899 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 27.5 | 24.266 | 25.894029999999997 | 25.6318 | 27.5 | 27.5 | 27.5 | 38.61894035034331 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 22.7921 | 22.7119 | 25.44466 | 23.0787 | 37.1025 | 37.1025 | 37.1025 | 39.30097710089268 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 35.7384 | 33.8456 | 36.37456 | 36.1729 | 40.1969 | 40.1969 | 40.1969 | 27.491741480859147 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 21.7071 | 21.7071 | 22.76996 | 22.0577 | 26.7788 | 26.7788 | 26.7788 | 43.917512371563234 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 26.3784 | 24.7781 | 25.56981 | 25.3517 | 26.3893 | 26.3893 | 26.3893 | 39.10862067414658 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

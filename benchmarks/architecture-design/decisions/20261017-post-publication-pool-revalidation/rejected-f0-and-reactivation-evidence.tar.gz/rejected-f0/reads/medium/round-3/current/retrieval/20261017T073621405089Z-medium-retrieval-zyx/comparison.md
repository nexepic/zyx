# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 3.92826 | 3.92826 | 3.96974 | 1 | 1 |  |  | 4.41215 | 1.12318 | 1.01056 |
| one_hop_fetch_neighbor_ids | medium | zyx | 3.06942 | 3.06942 | 2.96468 | 1 | 1 |  |  | 3.87205 | 1.26149 | 0.965876 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.65503 | 4.65503 | 4.82518 | 1 | 1 |  |  | 5.00425 | 1.07502 | 1.03655 |
| point_edge_fetch_by_endpoints | medium | zyx | 3.46622 | 3.46622 | 3.53414 | 1 | 1 |  |  | 3.80762 | 1.09849 | 1.01959 |
| point_node_fetch_by_id | medium | zyx | 3.58661 | 3.58661 | 3.66894 | 1 | 1 |  |  | 4.29932 | 1.19871 | 1.02295 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

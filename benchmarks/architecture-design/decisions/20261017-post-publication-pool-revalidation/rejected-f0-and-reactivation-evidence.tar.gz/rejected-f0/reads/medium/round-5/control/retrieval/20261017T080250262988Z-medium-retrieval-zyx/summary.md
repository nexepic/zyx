# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 100 | 22.387 | 22.2417 | 22.551295 | 22.4155 | 23.1269 | 23.737 | 23.8973 | 44.34335145720013 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 100 | 21.054 | 20.5615 | 21.525937 | 21.2465 | 22.9074 | 23.8749 | 24.77 | 46.455585185443965 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 100 | 35.2344 | 32.3899 | 34.479509 | 33.8476 | 37.6129 | 43.5287 | 44.5005 | 29.00273318857296 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 100 | 21.1093 | 21.1038 | 21.783494 | 21.569 | 23.205 | 24.0541 | 24.2601 | 45.90631787536012 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 22.7755 | 22.6657 | 23.12208 | 22.949 | 23.8437 | 23.8437 | 23.8437 | 43.248704268820106 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 24.0679 | 20.7765 | 23.783350000000002 | 24.0679 | 25.81 | 25.81 | 25.81 | 42.04622141119733 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 33.221 | 32.9769 | 34.355740000000004 | 34.1677 | 36.1373 | 36.1373 | 36.1373 | 29.10721760031948 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 23.3209 | 22.7247 | 24.29676 | 23.4686 | 27.5783 | 27.5783 | 27.5783 | 41.15775107462888 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 26.1532 | 25.5945 | 26.03441 | 25.8413 | 26.7725 | 26.7725 | 26.7725 | 38.41070337295909 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

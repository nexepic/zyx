# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 22.9122 | 22.9122 | 23.5349 | 1 | 1 |  |  | 23.5349 | 1.02718 | 1.02718 |
| one_hop_fetch_neighbor_ids | medium | zyx | 21.8389 | 21.8389 | 22.1095 | 1 | 1 |  |  | 22.723 | 1.04048 | 1.01239 |
| one_hop_fetch_neighbor_records | medium | zyx | 34.1452 | 34.1452 | 33.2292 | 1 | 1 |  |  | 37.4846 | 1.0978 | 0.973173 |
| point_edge_fetch_by_endpoints | medium | zyx | 21.8274 | 21.8274 | 22.1794 | 1 | 1 |  |  | 22.4159 | 1.02696 | 1.01613 |
| point_node_fetch_by_id | medium | zyx | 25.9728 | 25.9728 | 26.1563 | 1 | 1 |  |  | 33.5314 | 1.29102 | 1.00707 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 10.5438 | 10.203 | 10.45355 | 10.3697 | 10.9523 | 10.9523 | 10.9523 | 95.66128253081489 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 3171.85 | 3132.2 | 3246.7889999999998 | 3229.91 | 3386.72 | 3386.72 | 3386.72 | 0.30799660834134895 | ok | api |
| zyx | property_range_indexed | medium | 10 | 20790.0 | 20759.8 | 21059.97 | 20977.5 | 21664.6 | 21664.6 | 21664.6 | 0.04748344845695412 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

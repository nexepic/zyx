# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 3.94482 | 3.94482 | 3.88465 | 1 | 1 |  |  | 4.49002 | 1.13821 | 0.984747 |
| one_hop_fetch_neighbor_ids | medium | zyx | 3.06149 | 3.06149 | 3.22205 | 1 | 1 |  |  | 3.36643 | 1.09961 | 1.05245 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.92183 | 4.92183 | 4.72505 | 1 | 1 |  |  | 5.6019 | 1.13817 | 0.960019 |
| point_edge_fetch_by_endpoints | medium | zyx | 3.51946 | 3.51946 | 3.57128 | 1 | 1 |  |  | 3.98248 | 1.13156 | 1.01472 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.48603498726151884 | 0.4491400031838566 | 0.469457297003828 | 0.4731259832624346 | 0.48616499407216907 | 0.48616499407216907 | 0.48616499407216907 | 2130.1191958932227 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.5700280016753823 | 0.5225680069997907 | 0.54572619847022 | 0.5456620128825307 | 0.5700280016753823 | 0.5700280016753823 | 0.5700280016753823 | 1832.4207318673734 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.6958629819564521 | 0.6249189900700003 | 0.6684623978799209 | 0.663084996631369 | 0.7402980118058622 | 0.7402980118058622 | 0.7402980118058622 | 1495.9704587297292 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.4399260214995593 | 0.3930380044039339 | 0.44623270514421165 | 0.43741302215494215 | 0.5980890127830207 | 0.5980890127830207 | 0.5980890127830207 | 2240.9832100424464 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.22971798898652196 | 0.2135339891538024 | 0.24067779595497996 | 0.21965298219583929 | 0.37064499338157475 | 0.37064499338157475 | 0.37064499338157475 | 4154.932514784435 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

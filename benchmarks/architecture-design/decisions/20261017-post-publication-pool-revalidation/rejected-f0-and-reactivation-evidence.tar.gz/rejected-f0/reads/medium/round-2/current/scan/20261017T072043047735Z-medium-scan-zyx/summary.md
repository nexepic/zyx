# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 501.499 | 487.881 | 499.2772 | 499.321 | 509.845 | 509.845 | 509.845 | 2.002895385569379 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 496.734 | 479.248 | 492.6336 | 491.783 | 507.965 | 507.965 | 507.965 | 2.0299062020942134 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 783.087 | 758.057 | 776.3149000000001 | 775.504 | 797.587 | 797.587 | 797.587 | 1.2881370691197604 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 466.088 | 466.088 | 477.6229 | 470.431 | 496.904 | 496.904 | 496.904 | 2.0937019560829264 | ok | api |
| zyx | label_scan_filter | medium | 10 | 415.247 | 415.089 | 419.3759 | 418.087 | 426.493 | 426.493 | 426.493 | 2.3844956279080414 | ok | api |
| zyx | one_hop_expand | medium | 10 | 2.37573 | 2.33437 | 2.403489 | 2.37052 | 2.49939 | 2.49939 | 2.49939 | 416.0618168004929 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 1034.9 | 990.658 | 1031.5129000000002 | 1033.29 | 1066.9 | 1066.9 | 1066.9 | 0.9694498246216794 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 330.805 | 328.672 | 333.1044 | 332.709 | 340.831 | 340.831 | 340.831 | 3.002061816055267 | ok | api |
| zyx | topk_property_sort | medium | 10 | 508.644 | 491.631 | 498.41319999999996 | 496.621 | 508.644 | 508.644 | 508.644 | 2.006367407604775 | ok | api |
| zyx | two_hop_expand | medium | 10 | 2.8705 | 2.84103 | 2.971762 | 2.93547 | 3.42188 | 3.42188 | 3.42188 | 336.5007022769656 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

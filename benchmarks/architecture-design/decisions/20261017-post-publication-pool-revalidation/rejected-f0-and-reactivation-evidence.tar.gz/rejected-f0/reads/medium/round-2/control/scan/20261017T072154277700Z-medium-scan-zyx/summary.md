# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 2979.74 | 2769.55 | 2941.929 | 2858.05 | 3133.6 | 3133.6 | 3133.6 | 0.339913029852182 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 2863.9 | 2786.12 | 2885.669 | 2875.24 | 2976.17 | 2976.17 | 2976.17 | 0.3465400917430239 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5165.46 | 5075.73 | 5262.793 | 5289.2 | 5436.72 | 5436.72 | 5436.72 | 0.19001317361332662 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 2744.08 | 2742.53 | 2819.566 | 2809.68 | 2951.4 | 2951.4 | 2951.4 | 0.35466451219797657 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2851.61 | 2677.2 | 2753.3450000000003 | 2724.55 | 2851.61 | 2851.61 | 2851.61 | 0.3631945869478761 | ok | api |
| zyx | one_hop_expand | medium | 10 | 15.4699 | 15.392 | 20.31821 | 15.4832 | 48.1655 | 48.1655 | 48.1655 | 49.21693397203789 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6287.07 | 6203.42 | 6379.0650000000005 | 6297.35 | 6592.78 | 6592.78 | 6592.78 | 0.15676278576876077 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 574.893 | 563.332 | 583.5699 | 577.512 | 615.591 | 615.591 | 615.591 | 1.7135907797849068 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3480.6 | 3415.8 | 3477.5270000000005 | 3453.91 | 3587.0 | 3587.0 | 3587.0 | 0.28756067170722177 | ok | api |
| zyx | two_hop_expand | medium | 10 | 20.1696 | 19.6485 | 19.96604 | 19.7319 | 21.4186 | 21.4186 | 21.4186 | 50.08504440540037 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

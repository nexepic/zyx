# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | point_lookup_indexed | medium | 10 | 0.3215520118828863 | 0.20001298980787396 | 0.2515312051400542 | 0.2463220153003931 | 0.3215520118828863 | 0.3215520118828863 | 0.3215520118828863 | 3975.6498580094403 | ok | cypher |
| kuzu | property_equality_indexed | medium | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | unsupported | cypher |
| kuzu | property_range_indexed | medium | 0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | unsupported | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

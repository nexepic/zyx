# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | one_hop_expand | medium | 100 | 2.50361 | 2.36011 | 3.3145496000000003 | 3.17388 | 4.40133 | 5.10744 | 13.4263 | 301.70011635970087 | ok | api |
| zyx | two_hop_expand | medium | 100 | 2.88075 | 2.82364 | 2.9478023 | 2.88605 | 3.23389 | 3.62426 | 4.34797 | 339.2357757506329 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

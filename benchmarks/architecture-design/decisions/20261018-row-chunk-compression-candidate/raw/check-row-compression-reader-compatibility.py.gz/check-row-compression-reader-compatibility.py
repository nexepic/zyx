from pathlib import Path
import os,sys,json,hashlib,resource
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.workload_preflight import NativeWorker
r=Path('/workspace/zyx-resume-evaluation-20261018');db=r/'property-path-diagnosis-after-row-compression/diagnostic.zyx';resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3));before=hashlib.sha256(db.read_bytes()).hexdigest();reports=[]
identifier=(128+1048576)*1000+7;props={'id':identifier,**{f'field_{k}':k for k in range(128)},'body':'x'*1048576};props['field_0']=77
dynamic={'id':95,**{f'field_{k}':k+95 for k in range(64)}};dynamic['field_0']='changed';del dynamic['field_1']
for engine in ['control','current']:
 binary=r/f'{engine}-readonly-worker';w=NativeWorker(binary,db)
 try:
  w.call('QUERY','MATCH (n:Wide) RETURN count(*) AS count',expected=[[32]])
  w.call('QUERY',f'MATCH (n:Wide {{id:{identifier}}}) RETURN properties(n) AS fields',expected=[[props]])
  w.call('QUERY','MATCH (n:Dynamic {id:95}) RETURN properties(n) AS fields',expected=[[dynamic]])
  w.close()
 except BaseException:w.process.kill();w.process.wait();raise
 assert hashlib.sha256(db.read_bytes()).hexdigest()==before
 reports.append({'consumer':engine,'consumer_scope':'Pre-repair static core physical-readonly helper','consumer_binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'queries':3,'exact_typed_values_checked':True,'source_database_hash_unchanged':True})
(r/'row-compression-reader-compatibility.json').write_text(json.dumps({'status':'passed','new_compressed_producer_database_sha256':before,'consumers':reports,'format_or_driver_abi_change':False,'performance_samples':0},indent=2)+'\n');print('Both old readonly consumers passed exact values without changing database bytes')

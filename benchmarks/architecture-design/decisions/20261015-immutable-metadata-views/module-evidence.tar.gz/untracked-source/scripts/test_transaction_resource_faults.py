#!/usr/bin/env python3
"""Run explicitly selected transaction OOM/retention cases in isolated processes."""
import argparse
import json
import pathlib
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", required=True, type=pathlib.Path)
    parser.add_argument("--output", type=pathlib.Path)
    args = parser.parse_args()
    worker = args.worker.resolve(strict=True)
    results = []
    with tempfile.TemporaryDirectory(prefix="zyx-transaction-resource-") as temporary:
        for mode in ("rollback-oom", "rollback-many-oom", "rollback-retention", "commit-retention"):
            completed = subprocess.run(
                [str(worker), mode, str(pathlib.Path(temporary) / (mode + ".zyx"))],
                text=True, capture_output=True, timeout=120, check=False,
            )
            if completed.returncode:
                raise RuntimeError(f"{mode} exited {completed.returncode}: {completed.stderr.strip()}")
            evidence = json.loads(completed.stdout)
            if evidence.get("mode") != mode or evidence.get("passed") is not True:
                raise RuntimeError(f"{mode} returned invalid evidence: {evidence!r}")
            results.append(evidence)
    report = {"cases": results, "passed": len(results), "failures": 0, "full_suite": False}
    encoded = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()

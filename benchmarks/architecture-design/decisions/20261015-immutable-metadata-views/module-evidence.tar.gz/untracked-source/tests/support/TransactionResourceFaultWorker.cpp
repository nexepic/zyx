/**
 * @file TransactionResourceFaultWorker.cpp
 * @brief Isolated allocation-failure and terminal transaction retention checks.
 * Copyright (c) 2026 Nexepic. Licensed under the Apache License, Version 2.0.
 */
#include "graph/storage/relocatable/backend/RelocatableStorageBackend.hpp"
#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <memory>
#include <new>
#include <string>

namespace {
std::atomic<bool> denyAllocations{false};
std::atomic<size_t> liveBytes{0U};
struct alignas(std::max_align_t) AllocationHeader { void *base; size_t bytes; };

void *allocate(size_t bytes, size_t alignment = alignof(std::max_align_t)) {
    if (denyAllocations.load(std::memory_order_relaxed)) throw std::bad_alloc();
    bytes = std::max(size_t{1U}, bytes);
    alignment = std::max(alignment, alignof(AllocationHeader));
    if (bytes > (std::numeric_limits<size_t>::max)() - sizeof(AllocationHeader) - alignment)
        throw std::bad_alloc();
    const size_t total = bytes + sizeof(AllocationHeader) + alignment;
    void *base = std::malloc(total);
    if (!base) throw std::bad_alloc();
    void *result = static_cast<std::byte *>(base) + sizeof(AllocationHeader);
    size_t available = total - sizeof(AllocationHeader);
    if (!std::align(alignment, bytes, result, available)) { std::free(base); throw std::bad_alloc(); }
    auto *header = static_cast<AllocationHeader *>(result) - 1;
    std::construct_at(header, AllocationHeader{base, bytes});
    liveBytes.fetch_add(bytes, std::memory_order_relaxed);
    return result;
}
void deallocate(void *pointer) noexcept {
    if (!pointer) return;
    auto *header = static_cast<AllocationHeader *>(pointer) - 1;
    liveBytes.fetch_sub(header->bytes, std::memory_order_relaxed);
    std::free(header->base);
}
struct RejectAllocations {
    RejectAllocations() { denyAllocations.store(true, std::memory_order_relaxed); }
    ~RejectAllocations() { denyAllocations.store(false, std::memory_order_relaxed); }
};
} // namespace

// Only this independently selected executable replaces allocation. The normal
// test suite, production binaries and benchmark binaries retain their allocators.
void *operator new(size_t bytes) { return allocate(bytes); }
void *operator new[](size_t bytes) { return allocate(bytes); }
void operator delete(void *pointer) noexcept { deallocate(pointer); }
void operator delete[](void *pointer) noexcept { deallocate(pointer); }
void operator delete(void *pointer, size_t) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, size_t) noexcept { deallocate(pointer); }
void *operator new(size_t bytes, std::align_val_t alignment) { return allocate(bytes, static_cast<size_t>(alignment)); }
void *operator new[](size_t bytes, std::align_val_t alignment) { return allocate(bytes, static_cast<size_t>(alignment)); }
void operator delete(void *pointer, std::align_val_t) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, std::align_val_t) noexcept { deallocate(pointer); }
void operator delete(void *pointer, size_t, std::align_val_t) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, size_t, std::align_val_t) noexcept { deallocate(pointer); }
void *operator new(size_t bytes, const std::nothrow_t &) noexcept { try { return allocate(bytes); } catch (...) { return nullptr; } }
void *operator new[](size_t bytes, const std::nothrow_t &) noexcept { try { return allocate(bytes); } catch (...) { return nullptr; } }
void operator delete(void *pointer, const std::nothrow_t &) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, const std::nothrow_t &) noexcept { deallocate(pointer); }
void *operator new(size_t bytes, std::align_val_t alignment, const std::nothrow_t &) noexcept {
    try { return allocate(bytes, static_cast<size_t>(alignment)); } catch (...) { return nullptr; }
}
void *operator new[](size_t bytes, std::align_val_t alignment, const std::nothrow_t &) noexcept {
    try { return allocate(bytes, static_cast<size_t>(alignment)); } catch (...) { return nullptr; }
}
void operator delete(void *pointer, std::align_val_t, const std::nothrow_t &) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, std::align_val_t, const std::nothrow_t &) noexcept { deallocate(pointer); }

using namespace graph;
using namespace graph::storage;
namespace {
uint64_t stageNodes(LogicalGraphTransaction &transaction, size_t count, size_t payloadBytes = 0U) {
    LogicalGraphMutationBatch batch;
    batch.node_creates.resize(count);
    if (payloadBytes) batch.node_creates.front().properties.push_back({"payload", PropertyValue(std::string(payloadBytes, 'q'))});
    const auto result = transaction.stageMutationBatch(std::move(batch));
    if (result.created_node_ids.size() != count) throw std::runtime_error("staged identity count changed");
    return result.created_node_ids.back();
}
size_t destroyClosed(std::unique_ptr<LogicalGraphTransaction> &transaction) {
    const size_t before = liveBytes.load(std::memory_order_relaxed);
    transaction.reset();
    const size_t after = liveBytes.load(std::memory_order_relaxed);
    if (after > before) throw std::runtime_error("closed transaction destruction allocated memory");
    const size_t retained = before - after;
    // The closed object itself is expected; payloads, ID arrays and their spare
    // capacity must already have been released. This is not an RSS measurement.
    if (retained >= 16U * 1024U) throw std::runtime_error("closed transaction retained payload or ID capacity");
    return retained;
}
}
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    try {
        const std::string mode = argv[1];
        if (mode != "rollback-oom" && mode != "rollback-many-oom" && mode != "rollback-retention" && mode != "commit-retention") return 2;
        RelocatableStorageBackendOptions options;
        options.data_path = argv[2];
        options.open_mode = OpenMode::OPEN_CREATE_NEW_FILE;
        auto backend = RelocatableStorageBackend::initializeNew(options);
        backend->open();
        auto transaction = backend->beginLogicalGraphTransaction(false);
        size_t retained = 0U;
        if (mode == "commit-retention") {
            const auto id = stageNodes(*transaction, 1U, 1024U * 1024U);
            const auto result = transaction->commit();
            if (transaction->state() != LogicalGraphTransactionState::LGTTS_COMMITTED || result.created_node_ids != std::vector<uint64_t>{id}) return 3;
            retained = destroyClosed(transaction);
            auto snapshot = backend->openLogicalGraphReadSnapshot();
            if (snapshot->readNodeProperty(id, "payload") != PropertyValue(std::string(1024U * 1024U, 'q'))) return 4;
        } else {
            const size_t statements = mode == "rollback-many-oom" ? 40U : 1U;
            uint64_t abandoned = 0U;
            for (size_t statement = 0U; statement < statements; ++statement)
                abandoned = stageNodes(*transaction, mode == "rollback-retention" ? 8192U : 1U);
            {
                RejectAllocations rejection;
                transaction->rollback();
            }
            if (transaction->state() != LogicalGraphTransactionState::LGTTS_ROLLED_BACK) return 5;
            retained = destroyClosed(transaction);
            auto next = backend->beginLogicalGraphTransaction(false);
            const uint64_t nextId = stageNodes(*next, 1U);
            if (nextId <= abandoned) return 6;
            const auto result = next->commit();
            if (result.created_node_ids != std::vector<uint64_t>{nextId}) return 7;
            next.reset();
            auto snapshot = backend->openLogicalGraphReadSnapshot();
            if (snapshot->readNodeShaped(nextId, {}).node_id != nextId) return 8;
        }
        static_cast<void>(backend->verifyIntegrity());
        backend->close();
        backend->open();
        static_cast<void>(backend->verifyIntegrity());
        backend->close();
        std::cout << "{\"mode\":\"" << mode << "\",\"closed_object_bytes\":" << retained << ",\"passed\":true}\n";
        return 0;
    } catch (const std::exception &error) {
        denyAllocations.store(false, std::memory_order_relaxed);
        std::cerr << error.what() << '\n';
        return 10;
    }
}

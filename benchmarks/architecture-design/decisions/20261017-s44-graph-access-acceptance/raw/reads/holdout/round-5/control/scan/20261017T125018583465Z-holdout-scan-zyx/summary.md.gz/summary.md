# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | topk_property_sort | holdout | 100 | 2457.33 | 2367.25 | 2635.0834999999997 | 2649.04 | 2873.83 | 2988.03 | 3007.77 | 0.3794946156355197 | ok | api |
| zyx | two_hop_expand | holdout | 100 | 20.8982 | 18.9192 | 21.271179000000004 | 20.6474 | 24.0762 | 26.2315 | 60.5882 | 47.011968636059144 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

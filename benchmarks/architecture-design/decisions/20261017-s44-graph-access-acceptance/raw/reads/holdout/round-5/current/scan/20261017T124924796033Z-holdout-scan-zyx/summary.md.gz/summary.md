# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | topk_property_sort | holdout | 100 | 510.574 | 372.215 | 424.66844 | 406.543 | 517.455 | 557.522 | 561.463 | 2.3547782359338973 | ok | api |
| zyx | two_hop_expand | holdout | 100 | 3.41897 | 2.8366 | 3.238494 | 3.0517 | 4.13303 | 5.24916 | 6.33949 | 308.78550338521546 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

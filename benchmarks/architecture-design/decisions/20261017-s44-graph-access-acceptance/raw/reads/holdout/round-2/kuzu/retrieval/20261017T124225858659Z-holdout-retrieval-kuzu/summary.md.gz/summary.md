# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | point_node_fetch_by_id | holdout | 10 | 0.22436000290326774 | 0.21713998285122216 | 0.2432818029774353 | 0.22436000290326774 | 0.31627502175979316 | 0.31627502175979316 | 0.31627502175979316 | 4110.459507293077 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | aggregation_count_by_group | holdout | 10 | 2.509858983103186 | 2.5094689917750657 | 2.582717000041157 | 2.5155170005746186 | 2.6935490022879094 | 2.6935490022879094 | 2.6935490022879094 | 387.1891500245921 | ok | cypher |
| kuzu | label_scan_filter | holdout | 10 | 1.5454109816346318 | 1.5454109816346318 | 1.6052533959737048 | 1.5821050037629902 | 1.6923970251809806 | 1.6923970251809806 | 1.6923970251809806 | 622.9546079816428 | ok | cypher |
| kuzu | topk_property_sort | holdout | 10 | 3.0542990134563297 | 3.044495009817183 | 3.181331802625209 | 3.113857004791498 | 3.4577820042613894 | 3.4577820042613894 | 3.4577820042613894 | 314.3337639836273 | ok | cypher |
| kuzu | two_hop_expand | holdout | 10 | 0.8299899927806109 | 0.7596460054628551 | 0.8023080008570105 | 0.7971310114953667 | 0.8482359990011901 | 0.8482359990011901 | 0.8482359990011901 | 1246.4041227705802 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 363.746 | 354.569 | 377.0505 | 369.481 | 425.258 | 425.258 | 425.258 | 2.6521646304672717 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 340.121 | 297.711 | 309.1937 | 300.741 | 340.121 | 340.121 | 340.121 | 3.2342185497311235 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 393.158 | 390.775 | 406.1067 | 393.158 | 444.35 | 444.35 | 444.35 | 2.4624070472119763 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 2.99443 | 2.97806 | 3.2576590000000003 | 3.06285 | 4.35117 | 4.35117 | 4.35117 | 306.96890005982823 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

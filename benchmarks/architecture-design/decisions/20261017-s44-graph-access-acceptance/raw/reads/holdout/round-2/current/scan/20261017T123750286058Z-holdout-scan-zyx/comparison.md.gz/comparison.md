# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 369.481 | 369.481 | 363.746 | 1 | 1 |  |  | 425.258 | 1.15096 | 0.984478 |
| label_scan_filter | holdout | zyx | 300.741 | 300.741 | 340.121 | 1 | 1 |  |  | 340.121 | 1.13094 | 1.13094 |
| topk_property_sort | holdout | zyx | 393.158 | 393.158 | 393.158 | 1 | 1 |  |  | 444.35 | 1.13021 | 1 |
| two_hop_expand | holdout | zyx | 3.06285 | 3.06285 | 2.99443 | 1 | 1 |  |  | 4.35117 | 1.42063 | 0.977661 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

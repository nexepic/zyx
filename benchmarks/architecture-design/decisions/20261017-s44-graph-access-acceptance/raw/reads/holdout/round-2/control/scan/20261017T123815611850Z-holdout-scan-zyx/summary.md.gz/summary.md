# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 2265.85 | 1956.16 | 2078.939 | 2022.49 | 2265.85 | 2265.85 | 2265.85 | 0.4810145944638106 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 2102.97 | 1976.28 | 2068.696 | 2048.3 | 2237.2 | 2237.2 | 2237.2 | 0.48339630375850295 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 2506.31 | 2424.59 | 2592.2529999999997 | 2514.3 | 2917.08 | 2917.08 | 2917.08 | 0.38576481539417645 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 20.1934 | 19.3414 | 20.33867 | 19.924 | 23.7773 | 23.7773 | 23.7773 | 49.16742343525904 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 2022.49 | 2022.49 | 2265.85 | 1 | 1 |  |  | 2265.85 | 1.12033 | 1.12033 |
| label_scan_filter | holdout | zyx | 2048.3 | 2048.3 | 2102.97 | 1 | 1 |  |  | 2237.2 | 1.09222 | 1.02669 |
| topk_property_sort | holdout | zyx | 2514.3 | 2514.3 | 2506.31 | 1 | 1 |  |  | 2917.08 | 1.1602 | 0.996822 |
| two_hop_expand | holdout | zyx | 19.924 | 19.924 | 20.1934 | 1 | 1 |  |  | 23.7773 | 1.1934 | 1.01352 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

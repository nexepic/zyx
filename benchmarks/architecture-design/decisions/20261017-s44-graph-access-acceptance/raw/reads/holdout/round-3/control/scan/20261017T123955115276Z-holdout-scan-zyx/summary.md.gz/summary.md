# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 2144.0 | 1964.23 | 2102.388 | 2111.8 | 2266.46 | 2266.46 | 2266.46 | 0.47564959465141543 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 1886.61 | 1886.61 | 2013.209 | 1972.57 | 2182.06 | 2182.06 | 2182.06 | 0.4967194166129796 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 2618.4 | 2468.79 | 2643.143 | 2618.4 | 2832.43 | 2832.43 | 2832.43 | 0.3783374565810476 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 19.2772 | 18.8642 | 19.08847 | 19.0359 | 19.3329 | 19.3329 | 19.3329 | 52.387645526330815 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

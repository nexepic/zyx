# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | aggregation_count_by_group | holdout | 10 | 2.6619429991114885 | 2.457271999446675 | 2.5247163022868335 | 2.4912529916036874 | 2.6619429991114885 | 2.6619429991114885 | 2.6619429991114885 | 396.08410620005964 | ok | cypher |
| kuzu | label_scan_filter | holdout | 10 | 1.6573969915043563 | 1.6153040050994605 | 1.7047527042450383 | 1.7178849957417697 | 1.7643329920247197 | 1.7643329920247197 | 1.7643329920247197 | 586.595344597419 | ok | cypher |
| kuzu | topk_property_sort | holdout | 10 | 2.9980179970152676 | 2.8989420097786933 | 3.123854292789474 | 2.9955139907542616 | 3.56869597453624 | 3.56869597453624 | 3.56869597453624 | 320.117363446885 | ok | cypher |
| kuzu | two_hop_expand | holdout | 10 | 0.7824799977242947 | 0.7824799977242947 | 0.90796249860432 | 0.8298089960590005 | 1.270317006856203 | 1.270317006856203 | 1.270317006856203 | 1101.3670735709416 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

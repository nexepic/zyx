# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 456.819 | 379.562 | 435.75609999999995 | 433.856 | 486.856 | 486.856 | 486.856 | 2.2948617357278533 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 322.25 | 315.647 | 333.3977 | 325.675 | 370.938 | 370.938 | 370.938 | 2.9994208118412335 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 439.625 | 406.477 | 426.31409999999994 | 420.278 | 450.281 | 450.281 | 450.281 | 2.3456883082215674 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 4.64427 | 3.41361 | 4.3046750000000005 | 3.6687 | 7.64456 | 7.64456 | 7.64456 | 232.30557475303013 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

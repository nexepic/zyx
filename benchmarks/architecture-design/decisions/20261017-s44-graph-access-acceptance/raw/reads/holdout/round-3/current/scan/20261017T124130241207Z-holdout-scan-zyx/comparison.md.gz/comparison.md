# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 433.856 | 433.856 | 456.819 | 1 | 1 |  |  | 486.856 | 1.12216 | 1.05293 |
| label_scan_filter | holdout | zyx | 325.675 | 325.675 | 322.25 | 1 | 1 |  |  | 370.938 | 1.13898 | 0.989483 |
| topk_property_sort | holdout | zyx | 420.278 | 420.278 | 439.625 | 1 | 1 |  |  | 450.281 | 1.07139 | 1.04603 |
| two_hop_expand | holdout | zyx | 3.6687 | 3.6687 | 4.64427 | 1 | 1 |  |  | 7.64456 | 2.08372 | 1.26592 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

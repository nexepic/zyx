# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | topk_property_sort | holdout | 100 | 2655.68 | 2426.14 | 2577.1533 | 2558.96 | 2726.17 | 2895.36 | 2949.8 | 0.38802503522006243 | ok | api |
| zyx | two_hop_expand | holdout | 100 | 21.6685 | 18.9505 | 21.516822 | 21.2245 | 24.1865 | 27.1735 | 29.6078 | 46.47526479514493 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | topk_property_sort | holdout | 100 | 396.049 | 364.243 | 385.09292 | 371.366 | 435.232 | 468.363 | 485.58 | 2.596775863861636 | ok | api |
| zyx | two_hop_expand | holdout | 100 | 2.91568 | 2.8246 | 3.1180693 | 3.02531 | 3.51828 | 4.43033 | 5.06028 | 320.7112811764639 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

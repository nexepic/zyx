# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 365.867 | 365.867 | 374.45 | 1 | 1 |  |  | 405.858 | 1.1093 | 1.02346 |
| label_scan_filter | holdout | zyx | 300.461 | 300.461 | 330.37 | 1 | 1 |  |  | 347.541 | 1.15669 | 1.09954 |
| topk_property_sort | holdout | zyx | 380.198 | 380.198 | 457.481 | 1 | 1 |  |  | 471.116 | 1.23913 | 1.20327 |
| two_hop_expand | holdout | zyx | 2.87844 | 2.87844 | 2.89304 | 1 | 1 |  |  | 3.16631 | 1.10001 | 1.00507 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

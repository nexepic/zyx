# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 374.45 | 355.289 | 372.1403 | 365.867 | 405.858 | 405.858 | 405.858 | 2.687158579707707 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 330.37 | 296.016 | 312.8003 | 300.461 | 347.541 | 347.541 | 347.541 | 3.196927880184258 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 457.481 | 372.512 | 410.5085 | 380.198 | 471.116 | 471.116 | 471.116 | 2.436003152188079 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 2.89304 | 2.81924 | 2.911108 | 2.87844 | 3.16631 | 3.16631 | 3.16631 | 343.5118174935454 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | aggregation_count_by_group | holdout | 10 | 2.4919729912653565 | 2.4919729912653565 | 2.62916759820655 | 2.572892000898719 | 2.8619270015042275 | 2.8619270015042275 | 2.8619270015042275 | 380.34851817059365 | ok | cypher |
| kuzu | label_scan_filter | holdout | 10 | 1.60058299661614 | 1.582766999490559 | 1.6928473021835089 | 1.6598599904682487 | 1.944799005286768 | 1.944799005286768 | 1.944799005286768 | 590.7207334708547 | ok | cypher |
| kuzu | topk_property_sort | holdout | 10 | 3.59228000161238 | 2.9660089930985123 | 3.268676600418985 | 3.165132977301255 | 3.995323000708595 | 3.995323000708595 | 3.995323000708595 | 305.93421199020366 | ok | cypher |
| kuzu | two_hop_expand | holdout | 10 | 0.7651449996046722 | 0.7473279838450253 | 0.7887874904554337 | 0.7745179755147547 | 0.869228009833023 | 0.869228009833023 | 0.869228009833023 | 1267.7685841881384 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

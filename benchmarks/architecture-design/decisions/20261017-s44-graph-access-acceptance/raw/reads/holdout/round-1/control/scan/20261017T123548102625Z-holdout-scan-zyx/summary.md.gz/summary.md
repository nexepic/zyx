# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | holdout | 10 | 2063.46 | 2008.88 | 2176.554 | 2095.81 | 2423.73 | 2423.73 | 2423.73 | 0.4594418516609282 | ok | api |
| zyx | label_scan_filter | holdout | 10 | 2034.1 | 1943.74 | 2024.8049999999998 | 2034.1 | 2089.73 | 2089.73 | 2089.73 | 0.493874718800082 | ok | api |
| zyx | topk_property_sort | holdout | 10 | 2494.9 | 2494.9 | 2695.261 | 2661.06 | 2873.22 | 2873.22 | 2873.22 | 0.3710215819544007 | ok | api |
| zyx | two_hop_expand | holdout | 10 | 20.305 | 20.2084 | 21.23592 | 21.2814 | 22.5798 | 22.5798 | 22.5798 | 47.09002482586109 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

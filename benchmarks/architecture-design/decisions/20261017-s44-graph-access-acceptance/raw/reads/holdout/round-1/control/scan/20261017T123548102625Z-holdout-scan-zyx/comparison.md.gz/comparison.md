# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | holdout | zyx | 2095.81 | 2095.81 | 2063.46 | 1 | 1 |  |  | 2423.73 | 1.15646 | 0.984564 |
| label_scan_filter | holdout | zyx | 2034.1 | 2034.1 | 2034.1 | 1 | 1 |  |  | 2089.73 | 1.02735 | 1 |
| topk_property_sort | holdout | zyx | 2661.06 | 2661.06 | 2494.9 | 1 | 1 |  |  | 2873.22 | 1.07973 | 0.937559 |
| two_hop_expand | holdout | zyx | 21.2814 | 21.2814 | 20.305 | 1 | 1 |  |  | 22.5798 | 1.06101 | 0.95412 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

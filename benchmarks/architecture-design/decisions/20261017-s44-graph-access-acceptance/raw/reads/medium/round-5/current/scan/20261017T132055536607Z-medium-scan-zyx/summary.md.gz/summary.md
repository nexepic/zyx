# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_group_by | medium | 100 | 483.902 | 460.047 | 487.57327 | 483.446 | 516.262 | 536.256 | 546.399 | 2.050973795179543 | ok | api |
| zyx | all_nodes_property_filter | medium | 100 | 837.203 | 749.433 | 814.85077 | 811.784 | 894.841 | 913.39 | 933.203 | 1.227218574021842 | ok | api |
| zyx | label_multi_property_filter | medium | 100 | 513.07 | 462.098 | 508.37268000000006 | 506.729 | 552.486 | 562.236 | 598.39 | 1.9670608577943252 | ok | api |
| zyx | label_scan_filter | medium | 100 | 407.449 | 404.404 | 432.27036999999996 | 425.99 | 465.58 | 484.358 | 622.751 | 2.313366979096902 | ok | api |
| zyx | one_hop_expand | medium | 100 | 2.37943 | 2.3191 | 2.5047385 | 2.43949 | 2.86803 | 3.15093 | 3.2004 | 399.24327429789577 | ok | api |
| zyx | relationship_property_filter | medium | 100 | 1060.63 | 937.079 | 998.57863 | 993.341 | 1060.12 | 1092.31 | 1102.55 | 1.0014233931683476 | ok | api |
| zyx | relationship_type_scan | medium | 100 | 343.117 | 325.641 | 341.90907 | 336.565 | 364.714 | 378.424 | 394.09 | 2.9247542336329366 | ok | api |
| zyx | two_hop_expand | medium | 100 | 2.98711 | 2.80931 | 3.1519609 | 3.02858 | 3.72554 | 3.80711 | 5.80207 | 317.26281883763215 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

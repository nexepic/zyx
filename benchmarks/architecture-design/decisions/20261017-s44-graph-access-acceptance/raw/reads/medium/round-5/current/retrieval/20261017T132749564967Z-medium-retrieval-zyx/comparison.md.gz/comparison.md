# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 4.00306 | 4.00306 | 3.89398 | 1 | 1 |  |  | 4.43267 | 1.10732 | 0.972751 |
| one_hop_fetch_neighbor_ids | medium | zyx | 3.16746 | 3.16746 | 3.16746 | 1 | 1 |  |  | 3.74177 | 1.18132 | 1 |
| one_hop_fetch_neighbor_records | medium | zyx | 5.02759 | 5.02759 | 5.13176 | 1 | 1 |  |  | 6.10209 | 1.21372 | 1.02072 |
| point_node_fetch_by_id | medium | zyx | 3.72847 | 3.72847 | 3.76091 | 1 | 1 |  |  | 4.63366 | 1.24278 | 1.0087 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 24.3569 | 24.3569 | 25.1381 | 1 | 1 |  |  | 26.1795 | 1.07483 | 1.03207 |
| one_hop_fetch_neighbor_ids | medium | zyx | 22.1047 | 22.1047 | 23.1731 | 1 | 1 |  |  | 23.6374 | 1.06934 | 1.04833 |
| one_hop_fetch_neighbor_records | medium | zyx | 33.133 | 33.133 | 33.1107 | 1 | 1 |  |  | 34.7858 | 1.04988 | 0.999327 |
| point_node_fetch_by_id | medium | zyx | 25.1152 | 25.1152 | 25.034 | 1 | 1 |  |  | 29.1809 | 1.16188 | 0.996767 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_group_by | medium | 100 | 3033.8 | 2835.78 | 2983.1454 | 2982.2 | 3139.69 | 3200.18 | 3225.39 | 0.33521664750233093 | ok | api |
| zyx | all_nodes_property_filter | medium | 100 | 5607.1 | 5201.1 | 5509.033 | 5491.3 | 5773.37 | 5899.53 | 5972.21 | 0.18152005987257652 | ok | api |
| zyx | label_scan_filter | medium | 100 | 2992.3 | 2690.34 | 2852.7183 | 2861.52 | 2970.45 | 3070.84 | 3137.89 | 0.35054284890309706 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

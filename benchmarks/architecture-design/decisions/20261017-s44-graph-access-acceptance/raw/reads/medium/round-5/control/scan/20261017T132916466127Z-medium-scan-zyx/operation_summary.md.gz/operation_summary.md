# Operation Type Summary

Rows group benchmark workloads by database operation family. Unit: ms; lower p50-derived values are better.

| operation_type | database | scale | workload_count | workloads | ok_workloads | unsupported_workloads | failed_workloads | samples | geomean_p50_ms | avg_p50_ms | min_p50_ms | max_p50_ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| adjacency expand | zyx | medium | 2 | one_hop_expand;two_hop_expand | 2 | 0 | 0 | 200 | 18.6877 | 18.7774 | 16.9447 | 20.6101 |
| property filter | zyx | medium | 2 | label_multi_property_filter;relationship_property_filter | 2 | 0 | 0 | 200 | 4342.34 | 4701.86 | 2898.65 | 6505.07 |
| read scan | zyx | medium | 1 | relationship_type_scan | 1 | 0 | 0 | 100 | 577.477 | 577.477 | 577.477 | 577.477 |

## Operation Families

- `read scan`: scans without scalar property predicates, such as relationship type counts.
- `adjacency expand`: fixed-hop, bounded-reachability, and write-then-local-traversal workloads.
- `property filter`: node/relationship property predicates and indexed scalar lookup workloads.
- `topk/group`: sort/TopK and aggregation/grouping workloads.
- `point write`, `batch write`, `load/index build`: mutation and ingest phases kept separate from read latency.

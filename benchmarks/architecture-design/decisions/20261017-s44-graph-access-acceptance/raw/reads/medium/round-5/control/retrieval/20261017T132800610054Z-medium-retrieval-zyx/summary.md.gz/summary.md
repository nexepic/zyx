# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 100 | 25.1381 | 22.8208 | 24.465823999999998 | 24.3569 | 26.1795 | 26.7071 | 31.4688 | 40.87334234072803 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 100 | 23.1731 | 20.9089 | 22.317766000000002 | 22.1047 | 23.6374 | 26.0094 | 28.3982 | 44.80735213372162 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 100 | 33.1107 | 32.4599 | 33.400554 | 33.133 | 34.7858 | 36.2221 | 37.2656 | 29.93962315714883 | ok | api |
| zyx | point_node_fetch_by_id | medium | 100 | 25.034 | 24.4097 | 26.043306 | 25.1152 | 29.1809 | 35.6732 | 41.169 | 38.39758285680013 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

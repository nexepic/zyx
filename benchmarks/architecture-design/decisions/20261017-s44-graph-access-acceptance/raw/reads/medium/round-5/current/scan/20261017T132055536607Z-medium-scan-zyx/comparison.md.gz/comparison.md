# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_group_by | medium | zyx | 483.446 | 483.446 | 483.902 | 1 | 1 |  |  | 516.262 | 1.06788 | 1.00094 |
| all_nodes_property_filter | medium | zyx | 811.784 | 811.784 | 837.203 | 1 | 1 |  |  | 894.841 | 1.10231 | 1.03131 |
| label_multi_property_filter | medium | zyx | 506.729 | 506.729 | 513.07 | 1 | 1 |  |  | 552.486 | 1.0903 | 1.01251 |
| label_scan_filter | medium | zyx | 425.99 | 425.99 | 407.449 | 1 | 1 |  |  | 465.58 | 1.09294 | 0.956476 |
| one_hop_expand | medium | zyx | 2.43949 | 2.43949 | 2.37943 | 1 | 1 |  |  | 2.86803 | 1.17567 | 0.97538 |
| relationship_property_filter | medium | zyx | 993.341 | 993.341 | 1060.63 | 1 | 1 |  |  | 1060.12 | 1.06723 | 1.06774 |
| relationship_type_scan | medium | zyx | 336.565 | 336.565 | 343.117 | 1 | 1 |  |  | 364.714 | 1.08364 | 1.01947 |
| two_hop_expand | medium | zyx | 3.02858 | 3.02858 | 2.98711 | 1 | 1 |  |  | 3.72554 | 1.23013 | 0.986307 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

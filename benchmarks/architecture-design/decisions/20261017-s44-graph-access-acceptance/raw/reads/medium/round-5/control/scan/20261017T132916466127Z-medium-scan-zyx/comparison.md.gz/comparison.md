# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| label_multi_property_filter | medium | zyx | 2898.65 | 2898.65 | 2823.61 | 1 | 1 |  |  | 3038.69 | 1.04831 | 0.974112 |
| one_hop_expand | medium | zyx | 16.9447 | 16.9447 | 16.8403 | 1 | 1 |  |  | 18.999 | 1.12124 | 0.993839 |
| relationship_property_filter | medium | zyx | 6505.07 | 6505.07 | 6520.91 | 1 | 1 |  |  | 6735.62 | 1.03544 | 1.00244 |
| relationship_type_scan | medium | zyx | 577.477 | 577.477 | 570.108 | 1 | 1 |  |  | 625.018 | 1.08233 | 0.987239 |
| two_hop_expand | medium | zyx | 20.6101 | 20.6101 | 20.5879 | 1 | 1 |  |  | 21.8306 | 1.05922 | 0.998923 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

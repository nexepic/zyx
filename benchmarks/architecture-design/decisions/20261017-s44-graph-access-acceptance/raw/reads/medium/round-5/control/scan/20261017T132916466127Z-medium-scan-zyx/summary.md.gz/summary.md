# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | label_multi_property_filter | medium | 100 | 2823.61 | 2732.29 | 2906.0553999999997 | 2898.65 | 3038.69 | 3122.07 | 3145.79 | 0.3441090627522105 | ok | api |
| zyx | one_hop_expand | medium | 100 | 16.8403 | 15.5911 | 17.141566 | 16.9447 | 18.999 | 20.957 | 28.3029 | 58.337727136482165 | ok | api |
| zyx | relationship_property_filter | medium | 100 | 6520.91 | 6180.98 | 6473.993 | 6505.07 | 6735.62 | 6764.7 | 6930.98 | 0.15446417689978967 | ok | api |
| zyx | relationship_type_scan | medium | 100 | 570.108 | 546.583 | 583.66356 | 577.477 | 625.018 | 638.441 | 650.713 | 1.7133158013154017 | ok | api |
| zyx | two_hop_expand | medium | 100 | 20.5879 | 19.8595 | 20.774355999999997 | 20.6101 | 21.8306 | 22.3796 | 23.3772 | 48.13626954308476 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

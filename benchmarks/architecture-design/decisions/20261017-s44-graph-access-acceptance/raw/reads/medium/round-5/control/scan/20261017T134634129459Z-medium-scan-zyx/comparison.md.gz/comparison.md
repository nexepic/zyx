# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_group_by | medium | zyx | 2982.2 | 2982.2 | 3033.8 | 1 | 1 |  |  | 3139.69 | 1.05281 | 1.0173 |
| all_nodes_property_filter | medium | zyx | 5491.3 | 5491.3 | 5607.1 | 1 | 1 |  |  | 5773.37 | 1.05137 | 1.02109 |
| label_scan_filter | medium | zyx | 2861.52 | 2861.52 | 2992.3 | 1 | 1 |  |  | 2970.45 | 1.03807 | 1.0457 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

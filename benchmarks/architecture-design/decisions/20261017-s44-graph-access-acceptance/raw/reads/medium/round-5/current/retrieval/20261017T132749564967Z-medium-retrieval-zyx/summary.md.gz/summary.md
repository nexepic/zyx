# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 100 | 3.89398 | 3.73026 | 4.0743317999999995 | 4.00306 | 4.43267 | 4.75282 | 7.70103 | 245.43901898220466 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 100 | 3.16746 | 2.91795 | 3.2899475999999996 | 3.16746 | 3.74177 | 5.20375 | 8.63355 | 303.95620890740025 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 100 | 5.13176 | 4.50212 | 5.1510722 | 5.02759 | 6.10209 | 7.56905 | 7.61674 | 194.1343396429194 | ok | api |
| zyx | point_node_fetch_by_id | medium | 100 | 3.76091 | 3.50987 | 3.9364953 | 3.72847 | 4.63366 | 8.29004 | 8.56178 | 254.03307353116872 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

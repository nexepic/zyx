# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 1.78006 | 1.71471 | 1.756013 | 1.73632 | 1.842 | 1.842 | 1.842 | 569.4718660966632 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 228.485 | 193.498 | 219.54630000000003 | 200.268 | 263.286 | 263.286 | 263.286 | 4.5548478840226405 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1313.81 | 1149.02 | 1220.532 | 1202.54 | 1313.81 | 1313.81 | 1313.81 | 0.8193148561446976 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

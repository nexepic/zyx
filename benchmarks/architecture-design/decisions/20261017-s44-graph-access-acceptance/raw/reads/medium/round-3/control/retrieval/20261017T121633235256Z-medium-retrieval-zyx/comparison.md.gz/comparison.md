# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 25.1237 | 25.1237 | 25.2064 | 1 | 1 |  |  | 34.8132 | 1.38567 | 1.00329 |
| one_hop_fetch_neighbor_ids | medium | zyx | 23.5378 | 23.5378 | 23.7048 | 1 | 1 |  |  | 27.0788 | 1.15044 | 1.00709 |
| one_hop_fetch_neighbor_records | medium | zyx | 35.7086 | 35.7086 | 33.9243 | 1 | 1 |  |  | 41.0448 | 1.14944 | 0.950032 |
| point_edge_fetch_by_endpoints | medium | zyx | 22.015 | 22.015 | 23.8642 | 1 | 1 |  |  | 41.1104 | 1.86738 | 1.084 |
| point_node_fetch_by_id | medium | zyx | 28.6561 | 28.6561 | 27.3614 | 1 | 1 |  |  | 31.6724 | 1.10526 | 0.954819 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 3023.03 | 3023.03 | 2970.34 | 1 | 1 |  |  | 3153.67 | 1.04321 | 0.98257 |
| aggregation_group_by | medium | zyx | 3041.68 | 3041.68 | 2719.99 | 1 | 1 |  |  | 3424.07 | 1.12572 | 0.894239 |
| all_nodes_property_filter | medium | zyx | 5334.93 | 5334.93 | 5808.97 | 1 | 1 |  |  | 6012.33 | 1.12697 | 1.08886 |
| label_multi_property_filter | medium | zyx | 2959.71 | 2959.71 | 2994.57 | 1 | 1 |  |  | 3124.72 | 1.05575 | 1.01178 |
| label_scan_filter | medium | zyx | 2768.81 | 2768.81 | 2925.94 | 1 | 1 |  |  | 3168.68 | 1.14442 | 1.05675 |
| one_hop_expand | medium | zyx | 17.9751 | 17.9751 | 17.9751 | 1 | 1 |  |  | 19.6536 | 1.09338 | 1 |
| relationship_property_filter | medium | zyx | 6833.36 | 6833.36 | 6537.31 | 1 | 1 |  |  | 7045.18 | 1.031 | 0.956676 |
| relationship_type_scan | medium | zyx | 621.558 | 621.558 | 629.012 | 1 | 1 |  |  | 644.945 | 1.03763 | 1.01199 |
| topk_property_sort | medium | zyx | 3558.85 | 3558.85 | 3555.12 | 1 | 1 |  |  | 3744.02 | 1.05203 | 0.998952 |
| two_hop_expand | medium | zyx | 22.3218 | 22.3218 | 20.6395 | 1 | 1 |  |  | 23.6976 | 1.06163 | 0.924634 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 3.89938 | 3.89938 | 3.94447 | 1 | 1 |  |  | 5.22117 | 1.33897 | 1.01156 |
| one_hop_fetch_neighbor_ids | medium | zyx | 3.38904 | 3.38904 | 4.51737 | 1 | 1 |  |  | 5.68573 | 1.67768 | 1.33293 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.85882 | 4.85882 | 5.11464 | 1 | 1 |  |  | 5.32009 | 1.09493 | 1.05265 |
| point_edge_fetch_by_endpoints | medium | zyx | 3.72949 | 3.72949 | 3.80442 | 1 | 1 |  |  | 4.6432 | 1.245 | 1.02009 |
| point_node_fetch_by_id | medium | zyx | 3.76154 | 3.76154 | 3.75308 | 1 | 1 |  |  | 4.06467 | 1.08059 | 0.997751 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

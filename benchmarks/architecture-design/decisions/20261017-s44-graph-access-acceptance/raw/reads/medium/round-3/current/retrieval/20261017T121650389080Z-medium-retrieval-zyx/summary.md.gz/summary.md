# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 3.94447 | 3.79988 | 4.2526649999999995 | 3.89938 | 5.22117 | 5.22117 | 5.22117 | 235.14666685478403 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 4.51737 | 3.11327 | 3.7131410000000002 | 3.38904 | 5.68573 | 5.68573 | 5.68573 | 269.31376966293493 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 5.11464 | 4.5525 | 4.896446 | 4.85882 | 5.32009 | 5.32009 | 5.32009 | 204.22976174964452 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 3.80442 | 3.49844 | 3.8389960000000003 | 3.72949 | 4.6432 | 4.6432 | 4.6432 | 260.48477258116446 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 3.75308 | 3.65557 | 3.7890479999999997 | 3.76154 | 4.06467 | 4.06467 | 4.06467 | 263.91853573773676 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

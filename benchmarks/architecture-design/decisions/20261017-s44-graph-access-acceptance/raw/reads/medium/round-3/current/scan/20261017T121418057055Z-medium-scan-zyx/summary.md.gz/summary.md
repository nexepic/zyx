# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 492.156 | 485.57 | 510.8415 | 507.92 | 554.282 | 554.282 | 554.282 | 1.9575543490495584 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 507.279 | 474.857 | 494.1152 | 492.196 | 515.722 | 515.722 | 515.722 | 2.023819546534897 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 791.718 | 766.852 | 820.6398999999999 | 814.709 | 903.607 | 903.607 | 903.607 | 1.2185612715150702 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 490.348 | 471.226 | 496.41729999999995 | 494.514 | 519.531 | 519.531 | 519.531 | 2.014434227010219 | ok | api |
| zyx | label_scan_filter | medium | 10 | 412.365 | 412.013 | 423.07610000000005 | 416.115 | 464.158 | 464.158 | 464.158 | 2.3636409619924166 | ok | api |
| zyx | one_hop_expand | medium | 10 | 2.52038 | 2.52038 | 2.902315 | 2.67561 | 4.13677 | 4.13677 | 4.13677 | 344.552538232411 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 1022.64 | 990.491 | 1062.5501 | 1049.7 | 1131.51 | 1131.51 | 1131.51 | 0.9411320934419939 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 338.042 | 338.042 | 347.2021 | 343.395 | 363.193 | 363.193 | 363.193 | 2.8801669114328514 | ok | api |
| zyx | topk_property_sort | medium | 10 | 547.108 | 500.676 | 514.3417 | 511.794 | 547.108 | 547.108 | 547.108 | 1.9442327931023289 | ok | api |
| zyx | two_hop_expand | medium | 10 | 3.01423 | 2.9568 | 3.134433 | 3.08108 | 3.36269 | 3.36269 | 3.36269 | 319.0369677705665 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 10.9067 | 10.1489 | 11.34799 | 10.9536 | 13.2992 | 13.2992 | 13.2992 | 88.12133250029301 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 3363.87 | 3137.89 | 3252.927 | 3234.15 | 3363.87 | 3363.87 | 3363.87 | 0.30741544461342046 | ok | api |
| zyx | property_range_indexed | medium | 10 | 22219.5 | 20962.2 | 21990.39 | 21716.6 | 23612.8 | 23612.8 | 23612.8 | 0.045474409503424 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

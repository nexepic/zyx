# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 25.2064 | 22.7221 | 25.845999999999997 | 25.1237 | 34.8132 | 34.8132 | 34.8132 | 38.69070649230055 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 23.7048 | 21.4807 | 23.99096 | 23.5378 | 27.0788 | 27.0788 | 27.0788 | 41.682367024912715 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 33.9243 | 33.9243 | 36.54475 | 35.7086 | 41.0448 | 41.0448 | 41.0448 | 27.363711613843304 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 23.8642 | 21.3938 | 25.02167 | 22.015 | 41.1104 | 41.1104 | 41.1104 | 39.96535802766162 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 27.3614 | 27.3614 | 29.132240000000003 | 28.6561 | 31.6724 | 31.6724 | 31.6724 | 34.32623100729638 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

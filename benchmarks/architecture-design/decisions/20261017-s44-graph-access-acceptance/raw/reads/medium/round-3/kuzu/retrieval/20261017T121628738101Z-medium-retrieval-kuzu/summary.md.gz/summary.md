# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.46489297528751194 | 0.4506330005824566 | 0.5259734025457874 | 0.47538900980725884 | 0.8098100079223514 | 0.8098100079223514 | 0.8098100079223514 | 1901.236821405522 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.5870330205652863 | 0.5253229755908251 | 0.557750096777454 | 0.5530430062208325 | 0.6238269852474332 | 0.6238269852474332 | 0.6238269852474332 | 1792.9176629063081 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.7110460137482733 | 0.6343529967125505 | 0.7173677062382922 | 0.7110460137482733 | 0.841547007439658 | 0.841547007439658 | 0.841547007439658 | 1393.9852481564374 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.6034580001141876 | 0.38878098712302744 | 0.45655300200451165 | 0.42559500434435904 | 0.6034580001141876 | 0.6034580001141876 | 0.6034580001141876 | 2190.32619566505 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.22371899103745818 | 0.21873199148103595 | 0.24557709693908691 | 0.2254319842904806 | 0.30972500098869205 | 0.30972500098869205 | 0.30972500098869205 | 4072.040969879372 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

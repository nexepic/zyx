# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 507.92 | 507.92 | 492.156 | 1 | 1 |  |  | 554.282 | 1.09128 | 0.968964 |
| aggregation_group_by | medium | zyx | 492.196 | 492.196 | 507.279 | 1 | 1 |  |  | 515.722 | 1.0478 | 1.03064 |
| all_nodes_property_filter | medium | zyx | 814.709 | 814.709 | 791.718 | 1 | 1 |  |  | 903.607 | 1.10912 | 0.97178 |
| label_multi_property_filter | medium | zyx | 494.514 | 494.514 | 490.348 | 1 | 1 |  |  | 519.531 | 1.05059 | 0.991576 |
| label_scan_filter | medium | zyx | 416.115 | 416.115 | 412.365 | 1 | 1 |  |  | 464.158 | 1.11546 | 0.990988 |
| one_hop_expand | medium | zyx | 2.67561 | 2.67561 | 2.52038 | 1 | 1 |  |  | 4.13677 | 1.5461 | 0.941983 |
| relationship_property_filter | medium | zyx | 1049.7 | 1049.7 | 1022.64 | 1 | 1 |  |  | 1131.51 | 1.07794 | 0.974221 |
| relationship_type_scan | medium | zyx | 343.395 | 343.395 | 338.042 | 1 | 1 |  |  | 363.193 | 1.05765 | 0.984412 |
| topk_property_sort | medium | zyx | 511.794 | 511.794 | 547.108 | 1 | 1 |  |  | 547.108 | 1.069 | 1.069 |
| two_hop_expand | medium | zyx | 3.08108 | 3.08108 | 3.01423 | 1 | 1 |  |  | 3.36269 | 1.0914 | 0.978303 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

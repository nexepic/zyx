# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| point_lookup_indexed | medium | zyx | 10.9536 | 10.9536 | 10.9067 | 1 | 1 |  |  | 13.2992 | 1.21414 | 0.995718 |
| property_equality_indexed | medium | zyx | 3234.15 | 3234.15 | 3363.87 | 1 | 1 |  |  | 3363.87 | 1.04011 | 1.04011 |
| property_range_indexed | medium | zyx | 21716.6 | 21716.6 | 22219.5 | 1 | 1 |  |  | 23612.8 | 1.08732 | 1.02316 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 2970.34 | 2852.22 | 3001.2 | 3023.03 | 3153.67 | 3153.67 | 3153.67 | 0.3332000533120085 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 2719.99 | 2719.99 | 3080.481 | 3041.68 | 3424.07 | 3424.07 | 3424.07 | 0.32462462842653467 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5808.97 | 5173.58 | 5446.508 | 5334.93 | 6012.33 | 6012.33 | 6012.33 | 0.1836038797703042 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 2994.57 | 2826.26 | 2976.1279999999997 | 2959.71 | 3124.72 | 3124.72 | 3124.72 | 0.33600705346006626 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2925.94 | 2725.27 | 2821.061 | 2768.81 | 3168.68 | 3168.68 | 3168.68 | 0.35447656041468084 | ok | api |
| zyx | one_hop_expand | medium | 10 | 17.9751 | 16.8938 | 18.14099 | 17.9751 | 19.6536 | 19.6536 | 19.6536 | 55.12378321139034 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6537.31 | 6323.17 | 6747.627 | 6833.36 | 7045.18 | 7045.18 | 7045.18 | 0.1482002487689376 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 629.012 | 579.999 | 617.2013 | 621.558 | 644.945 | 644.945 | 644.945 | 1.6202169373266064 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3555.12 | 3492.72 | 3603.114 | 3558.85 | 3744.02 | 3744.02 | 3744.02 | 0.27753770766065133 | ok | api |
| zyx | two_hop_expand | medium | 10 | 20.6395 | 20.6395 | 22.15778 | 22.3218 | 23.6976 | 23.6976 | 23.6976 | 45.1308750244835 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 3006.76 | 3006.76 | 2852.88 | 1 | 1 |  |  | 3137.5 | 1.04348 | 0.948822 |
| aggregation_group_by | medium | zyx | 3114.98 | 3114.98 | 3072.77 | 1 | 1 |  |  | 3598.79 | 1.15532 | 0.986449 |
| all_nodes_property_filter | medium | zyx | 5432.25 | 5432.25 | 5432.25 | 1 | 1 |  |  | 6080.5 | 1.11933 | 1 |
| label_multi_property_filter | medium | zyx | 2913.05 | 2913.05 | 2934.15 | 1 | 1 |  |  | 3255.75 | 1.11764 | 1.00724 |
| label_scan_filter | medium | zyx | 2896 | 2896 | 2908.83 | 1 | 1 |  |  | 3270.18 | 1.12921 | 1.00443 |
| one_hop_expand | medium | zyx | 18.4891 | 18.4891 | 17.6684 | 1 | 1 |  |  | 20.1653 | 1.09066 | 0.955612 |
| relationship_property_filter | medium | zyx | 6104.3 | 6104.3 | 6075.63 | 1 | 1 |  |  | 7113.77 | 1.16537 | 0.995303 |
| relationship_type_scan | medium | zyx | 566.16 | 566.16 | 545.66 | 1 | 1 |  |  | 610.632 | 1.07855 | 0.963791 |
| topk_property_sort | medium | zyx | 3761.84 | 3761.84 | 3824.18 | 1 | 1 |  |  | 4282.16 | 1.13832 | 1.01657 |
| two_hop_expand | medium | zyx | 24.6634 | 24.6634 | 23.142 | 1 | 1 |  |  | 27.0615 | 1.09723 | 0.938313 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

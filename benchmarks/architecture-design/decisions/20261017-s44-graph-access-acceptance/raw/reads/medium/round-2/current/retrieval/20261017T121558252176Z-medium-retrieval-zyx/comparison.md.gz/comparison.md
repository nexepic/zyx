# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 3.96513 | 3.96513 | 3.79879 | 1 | 1 |  |  | 4.37793 | 1.10411 | 0.958049 |
| one_hop_fetch_neighbor_ids | medium | zyx | 3.10003 | 3.10003 | 3.29229 | 1 | 1 |  |  | 3.31695 | 1.06997 | 1.06202 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.64057 | 4.64057 | 4.5111 | 1 | 1 |  |  | 5.01727 | 1.08118 | 0.9721 |
| point_edge_fetch_by_endpoints | medium | zyx | 3.44364 | 3.44364 | 3.86157 | 1 | 1 |  |  | 3.86157 | 1.12136 | 1.12136 |
| point_node_fetch_by_id | medium | zyx | 3.89234 | 3.89234 | 3.77451 | 1 | 1 |  |  | 4.22405 | 1.08522 | 0.969728 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 1.72312 | 1.68676 | 1.801369 | 1.78669 | 2.06792 | 2.06792 | 2.06792 | 555.1333458053291 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 202.731 | 198.426 | 203.2972 | 202.731 | 208.168 | 208.168 | 208.168 | 4.918906900832869 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1197.45 | 1195.8 | 1260.4630000000002 | 1222.17 | 1376.84 | 1376.84 | 1376.84 | 0.7933592656031949 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 477.941 | 477.941 | 636.247 | 1 | 1 |  |  | 636.247 | 1.33122 | 1.33122 |
| aggregation_group_by | medium | zyx | 488.093 | 488.093 | 548.251 | 1 | 1 |  |  | 548.251 | 1.12325 | 1.12325 |
| all_nodes_property_filter | medium | zyx | 743.318 | 743.318 | 759.042 | 1 | 1 |  |  | 768.708 | 1.03416 | 1.02115 |
| label_multi_property_filter | medium | zyx | 457.436 | 457.436 | 460.87 | 1 | 1 |  |  | 460.87 | 1.00751 | 1.00751 |
| label_scan_filter | medium | zyx | 411.157 | 411.157 | 410.801 | 1 | 1 |  |  | 433.347 | 1.05397 | 0.999134 |
| one_hop_expand | medium | zyx | 2.37887 | 2.37887 | 2.49378 | 1 | 1 |  |  | 2.69245 | 1.13182 | 1.0483 |
| relationship_property_filter | medium | zyx | 1044.97 | 1044.97 | 1028.34 | 1 | 1 |  |  | 1142.45 | 1.09328 | 0.984086 |
| relationship_type_scan | medium | zyx | 357.772 | 357.772 | 337.299 | 1 | 1 |  |  | 374.213 | 1.04595 | 0.942776 |
| topk_property_sort | medium | zyx | 501.052 | 501.052 | 489.652 | 1 | 1 |  |  | 532.614 | 1.06299 | 0.977248 |
| two_hop_expand | medium | zyx | 2.95491 | 2.95491 | 2.97751 | 1 | 1 |  |  | 3.29724 | 1.11585 | 1.00765 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

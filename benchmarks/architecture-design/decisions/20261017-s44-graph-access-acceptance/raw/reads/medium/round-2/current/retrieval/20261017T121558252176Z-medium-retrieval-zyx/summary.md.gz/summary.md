# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 3.79879 | 3.79879 | 4.037841 | 3.96513 | 4.37793 | 4.37793 | 4.37793 | 247.6571019017341 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 3.29229 | 3.00748 | 3.148555 | 3.10003 | 3.31695 | 3.31695 | 3.31695 | 317.60601291703654 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 4.5111 | 4.5111 | 4.7044939999999995 | 4.64057 | 5.01727 | 5.01727 | 5.01727 | 212.5627113139054 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 3.86157 | 3.38528 | 3.4986599999999997 | 3.44364 | 3.86157 | 3.86157 | 3.86157 | 285.82371536531133 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 3.77451 | 3.77451 | 3.9289639999999997 | 3.89234 | 4.22405 | 4.22405 | 4.22405 | 254.52002105389616 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.5067249876447022 | 0.44799799798056483 | 0.4972068913048133 | 0.504912983160466 | 0.5575989780481905 | 0.5575989780481905 | 0.5575989780481905 | 2011.2351970338011 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.5697169981431216 | 0.5158180138096213 | 0.5636323970975354 | 0.5517609824892133 | 0.614732998656109 | 0.614732998656109 | 0.614732998656109 | 1774.206034198123 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.6286140123847872 | 0.6218639900907874 | 0.6490942905656993 | 0.6456789851654321 | 0.6953729898668826 | 0.6953729898668826 | 0.6953729898668826 | 1540.6082206153424 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.5473950004670769 | 0.39642301271669567 | 0.45286570384632796 | 0.42197000584565103 | 0.5473950004670769 | 0.5473950004670769 | 0.5473950004670769 | 2208.160148818274 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.22531099966727197 | 0.21532599930651486 | 0.257717800559476 | 0.22531099966727197 | 0.3838849952444434 | 0.3838849952444434 | 0.3838849952444434 | 3880.213154966843 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 10.825 | 10.4046 | 11.07833 | 10.8859 | 11.8903 | 11.8903 | 11.8903 | 90.2663127023658 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 3542.5 | 3163.9 | 3273.032 | 3250.07 | 3542.5 | 3542.5 | 3542.5 | 0.30552710758709356 | ok | api |
| zyx | property_range_indexed | medium | 10 | 21220.5 | 21220.5 | 21973.54 | 21583.5 | 22944.7 | 22944.7 | 22944.7 | 0.0455092807076147 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 636.247 | 474.14 | 497.68850000000003 | 477.941 | 636.247 | 636.247 | 636.247 | 2.0092889427824834 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 548.251 | 465.948 | 496.7638 | 488.093 | 548.251 | 548.251 | 548.251 | 2.013029129739325 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 759.042 | 735.549 | 750.0202999999999 | 743.318 | 768.708 | 768.708 | 768.708 | 1.333297245421224 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 460.87 | 455.341 | 457.6473 | 457.436 | 460.87 | 460.87 | 460.87 | 2.185088822768101 | ok | api |
| zyx | label_scan_filter | medium | 10 | 410.801 | 404.688 | 414.0693 | 411.157 | 433.347 | 433.347 | 433.347 | 2.415054678045438 | ok | api |
| zyx | one_hop_expand | medium | 10 | 2.49378 | 2.32857 | 2.415007 | 2.37887 | 2.69245 | 2.69245 | 2.69245 | 414.0774747236758 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 1028.34 | 998.31 | 1053.308 | 1044.97 | 1142.45 | 1142.45 | 1142.45 | 0.9493899220360996 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 337.299 | 333.941 | 359.663 | 357.772 | 374.213 | 374.213 | 374.213 | 2.780380522878361 | ok | api |
| zyx | topk_property_sort | medium | 10 | 489.652 | 489.652 | 505.57430000000005 | 501.052 | 532.614 | 532.614 | 532.614 | 1.9779486417723369 | ok | api |
| zyx | two_hop_expand | medium | 10 | 2.97751 | 2.8055 | 3.020841 | 2.95491 | 3.29724 | 3.29724 | 3.29724 | 331.03364261806564 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

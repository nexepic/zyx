# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 23.6989 | 23.6989 | 23.445 | 1 | 1 |  |  | 26.2529 | 1.10777 | 0.989286 |
| one_hop_fetch_neighbor_ids | medium | zyx | 21.6759 | 21.6759 | 21.9279 | 1 | 1 |  |  | 22.143 | 1.02155 | 1.01163 |
| one_hop_fetch_neighbor_records | medium | zyx | 33.7267 | 33.7267 | 34.2245 | 1 | 1 |  |  | 36.2814 | 1.07575 | 1.01476 |
| point_edge_fetch_by_endpoints | medium | zyx | 22.4565 | 22.4565 | 22.7472 | 1 | 1 |  |  | 22.9058 | 1.02001 | 1.01295 |
| point_node_fetch_by_id | medium | zyx | 26.4221 | 26.4221 | 25.8294 | 1 | 1 |  |  | 29.5535 | 1.11851 | 0.977568 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

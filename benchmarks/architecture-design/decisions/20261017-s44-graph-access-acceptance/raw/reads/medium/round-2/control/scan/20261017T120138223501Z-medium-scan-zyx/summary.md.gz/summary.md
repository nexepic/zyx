# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 2852.88 | 2852.88 | 3004.983 | 3006.76 | 3137.5 | 3137.5 | 3137.5 | 0.3327805847820104 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 3072.77 | 2923.08 | 3170.568 | 3114.98 | 3598.79 | 3598.79 | 3598.79 | 0.31540089977568686 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5432.25 | 5332.17 | 5574.074 | 5432.25 | 6080.5 | 6080.5 | 6080.5 | 0.17940199573956142 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 2934.15 | 2801.02 | 2943.665 | 2913.05 | 3255.75 | 3255.75 | 3255.75 | 0.33971256919520393 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2908.83 | 2793.3 | 2972.625 | 2896.0 | 3270.18 | 3270.18 | 3270.18 | 0.33640301080694673 | ok | api |
| zyx | one_hop_expand | medium | 10 | 17.6684 | 16.9251 | 18.66314 | 18.4891 | 20.1653 | 20.1653 | 20.1653 | 53.58155165743814 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6075.63 | 6071.46 | 6247.035 | 6104.3 | 7113.77 | 7113.77 | 7113.77 | 0.16007594002594833 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 545.66 | 545.66 | 574.1233 | 566.16 | 610.632 | 610.632 | 610.632 | 1.7417861285197795 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3824.18 | 3611.63 | 3858.2019999999998 | 3761.84 | 4282.16 | 4282.16 | 4282.16 | 0.2591880881301705 | ok | api |
| zyx | two_hop_expand | medium | 10 | 23.142 | 23.0324 | 24.99429 | 24.6634 | 27.0615 | 27.0615 | 27.0615 | 40.0091380871391 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

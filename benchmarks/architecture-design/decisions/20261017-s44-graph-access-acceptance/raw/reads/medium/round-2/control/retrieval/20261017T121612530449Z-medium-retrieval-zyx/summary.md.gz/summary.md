# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 23.445 | 23.3822 | 24.06473 | 23.6989 | 26.2529 | 26.2529 | 26.2529 | 41.5545904732777 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 21.9279 | 21.238 | 21.70536 | 21.6759 | 22.143 | 22.143 | 22.143 | 46.07156941879794 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 34.2245 | 33.0826 | 33.92527 | 33.7267 | 36.2814 | 36.2814 | 36.2814 | 29.476552434217915 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 22.7472 | 21.9564 | 22.48049 | 22.4565 | 22.9058 | 22.9058 | 22.9058 | 44.48301616201426 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 25.8294 | 25.8294 | 26.67894 | 26.4221 | 29.5535 | 29.5535 | 29.5535 | 37.48274856497297 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 23.0315 | 23.0315 | 23.5633 | 1 | 1 |  |  | 23.5633 | 1.02309 | 1.02309 |
| one_hop_fetch_neighbor_ids | medium | zyx | 21.3947 | 21.3947 | 21.1915 | 1 | 1 |  |  | 22.269 | 1.04087 | 0.990502 |
| one_hop_fetch_neighbor_records | medium | zyx | 35.8187 | 35.8187 | 33.6722 | 1 | 1 |  |  | 41.2865 | 1.15265 | 0.940073 |
| point_edge_fetch_by_endpoints | medium | zyx | 21.9194 | 21.9194 | 22.4479 | 1 | 1 |  |  | 22.5317 | 1.02793 | 1.02411 |
| point_node_fetch_by_id | medium | zyx | 25.6904 | 25.6904 | 28.1545 | 1 | 1 |  |  | 30.5264 | 1.18824 | 1.09592 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

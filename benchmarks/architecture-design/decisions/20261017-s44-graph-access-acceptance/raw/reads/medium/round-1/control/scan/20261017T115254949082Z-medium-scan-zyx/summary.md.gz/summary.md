# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 2926.29 | 2771.16 | 2957.195 | 2926.29 | 3182.59 | 3182.59 | 3182.59 | 0.3381582885132702 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 3138.67 | 2797.42 | 2937.812 | 2865.87 | 3229.09 | 3229.09 | 3229.09 | 0.3403893782175306 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5531.43 | 5375.5 | 5774.896 | 5795.66 | 6011.85 | 6011.85 | 6011.85 | 0.17316329159867122 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 3126.59 | 2821.74 | 3078.392 | 3119.41 | 3171.21 | 3171.21 | 3171.21 | 0.3248449190356524 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2721.98 | 2649.41 | 2761.7380000000003 | 2750.08 | 2857.0 | 2857.0 | 2857.0 | 0.362090828311737 | ok | api |
| zyx | one_hop_expand | medium | 10 | 16.4168 | 15.8363 | 16.33015 | 16.2936 | 16.7434 | 16.7434 | 16.7434 | 61.23642465011038 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6641.38 | 6269.81 | 6508.951 | 6401.14 | 6975.75 | 6975.75 | 6975.75 | 0.15363458720153217 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 631.606 | 590.872 | 615.0045 | 614.942 | 635.356 | 635.356 | 635.356 | 1.6260043625697047 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3792.18 | 3531.3 | 3726.5629999999996 | 3727.05 | 3918.66 | 3918.66 | 3918.66 | 0.26834377950943 | ok | api |
| zyx | two_hop_expand | medium | 10 | 19.962 | 19.962 | 21.3417 | 21.352 | 22.9046 | 22.9046 | 22.9046 | 46.85662341800325 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

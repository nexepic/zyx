# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 510.384 | 510.384 | 524.276 | 1 | 1 |  |  | 581.892 | 1.14011 | 1.02722 |
| aggregation_group_by | medium | zyx | 482.516 | 482.516 | 592.686 | 1 | 1 |  |  | 592.686 | 1.22832 | 1.22832 |
| all_nodes_property_filter | medium | zyx | 767.552 | 767.552 | 762.683 | 1 | 1 |  |  | 785.503 | 1.02339 | 0.993656 |
| label_multi_property_filter | medium | zyx | 476.428 | 476.428 | 470.222 | 1 | 1 |  |  | 521.862 | 1.09536 | 0.986974 |
| label_scan_filter | medium | zyx | 415.777 | 415.777 | 419.236 | 1 | 1 |  |  | 429.037 | 1.03189 | 1.00832 |
| one_hop_expand | medium | zyx | 2.71214 | 2.71214 | 2.37436 | 1 | 1 |  |  | 3.06207 | 1.12902 | 0.875456 |
| relationship_property_filter | medium | zyx | 987.35 | 987.35 | 1325.79 | 1 | 1 |  |  | 1325.79 | 1.34278 | 1.34278 |
| relationship_type_scan | medium | zyx | 337.764 | 337.764 | 336.936 | 1 | 1 |  |  | 346.246 | 1.02511 | 0.997549 |
| topk_property_sort | medium | zyx | 519.024 | 519.024 | 523.464 | 1 | 1 |  |  | 584.404 | 1.12597 | 1.00855 |
| two_hop_expand | medium | zyx | 3.0998 | 3.0998 | 3.70085 | 1 | 1 |  |  | 3.70085 | 1.1939 | 1.1939 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

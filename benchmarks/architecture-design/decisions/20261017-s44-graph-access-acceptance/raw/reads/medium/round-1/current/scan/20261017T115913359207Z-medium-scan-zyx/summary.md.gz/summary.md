# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 524.276 | 496.768 | 521.1895000000001 | 510.384 | 581.892 | 581.892 | 581.892 | 1.9186879244497441 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 592.686 | 470.463 | 498.4071 | 482.516 | 592.686 | 592.686 | 592.686 | 2.0063919635173737 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 762.683 | 747.227 | 766.7466000000001 | 767.552 | 785.503 | 785.503 | 785.503 | 1.3042118478256048 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 470.222 | 465.457 | 483.9916999999999 | 476.428 | 521.862 | 521.862 | 521.862 | 2.06615113440995 | ok | api |
| zyx | label_scan_filter | medium | 10 | 419.236 | 408.314 | 417.197 | 415.777 | 429.037 | 429.037 | 429.037 | 2.3969491631051993 | ok | api |
| zyx | one_hop_expand | medium | 10 | 2.37436 | 2.37436 | 2.732836 | 2.71214 | 3.06207 | 3.06207 | 3.06207 | 365.9202381701646 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 1325.79 | 967.371 | 1038.4253 | 987.35 | 1325.79 | 1325.79 | 1325.79 | 0.9629965679765313 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 336.936 | 332.336 | 338.80219999999997 | 337.764 | 346.246 | 346.246 | 346.246 | 2.9515746946153243 | ok | api |
| zyx | topk_property_sort | medium | 10 | 523.464 | 491.678 | 527.9268 | 519.024 | 584.404 | 584.404 | 584.404 | 1.894201999216558 | ok | api |
| zyx | two_hop_expand | medium | 10 | 3.70085 | 2.99346 | 3.264518 | 3.0998 | 3.70085 | 3.70085 | 3.70085 | 306.3239351107882 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

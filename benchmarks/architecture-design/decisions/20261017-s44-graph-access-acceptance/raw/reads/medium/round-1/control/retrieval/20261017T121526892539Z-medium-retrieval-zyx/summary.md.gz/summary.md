# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 23.5633 | 22.5088 | 22.99134 | 23.0315 | 23.5633 | 23.5633 | 23.5633 | 43.494637546136936 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 21.1915 | 20.8654 | 21.51454 | 21.3947 | 22.269 | 22.269 | 22.269 | 46.480194324396436 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 33.6722 | 33.6722 | 35.951389999999996 | 35.8187 | 41.2865 | 41.2865 | 41.2865 | 27.81533620814105 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 22.4479 | 21.4479 | 21.944290000000002 | 21.9194 | 22.5317 | 22.5317 | 22.5317 | 45.569940973255456 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 28.1545 | 24.5196 | 27.182760000000002 | 25.6904 | 30.5264 | 30.5264 | 30.5264 | 36.78802299692893 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

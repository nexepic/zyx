# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 4.10032 | 4.10032 | 4.09232 | 1 | 1 |  |  | 4.52116 | 1.10264 | 0.998049 |
| one_hop_fetch_neighbor_ids | medium | zyx | 3.06932 | 3.06932 | 3.15884 | 1 | 1 |  |  | 3.42647 | 1.11636 | 1.02917 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.80985 | 4.80985 | 4.90393 | 1 | 1 |  |  | 4.93204 | 1.0254 | 1.01956 |
| point_edge_fetch_by_endpoints | medium | zyx | 3.54324 | 3.54324 | 4.1113 | 1 | 1 |  |  | 4.1113 | 1.16032 | 1.16032 |
| point_node_fetch_by_id | medium | zyx | 3.89624 | 3.89624 | 3.97405 | 1 | 1 |  |  | 4.15532 | 1.06649 | 1.01997 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 1.83309 | 1.73575 | 1.7983619999999998 | 1.77703 | 1.9137 | 1.9137 | 1.9137 | 556.0615715856986 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 218.894 | 200.067 | 217.27849999999998 | 212.884 | 255.051 | 255.051 | 255.051 | 4.6023881792262005 | ok | api |
| zyx | property_range_indexed | medium | 10 | 1214.34 | 1159.77 | 1247.398 | 1225.07 | 1321.92 | 1321.92 | 1321.92 | 0.8016687536776554 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | point_lookup_indexed | medium | 10 | 11.7562 | 10.0947 | 10.41905 | 10.2102 | 11.7562 | 11.7562 | 11.7562 | 95.97804022439666 | ok | api |
| zyx | property_equality_indexed | medium | 10 | 3367.88 | 3119.7 | 3318.2650000000003 | 3259.51 | 3515.88 | 3515.88 | 3515.88 | 0.30136230831473676 | ok | api |
| zyx | property_range_indexed | medium | 10 | 22107.5 | 21043.0 | 21555.23 | 21355.1 | 22204.4 | 22204.4 | 22204.4 | 0.04639245324684543 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| kuzu | batch_node_fetch_100 | medium | 10 | 0.49268401926383376 | 0.4493110172916204 | 0.4917441983707249 | 0.4788440128322691 | 0.5758469924330711 | 0.5758469924330711 | 0.5758469924330711 | 2033.577626972026 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_ids | medium | 10 | 0.5357880145311356 | 0.5187319766264409 | 0.5434338934719563 | 0.5479959945660084 | 0.5799729842692614 | 0.5799729842692614 | 0.5799729842692614 | 1840.1502225249128 | ok | cypher |
| kuzu | one_hop_fetch_neighbor_records | medium | 10 | 0.7207299931906164 | 0.6274530023802072 | 0.7776276004733518 | 0.7207299931906164 | 0.9891150111798197 | 0.9891150111798197 | 0.9891150111798197 | 1285.9625859361054 | ok | cypher |
| kuzu | point_edge_fetch_by_endpoints | medium | 10 | 0.41111401515081525 | 0.4005890223197639 | 0.5246123037068173 | 0.4642830172087997 | 0.9900460136123002 | 0.9900460136123002 | 0.9900460136123002 | 1906.1695521324561 | ok | cypher |
| kuzu | point_node_fetch_by_id | medium | 10 | 0.22549202549271286 | 0.21467500482685864 | 0.2354470023419708 | 0.22548099514096975 | 0.2989000058732927 | 0.2989000058732927 | 0.2989000058732927 | 4247.240313332033 | ok | cypher |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

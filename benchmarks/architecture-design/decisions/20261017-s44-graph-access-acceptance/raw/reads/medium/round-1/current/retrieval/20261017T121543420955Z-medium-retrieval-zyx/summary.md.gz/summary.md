# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 10 | 4.09232 | 3.92949 | 4.1402149999999995 | 4.10032 | 4.52116 | 4.52116 | 4.52116 | 241.53335032117897 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 10 | 3.15884 | 2.94635 | 3.1074930000000003 | 3.06932 | 3.42647 | 3.42647 | 3.42647 | 321.8028166113327 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 10 | 4.90393 | 4.53833 | 4.797553 | 4.80985 | 4.93204 | 4.93204 | 4.93204 | 208.43959410140963 | ok | api |
| zyx | point_edge_fetch_by_endpoints | medium | 10 | 4.1113 | 3.42805 | 3.6418410000000003 | 3.54324 | 4.1113 | 4.1113 | 4.1113 | 274.586397374295 | ok | api |
| zyx | point_node_fetch_by_id | medium | 10 | 3.97405 | 3.70791 | 3.893672 | 3.89624 | 4.15532 | 4.15532 | 4.15532 | 256.8269746398772 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

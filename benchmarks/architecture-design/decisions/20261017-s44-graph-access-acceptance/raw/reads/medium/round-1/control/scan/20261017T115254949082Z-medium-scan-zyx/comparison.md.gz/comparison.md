# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 2926.29 | 2926.29 | 2926.29 | 1 | 1 |  |  | 3182.59 | 1.08759 | 1 |
| aggregation_group_by | medium | zyx | 2865.87 | 2865.87 | 3138.67 | 1 | 1 |  |  | 3229.09 | 1.12674 | 1.09519 |
| all_nodes_property_filter | medium | zyx | 5795.66 | 5795.66 | 5531.43 | 1 | 1 |  |  | 6011.85 | 1.0373 | 0.954409 |
| label_multi_property_filter | medium | zyx | 3119.41 | 3119.41 | 3126.59 | 1 | 1 |  |  | 3171.21 | 1.01661 | 1.0023 |
| label_scan_filter | medium | zyx | 2750.08 | 2750.08 | 2721.98 | 1 | 1 |  |  | 2857 | 1.03888 | 0.989782 |
| one_hop_expand | medium | zyx | 16.2936 | 16.2936 | 16.4168 | 1 | 1 |  |  | 16.7434 | 1.02761 | 1.00756 |
| relationship_property_filter | medium | zyx | 6401.14 | 6401.14 | 6641.38 | 1 | 1 |  |  | 6975.75 | 1.08977 | 1.03753 |
| relationship_type_scan | medium | zyx | 614.942 | 614.942 | 631.606 | 1 | 1 |  |  | 635.356 | 1.0332 | 1.0271 |
| topk_property_sort | medium | zyx | 3727.05 | 3727.05 | 3792.18 | 1 | 1 |  |  | 3918.66 | 1.05141 | 1.01747 |
| two_hop_expand | medium | zyx | 21.352 | 21.352 | 19.962 | 1 | 1 |  |  | 22.9046 | 1.07271 | 0.934901 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

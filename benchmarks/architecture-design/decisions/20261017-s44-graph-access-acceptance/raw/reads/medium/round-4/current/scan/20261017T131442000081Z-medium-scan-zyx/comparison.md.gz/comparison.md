# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_group_by | medium | zyx | 490.085 | 490.085 | 477.122 | 1 | 1 |  |  | 536.586 | 1.09488 | 0.973549 |
| all_nodes_property_filter | medium | zyx | 774.869 | 774.869 | 846.356 | 1 | 1 |  |  | 842.125 | 1.0868 | 1.09226 |
| label_multi_property_filter | medium | zyx | 506.493 | 506.493 | 511.938 | 1 | 1 |  |  | 539.876 | 1.06591 | 1.01075 |
| label_scan_filter | medium | zyx | 415.645 | 415.645 | 424.224 | 1 | 1 |  |  | 453.002 | 1.08988 | 1.02064 |
| one_hop_expand | medium | zyx | 2.37405 | 2.37405 | 2.43551 | 1 | 1 |  |  | 2.71719 | 1.14454 | 1.02589 |
| relationship_property_filter | medium | zyx | 995.73 | 995.73 | 1020.15 | 1 | 1 |  |  | 1071.29 | 1.07588 | 1.02452 |
| relationship_type_scan | medium | zyx | 341.397 | 341.397 | 328.751 | 1 | 1 |  |  | 367.651 | 1.0769 | 0.962958 |
| two_hop_expand | medium | zyx | 2.87987 | 2.87987 | 2.83772 | 1 | 1 |  |  | 3.17318 | 1.10185 | 0.985364 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

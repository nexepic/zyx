# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 3.97362 | 3.97362 | 3.95762 | 1 | 1 |  |  | 4.90591 | 1.23462 | 0.995973 |
| one_hop_fetch_neighbor_ids | medium | zyx | 2.97351 | 2.97351 | 2.93625 | 1 | 1 |  |  | 3.28484 | 1.1047 | 0.987469 |
| one_hop_fetch_neighbor_records | medium | zyx | 4.67015 | 4.67015 | 4.9365 | 1 | 1 |  |  | 5.3233 | 1.13986 | 1.05703 |
| point_node_fetch_by_id | medium | zyx | 3.7595 | 3.7595 | 4.23238 | 1 | 1 |  |  | 4.70341 | 1.25107 | 1.12578 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

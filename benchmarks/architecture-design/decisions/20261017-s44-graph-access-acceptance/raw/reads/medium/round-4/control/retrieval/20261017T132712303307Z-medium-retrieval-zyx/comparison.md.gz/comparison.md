# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| batch_node_fetch_100 | medium | zyx | 23.8815 | 23.8815 | 23.4637 | 1 | 1 |  |  | 28.2952 | 1.18482 | 0.982505 |
| one_hop_fetch_neighbor_ids | medium | zyx | 22.8412 | 22.8412 | 24.3837 | 1 | 1 |  |  | 25.8709 | 1.13264 | 1.06753 |
| one_hop_fetch_neighbor_records | medium | zyx | 33.6604 | 33.6604 | 36.4883 | 1 | 1 |  |  | 38.3137 | 1.13824 | 1.08401 |
| point_node_fetch_by_id | medium | zyx | 25.1765 | 25.1765 | 25.938 | 1 | 1 |  |  | 27.7291 | 1.10139 | 1.03025 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

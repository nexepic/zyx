# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_group_by | medium | 100 | 477.122 | 455.119 | 491.92336 | 490.085 | 536.586 | 556.489 | 563.12 | 2.032836985013275 | ok | api |
| zyx | all_nodes_property_filter | medium | 100 | 846.356 | 733.398 | 782.09177 | 774.869 | 842.125 | 851.152 | 877.045 | 1.2786223284257294 | ok | api |
| zyx | label_multi_property_filter | medium | 100 | 511.938 | 465.537 | 505.34012 | 506.493 | 539.876 | 558.757 | 564.681 | 1.9788652442636059 | ok | api |
| zyx | label_scan_filter | medium | 100 | 424.224 | 397.101 | 420.12124000000006 | 415.645 | 453.002 | 467.833 | 486.172 | 2.380265277708882 | ok | api |
| zyx | one_hop_expand | medium | 100 | 2.43551 | 2.31194 | 2.4316765 | 2.37405 | 2.71719 | 2.864 | 2.91958 | 411.23891274188816 | ok | api |
| zyx | relationship_property_filter | medium | 100 | 1020.15 | 954.543 | 1007.7425599999999 | 995.73 | 1071.29 | 1170.84 | 1218.28 | 0.9923169266563477 | ok | api |
| zyx | relationship_type_scan | medium | 100 | 328.751 | 325.025 | 345.00428999999997 | 341.397 | 367.651 | 381.043 | 382.524 | 2.8985146822377197 | ok | api |
| zyx | two_hop_expand | medium | 100 | 2.83772 | 2.78942 | 2.9383285999999997 | 2.87987 | 3.17318 | 3.37833 | 3.8031 | 340.32953291881654 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 100 | 3.95762 | 3.73155 | 4.1219262 | 3.97362 | 4.90591 | 5.79636 | 6.38173 | 242.6050228652808 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 100 | 2.93625 | 2.87545 | 3.0124979 | 2.97351 | 3.28484 | 3.35289 | 3.39947 | 331.95043887001543 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 100 | 4.9365 | 4.45508 | 4.7460054000000005 | 4.67015 | 5.3233 | 5.44197 | 5.55999 | 210.70351078825152 | ok | api |
| zyx | point_node_fetch_by_id | medium | 100 | 4.23238 | 3.55114 | 3.9576335 | 3.7595 | 4.70341 | 6.25922 | 6.28736 | 252.67625210874124 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

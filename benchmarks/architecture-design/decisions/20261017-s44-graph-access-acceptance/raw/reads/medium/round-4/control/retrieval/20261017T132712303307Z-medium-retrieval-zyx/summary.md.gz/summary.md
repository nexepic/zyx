# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | batch_node_fetch_100 | medium | 100 | 23.4637 | 22.6141 | 24.459749000000002 | 23.8815 | 28.2952 | 30.8203 | 34.3528 | 40.88349393936953 | ok | api |
| zyx | one_hop_fetch_neighbor_ids | medium | 100 | 24.3837 | 21.1937 | 23.509265999999997 | 22.8412 | 25.8709 | 34.0709 | 40.6084 | 42.536419469667834 | ok | api |
| zyx | one_hop_fetch_neighbor_records | medium | 100 | 36.4883 | 32.5292 | 34.41801 | 33.6604 | 38.3137 | 39.8772 | 42.3171 | 29.05455603040385 | ok | api |
| zyx | point_node_fetch_by_id | medium | 100 | 25.938 | 24.4913 | 25.424378 | 25.1765 | 27.7291 | 29.2212 | 29.9103 | 39.33232899542321 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

#include <fstream>
#include <iostream>
#include "graph/storage/StorageIO.hpp"
#include "graph/storage/relocatable/metadata/RelocatableMetadataStore.hpp"
using namespace graph::storage;
int main(int argc,char **argv) {
 if(argc!=2)return 2;
 auto stream=std::make_shared<std::fstream>(argv[1],std::ios::in|std::ios::out|std::ios::binary);
 auto io=std::make_shared<StorageIO>(stream,INVALID_FILE_HANDLE,INVALID_FILE_HANDLE);
 auto metadata=RelocatableMetadataStore::open(io);
 auto before=metadata->pagePoolStats();auto pin=metadata->openSnapshot();auto lsn=pin.superblock().checkpoint_lsn.value();pin.release();
 auto result=metadata->reclaimEmptyMetadataPagePools(LogSequenceNumber(lsn+1U));auto after=metadata->pagePoolStats();
 std::cout<<"{\"scope\":\"Existing metadata lifecycle diagnostic only; not backend quota admission or performance evidence\",\"before_pools\":"<<before.pools<<",\"after_pools\":"<<after.pools<<",\"reclaimed_pools\":"<<result.reclaimed_pool_slots<<",\"allocated_pages_before\":"<<before.allocated_pages<<",\"allocated_pages_after\":"<<after.allocated_pages<<"}\n";
}

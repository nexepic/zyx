#include <fstream>
#include <bit>
#include "graph/storage/relocatable/metadata/MetadataPagePool.hpp"
#include <iostream>
#include "graph/storage/StorageIO.hpp"
#include "graph/storage/relocatable/metadata/RelocatableMetadataStore.hpp"
using namespace graph::storage;
int main(int argc,char **argv) {
 if(argc!=2)return 2;
 auto stream=std::make_shared<std::fstream>(argv[1],std::ios::in|std::ios::binary);
 auto io=std::make_shared<StorageIO>(stream,INVALID_FILE_HANDLE,INVALID_FILE_HANDLE,StorageIOAccessMode::SIOAM_READ_ONLY);
 auto metadata=RelocatableMetadataStore::openReadOnly(io);auto snapshot=metadata->openSnapshot();
 std::cout<<"{\"generation\":"<<snapshot.superblock().generation.value()<<",\"catalog\":[";bool first=true;
 metadata->visitCatalogEntries(snapshot,[&](const CatalogEntry &e){if(!first)std::cout<<',';first=false;std::cout<<"{\"id\":"<<e.segment_id.value()<<",\"slot\":"<<e.physical_slot.value()<<",\"kind\":"<<unsigned(e.kind)<<",\"owner\":"<<e.owner_id<<",\"state\":"<<unsigned(e.state)<<",\"generation\":"<<e.generation.value()<<'}';});
 std::cout<<"],\"pages\":[";first=true;
 metadata->visitPageLocationsUntil(snapshot,[&](const PageLocation &l){if(!first)std::cout<<',';first=false;std::cout<<"{\"page\":"<<l.page_id.value()<<",\"segment\":"<<l.segment_id.value()<<'}';return true;});
 std::cout<<"],\"metadata_pool_headers\":[";first=true;
 MetadataPagePoolAllocator pools(io,snapshot.superblock(),MetadataPagePoolOpenMode::CPOM_ROOT_DISCOVER_ONLY);
 metadata->visitCatalogEntries(snapshot,[&](const CatalogEntry &e){
  if(e.kind!=SegmentKind::SGK_METADATA_PAGE_POOL || e.state!=SegmentState::SGS_SEALED)return;
  pools.registerCatalogPool(e.physical_slot,e.segment_id,e.generation,e.committed_lsn);
  const auto header=pools.poolHeader(e.physical_slot);
  if(!first)std::cout<<',';first=false;
  std::cout<<"{\"id\":"<<e.segment_id.value()<<",\"slot\":"<<e.physical_slot.value()<<",\"allocated_header_frames\":"<<std::popcount(header.allocated_frames)<<'}';
 });
 std::cout<<"]}\n";snapshot.release();
}

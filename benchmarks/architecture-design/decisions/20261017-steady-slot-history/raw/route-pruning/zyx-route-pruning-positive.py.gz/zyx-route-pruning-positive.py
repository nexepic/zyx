from pathlib import Path
import subprocess,json,shlex,xml.etree.ElementTree as ET,hashlib
r=Path('/workspace/zyx');modules=['tests/src/storage/relocatable/metadata/test_MetadataPoolReclaimHeadroom.cpp']
objects=['CMakeFiles/zyx_test_suite.dir/'+s+'.o' for s in modules];subprocess.run(['cmake','--build','buildDir','--target','zyx_core',*objects,'-j','2'],cwd=r,check=True)
link=json.loads(Path('/tmp/zyx-final-five-targeted-link.json').read_text());first=next(i for i,x in enumerate(link) if 'CMakeFiles/zyx_test_suite.dir/' in x);last=link.index('/tmp/zyx-final-five-crash-dispatch.o');link[first:last]=[str(r/'buildDir'/o) for o in objects];link.remove('/tmp/zyx-final-five-crash-dispatch.o');binary='/tmp/zyx-route-pruning-positive-tests';link[link.index('-o')+1]=binary;subprocess.run(link,cwd=r/'buildDir',check=True)
Path('/tmp/zyx-route-pruning-positive-provenance.json').write_text(json.dumps({'modules':modules,'module_count':len(modules),'full_suite':False,'binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'core_sha256':hashlib.sha256((r/'buildDir/libzyx_core.a').read_bytes()).hexdigest(),'link':link},indent=2)+'\n')
subprocess.run([binary,'--gtest_output=xml:/tmp/zyx-route-pruning-positive-tests.xml'],cwd=r,check=True)

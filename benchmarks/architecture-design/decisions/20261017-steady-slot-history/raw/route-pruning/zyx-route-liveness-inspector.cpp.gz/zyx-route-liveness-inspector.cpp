#include <fstream>
#include <set>
#include "graph/storage/relocatable/metadata/MetadataPageFile.hpp"
#include <iostream>
#include "graph/storage/StorageIO.hpp"
#include "graph/storage/relocatable/metadata/RelocatableMetadataStore.hpp"
using namespace graph::storage;
int main(int argc,char **argv) {
 if(argc!=2)return 2;
 auto stream=std::make_shared<std::fstream>(argv[1],std::ios::in|std::ios::binary);
 auto io=std::make_shared<StorageIO>(stream,INVALID_FILE_HANDLE,INVALID_FILE_HANDLE,StorageIOAccessMode::SIOAM_READ_ONLY);
 auto metadata=RelocatableMetadataStore::openReadOnly(io);auto snapshot=metadata->openSnapshot();
 std::cout<<"{\"generation\":"<<snapshot.superblock().generation.value()<<",\"catalog\":[";bool first=true;
 metadata->visitCatalogEntries(snapshot,[&](const CatalogEntry &e){if(!first)std::cout<<',';first=false;std::cout<<"{\"id\":"<<e.segment_id.value()<<",\"slot\":"<<e.physical_slot.value()<<",\"kind\":"<<unsigned(e.kind)<<",\"owner\":"<<e.owner_id<<",\"state\":"<<unsigned(e.state)<<",\"generation\":"<<e.generation.value()<<'}';});
 std::cout<<"],\"pages\":[";first=true;
 metadata->visitPageLocationsUntil(snapshot,[&](const PageLocation &l){if(!first)std::cout<<',';first=false;std::cout<<"{\"page\":"<<l.page_id.value()<<",\"segment\":"<<l.segment_id.value()<<'}';return true;});
 std::cout<<"]";
 MetadataPageFile pages(io,snapshot.superblock()); MetadataPageRouteDirectory routes(pages);
 const auto bootstrap=pages.readPageDirectoryBootstrap(snapshot.superblock().page_directory_root);
 auto physical=snapshot.superblock();physical.page_directory_root=bootstrap.data_page_directory_root;
 const auto needed=routes.collectRoutesFromPhysicalDirectoryRoots(physical);
 const auto registered=routes.collectRoutesFromRouteBranch(snapshot.superblock(),bootstrap.metadata_page_directory_root);
 std::set<uint64_t> live;for(const auto &r:needed)live.insert(r.page_id.value());
 size_t orphan=0U;for(const auto &r:registered)if(!live.contains(r.page_id.value()))++orphan;
 std::cout<<",\"registered_metadata_routes\":"<<registered.size()<<",\"current_directory_metadata_routes\":"<<needed.size()<<",\"routes_without_current_directory_reference\":"<<orphan<<"}\n";snapshot.release();
}

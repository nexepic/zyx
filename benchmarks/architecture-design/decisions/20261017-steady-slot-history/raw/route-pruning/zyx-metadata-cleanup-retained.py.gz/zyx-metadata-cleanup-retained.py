from pathlib import Path
import sys,json,os,shutil,tempfile,importlib.util
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
spec=importlib.util.spec_from_file_location('w','/tmp/zyx-final-repaired-window.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w);w.restrict()
from runner.workload_preflight import NativeWorker
r=Path('/tmp/zyx-metadata-cleanup-retained-20261017');r.mkdir(exist_ok=False);source=Path('/tmp/zyx-steady-lifecycle-preflight-20261017/fresh-endpoint.zyx');before=w.digest(source);binary=Path('/workspace/zyx/buildDir_perf_control/zyx-workload-contract-worker');binary_hash=w.digest(binary)
with tempfile.TemporaryDirectory(prefix='zyx-metadata-cleanup-retained-') as tmp:
 path=Path(tmp)/'private.zyx';worker=NativeWorker(binary,path,r)
 try:
  worker.call('READONLY');replacement=path.with_suffix('.next');shutil.copyfile(source,replacement);os.replace(replacement,path);worker.call('READWRITE')
  stats_before=worker.call('STATS');first=worker.call('MAINTAIN');stats_after=worker.call('STATS');worker.call('INTEGRITY');worker.call('REOPEN');worker.call('INTEGRITY')
  worker.call('QUERY','MATCH (n:User) RETURN n.id AS id,n.country AS country,n.score AS score,n.age AS age ORDER BY id',expected=[[i,f'country-{i%8}',i%7,18+i%53] for i in range(10000)],ordered=True)
  worker.call('QUERY','MATCH (n:Churn) RETURN n.id AS id',expected=[])
  second=worker.call('MAINTAIN');worker.call('INTEGRITY');worker.call('READONLY');shutil.copyfile(path,r/'repaired-endpoint.zyx')
  report={'scope':'Exact stopped-source endpoint replay; untimed correctness/resource check only, same original quotas. Not a13window result or formal performance sample.','source_commit':'e4c12fde','binary_sha256':binary_hash,'source_sha256':before,'first':first,'second':second,'stats_before_maintenance':stats_before,'stats_immediately_after_maintenance':stats_after,'full10000_user_rows_and_empty_churn':'passed','reopen_integrity':'passed'}
  (r/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
 finally:
  worker.close();(r/'trace.json').write_text(json.dumps(worker.trace,indent=2)+'\n')
assert w.digest(source)==before and w.digest(binary)==binary_hash

from pathlib import Path
import sys,json,os,shutil,tempfile,importlib.util,hashlib
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
spec=importlib.util.spec_from_file_location('w','/tmp/zyx-final-repaired-window.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w);w.restrict()
import runner.workload_preflight as f
r=Path('/tmp/zyx-steady-lifecycle-preflight-20261017');r.mkdir(exist_ok=False)
binary=Path('/workspace/zyx/buildDir_perf_control/zyx-workload-contract-worker')
production=['src/storage/relocatable/maintenance/LargeValueReachabilityReclaimer.cpp','src/storage/relocatable/metadata/RelocatableMetadataStore.cpp']
registration={'scope':'Untimed correctness/resource preflight only; zero formal performance samples. Exact existing 3 warmup +10 subsequent maintenance windows, unchanged 1800s deadline and original quotas.','binary_sha256':w.digest(binary),'production_sha256':{p:w.digest(Path('/workspace/zyx')/p) for p in production}}
(r/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
source=Path('/tmp/zyx-reactivation-full-untimed-20261017/normalized-endpoint-v2.zyx');before=w.digest(source);out=r/'retained-repair';out.mkdir()
with tempfile.TemporaryDirectory(prefix='zyx-steady-fixed-') as tmp:
 path=Path(tmp)/'private.zyx';worker=f.NativeWorker(binary,path,out)
 try:
  worker.call('READONLY');replacement=path.with_suffix('.next');shutil.copyfile(source,replacement);os.replace(replacement,path);worker.call('READWRITE')
  first=worker.call('MAINTAIN');worker.call('REOPEN');worker.call('INTEGRITY')
  worker.call('QUERY','MATCH (n:User) RETURN count(n) AS count',expected=[[10000]]);worker.call('QUERY','MATCH (n:Churn) RETURN count(n) AS count',expected=[[0]])
  second=worker.call('MAINTAIN');worker.call('INTEGRITY');assert second['retired_values']==0
  worker.call('READONLY');shutil.copyfile(path,r/'repaired-retained-endpoint.zyx')
  report={'source_sha256':before,'first':first,'second':second,'stats':worker.call('STATS'),'integrity_reopen_exact_counts':'passed'}
  (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'retained_repair':report}),flush=True)
 finally:
  worker.close();(out/'trace.json').write_text(json.dumps(worker.trace,indent=2)+'\n')
assert w.digest(source)==before
original_init=f.NativeWorker.__init__;original_close=f.NativeWorker.close
def init(self,binary,database,evidence=None):
 self.steady_path=Path(database);return original_init(self,binary,database,evidence)
def close(self):
 try:return original_close(self)
 finally:
  if self.steady_path.exists():os.link(self.steady_path,r/'fresh-endpoint.zyx')
f.NativeWorker.__init__=init;f.NativeWorker.close=close
try:
 full=f.run_native(binary,r/'full-maintenance',profile='contract',seed=42,family='maintenance')
 assert len(full['maintenance_windows'])==10 and full['full_results_checked']
 (r/'proof.json').write_text(json.dumps({'registration':registration,'retained':report,'full_maintenance':full,'formal_performance_samples':0},indent=2)+'\n');print(json.dumps({'full13windows':'passed','formal_performance_samples':0}),flush=True)
except BaseException as error:
 (r/'failure.json').write_text(json.dumps({'error':repr(error),'formal_performance_samples':0},indent=2)+'\n');raise
finally:
 assert w.digest(binary)==registration['binary_sha256']
 for p,h in registration['production_sha256'].items():assert w.digest(Path('/workspace/zyx')/p)==h

from pathlib import Path
import subprocess,json,hashlib,shutil,tarfile
repo=Path('/workspace/zyx');r=repo/'benchmarks/architecture-design/results/20261020-work-resume';out=r/'r7-repair';out.mkdir(exist_ok=True)
def sha(p):return hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert (r/'r7-final/window/campaign-completed.json').exists()
checks={mode:json.loads((r/f'r7-repair-selected-{mode}-latest.json').read_text()) for mode in ['candidate','default']}
for check in checks.values():
 assert check.get('returncode')==0
 for path,digest in check['source_files'].items():
  if path.startswith(('src/','include/','tests/')):assert sha(repo/path)==digest,('source changed since module verification',path)
old=json.loads((r/'r7-final/freeze.json').read_text());relocations={}
for name in ['after-row','after-hybrid']:
 entry=old['frozen_engine_libraries'][name];source=Path(entry['path']);destination=out/f'previous-{name}-libzyx_core.a'
 if destination.exists():assert sha(destination)==entry['sha256'],('preserved original library changed',name)
 else:
  assert sha(source)==entry['sha256'],('original frozen library changed',name)
  shutil.copy2(source,destination)
 assert sha(destination)==entry['sha256'];relocations[name]={'original':str(source),'preserved':str(destination),'sha256':entry['sha256']}
(out/'previous-library-relocations.json').write_text(json.dumps(relocations,indent=2)+'\n')
public=json.loads((r/'r7-final-public-probes-build.json').read_text());imports=json.loads((r/'r7-final-import-build.json').read_text());maintenance=json.loads((r/'r7-final-maintenance-build.json').read_text());report={}
for name,build in [('after-row','/workspace/zyx-build-r7-row'),('after-hybrid','/workspace/zyx-build-r7-hybrid')]:
 command=['cmake','--build',build,'--target','zyx_core','-j3']
 print('build',name,flush=True)
 with (out/f'{name}-core-build.log').open('w') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 library=Path(build)/'libzyx_core.a';entry={'core_build':command,'library':{'path':str(library),'sha256':sha(library)},'observers':{}}
 templates=[('public-probe',public[name])]
 if name=='after-row':templates += [('import',imports[name]),('maintenance',maintenance[name])]
 for family,template in templates:
  previous=f'r7-final-{family}-{name}';current=f'r7-repair-{family}-{name}'
  compile=[x.replace(previous,current).replace('r7-final-public-probe.cpp','r7-repair-public-probe.cpp').replace('/workspace/zyx/benchmarks/graphdb-comparison/native-maintenance-cost/main.cpp',str(r/'r7-repair-maintenance.cpp')) for x in template['compile']];link=[x.replace(previous,current) for x in template['link']]
  with (out/f'{name}-{family}-build.log').open('w') as log:
   subprocess.run(compile,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
   subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
  entry['observers'][family]={'compile':compile,'link':link,'cwd':build,'binary':str(r/current),'sha256':sha(r/current)}
 report[name]=entry
 (out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
# Supplementary fixed JOIN observer keeps the old engine and headers intact.
template=public['before'];build=template['cwd'];name='before'
original=old['frozen_engine_libraries'][name];assert sha(original['path'])==original['sha256']
previous='r7-final-public-probe-before';current='r7-repair-public-probe-before'
compile=[x.replace(previous,current).replace('r7-final-public-probe.cpp','r7-repair-public-probe.cpp').replace('/workspace/zyx/benchmarks/graphdb-comparison/native-maintenance-cost/main.cpp',str(r/'r7-repair-maintenance.cpp')) for x in template['compile']]
link=[x.replace(previous,current) for x in template['link']]
with (out/'before-public-probe-build.log').open('w') as log:
 subprocess.run(compile,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
report['before']={'engine_rebuilt':False,'library':original,'observers':{'public-probe':{'compile':compile,'link':link,'cwd':build,'binary':str(r/current),'sha256':sha(r/current)}}}
(out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
template=maintenance['before'];build='/workspace/zyx/buildDir_perf_control'
previous='r7-final-maintenance-before';current='r7-repair-maintenance-before'
compile=[x.replace(previous,current).replace('/workspace/zyx/benchmarks/graphdb-comparison/native-maintenance-cost/main.cpp',str(r/'r7-repair-maintenance.cpp')) for x in template['compile']]
link=[x.replace(previous,current) for x in template['link']]
with (out/'before-maintenance-build.log').open('w') as log:
 subprocess.run(compile,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
report['before']['observers']['maintenance']={'compile':compile,'link':link,'cwd':build,'binary':str(r/current),'sha256':sha(r/current)}
(out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
paths=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
files={p:sha(repo/p) for p in paths if (repo/p).is_file()}
with (out/'source-delta.patch').open('w') as patch:subprocess.run(['git','diff','--binary','HEAD'],cwd=repo,stdout=patch,check=True)
with tarfile.open(out/'source-files.tar','w') as archive:
 for path in files:archive.add(repo/path,arcname=path)
freeze={'parent_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'uncommitted_repair':True,'source_files':files,'source_delta_sha256':sha(out/'source-delta.patch'),'source_archive_sha256':sha(out/'source-files.tar'),'module_checks':checks,'build':report,'previous_libraries':relocations,'harness_files':{name:sha(r/name) for name in ['r7-repair-public-probe.cpp','r7-repair-kuzu-worker.py','r7_repair_oracle.py','r7_final_oracle.py','r7-final-import.cpp','r7-repair-campaign.py','r7-repair-preflight.py','r7-repair-maintenance.cpp']},'timing_started':False}
(out/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print('repair Release identities frozen; performance not started',flush=True)

print('start untimed repair preflight',flush=True)
subprocess.run(['python3',str(r/'r7-repair-preflight.py')],check=True)

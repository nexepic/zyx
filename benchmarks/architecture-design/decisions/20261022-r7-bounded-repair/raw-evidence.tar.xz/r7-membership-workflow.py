from pathlib import Path
import subprocess
r=Path(__file__).parent
for mode in ['candidate','default']:
 print('Affected modules',mode,flush=True)
 subprocess.run(['python3',str(r/'r7-membership-run-tests.py'),mode],check=True)
subprocess.run(['python3',str(r/'r7-membership-build-release.py')],check=True)
subprocess.run(['python3',str(r/'r7-membership-preflight.py')],check=True)
print('Write-auth modules,Release,untimed preflight complete; no timing started.',flush=True)

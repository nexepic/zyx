from pathlib import Path
import subprocess,json,resource,sys,time,hashlib
from r7_repair_oracle import *
r=ROOT;out=r/'r7-repair'/f'preflight-attempt-{time.time_ns()}';out.mkdir(parents=True);results=[]
freeze=json.loads((r/'r7-repair/freeze.json').read_text())
for engine,entry in freeze['build'].items():
 for artifact in entry['observers'].values():require(hashlib.file_digest(Path(artifact['binary']).open('rb'),'sha256').hexdigest()==artifact['sha256'],'frozen observation binary')
inputs={}
def input_file(path,expected=None):
 digest=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
 if expected:require(digest==expected,'original input identity: '+str(path))
 st=path.stat();inputs[str(path)]={'sha256':digest,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns}
for scale in ['medium','holdout']:
 manifest=r/f'r7-inputs/{scale}/manifest.json';input_file(manifest)
 for name,entry in json.loads(manifest.read_text())['files'].items():input_file(manifest.parent/name,entry['sha256'])
for entry in json.loads((r/'r43-identity-untimed-preparation.json').read_text())['cases']:
 input_file(r/f'r7-inputs/{entry["scale"]}-r43-identity.zyx',entry['sha256'])
for entry in json.loads((r/'r7-final-kuzu-untimed-preparation.json').read_text())['cases']:
 input_file(r/f'r7-inputs/{entry["scale"]}-r7-final.kuzu',entry['sha256'])
for scale,digest in [('medium','65852fdced53810645824c887a66ebd9fb37db24f37830d270074f3d7189a6ee'),('holdout','6bf075b56cc6f1f50b33e7fae2e680ff11133e96108d2b05788a8bf6c8fcfb5e')]:
 input_file(r/f'r7-inputs/{scale}-r7-final-indexed.zyx',digest)
for layout in ['row','native']:input_file(r/f'r7-inputs/r7-cohort-{layout}.zyx')
(out/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print('complete CSV/native/Kuzu inputs verified before repair timing',flush=True)
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
def run(engine,scale,family,cases,source,mode):
 stem=out/f'{engine}-{scale}-{family}';target=Path(str(stem)+('.kuzu' if engine=='kuzu' else '.zyx'))
 command=[sys.executable,str(r/'r7-repair-kuzu-worker.py'),mode,str(source),str(target),','.join(cases),'0','1'] if engine=='kuzu' else [str(r/f'r7-repair-public-probe-{engine}'),mode,str(source),str(target),','.join(cases),'0','1']
 try:
  with Path(str(stem)+'.jsonl').open('w') as stdout,Path(str(stem)+'.stderr').open('w') as stderr:p=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=limits,timeout=900)
  events=[json.loads(line) for line in Path(str(stem)+'.jsonl').read_text().splitlines() if line.startswith('{')]
  require(p.returncode==0,'process success')
  require(not any('latency_ms' in event for event in events),'untimed preflight must not emit latency')
  for case in cases:
   found=[event for event in events if event.get('case')==case]
   require(len(found)==1 and 'rows' in found[0],'one complete supported observation per case')
   require(found[0].get('status')!='failed','no engine error')
   check_event(case,found[0],scale,mode=='check-write')
  result={'engine':engine,'scale':scale,'family':family,'cases':cases,'passed':True,'command':command}
 except Exception as error:result={'engine':engine,'scale':scale,'family':family,'cases':cases,'passed':False,'error':str(error),'command':command}
 results.append(result);(out/'summary.json').write_text(json.dumps({'timing_benchmark':False,'results':results},indent=2)+'\n');print(engine,scale,family,result['passed'],flush=True)
for layout in ['row','native']:
 run('after-hybrid',layout,'cohort-read',COHORT,r/f'r7-inputs/r7-cohort-{layout}.zyx','check-read')
 for case in CWRITES:run('after-hybrid',layout,'write-'+case,[case],r/f'r7-inputs/r7-cohort-{layout}.zyx','check-write')
explicit=['label_scan_filter','label_multi_property_filter','aggregation_count_by_group','multi_key_group','distinct_tuple','empty_count']
for scale in ['medium','holdout']:
 for engine in ['before','after-row','kuzu']:
  scan=r/f'r7-inputs/{scale}-r7-final.kuzu' if engine=='kuzu' else r/f'r7-inputs/{scale}-r43-identity.zyx'
  indexed=r/f'r7-inputs/{scale}-r7-final.kuzu' if engine=='kuzu' else r/f'r7-inputs/{scale}-r7-final-indexed.zyx'
  run(engine,scale,'explicit-read',explicit,scan,'check-read-transaction')
  run(engine,scale,'plan-join',['plan_join_count'],indexed,'check-read')
  for case in ['edge_create','edge_create_delete','edge_batch_100','edge_batch_1000']:run(engine,scale,'write-'+case,[case],indexed,'check-write')
for engine in ['before','after-row']:
 stem=out/f'{engine}-maintenance-bounded-1';target=Path(str(stem)+'.zyx')
 command=[str(r/f'r7-repair-maintenance-{engine}'),str(target),'1','scattered','65','8192','check-reclaim']
 try:
  with Path(str(stem)+'.jsonl').open('w') as stdout,Path(str(stem)+'.stderr').open('w') as stderr:p=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=limits,timeout=900)
  events=[json.loads(line) for line in Path(str(stem)+'.jsonl').read_text().splitlines() if line.startswith('{')]
  require(p.returncode==0 and len(events)==1,'one complete successful bounded maintenance check')
  require(events[0].get('timing_benchmark') is False and 'milliseconds' not in events[0],'untimed maintenance')
  require(events[0]['checked']==65 and events[0]['retired_values']==1 and events[0]['retired_data_pages']>0 and events[0]['retired_manifest_pages']>0,'maintenance contents and work unit')
  results.append({'engine':engine,'family':'maintenance-bounded-1','passed':True,'command':command})
 except Exception as error:results.append({'engine':engine,'family':'maintenance-bounded-1','passed':False,'error':str(error),'command':command})
summary={'timing_benchmark':False,'all_passed':all(x['passed'] for x in results),'results':results,'path':str(out/'summary.json'),'input_identities':inputs,'freeze_sha256':hashlib.file_digest((r/'r7-repair/freeze.json').open('rb'),'sha256').hexdigest()}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(r/'r7-repair/preflight-latest.json').write_text(json.dumps(summary,indent=2)+'\n')
raise SystemExit(0 if summary['all_passed'] else 1)

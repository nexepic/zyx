from pathlib import Path
import json,statistics,math,collections
r=Path(__file__).parent
root=r/'r7-repair/window'
name='campaign-completed.json' if (root/'campaign-completed.json').exists() else 'campaign-progress.json'
repair=json.loads((root/name).read_text())
original=json.loads((r/'r7-final/window/campaign-completed.json').read_text())
# Keep original before/Kuzu observations; never reuse original current-candidate results.
processes=[x for x in original['results'] if x['engine'] in ['before','kuzu']]
for x in repair['results']:
 if x.get('reused_from'):continue
 x=dict(x)
 if x['family'].startswith('near-'):x['family']=x['family'][5:]
 processes.append(x)
groups=collections.defaultdict(list)
def p95(values):return sorted(values)[math.ceil(.95*len(values))-1]
for x in processes:
 for c in x.get('cases',[]):
  groups[x['scale'],x['family'],c['case'],x['engine']].append((x,c))
summary=[]
for key,items in sorted(groups.items()):
 valid=[(x,c) for x,c in items if x['status']=='completed' and c['status']=='passed' and c.get('samples')]
 samples=[v for x,c in valid for v in c['samples']]
 summary.append(dict(zip(['scale','family','case','engine'],key),processes=len(valid),process_medians=[statistics.median(c['samples']) for x,c in valid],process_p95=[p95(c['samples']) for x,c in valid],pooled_median=statistics.median(samples) if samples else None,pooled_p95=p95(samples) if samples else None,attempts=[{'round':x['round'],'process_status':x['status'],'case_status':c['status'],'resources':x.get('resources',{})} for x,c in items]))
lookup={(s['scale'],s['family'],s['case'],s['engine']):s for s in summary}
def comparison(b,a):
 if not b or min(a['processes'],b['processes'])<3:return {'status':'incomplete_or_NA'}
 am,bm,ap,bp=a['process_medians'],b['process_medians'],a['process_p95'],b['process_p95']
 stable=min(am)>1.05*max(bm) or min(ap)>1.05*max(bp)
 within=max(am)<=1.05*max(bm) and max(ap)<=1.05*max(bp)
 return {'status':'stable_regression' if stable else 'within_before_variation_plus_5pct' if within else 'uncertain','primary_repeatable_10pct':max(am)<=.9*min(bm),'median_ratio_after_over_before':a['pooled_median']/b['pooled_median'],'p95_ratio_after_over_before':a['pooled_p95']/b['pooled_p95']}
comparisons=[];layouts=[]
for a in summary:
 if a['engine']=='after-row':
  key=(a['scale'],a['family'],a['case'])
  b=lookup.get((*key,'before'));k=lookup.get((*key,'kuzu'))
  comparisons.append(dict(zip(['scale','family','case'],key),**comparison(b,a),kuzu_median_ratio_after_over_kuzu=a['pooled_median']/k['pooled_median'] if a['processes']>=3 and k and k['processes']>=3 else None))
 if a['engine']=='after-hybrid' and a['scale']=='native':
  layouts.append({'case':a['case'],**comparison(lookup.get(('row',a['family'],a['case'],a['engine'])),a)})
result={'complete':name=='campaign-completed.json','readme':'Descriptive variation envelope uses maximum before process median and P95. The earlier max-after/min-before positive screen was conservative, not the registered stable-regression rejection. Uncertain cases remain unresolved. All original baseline and two extra complete control rounds retained; no failed-current observations reused. Import P95 with one sample/process is descriptive only.','summary':summary,'before_after':comparisons,'layout':layouts}
(root/'analysis-current.json').write_text(json.dumps(result,indent=2)+'\n')
print('complete',result['complete'],'repair processes',len(repair['results']),'baseline comparisons',dict(collections.Counter(x['status'] for x in comparisons)))
for x in comparisons:
 if x['status']=='stable_regression':print('REGRESSION',x)
print('layout',layouts)

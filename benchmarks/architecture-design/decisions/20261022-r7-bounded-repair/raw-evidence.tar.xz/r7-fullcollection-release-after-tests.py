from pathlib import Path
import time,json,subprocess
r=Path(__file__).parent
print('Awaiting completed affected module receipts; no build during timing.',flush=True)
while True:
 checks=[]
 for mode in ['candidate','default']:
  try:checks.append(json.loads((r/f'r7-fullcollection-selected-{mode}-latest.json').read_text()))
  except (FileNotFoundError,json.JSONDecodeError):pass
 if any(x.get('returncode',0)!=0 for x in checks):raise SystemExit('Affected modules failed: no Release build or timing')
 if len(checks)==2 and all(x.get('returncode')==0 for x in checks):break
 time.sleep(5)
subprocess.run(['python3',str(r/'r7-fullcollection-build-release.py')],check=True)
subprocess.run(['python3',str(r/'r7-fullcollection-preflight.py')],check=True)
print('Release and untimed preflight complete; no new performance launched.',flush=True)

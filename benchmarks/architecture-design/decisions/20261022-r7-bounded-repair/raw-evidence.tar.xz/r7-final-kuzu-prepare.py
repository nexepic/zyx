from pathlib import Path
import sys,json,os,hashlib,resource
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.adapters.kuzu import KuzuAdapter,supports_secondary_property_indexes
resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
os.environ.update(KUZU_BENCH_BUFFER_POOL_BYTES=str(64*1024**2),KUZU_BENCH_MAX_DB_BYTES=str(2*1024**3))
r=Path('/workspace/zyx/benchmarks/architecture-design/results/20261020-work-resume')
import kuzu
report={'timing_benchmark':False,'version':kuzu.__version__,'buffer_pool_bytes':64*1024**2,'max_db_bytes':2*1024**3,'threads':1,'secondary_property_indexes':supports_secondary_property_indexes(),'cases':[]}
for scale in ['medium','holdout']:
 data=r/f'r7-inputs/{scale}';target=r/f'r7-inputs/{scale}-r7-final.kuzu';assert not target.exists()
 adapter=KuzuAdapter('kuzu',data,'medium' if scale=='holdout' else scale,'scan',1);adapter.db_path=target
 adapter.setup()
 try:
  rows=adapter.load_nodes_edges();manifest=json.loads((data/'manifest.json').read_text());counts=manifest['counts']
  nodes=sum(adapter._scalar_int(f'MATCH (n:{label}) RETURN count(n)') for label in ['User','Post','Tag'])
  edges=sum(adapter._scalar_int(f'MATCH ()-[r:{label}]->() RETURN count(r)') for label in ['FOLLOWS','AUTHORED','HAS_TAG'])
  assert rows==sum(counts.values()) and nodes==counts['users']+counts['posts']+counts['tags'] and edges==counts['follows']+counts['authored']+counts['has_tag']
 finally:adapter.teardown()
 case={'scale':scale,'nodes':nodes,'edges':edges,'prepared_rows':rows,'bytes':target.stat().st_size,'sha256':hashlib.file_digest(target.open('rb'),'sha256').hexdigest()};report['cases'].append(case);(r/'r7-final-kuzu-untimed-preparation.json').write_text(json.dumps(report,indent=2)+'\n');print(scale,'prepared',flush=True)

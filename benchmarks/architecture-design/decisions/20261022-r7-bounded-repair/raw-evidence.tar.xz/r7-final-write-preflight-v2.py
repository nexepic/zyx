from r7_final_oracle import *
import subprocess,resource
r=ROOT;out=r/'r7-final/preflight-v2';out.mkdir(parents=True,exist_ok=True)
def caps():
 resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
report={'timing_benchmark':False,'changes':['Normalize double-tagged JSON numeric payloads before unordered comparison;1and1.0 encode the same double','Original mutation count(r)/WITH forms are unsupported in both engines; use the existing supported constant-return/create-delete statement contract','Add persisted-value/count postconditions outside operation timing'],'cases':[]}
for engine,scale,source,cases in [*( (engine,'medium',r/'r7-inputs/medium-r7-final-indexed.zyx',[x for x in WRITES if not(engine=='before' and x=='steady_property')]) for engine in ['before','after-row']),*(('after-hybrid',layout,r/f'r7-inputs/r7-cohort-{layout}.zyx',CWRITES) for layout in ['row','native']),*((engine,'large',r/'r7-inputs/r7-fixtures-large.zyx',['large_patch']) for engine in ['before','after-row'])]:
 for case in cases:
  stem=out/f'{engine}-{scale}-{case}';target=Path(str(stem)+'.zyx')
  with Path(str(stem)+'.jsonl').open('w') as stdout,Path(str(stem)+'.stderr').open('w') as stderr:
   p=subprocess.run([str(r/f'r7-final-public-probe-{engine}'),'check-write',str(source),str(target),case,'0','1'],stdout=stdout,stderr=stderr,preexec_fn=caps,timeout=900)
  events=[json.loads(line) for line in Path(str(stem)+'.jsonl').read_text().splitlines() if line.startswith('{')];errors=[]
  try:
   require(p.returncode==0,'process exit '+str(p.returncode));observations=[e for e in events if e.get('case')==case];require(bool(observations),'missing observations')
   for event in observations:check_event(case,event,scale,True)
  except Exception as error:errors.append(str(error))
  entry={'engine':engine,'scale':scale,'case':case,'passed':not errors,'errors':errors,'returncode':p.returncode};report['cases'].append(entry);(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(engine,scale,case,entry['passed'],flush=True)

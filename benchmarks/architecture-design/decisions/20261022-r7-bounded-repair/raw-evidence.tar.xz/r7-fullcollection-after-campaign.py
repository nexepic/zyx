from pathlib import Path
import time,json,hashlib,shutil,subprocess
r=Path(__file__).parent
out=r/'r7-fullcollection';out.mkdir(exist_ok=True)
print('Waiting for the frozen repair campaign to finish; no concurrent compilation.',flush=True)
while not (r/'r7-repair/window/campaign-completed.json').exists():time.sleep(5)
print('Repair campaign completed; preserve engine archives before rebuilding.',flush=True)
def sha(p):return hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
freeze=json.loads((r/'r7-repair/freeze.json').read_text())
preserved={}
for name in ['after-row','after-hybrid']:
 source=Path(freeze['build'][name]['library']['path']);expected=freeze['build'][name]['library']['sha256'];destination=out/('previous-'+name+'-libzyx_core.a')
 assert sha(source)==expected
 if not destination.exists():shutil.copy2(source,destination)
 assert sha(destination)==expected
 preserved[name]={'path':str(destination),'sha256':expected}
(out/'preserved-campaign-libraries.json').write_text(json.dumps(preserved,indent=2)+'\n')
for mode in ['candidate','default']:
 print('Start selected full-collection modules:',mode,flush=True)
 subprocess.run(['python3',str(r/'r7-fullcollection-run-tests.py'),mode],check=True)
print('Full-collection selected modules passed; no new performance timing launched.',flush=True)

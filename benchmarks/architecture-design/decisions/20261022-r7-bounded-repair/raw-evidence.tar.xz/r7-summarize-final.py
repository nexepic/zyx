from pathlib import Path
import json,statistics,math,collections
r=Path(__file__).parent; root=r/'r7-final/window'
source=root/('campaign-completed.json' if (root/'campaign-completed.json').exists() else 'campaign-progress.json')
a=json.loads(source.read_text()); groups=collections.defaultdict(list)
def percentile(values,q):
 s=sorted(values);return s[max(0,math.ceil(len(s)*q)-1)]
for process in a['results']:
 for case in process.get('cases',[]):
  key=(process['scale'],process['family'],case['case'],process['engine'])
  groups[key].append({'round':process['round'],'status':case['status'],'process_status':process['status'],'samples':case.get('samples',[]),'resources':process.get('resources',{})})
summary=[]
for (scale,family,case,engine),processes in sorted(groups.items()):
 valid=[p for p in processes if p['status']=='passed' and p['process_status']=='completed' and p['samples']]
 samples=[s for p in valid for s in p['samples']]
 summary.append({'scale':scale,'family':family,'case':case,'engine':engine,'status':'passed' if len(valid)==3 else 'incomplete_or_NA', 'processes':len(valid),'sample_count':len(samples),'process_medians':[statistics.median(p['samples']) for p in valid],'process_p95':[percentile(p['samples'],.95) for p in valid], 'pooled_median':statistics.median(samples) if samples else None,'pooled_p95':percentile(samples,.95) if samples else None,'rss':[p['resources'].get('peak_rss_bytes') for p in processes], 'process_statuses':[p['process_status'] for p in processes],'case_statuses':[p['status'] for p in processes]})
lookup={(v['scale'],v['family'],v['case'],v['engine']):v for v in summary}
def compare(before,after):
 if not before or not after or before['processes']!=3 or after['processes']!=3:return {'status':'incomplete_or_NA'}
 b=before['process_medians'];c=after['process_medians'];bp=before['process_p95'];cp=after['process_p95']
 primary=max(c)<=.9*min(b)
 stable=min(c)>1.05*max(b) or min(cp)>1.05*max(bp)
 protected=max(c)<=1.05*min(b) and max(cp)<=1.05*min(bp)
 return {'status':'stable_regression' if stable else 'protected' if protected else 'uncertain','primary_repeatable_10pct':primary,'median_ratio_after_over_before':after['pooled_median']/before['pooled_median'],'p95_ratio_after_over_before':after['pooled_p95']/before['pooled_p95']}
comparisons=[]
for x in summary:
 if x['engine']=='after-row':
  base=lookup.get((x['scale'],x['family'],x['case'],'before'));kuzu=lookup.get((x['scale'],x['family'],x['case'],'kuzu'))
  v={k:x[k] for k in ['scale','family','case']};v.update(compare(base,x));v['kuzu_median_ratio_after_over_kuzu']=x['pooled_median']/kuzu['pooled_median'] if x['processes']==3 and kuzu and kuzu['processes']==3 else None;comparisons.append(v)
layout=[]
for x in summary:
 if x['scale']=='native':
  v={'case':x['case']};v.update(compare(lookup.get(('row',x['family'],x['case'],x['engine'])),x));layout.append(v)
result={'final_window_complete':(root/'campaign-completed.json').exists(),'source':str(source),'source_process_count':len(a['results']),'statistics':'nearest-rank P95; process ranges and pooled distributions retained; three-process gates only; API/schema differences remain in registration','summary':summary,'before_after':comparisons,'layout':layout}
(root/'analysis-current.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'processes':len(a['results']),'complete':result['final_window_complete'],'fully_measured_cases':sum(x['processes']==3 for x in summary),'before_after_gate_counts':dict(collections.Counter(x['status'] for x in comparisons)),'layout':layout},indent=2))

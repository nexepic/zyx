from pathlib import Path
import json,subprocess
r=Path('/workspace/zyx/benchmarks/architecture-design/results/20261020-work-resume');a=json.loads((r/'r7-row-result-contract-build.json').read_text());c=a['compile'];l=a['link'];old=c[c.index('-o')+1];new=str(r/'r7-readonly-footprint.o')
c=[new if v==old else v for v in c];c[c.index('-c')+1]=str(r/'r7-readonly-footprint.cpp');l=[new if v==old else v for v in l];l[l.index('-o')+1]=str(r/'r7-readonly-footprint')
with (r/'r7-readonly-footprint-build.log').open('w') as out:
 subprocess.run(c,cwd='/workspace/zyx-build-r7-row',check=True,stdout=out,stderr=subprocess.STDOUT)
 subprocess.run(l,cwd='/workspace/zyx-build-r7-row',check=True,stdout=out,stderr=subprocess.STDOUT)
with (r/'r7-medium-failed-import-footprint.json').open('w') as out,(r/'r7-medium-failed-import-footprint.stderr').open('w') as err:
 p=subprocess.run([str(r/'r7-readonly-footprint'),str(r/'r7-inputs/medium-bounded.zyx')],stdout=out,stderr=err,timeout=1800)
print(p.returncode)

from pathlib import Path
import subprocess,json,time,hashlib
r=Path(__file__).parent;out=r/'r7-repair';expected='RelocatableStorageBackendTest.UnmodifiedOverlayForwardsCellsAndChangedOverlayFallsBack'
def sha(path):return hashlib.file_digest(Path(path).open('rb'),'sha256').hexdigest()
while True:
 receipt=json.loads((r/'r7-repair-selected-candidate-latest.json').read_text())
 if receipt.get('returncode') is not None:break
 time.sleep(2)
full=json.loads(Path(receipt['test_results']).read_text());failed=[]
for suite in full['testsuites']:
 for test in suite['testsuite']:
  if test.get('failures'):failed.append(suite['name']+'.'+test['name'])
assert failed==[expected],failed
for path,digest in receipt['source_files'].items():
 if path.startswith(('include/','src/')):assert sha(Path('/workspace/zyx')/path)==digest
library=Path('/workspace/zyx-build-work-candidate/libzyx_core.a');engine_sha=sha(library)
(out/'candidate-full-run-final-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('full candidate run:',full['tests'],'tests; one missing-cell oracle failure; preserve all other passes',flush=True)
subprocess.run(['python3',str(r/'r7-repair-run-module-tests.py'),'candidate','--gtest_filter='+expected],check=True)
corrected=json.loads((r/'r7-repair-selected-candidate-latest.json').read_text());small=json.loads(Path(corrected['test_results']).read_text())
assert small['tests']==1 and small['failures']==0 and corrected['returncode']==0
assert sha(library)==engine_sha==corrected['engine_archive_sha256'],'production engine changed during test-only correction'
merged={}
for result in [full,small]:
 for suite in result['testsuites']:
  for test in suite['testsuite']:
   if test.get('status')=='RUN':merged[suite['name']+'.'+test['name']]=test
assert len(merged)==full['tests']-full.get('disabled',0) and not any(test.get('failures') for test in merged.values())
evidence={'unique_tests':len(merged),'failures':0,'disabled':full.get('disabled',0),'engine_archive_sha256':engine_sha,'full_run':receipt['test_results'],'corrected_case':corrected['test_results'],'explanation':'Only the missing-cell representation oracle changed. Omitted and disengaged optional both mean missing; stored NULL remains engaged. Unchanged production library; prior passes retained, not rerun.'}
(out/'candidate-merged-module-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
corrected['completed_module_evidence']=evidence
(r/'r7-repair-selected-candidate-latest.json').write_text(json.dumps(corrected,indent=2)+'\n')
print('candidate unique cases verified',len(merged),flush=True)
subprocess.run(['python3',str(r/'r7-repair-run-module-tests.py'),'default'],check=True)
subprocess.run(['python3',str(r/'r7-repair-build-release.py')],check=True)

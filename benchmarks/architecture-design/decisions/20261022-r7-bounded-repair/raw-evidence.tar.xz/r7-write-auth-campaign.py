from pathlib import Path
import subprocess,resource,os,time,signal,json,sys,math,hashlib
from datetime import datetime,timezone
from r7_repair_oracle import *
r=ROOT;root=r/'r7-write-auth/window';state=root/'state.json'
registration=json.loads((root/'registration.json').read_text());orders=registration['warm']['round_orders']
if state.exists():start_epoch=json.loads(state.read_text())['start_epoch']
else:
 start_epoch=time.time();state.write_text(json.dumps({'start_epoch':start_epoch,'started_at':datetime.now(timezone.utc).isoformat(),'timing_started':True},indent=2)+'\n')
deadline=start_epoch+registration['window_budget_seconds'];all_results=[]
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
def process(command,stem):
 if time.time()>=deadline:return {'exit':None,'timeout':True,'window_exhausted':True}
 with Path(str(stem)+'.jsonl').open('w') as out,Path(str(stem)+'.stderr').open('w') as err:
  p=subprocess.Popen(command,stdout=out,stderr=err,start_new_session=True,preexec_fn=limits)
  expires=min(deadline,time.time()+registration['family_process_timeout_seconds']);timed=False
  while True:
   pid,status,usage=os.wait4(p.pid,os.WNOHANG)
   if pid:break
   if time.time()>expires:timed=True;os.killpg(p.pid,signal.SIGKILL);pid,status,usage=os.wait4(p.pid,0);break
   time.sleep(.2)
  p.returncode=os.waitstatus_to_exitcode(status)
 return {'exit':p.returncode,'timeout':timed,'peak_rss_bytes':usage.ru_maxrss*1024,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime,'os_read_bytes':usage.ru_inblock*512,'os_write_bytes':usage.ru_oublock*512}
def run(engine,scale,family,cases,source,number,mode='read',kind='public'):
 stem=root/f'round-{number}'/scale/family/engine;stem.parent.mkdir(parents=True,exist_ok=True);marker=Path(str(stem)+'-outcome.json')
 if marker.exists():all_results.append(json.loads(marker.read_text()));return
 if kind=='import' and engine in ['before','kuzu']:
  original=r/'r7-final/window'/f'round-{number}'/scale/family/(engine+'-outcome.json')
  if original.exists():
   previous=json.loads(original.read_text())
   # Keep every completed, failed, or window-limited baseline attempt. No
   # repeated old-engine import is used to turn a failure into a passing sample.
   previous['reused_from']=str(original)
   marker.write_text(json.dumps(previous,indent=2)+'\n');all_results.append(previous);return
 if engine=='before' and scale=='medium' and family=='write-steady_property':
  outcome={'engine':engine,'scale':scale,'family':family,'round':number,'status':'unmeasurable_preflight_resource','cases':[{'case':'steady_property','status':'unmeasurable_resource','samples':[]}],'source':'preflight/before-medium-write-steady_property.stderr'};marker.write_text(json.dumps(outcome,indent=2)+'\n');all_results.append(outcome);return
 previous=[x for x in all_results if x['engine']==engine and x['scale']==scale and x['family']==family and x.get('status') in ['failed','timeout','window_exhausted']]
 if previous:
  outcome={'engine':engine,'scale':scale,'family':family,'round':number,'status':'unmeasurable_previous_failure','cases':[],'source_round':previous[0]['round']};marker.write_text(json.dumps(outcome,indent=2)+'\n');all_results.append(outcome);return
 target=Path(str(stem)+('.kuzu' if engine=='kuzu' else '.zyx'));require(not target.exists(),'fresh campaign target')
 warm=0 if mode=='read-opened' else 3;iterations=10
 if kind=='maintenance':command=[str(r/f'r7-repair-maintenance-{engine}'),str(target),'1','scattered','65','8192','reclaim']
 elif kind=='import':
  counts=data(scale)['counts'];expected=sum(counts.values())
  command=[sys.executable,str(r/'r7-final-kuzu-import.py'),str(r/f'r7-inputs/{scale}'),str(target),scale] if engine=='kuzu' else [str(r/f'{"r7-final" if engine=="before" else "r7-repair"}-import-{engine}'),str(r/f'r7-inputs/{scale}'),str(target),str(expected)]
 elif engine=='kuzu':command=[sys.executable,str(r/('r7-final-kuzu-worker.py' if kind=='original-public' else 'r7-repair-kuzu-worker.py')),mode,str(source),str(target),','.join(cases),str(warm),str(iterations)]
 else:command=[str(r/f'{"r7-write-auth" if engine in ["after-row","after-hybrid"] else "r7-repair"}-public-probe-{engine}'),mode,str(source),str(target),','.join(cases),str(warm),str(iterations)]
 print(json.dumps({'event':'start','engine':engine,'scale':scale,'family':family,'round':number}),flush=True)
 measured=process(command,stem);events=[];parse_errors=[]
 path=Path(str(stem)+'.jsonl')
 if path.exists():
  for line in path.read_text().splitlines():
   if line.startswith('{'):
    try:events.append(json.loads(line))
    except Exception as e:parse_errors.append(str(e))
 outcomes=[]
 if kind=='maintenance':
  samples=[e['milliseconds'] for e in events if e.get('event')=='sample'];valid=measured['exit']==0 and len(samples)==10 and all(e.get('checked')==65 for e in events if e.get('event')=='sample')
  outcomes=[{'case':'reclaim_scattered','status':'passed' if valid else 'failed','samples':samples}]
 elif kind=='import':
  samples=[e for e in events if e.get('event')=='sample'];valid=measured['exit']==0 and len(samples)==1
  if valid:
   e=samples[0];d=data(scale)['counts'];valid=e['loaded_rows']==sum(d.values()) and e['nodes']==d['users']+d['posts']+d['tags'] and e['edges']==d['follows']+d['authored']+d['has_tag']
  outcomes=[{'case':'fresh_import','status':'passed' if valid else 'failed','samples':[e['latency_ms'] for e in samples],'details':samples}]
 else:
  for case in cases:
   found=[e for e in events if e.get('case')==case];failures=[]
   if found and found[0].get('status')=='unsupported_NA':outcomes.append({'case':case,'status':'unsupported_NA','samples':[]});continue
   observations=[e for e in found if 'latency_ms' in e and 'rows' in e]
   try:
    require(measured['exit']==0 and not measured['timeout'],'process failed or timed out')
    require(not any(e.get('status')=='failed' for e in found),'engine case failure')
    require(len(observations)==(37 if case=='steady_property' else 10),'expected complete samples')
    for e in observations:
     require(math.isfinite(e['latency_ms']) and e['latency_ms']>=0,'finite latency')
     check_event(case,e,scale,mode=='write')
   except Exception as error:failures.append(str(error))
   outcomes.append({'case':case,'status':'failed' if failures else 'passed','errors':failures,'samples':[e['latency_ms'] for e in observations]})
 status='window_exhausted' if measured.get('window_exhausted') else 'timeout' if measured['timeout'] else 'failed' if parse_errors or any(e['status']=='failed' for e in outcomes) else 'completed'
 outcome={'engine':engine,'scale':scale,'family':family,'round':number,'mode':mode,'status':status,'command':command,'resources':measured,'cases':outcomes,'parse_errors':parse_errors,'raw_stdout':str(path),'raw_stderr':str(stem)+'.stderr'}
 marker.write_text(json.dumps(outcome,indent=2)+'\n');all_results.append(outcome)
 (root/'campaign-progress.json').write_text(json.dumps({'elapsed_seconds':time.time()-start_epoch,'results':all_results},indent=2)+'\n')
 print(json.dumps({'event':'finish','engine':engine,'scale':scale,'family':family,'round':number,'status':status}),flush=True)
 # Only validated, privately created successful import outputs are regenerable.
 if kind=='import' and status=='completed':
  for p in target.parent.glob(target.name+'*'):
   if p.is_file():p.unlink()
for number in range(1,6):
 for layout in (['row','native'] if number%2 else ['native','row']):
  run('after-hybrid',layout,'cohort-read',COHORT,r/f'r7-inputs/r7-cohort-{layout}.zyx',number)
  for case in CWRITES:run('after-hybrid',layout,'write-'+case,[case],r/f'r7-inputs/r7-cohort-{layout}.zyx',number,'write')
(root/'campaign-completed.json').write_text(json.dumps({'elapsed_seconds':time.time()-start_epoch,'results':all_results,'all_families_attempted':True,'all_passed':all(v['status']=='completed' for v in all_results)},indent=2)+'\n')

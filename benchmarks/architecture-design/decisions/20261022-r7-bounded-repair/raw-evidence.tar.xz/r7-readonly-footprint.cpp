#include <fstream>
#include <iostream>
#include <map>
#include "graph/storage/StorageIO.hpp"
#include "graph/storage/relocatable/metadata/RelocatableMetadataStore.hpp"
#include "graph/storage/relocatable/allocation/SlottedPagePool.hpp"
#include "graph/storage/relocatable/index/BTreePageStore.hpp"
#include "graph/storage/relocatable/schema/SystemCatalog.hpp"
#include "graph/storage/relocatable/maintenance/NativeStorageAllocationCensus.hpp"
#include "graph/query/execution/MaterializedByteBudget.hpp"
int main(int argc,char **argv) {
    using namespace graph::storage;
    try {
        if(argc!=2) return 2;
        auto file=std::make_shared<std::fstream>(argv[1],std::ios::in|std::ios::binary);
        if(!file->is_open()) return 3;
        auto io=std::make_shared<StorageIO>(file,INVALID_FILE_HANDLE,INVALID_FILE_HANDLE);
        auto metadata=RelocatableMetadataStore::openReadOnly(io);
        auto pin=metadata->openSnapshot();
        SlottedPagePool slots(io,*metadata,SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        BTreePageStore trees(slots,*metadata);SystemCatalog catalog(trees,*metadata);
        const auto graph=catalog.readGraphCardinalityStatistics(pin);
        std::map<std::pair<int,int>,uint64_t> categories;
        uint64_t retirements=0;
        SharedPagePoolAllocator pools(io,*metadata,SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        std::map<uint64_t,std::pair<uint64_t,uint64_t>> index_owners;
        metadata->visitCatalogEntries(pin,[&](const auto &entry){++categories[{int(entry.kind),int(entry.state)}];
            if(entry.kind==SegmentKind::SGK_INDEX_PAGE_POOL) {
                auto &cost=index_owners[entry.owner_id];++cost.first;cost.second+=pools.availableFrameCount(entry);
            }});
        metadata->visitRetireQueueEntries(pin,[&](const auto &){++retirements;});
        std::cout<<"{\"generation\":"<<pin.superblock().generation.value()<<",\"nodes\":"<<(graph?graph->node_count:0)
            <<",\"edges\":"<<(graph?graph->edge_count:0)<<",\"retirement_records\":"<<retirements<<",\"categories\":[";
        bool first=true;for(const auto &[key,count]:categories){if(!first)std::cout<<',';first=false;
            std::cout<<"{\"kind\":"<<key.first<<",\"state\":"<<key.second<<",\"pools\":"<<count<<'}';}
        std::cout<<"],\"index_owners\":[";first=true;
        for(const auto &[owner,cost]:index_owners){if(!first)std::cout<<',';first=false;
            std::cout<<"{\"owner\":"<<owner<<",\"pools\":"<<cost.first<<",\"free_frames\":"<<cost.second<<'}';}
        std::cout<<"]}"<<std::endl;
        return 0;
    }catch(const std::exception &e){std::cerr<<e.what()<<std::endl;return 1;}
}

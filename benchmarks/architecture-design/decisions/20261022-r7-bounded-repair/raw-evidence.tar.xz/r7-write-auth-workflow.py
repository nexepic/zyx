from pathlib import Path
import subprocess
r=Path(__file__).parent
for mode in ['candidate','default']:
 print('Affected modules',mode,flush=True)
 subprocess.run(['python3',str(r/'r7-write-auth-run-tests.py'),mode],check=True)
subprocess.run(['python3',str(r/'r7-write-auth-build-release.py')],check=True)
subprocess.run(['python3',str(r/'r7-write-auth-preflight.py')],check=True)
print('Write-auth modules,Release,untimed preflight complete; no timing started.',flush=True)

from pathlib import Path
import json,time,subprocess,os
r=Path(__file__).parent
marker=r/'r7-final/window/campaign-completed.json'
while True:
 try:
  a=json.loads(marker.read_text())
  if a.get('all_families_attempted'):break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(5)
for mode in ['candidate','default']:
 print('start selected repair verification',mode,flush=True)
 p=subprocess.run(['python3',str(r/'r7-repair-run-module-tests.py'),mode])
 if p.returncode:raise SystemExit(p.returncode)
 print('finish selected repair verification',mode,flush=True)
print('start verified Release repair builds',flush=True)
p=subprocess.run(['python3',str(r/'r7-repair-build-release.py')])
raise SystemExit(p.returncode)

from pathlib import Path
import subprocess,json,hashlib
r=Path('/workspace/zyx/benchmarks/architecture-design/results/20261020-work-resume');freeze=json.loads((r/'r7-final/freeze.json').read_text())
template=json.loads((r/'r7-final-row-result-contract-build.json').read_text());report={}
for name,build,cohort in [('before','/workspace/zyx/buildDir_perf_control',False),('after-row','/workspace/zyx-build-r7-row',False),('after-hybrid','/workspace/zyx-build-r7-hybrid',True)]:
 lib=freeze['frozen_engine_libraries'][name];assert hashlib.file_digest(Path(lib['path']).open('rb'),'sha256').hexdigest()==lib['sha256']
 binary=r/f'r7-final-public-probe-{name}';obj=r/f'r7-final-public-probe-{name}.o'
 compile=[]
 for x in template['compile']:
  x=x.replace('r7-final-row-result-contract.o',obj.name).replace('r43-identity-native-result-contract.cpp','r7-final-public-probe.cpp').replace('r7-final-row-result-contract.d',f'r7-final-public-probe-{name}.d')
  x=x.replace('/workspace/zyx-build-r7-row',build)
  if name=='before' and x.startswith('-I'):
   root=x[2:]
   if root=='/workspace/zyx' or root=='/workspace/zyx/include' or root.startswith('/workspace/zyx/src'):
    x='-I'+root.replace('/workspace/zyx','/workspace/zyx-r7-before-source',1)
  if cohort:x=x.replace('ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT=0','ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT=1')
  compile.append(x)
 compile.insert(1,'-DR7_COHORT='+str(int(cohort)))
 link=[x.replace('r7-final-row-result-contract.o',obj.name).replace('r7-final-row-result-contract',binary.name) for x in template['link']]
 with (r/f'r7-final-public-probe-{name}-build.log').open('w') as log:
  subprocess.run(compile,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
 report[name]={'compile':compile,'link':link,'cwd':build,'binary':str(binary),'sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'engine_archive_sha256':lib['sha256'],'engine_rebuilt':False,'source_engine_revision':'9cc2821c' if name=='before' else 'b6a6e87e'}
 (r/'r7-final-public-probes-build.json').write_text(json.dumps(report,indent=2)+'\n');print(name,'built',flush=True)

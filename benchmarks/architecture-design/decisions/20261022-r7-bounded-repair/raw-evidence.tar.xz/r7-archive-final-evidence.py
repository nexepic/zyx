from pathlib import Path
import json,hashlib,tarfile
r=Path(__file__).parent;repo=Path('/workspace/zyx');out=repo/'benchmarks/architecture-design/decisions/20261022-r7-bounded-repair';out.mkdir(exist_ok=True)
assert (r/'r7-repair/window/campaign-completed.json').exists()
assert (r/'r7-membership/window/campaign-completed.json').exists()
allow={'.json','.jsonl','.stderr','.log','.patch','.tar','.py','.cpp','.work','.txt','.csv'}
paths=set()
for folder in ['r7-final','r7-repair','r7-fullcollection','r7-write-auth','r7-membership','r7-r3-write-work']:
 for p in (r/folder).rglob('*'):
  if p.is_file() and p.suffix in allow and p.name != 'r7-archive-final-evidence.log' and 'admission-draft-not-accepted' not in p.parts:paths.add(p)
for p in r.glob('r7*'):
 if p.is_file() and p.suffix in allow and p.name != 'r7-archive-final-evidence.log' and 'admission-draft-not-accepted' not in p.parts:paths.add(p)
for scale in ['medium','holdout']:paths.add(r/f'r7-inputs/{scale}/manifest.json')
manifest=[]
for p in sorted(paths):
 manifest.append({'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()})
(out/'raw-manifest.json').write_text(json.dumps({'root':'results/20261020-work-resume','files':manifest,'excluded':'Engine/database/object/test binaries and derived private DB copies. Original and repaired raw outcomes, source snapshots, failed compile/test/oracle evidence retained. Original input DB identity is recorded in each freeze/preflight. No failed outcome is deleted from the report.'},indent=2)+'\n')
with tarfile.open(out/'raw-evidence.tar.xz','w:xz',preset=3) as archive:
 for p in sorted(paths):archive.add(p,arcname=str(p.relative_to(r)))
p=out/'raw-evidence.tar.xz'
(out/'archive.json').write_text(json.dumps({'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),'files':len(manifest)},indent=2)+'\n')
print('Archived',len(manifest),'raw files,',p.stat().st_size,'bytes',flush=True)

from pathlib import Path
import json,hashlib
r=Path(__file__).parent;out=r/'r7-fullcollection';root=out/'window'
original=json.loads((root/'campaign-completed.json').read_text())
freeze=json.loads((out/'freeze.json').read_text())
def sha(p):return hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
for name,digest in freeze['harness_files'].items():assert sha(r/name)==digest
for entry in freeze['build'].values():assert sha(entry['binary']['path'])==entry['binary']['sha256']
source=(r/'r7-fullcollection-campaign.py').read_text();prefix=source[:source.index('for number in range(1,4):')]
ns={'__file__':str(r/'r7-fullcollection-campaign.py'),'__name__':'registered_capped_layout_controls'}
exec(compile(prefix,str(r/'r7-fullcollection-campaign.py'),'exec'),ns)
ns['all_results'].extend(original['results'])
for number,layouts in [(4,['row','native']),(5,['native','row'])]:
 for layout in layouts:
  ns['run']('after-hybrid',layout,'cohort-read',ns['COHORT'],r/f'r7-inputs/r7-cohort-{layout}.zyx',number)
  for case in ns['CWRITES']:ns['run']('after-hybrid',layout,'write-'+case,[case],r/f'r7-inputs/r7-cohort-{layout}.zyx',number,'write')
results=ns['all_results']
(root/'campaign-capped-controls-completed.json').write_text(json.dumps({'results':results,'all_passed':all(x['status']=='completed' for x in results),'addendum':'../layout-capped-controls-addendum.json'},indent=2)+'\n')

from pathlib import Path
import subprocess,json,resource,sys,time,hashlib
from r7_repair_oracle import *
r=ROOT;out=r/'r7-write-auth'/f'preflight-attempt-{time.time_ns()}';out.mkdir(parents=True);results=[]
freeze=json.loads((r/'r7-write-auth/freeze.json').read_text())
for entry in freeze['build'].values():
 artifact=entry['binary'];require(hashlib.file_digest(Path(artifact['path']).open('rb'),'sha256').hexdigest()==artifact['sha256'],'frozen observation binary')
inputs={}
def input_file(path,expected=None):
 digest=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
 if expected:require(digest==expected,'original input identity: '+str(path))
 st=path.stat();inputs[str(path)]={'sha256':digest,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns}
previous=json.loads((r/'r7-repair/preflight-latest.json').read_text())['input_identities']
for layout in ['row','native']:
 path=r/f'r7-inputs/r7-cohort-{layout}.zyx';input_file(path,previous[str(path)]['sha256'])
(out/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print('fixed ROW/native cohort inputs verified before affected-slice timing',flush=True)
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
def run(engine,scale,family,cases,source,mode):
 stem=out/f'{engine}-{scale}-{family}';target=Path(str(stem)+('.kuzu' if engine=='kuzu' else '.zyx'))
 command=[sys.executable,str(r/'r7-repair-kuzu-worker.py'),mode,str(source),str(target),','.join(cases),'0','1'] if engine=='kuzu' else [str(r/f'r7-write-auth-public-probe-{engine}'),mode,str(source),str(target),','.join(cases),'0','1']
 try:
  with Path(str(stem)+'.jsonl').open('w') as stdout,Path(str(stem)+'.stderr').open('w') as stderr:p=subprocess.run(command,stdout=stdout,stderr=stderr,preexec_fn=limits,timeout=900)
  events=[json.loads(line) for line in Path(str(stem)+'.jsonl').read_text().splitlines() if line.startswith('{')]
  require(p.returncode==0,'process success')
  require(not any('latency_ms' in event for event in events),'untimed preflight must not emit latency')
  for case in cases:
   found=[event for event in events if event.get('case')==case]
   require(len(found)==1 and 'rows' in found[0],'one complete supported observation per case')
   require(found[0].get('status')!='failed','no engine error')
   check_event(case,found[0],scale,mode=='check-write')
  result={'engine':engine,'scale':scale,'family':family,'cases':cases,'passed':True,'command':command}
 except Exception as error:result={'engine':engine,'scale':scale,'family':family,'cases':cases,'passed':False,'error':str(error),'command':command}
 results.append(result);(out/'summary.json').write_text(json.dumps({'timing_benchmark':False,'results':results},indent=2)+'\n');print(engine,scale,family,result['passed'],flush=True)
for layout in ['row','native']:
 run('after-hybrid',layout,'cohort-read',COHORT,r/f'r7-inputs/r7-cohort-{layout}.zyx','check-read')
 for case in CWRITES:run('after-hybrid',layout,'write-'+case,[case],r/f'r7-inputs/r7-cohort-{layout}.zyx','check-write')
summary={'timing_benchmark':False,'all_passed':all(x['passed'] for x in results),'results':results,'path':str(out/'summary.json'),'input_identities':inputs,'freeze_sha256':hashlib.file_digest((r/'r7-write-auth/freeze.json').open('rb'),'sha256').hexdigest()}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(r/'r7-write-auth/preflight-latest.json').write_text(json.dumps(summary,indent=2)+'\n')
raise SystemExit(0 if summary['all_passed'] else 1)

from r7_final_oracle import *
from r7_final_oracle import check as base_check,check_event as base_event
def check(name,rows,scale='medium',iteration=0):
 if name=='plan_join_count':
  expected=[[cell(len(data(scale)['first']))]]
  require(canonical(rows)==canonical(expected),'fixed R5 JOIN complete typed count')
  return
 return base_check(name,rows,scale,iteration)
def check_event(name,event,scale='medium',require_post=False):
 if name=='plan_join_count':return check(name,event['rows'],scale,event.get('iteration',0))
 return base_event(name,event,scale,require_post)

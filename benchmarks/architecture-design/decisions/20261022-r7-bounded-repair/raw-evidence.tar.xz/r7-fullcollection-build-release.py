from pathlib import Path
import subprocess,json,hashlib,tarfile
r=Path(__file__).parent;repo=Path('/workspace/zyx');out=r/'r7-fullcollection'
def sha(p):return hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
assert (r/'r7-repair/window/campaign-completed.json').exists()
checks={mode:json.loads((r/f'r7-fullcollection-selected-{mode}-latest.json').read_text()) for mode in ['candidate','default']}
for check in checks.values():
 assert check.get('returncode')==0
 for path,digest in check['source_files'].items():
  if path.startswith(('src/','include/','tests/')):assert sha(repo/path)==digest,('source changed since module checks',path)
previous=json.loads((r/'r7-repair/build.json').read_text());report={}
for name,build in [('after-row','/workspace/zyx-build-r7-row'),('after-hybrid','/workspace/zyx-build-r7-hybrid')]:
 print('Release build',name,flush=True)
 with (out/f'{name}-build.log').open('w') as log:subprocess.run(['cmake','--build',build,'--target','zyx_core','-j3'],stdout=log,stderr=subprocess.STDOUT,check=True)
 library=Path(build)/'libzyx_core.a'
 template=previous[name]['observers']['public-probe']
 old='r7-repair-public-probe-'+name;new='r7-fullcollection-public-probe-'+name
 compile=[x.replace(old,new) for x in template['compile']];link=[x.replace(old,new) for x in template['link']]
 with (out/f'{name}-observer-build.log').open('w') as log:
  subprocess.run(compile,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
  subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
 report[name]={'library':{'path':str(library),'sha256':sha(library)},'binary':{'path':str(r/new),'sha256':sha(r/new)},'compile':compile,'link':link,'cwd':build,'unchanged_from_repair_library':sha(library)==previous[name]['library']['sha256'],'unchanged_from_repair_binary':sha(r/new)==template['sha256']}
 (out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
# Reusing the completed ROW matrix requires exact identities, not a source assumption.
assert report['after-row']['unchanged_from_repair_library'],'ROW archive changed: full repair results cannot be labeled final for this candidate'
assert report['after-row']['unchanged_from_repair_binary'],'ROW observer changed: investigate before reusing timing'
paths=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=repo,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=repo,text=True).splitlines()
files={p:sha(repo/p) for p in paths if (repo/p).is_file()}
with (out/'source-delta.patch').open('w') as f:subprocess.run(['git','diff','--binary','HEAD'],cwd=repo,stdout=f,check=True)
with tarfile.open(out/'source-files.tar','w') as archive:
 for path in files:archive.add(repo/path,arcname=path)
freeze={'parent':'r7-repair/freeze.json','source_files':files,'patch_sha256':sha(out/'source-delta.patch'),'source_archive_sha256':sha(out/'source-files.tar'),'build':report,'module_checks':checks,'harness_files':{n:sha(r/n) for n in ['r7-repair-public-probe.cpp','r7_repair_oracle.py','r7_final_oracle.py','r7-fullcollection-campaign.py','r7-fullcollection-preflight.py','r7-fullcollection-lock-and-run.py']},'timing_started':False}
(out/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print('Release full-collection candidate frozen; ROW identities exactly unchanged. No timing started.',flush=True)

from r7_final_oracle import *
import resource,subprocess,sys
r=ROOT;out=r/'r7-final/kuzu-preflight';out.mkdir(parents=True,exist_ok=True)
def caps():
 resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
report={'timing_benchmark':False,'cases':[]}
for scale in ['medium','holdout']:
 for family,cases,writing in [('scan',SCAN,False),('indexed',INDEXED,False),('retrieval',RETRIEVAL,False)]+[(x,[x],True) for x in WRITES]:
  stem=out/f'{scale}-{family}';target=Path(str(stem)+'.kuzu')
  with Path(str(stem)+'.jsonl').open('w') as stdout,Path(str(stem)+'.stderr').open('w') as stderr:
   p=subprocess.run([sys.executable,str(r/'r7-final-kuzu-worker.py'),'check-write' if writing else 'check-read',str(r/f'r7-inputs/{scale}-r7-final.kuzu'),str(target),','.join(cases),'0','1'],stdout=stdout,stderr=stderr,preexec_fn=caps,timeout=900)
  events=[json.loads(line) for line in Path(str(stem)+'.jsonl').read_text().splitlines() if line.startswith('{')]
  for name in cases:
   found=[e for e in events if e.get('case')==name];status='passed';errors=[]
   if found and found[0].get('status')=='unsupported_NA':status='unsupported_NA'
   else:
    try:
     require(p.returncode==0,'worker exit '+str(p.returncode));require(found and all('rows' in e for e in found),'missing complete rows/engine error')
     for event in found:check_event(name,event,scale,writing)
    except Exception as error:status='failed';errors.append(str(error))
   report['cases'].append({'scale':scale,'case':name,'status':status,'errors':errors,'returncode':p.returncode})
  (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(scale,family,[x['status'] for x in report['cases'][-len(cases):]],flush=True)

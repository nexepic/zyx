from pathlib import Path
import subprocess,json,hashlib,sys,os
from datetime import datetime,timezone
r=Path(__file__).parent;out=r/'r7-repair';root=out/'window';root.mkdir(exist_ok=True)
def sha(p):return hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
freeze=json.loads((out/'freeze.json').read_text());preflight=json.loads((out/'preflight-latest.json').read_text())
assert preflight['all_passed'] and preflight['freeze_sha256']==sha(out/'freeze.json')
for path,digest in freeze['source_files'].items():
 if path.startswith(('src/','include/','tests/')):assert sha(Path('/workspace/zyx')/path)==digest,('compiled source changed',path)
for name,digest in freeze['harness_files'].items():assert sha(r/name)==digest,('observation source changed',name)
for engine,entry in freeze['build'].items():
 for observer in entry['observers'].values():assert sha(observer['binary'])==observer['sha256']
for path,identity in preflight['input_identities'].items():
 st=Path(path).stat();assert st.st_size==identity['bytes'] and st.st_mtime_ns==identity['mtime_ns'],('input changed',path)
original=json.loads((r/'r7-final-public-probes-build.json').read_text())
for engine in ['before','after-row','after-hybrid']:assert sha(original[engine]['binary'])==original[engine]['sha256']
imports=json.loads((r/'r7-final-import-build.json').read_text());assert sha(imports['before']['binary'])==imports['before']['sha256']
plan=json.loads((out/'registration-plan.json').read_text());registration=dict(plan,locked_at=datetime.now(timezone.utc).isoformat(),engine_freeze=freeze,preflight=preflight,freeze_sha256=sha(out/'freeze.json'),original_observers=original)
registration['harness_files']={name:sha(r/name) for name in ['r7-repair-campaign.py','r7-repair-public-probe.cpp','r7-repair-maintenance.cpp','r7-repair-kuzu-worker.py','r7_repair_oracle.py','r7_final_oracle.py','r7-final-kuzu-import.py','r7-final-import.cpp']}
if (root/'state.json').exists():
 old=json.loads((root/'registration.json').read_text());assert old['freeze_sha256']==registration['freeze_sha256'] and old['harness_files']==registration['harness_files'],'cannot mix identities in a running campaign'
else:(root/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
with (out/'campaign.log').open('a') as log:p=subprocess.run([sys.executable,str(r/'r7-repair-campaign.py')],stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(p.returncode)

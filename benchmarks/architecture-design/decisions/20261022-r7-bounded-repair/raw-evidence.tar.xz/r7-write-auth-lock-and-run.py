from pathlib import Path
import subprocess,json,hashlib,sys
from datetime import datetime,timezone
r=Path(__file__).parent;out=r/'r7-write-auth';root=out/'window';root.mkdir(exist_ok=True)
def sha(p):return hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
freeze=json.loads((out/'freeze.json').read_text());preflight=json.loads((out/'preflight-latest.json').read_text())
assert preflight['all_passed'] and preflight['freeze_sha256']==sha(out/'freeze.json')
for path,digest in freeze['source_files'].items():
 if path.startswith(('src/','include/','tests/')):assert sha(Path('/workspace/zyx')/path)==digest,('compiled source changed',path)
for name,digest in freeze['harness_files'].items():assert sha(r/name)==digest,('observation source changed',name)
for entry in freeze['build'].values():assert sha(entry['binary']['path'])==entry['binary']['sha256']
for path,identity in preflight['input_identities'].items():
 st=Path(path).stat();assert st.st_size==identity['bytes'] and st.st_mtime_ns==identity['mtime_ns'],('input changed',path)
old=json.loads((r/'r7-repair/freeze.json').read_text())
for name,digest in old['harness_files'].items():assert sha(r/name)==digest,('original observation source changed',name)
for engine in ['before','after-row']:
 for observer in old['build'][engine]['observers'].values():assert sha(observer['binary'])==observer['sha256']
original_inputs=json.loads((r/'r7-repair/preflight-latest.json').read_text())['input_identities']
for path,identity in original_inputs.items():
 st=Path(path).stat();assert st.st_size==identity['bytes'] and st.st_mtime_ns==identity['mtime_ns'],('control input changed',path)
plan=json.loads((out/'registration-plan.json').read_text());registration=dict(plan,locked_at=datetime.now(timezone.utc).isoformat(),engine_freeze=freeze,preflight=preflight,freeze_sha256=sha(out/'freeze.json'))
if (root/'state.json').exists():
 old=json.loads((root/'registration.json').read_text());assert old['freeze_sha256']==registration['freeze_sha256'],'cannot mix candidate identities'
else:(root/'registration.json').write_text(json.dumps(registration,indent=2)+'\n')
with (out/'campaign.log').open('a') as log:p=subprocess.run([sys.executable,str(r/'r7-write-auth-campaign.py')],stdout=log,stderr=subprocess.STDOUT)
raise SystemExit(p.returncode)

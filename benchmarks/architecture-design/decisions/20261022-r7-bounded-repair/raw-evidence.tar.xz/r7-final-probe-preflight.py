from pathlib import Path
import json,subprocess,resource,sys,hashlib
from r7_final_oracle import *
r=ROOT;out=r/'r7-final/preflight';out.mkdir(parents=True,exist_ok=True)
def caps():
 resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
report={'timing_benchmark':False,'cases':[]}
def run(engine,source,scale,family,cases,write=False):
 binary=r/f'r7-final-public-probe-{engine}';stem=out/f'{engine}-{scale}-{family}';target=Path(str(stem)+'.zyx');require(not target.exists(),'fresh preflight target')
 with Path(str(stem)+'.jsonl').open('w') as stdout,Path(str(stem)+'.stderr').open('w') as stderr:
  p=subprocess.run([str(binary),'check-write' if write else 'check-read',str(source),str(target),','.join(cases),'0','1'],stdout=stdout,stderr=stderr,preexec_fn=caps,timeout=900)
 events=[json.loads(line) for line in Path(str(stem)+'.jsonl').read_text().splitlines() if line.startswith('{')]
 for case in cases:
  found=[v for v in events if v.get('case')==case];errors=[]
  try:
   require(p.returncode==0,'process exit '+str(p.returncode));require(found and all('rows' in x for x in found),'missing complete rows or engine failure')
   for event in found:check(case,event['rows'],scale,event.get('iteration',0))
  except Exception as error:errors.append(str(error))
  result={'engine':engine,'scale':scale,'family':family,'case':case,'passed':not errors,'errors':errors,'returncode':p.returncode};report['cases'].append(result)
 (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(engine,scale,family,all(x['passed'] for x in report['cases'][-len(cases):]),flush=True)
for scale in ['medium','holdout']:
 for engine in ['before','after-row']:
  for family,cases in [('scan',SCAN),('indexed',INDEXED),('retrieval',RETRIEVAL)]:
   source=r/f'r7-inputs/{scale}-r43-identity.zyx' if family=='scan' else r/f'r7-inputs/{scale}-r7-final-indexed.zyx'
   run(engine,source,scale,family,cases)
for layout in ['row','native']:run('after-hybrid',r/f'r7-inputs/r7-cohort-{layout}.zyx',layout,'cohort',COHORT)
for engine in ['before','after-row']:
 run(engine,r/'r7-inputs/r7-fixtures-large.zyx','large','large',['large_selected','large_full'])
 run(engine,r/'r7-inputs/r7-fixtures-skew.zyx','skew','skew',['skew_out','skew_both','skew_twohop'])
# Untimed one-shot mutation validation. Each source is copied privately.
for engine in ['before','after-row']:
 for case in WRITES:run(engine,r/'r7-inputs/medium-r7-final-indexed.zyx','medium','write-'+case,[case],True)
for layout in ['row','native']:
 for case in CWRITES:run('after-hybrid',r/f'r7-inputs/r7-cohort-{layout}.zyx',layout,'write-'+case,[case],True)
for engine in ['before','after-row']:run(engine,r/'r7-inputs/r7-fixtures-large.zyx','large','write-large',['large_patch'],True)
print('passed',sum(x['passed'] for x in report['cases']),'total',len(report['cases']),flush=True)

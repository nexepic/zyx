/**
 * @file PropertyHeapRequestBytes.hpp
 * @brief Bounds for standard-allocator PropertyValue copies and retained data.
 * Copyright (c) 2026 Nexepic. Licensed under the Apache License, Version 2.0.
 */
#pragma once
#include "graph/core/PropertyTypes.hpp"
#include "graph/utils/StandardContainerHeapBytes.hpp"
#include "graph/utils/StringBufferBytes.hpp"

namespace graph::property_heap {
namespace detail {
template<class T>
size_t copiedVectorBytes(size_t count) {
    if (count > (std::numeric_limits<size_t>::max)()/sizeof(T))
        throw std::overflow_error("Property vector request overflowed");
    return utils::detail::addStandardHeapBytes(utils::detail::standardContainerProxyBytes(),
        utils::detail::standardAllocatorRequestBytes(count * sizeof(T), alignof(T)));
}
template<bool Copy>
size_t valueBytes(const PropertyValue &value, size_t depth) {
    if (depth > 64U) throw std::length_error("Property heap admission exceeds maximum nesting depth");
    using namespace utils::detail;
    const auto &variant = value.getVariant();
    if (const auto *text = std::get_if<std::string>(&variant))
        return Copy ? standardFreshStringHeapUpper(text->size()) : dynamicStringBufferBytes(*text);
    if (const auto *bytes = std::get_if<PropertyValue::Bytes>(&variant))
        return Copy ? copiedVectorBytes<std::byte>(bytes->size()) : standardVectorHeapBufferBytes(*bytes);
    size_t result = 0U;
    if (const auto *list = std::get_if<std::vector<PropertyValue>>(&variant)) {
        result = Copy ? copiedVectorBytes<PropertyValue>(list->size()) : standardVectorHeapBufferBytes(*list);
        for (const auto &child : *list) result = addStandardHeapBytes(result, valueBytes<Copy>(child, depth + 1U));
    } else if (const auto *map = std::get_if<PropertyValue::MapType>(&variant)) {
        // Standard map copies preserve visible bucket storage on the audited
        // C++20 STLs; payload strings/vectors normalize their copy capacities.
        result = standardUnorderedMapStructuralHeapBytes(*map);
        for (const auto &[key, child] : *map) {
            result = addStandardHeapBytes(result, Copy ? standardFreshStringHeapUpper(key.size()) : dynamicStringBufferBytes(key));
            result = addStandardHeapBytes(result, valueBytes<Copy>(child, depth + 1U));
        }
    }
    return result;
}
} // namespace detail
inline size_t copyRequestUpper(const PropertyValue &value) { return detail::valueBytes<true>(value, 0U); }
inline size_t retainedRequestUpper(const PropertyValue &value) { return detail::valueBytes<false>(value, 0U); }
} // namespace graph::property_heap

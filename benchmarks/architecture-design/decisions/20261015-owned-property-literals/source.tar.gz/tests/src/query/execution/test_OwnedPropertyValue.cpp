#include <gtest/gtest.h>
#include "graph/core/OwnedPropertyValue.hpp"
#include "graph/query/execution/MaterializedByteBudget.hpp"
#include "graph/query/expressions/Expression.hpp"

namespace {
using namespace graph;
using namespace query::execution;

TEST(OwnedPropertyValueTest, CopiesWithinOneOwnerShareImmutableDataAndReplaceIndependently) {
    auto memory = std::make_shared<MaterializedByteBudget>(1024U * 1024U);
    const PropertyValue source(std::vector<PropertyValue>(256U, PropertyValue(std::string(512U, 's'))));
    {
        utils::OwnedAllocationScope scope(memory);
        OwnedPropertyValue value(source);
        const auto retained = memory->used();
        OwnedPropertyValue copy(value);
        EXPECT_EQ(&value.get(), &copy.get());
        EXPECT_EQ(memory->used(), retained);
        copy = PropertyValue(int64_t{42});
        EXPECT_EQ(value.get(), source);
        EXPECT_EQ(copy.get(), PropertyValue(int64_t{42}));
    }
    EXPECT_EQ(memory->used(), 0U);
}

TEST(OwnedPropertyValueTest, ScopeChangesClonePayloadBeforeReplacingItsOwner) {
    auto first = std::make_shared<MaterializedByteBudget>(65536U);
    auto second = std::make_shared<MaterializedByteBudget>(65536U);
    const PropertyValue source(std::string(8192U, 's'));
    std::optional<OwnedPropertyValue> value, copy;
    {
        utils::OwnedAllocationScope scope(first); value.emplace(source);
    }
    {
        utils::OwnedAllocationScope scope(second); copy.emplace(*value);
    }
    EXPECT_NE(&value->get(), &copy->get());
    EXPECT_GT(first->used(), 8192U); EXPECT_GT(second->used(), 8192U);
    value.reset(); EXPECT_EQ(first->used(), 0U);
    EXPECT_EQ(copy->get(), source);
    copy.reset(); EXPECT_EQ(second->used(), 0U);
}

TEST(OwnedPropertyValueTest, DeniedNestedReplacementPreservesTheOldLiteralAndCredit) {
    auto memory = std::make_shared<MaterializedByteBudget>(4096U);
    const PropertyValue large(std::vector<PropertyValue>(256U, PropertyValue(std::string(512U, 's'))));
    {
        utils::OwnedAllocationScope scope(memory);
        OwnedPropertyValue value(PropertyValue(int64_t{7}));
        const auto retained = memory->used();
        EXPECT_THROW(value = large, MaterializedByteLimitExceeded);
        EXPECT_EQ(value.get(), PropertyValue(int64_t{7}));
        EXPECT_EQ(memory->used(), retained);
    }
    EXPECT_EQ(memory->used(), 0U);
}

TEST(OwnedPropertyValueTest, EmptyMovedOwnersRemainReusableAfterTheDestinationIsDestroyed) {
    auto memory = std::make_shared<MaterializedByteBudget>(65536U);
    std::optional<OwnedPropertyValue> value;
    {
        utils::OwnedAllocationScope scope(memory); value.emplace(PropertyValue(std::string(8192U, 's')));
    }
    {
        OwnedPropertyValue moved(std::move(*value));
        EXPECT_EQ(moved.get(), PropertyValue(std::string(8192U, 's')));
        EXPECT_EQ(value->get().getType(), PropertyType::NULL_TYPE);
    }
    EXPECT_EQ(memory->used(), 0U);
    *value = PropertyValue(std::string(4096U, 'r'));
    EXPECT_GT(memory->used(), 4096U);
    value.reset(); EXPECT_EQ(memory->used(), 0U);
}

TEST(OwnedPropertyValueTest, LiteralConstructorDenialRefundsItsPartiallyAllocatedExpression) {
    auto memory = std::make_shared<MaterializedByteBudget>(4096U);
    const PropertyValue source(std::vector<PropertyValue>(1024U, PropertyValue(int64_t{1})));
    {
        utils::OwnedAllocationScope scope(memory);
        EXPECT_THROW(static_cast<void>(std::make_unique<query::expressions::LiteralExpression>(source)),
            MaterializedByteLimitExceeded);
    }
    EXPECT_EQ(memory->used(), 0U);
    EXPECT_EQ(source.getList().size(), 1024U);
}
} // namespace

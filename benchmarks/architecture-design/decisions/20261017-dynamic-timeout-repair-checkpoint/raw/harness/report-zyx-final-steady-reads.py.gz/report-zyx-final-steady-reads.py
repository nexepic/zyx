from pathlib import Path
from collections import defaultdict
import json,statistics,math,csv
root=Path('/tmp/zyx-final-five-steady-window-20261017')
def q(values,p):
 values=sorted(values);index=(len(values)-1)*p;lo=math.floor(index);hi=math.ceil(index)
 return values[lo]+(values[hi]-values[lo])*(index-lo)
processes=[];groups=defaultdict(lambda:defaultdict(list));unsupported=[]
for marker in sorted((root/'read-case-status').rglob('outcome.json')):
 case=json.loads(marker.read_text())
 if case['status']!='completed' or case['round'] not in [1,2,3]:continue
 folder=root/'reads'/case['scale']/f"round-{case['round']}"/case['engine']/case['profile']
 raw=list(folder.rglob('raw.jsonl'));assert len(raw)==1,(marker,raw)
 result=raw[0].parent;checks=json.loads((result/'correctness.json').read_text());assert not checks['scalar']['failures'] and not checks['full_results']['failures']
 values=defaultdict(list)
 for line in raw[0].open():
  v=json.loads(line)
  if v.get('event')=='sample' and v.get('status')=='ok':values[v['workload']].append(v['latency_ms'])
  if v.get('status')=='unsupported':unsupported.append({'case':case,'record':v})
 resource_path=root/'read-process-resources'/case['scale']/case['profile']/f"round-{case['round']}"/(case['engine']+'.json')
 resource=json.loads(resource_path.read_text()) if resource_path.exists() else None
 for workload,latencies in values.items():
  item={'scale':case['scale'],'profile':case['profile'],'engine':case['engine'],'round':case['round'],'workload':workload,'samples':len(latencies),'p50_ms':statistics.median(latencies),'p95_ms':q(latencies,.95),'p95_scope':'descriptive for10samples; extended samples needed where registered tail uncertainty applies','min_ms':min(latencies),'max_ms':max(latencies),'full_results_verified':True,'process_resources':resource,'source':'d09fc467 frozen control' if case['engine']=='control' else ('e8c38315 frozen candidate' if case['engine']=='current' else 'Kuzu0.11.3')}
  processes.append(item);groups[(case['scale'],workload)][case['engine']].append(item)
rows=[]
for (scale,workload),engines in sorted(groups.items()):
 row={'scale':scale,'workload':workload}
 for engine in ['control','current','kuzu']:
  p=engines.get(engine,[]);v=[x['p50_ms'] for x in p]
  row.update({engine+'_processes':len(p),engine+'_median_process_p50_ms':statistics.median(v) if v else None,engine+'_process_p50_min_ms':min(v) if v else None,engine+'_process_p50_max_ms':max(v) if v else None,engine+'_median_process_p95_ms':statistics.median(x['p95_ms'] for x in p) if p else None})
 a=row['control_median_process_p50_ms'];b=row['current_median_process_p50_ms'];k=row['kuzu_median_process_p50_ms'];row['current_p50_reduction_vs_control']=1-b/a if a and b else None;row['current_over_kuzu_p50_ratio']=b/k if b and k else None;row['three_independent_processes_available']=all(row[e+'_processes']>=3 for e in ['control','current','kuzu']);row['automatic_acceptance']=False;rows.append(row)
payload={'status':'observations_only_review_registered_gates_no_auto_acceptance','source':'e8c38315','complete_read_campaign':(root/'read-campaign-completed.json').exists(),'independent_process_workload_distributions':len(processes),'accepted_sample_records_in_completed_profiles':sum(v['samples'] for v in processes),'process_aggregation':'Median of independent process P50s; never pool per-process samples as independent processes','resource_capture_limit':'Every repaired-window case has post-query OS capture. Native child high-water RSS includes Git/provenance helpers and the benchmark, so it is not an isolated engine peak. Kuzu driver/engine RSS and native parent RSS are separately reported. Never sum noncoincident peaks; AS limits are not a6GiB cgroup equivalence.','processes':processes,'comparisons':rows,'unsupported_records':unsupported}
(root/'read-comparison-progress.json').write_text(json.dumps(payload,indent=2)+'\n')
if rows:
 with (root/'read-comparison-progress.csv').open('w',newline='') as stream:
  w=csv.DictWriter(stream,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps({'distributions':len(processes),'valid_samples':payload['accepted_sample_records_in_completed_profiles'],'workloads':len(rows),'complete':payload['complete_read_campaign']}))

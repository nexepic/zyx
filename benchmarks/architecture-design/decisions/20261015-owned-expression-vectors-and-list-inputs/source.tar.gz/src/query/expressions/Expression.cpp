/**
 * @file Expression.cpp
 * @author ZYX Contributors
 * @date 2025
 *
 * @copyright Copyright (c) 2025
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/

#include "graph/query/expressions/Expression.hpp"
#include <sstream>

namespace graph::query::expressions {

// ============================================================================
// LiteralExpression Implementation
// ============================================================================

LiteralExpression::LiteralExpression(utils::OwnedStdString value)
	: stringValue_(std::move(value)), integerValue_(0), doubleValue_(0.0), booleanValue_(false),
	  propertyValue_(), literalType_(LiteralType::STRING) {}

LiteralExpression::LiteralExpression(int64_t value)
	: stringValue_(), integerValue_(value), doubleValue_(0.0), booleanValue_(false),
	  propertyValue_(), literalType_(LiteralType::INTEGER) {}

LiteralExpression::LiteralExpression(double value)
	: stringValue_(), integerValue_(0), doubleValue_(value), booleanValue_(false),
	  propertyValue_(), literalType_(LiteralType::DOUBLE) {}

LiteralExpression::LiteralExpression(bool value)
	: stringValue_(), integerValue_(0), doubleValue_(0.0), booleanValue_(value),
	  propertyValue_(), literalType_(LiteralType::BOOLEAN) {}

LiteralExpression::LiteralExpression(OwnedPropertyValue value)
	: stringValue_(), integerValue_(0), doubleValue_(0.0), booleanValue_(false),
	  propertyValue_(std::move(value)), literalType_(LiteralType::PROPERTY_VALUE) {}

LiteralExpression::LiteralExpression()
	: stringValue_(), integerValue_(0), doubleValue_(0.0), booleanValue_(false),
	  propertyValue_(), literalType_(LiteralType::NULL_VAL) {}

void LiteralExpression::accept(ExpressionVisitor &visitor) {
	visitor.visit(this);
}

void LiteralExpression::accept(ConstExpressionVisitor &visitor) const {
	visitor.visit(this);
}

std::string LiteralExpression::toString() const {
	switch (literalType_) {
		case LiteralType::NULL_VAL:
			return "null";
		case LiteralType::BOOLEAN:
			return booleanValue_ ? "true" : "false";
		case LiteralType::INTEGER:
			return std::to_string(integerValue_);
		case LiteralType::DOUBLE: {
			std::ostringstream oss;
			oss << doubleValue_;
			return oss.str();
		}
		case LiteralType::STRING:
			return "'" + stringValue_ + "'";
		case LiteralType::PROPERTY_VALUE:
			return propertyValue_.toString();
	}
}

std::unique_ptr<Expression> LiteralExpression::clone() const {
	switch (literalType_) {
		case LiteralType::NULL_VAL:
			return std::make_unique<LiteralExpression>();
		case LiteralType::BOOLEAN:
			return std::make_unique<LiteralExpression>(booleanValue_);
		case LiteralType::INTEGER:
			return std::make_unique<LiteralExpression>(integerValue_);
		case LiteralType::DOUBLE:
			return std::make_unique<LiteralExpression>(doubleValue_);
		case LiteralType::STRING:
			return std::make_unique<LiteralExpression>(stringValue_);
		case LiteralType::PROPERTY_VALUE:
			return std::make_unique<LiteralExpression>(propertyValue_);
	}
	return std::make_unique<LiteralExpression>();
}

bool LiteralExpression::isNull() const {
	return literalType_ == LiteralType::NULL_VAL;
}

bool LiteralExpression::isBoolean() const {
	return literalType_ == LiteralType::BOOLEAN;
}

bool LiteralExpression::isInteger() const {
	return literalType_ == LiteralType::INTEGER;
}

bool LiteralExpression::isDouble() const {
	return literalType_ == LiteralType::DOUBLE;
}

bool LiteralExpression::isString() const {
	return literalType_ == LiteralType::STRING;
}

bool LiteralExpression::isPropertyValue() const {
	return literalType_ == LiteralType::PROPERTY_VALUE;
}

bool LiteralExpression::getBooleanValue() const {
	return booleanValue_;
}

int64_t LiteralExpression::getIntegerValue() const {
	return integerValue_;
}

double LiteralExpression::getDoubleValue() const {
	return doubleValue_;
}

const std::string &LiteralExpression::getStringValue() const {
	return stringValue_;
}

const PropertyValue &LiteralExpression::getPropertyValue() const {
	return propertyValue_;
}

// ============================================================================
// VariableReferenceExpression Implementation
// ============================================================================

VariableReferenceExpression::VariableReferenceExpression(utils::OwnedStdString variableName)
	: variableName_(std::move(variableName)), hasProperty_(false), propertyName_() {}

VariableReferenceExpression::VariableReferenceExpression(utils::OwnedStdString variableName,
                                                          utils::OwnedStdString propertyName)
	: variableName_(std::move(variableName)), hasProperty_(true), propertyName_(std::move(propertyName)) {}

void VariableReferenceExpression::accept(ExpressionVisitor &visitor) {
	visitor.visit(this);
}

void VariableReferenceExpression::accept(ConstExpressionVisitor &visitor) const {
	visitor.visit(this);
}

std::string VariableReferenceExpression::toString() const {
	if (hasProperty_) {
		return variableName_ + "." + propertyName_;
	}
	return variableName_;
}

std::unique_ptr<Expression> VariableReferenceExpression::clone() const {
	if (hasProperty_) {
		return std::make_unique<VariableReferenceExpression>(variableName_, propertyName_);
	}
	return std::make_unique<VariableReferenceExpression>(variableName_);
}

// ============================================================================
// BinaryOpExpression Implementation
// ============================================================================

BinaryOpExpression::BinaryOpExpression(std::unique_ptr<Expression> left,
                                       BinaryOperatorType op,
                                       std::unique_ptr<Expression> right)
	: left_(std::move(left)), right_(std::move(right)), op_(op) {}

void BinaryOpExpression::accept(ExpressionVisitor &visitor) {
	visitor.visit(this);
}

void BinaryOpExpression::accept(ConstExpressionVisitor &visitor) const {
	visitor.visit(this);
}

std::string BinaryOpExpression::toString() const {
	std::ostringstream oss;
	oss << "(" << left_->toString() << " " << graph::query::expressions::toString(op_) << " " << right_->toString() << ")";
	return oss.str();
}

std::unique_ptr<Expression> BinaryOpExpression::clone() const {
	return std::make_unique<BinaryOpExpression>(
		left_ ? left_->clone() : nullptr, op_,
		right_ ? right_->clone() : nullptr);
}

// ============================================================================
// UnaryOpExpression Implementation
// ============================================================================

UnaryOpExpression::UnaryOpExpression(UnaryOperatorType op, std::unique_ptr<Expression> operand)
	: operand_(std::move(operand)), op_(op) {}

void UnaryOpExpression::accept(ExpressionVisitor &visitor) {
	visitor.visit(this);
}

void UnaryOpExpression::accept(ConstExpressionVisitor &visitor) const {
	visitor.visit(this);
}

std::string UnaryOpExpression::toString() const {
	std::ostringstream oss;
	oss << graph::query::expressions::toString(op_) << "(" << (operand_ ? operand_->toString() : "null") << ")";
	return oss.str();
}

std::unique_ptr<Expression> UnaryOpExpression::clone() const {
	return std::make_unique<UnaryOpExpression>(op_, operand_ ? operand_->clone() : nullptr);
}

// ============================================================================
// FunctionCallExpression Implementation
// ============================================================================

FunctionCallExpression::FunctionCallExpression(utils::OwnedStdString functionName,
                                               utils::OwnedStdVector<std::unique_ptr<Expression>> arguments,
                                               bool distinct)
	: functionName_(std::move(functionName)), arguments_(std::move(arguments)), distinct_(distinct) {}

void FunctionCallExpression::accept(ExpressionVisitor &visitor) {
	visitor.visit(this);
}

void FunctionCallExpression::accept(ConstExpressionVisitor &visitor) const {
	visitor.visit(this);
}

std::string FunctionCallExpression::toString() const {
	std::ostringstream oss;
	oss << functionName_ << "(";
	for (size_t i = 0; i < arguments_.size(); ++i) {
		if (i > 0) oss << ", ";
		oss << arguments_[i]->toString();
	}
	oss << ")";
	return oss.str();
}

std::unique_ptr<Expression> FunctionCallExpression::clone() const {
	utils::OwnedStdVector<std::unique_ptr<Expression>> clonedArgs;
	clonedArgs.reserve(arguments_.size());
	for (const auto &arg : arguments_) {
		clonedArgs.push_back(arg->clone());
	}
	return std::make_unique<FunctionCallExpression>(functionName_, std::move(clonedArgs), distinct_);
}

// ============================================================================
// InExpression Implementation
// ============================================================================

void InExpression::accept(ExpressionVisitor &visitor) {
	visitor.visit(this);
}

void InExpression::accept(ConstExpressionVisitor &visitor) const {
	visitor.visit(this);
}

std::string InExpression::toString() const {
	std::ostringstream oss;
	oss << "(" << value_->toString() << " IN ";
	if (hasDynamicList()) {
		oss << listExpression_->toString();
	} else {
		oss << "[";
		for (size_t i = 0; i < listValues_.size(); ++i) {
			if (i > 0) oss << ", ";
			oss << listValues_[i].toString();
		}
		oss << "]";
	}
	oss << ")";
	return oss.str();
}

std::unique_ptr<Expression> InExpression::clone() const {
	if (hasDynamicList()) {
		return std::make_unique<InExpression>(value_->clone(), listExpression_->clone());
	}
	return std::make_unique<InExpression>(value_->clone(), listValues_);
}

// ============================================================================
// CaseExpression Implementation
// ============================================================================

CaseExpression::CaseExpression(std::unique_ptr<Expression> comparisonExpr)
	: comparisonExpression_(std::move(comparisonExpr)), elseExpression_(std::make_unique<LiteralExpression>()) {}

CaseExpression::CaseExpression()
	: comparisonExpression_(nullptr), elseExpression_(std::make_unique<LiteralExpression>()) {}

void CaseExpression::addBranch(std::unique_ptr<Expression> whenExpr, std::unique_ptr<Expression> thenExpr) {
	branches_.emplace_back(std::move(whenExpr), std::move(thenExpr));
}

void CaseExpression::setElseExpression(std::unique_ptr<Expression> elseExpr) {
	elseExpression_ = std::move(elseExpr);
}

void CaseExpression::accept(ExpressionVisitor &visitor) {
	visitor.visit(this);
}

void CaseExpression::accept(ConstExpressionVisitor &visitor) const {
	visitor.visit(this);
}

std::string CaseExpression::toString() const {
	std::ostringstream oss;
	oss << "CASE";
	if (comparisonExpression_) {
		oss << " " << comparisonExpression_->toString();
	}
	for (const auto &branch : branches_) {
		oss << " WHEN " << branch.whenExpression->toString()
		    << " THEN " << branch.thenExpression->toString();
	}
	if (elseExpression_) {
		oss << " ELSE " << elseExpression_->toString();
	}
	oss << " END";
	return oss.str();
}

std::unique_ptr<Expression> CaseExpression::clone() const {
	auto cloned = isSimpleCase()
		? std::make_unique<CaseExpression>(comparisonExpression_->clone())
		: std::make_unique<CaseExpression>();

	for (const auto &branch : branches_) {
		cloned->addBranch(branch.whenExpression->clone(), branch.thenExpression->clone());
	}
	if (elseExpression_) {
		cloned->setElseExpression(elseExpression_->clone());
	} else {
		// Preserve an explicitly absent ELSE branch instead of normalizing the
		// cloned AST to the constructor's implicit NULL expression.
		cloned->setElseExpression(nullptr);
	}
	return cloned;
}

// ============================================================================
// Utility Functions
// ============================================================================

std::string toString(BinaryOperatorType op) {
	switch (op) {
		case BinaryOperatorType::BOP_ADD: return "+";
		case BinaryOperatorType::BOP_SUBTRACT: return "-";
		case BinaryOperatorType::BOP_MULTIPLY: return "*";
		case BinaryOperatorType::BOP_DIVIDE: return "/";
		case BinaryOperatorType::BOP_MODULO: return "%";
		case BinaryOperatorType::BOP_POWER: return "^";
		case BinaryOperatorType::BOP_EQUAL: return "=";
		case BinaryOperatorType::BOP_NOT_EQUAL: return "<>";
		case BinaryOperatorType::BOP_LESS: return "<";
		case BinaryOperatorType::BOP_GREATER: return ">";
		case BinaryOperatorType::BOP_LESS_EQUAL: return "<=";
		case BinaryOperatorType::BOP_GREATER_EQUAL: return ">=";
		case BinaryOperatorType::BOP_IN: return "IN";
		case BinaryOperatorType::BOP_STARTS_WITH: return "STARTS WITH";
		case BinaryOperatorType::BOP_ENDS_WITH: return "ENDS WITH";
		case BinaryOperatorType::BOP_CONTAINS: return "CONTAINS";
		case BinaryOperatorType::BOP_REGEX_MATCH: return "=~";
		case BinaryOperatorType::BOP_AND: return "AND";
		case BinaryOperatorType::BOP_OR: return "OR";
		case BinaryOperatorType::BOP_XOR: return "XOR";
	}
	return "?";
}

std::string toString(UnaryOperatorType op) {
	switch (op) {
		case UnaryOperatorType::UOP_MINUS: return "-";
		case UnaryOperatorType::UOP_NOT: return "NOT";
	}
	return "?";
}

bool isArithmeticOperator(BinaryOperatorType op) {
	return op == BinaryOperatorType::BOP_ADD ||
	       op == BinaryOperatorType::BOP_SUBTRACT ||
	       op == BinaryOperatorType::BOP_MULTIPLY ||
	       op == BinaryOperatorType::BOP_DIVIDE ||
	       op == BinaryOperatorType::BOP_MODULO ||
	       op == BinaryOperatorType::BOP_POWER;
}

bool isComparisonOperator(BinaryOperatorType op) {
	return op == BinaryOperatorType::BOP_EQUAL ||
	       op == BinaryOperatorType::BOP_NOT_EQUAL ||
	       op == BinaryOperatorType::BOP_LESS ||
	       op == BinaryOperatorType::BOP_GREATER ||
	       op == BinaryOperatorType::BOP_LESS_EQUAL ||
	       op == BinaryOperatorType::BOP_GREATER_EQUAL ||
	       op == BinaryOperatorType::BOP_STARTS_WITH ||
	       op == BinaryOperatorType::BOP_ENDS_WITH ||
	       op == BinaryOperatorType::BOP_CONTAINS ||
	       op == BinaryOperatorType::BOP_REGEX_MATCH;
}

bool isLogicalOperator(BinaryOperatorType op) {
	return op == BinaryOperatorType::BOP_AND ||
	       op == BinaryOperatorType::BOP_OR ||
	       op == BinaryOperatorType::BOP_XOR;
}

} // namespace graph::query::expressions

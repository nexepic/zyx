from pathlib import Path
import subprocess,shlex
root=Path('/workspace/zyx');original=root/'tests/src/storage/relocatable/backend/test_RelocatableQueryResources.cpp';source=Path('/tmp/zyx-trace-full-property-allocation.cpp')
s=original.read_text().replace('#include "graph/utils/OwnedPmrAllocator.hpp"','#include "graph/utils/OwnedPmrAllocator.hpp"\n#include <execinfo.h>')
s=s.replace('void *do_allocate(size_t, size_t) override { throw std::bad_alloc(); }','void *do_allocate(size_t, size_t) override { void *frames[30]; int count=::backtrace(frames, 30); ::backtrace_symbols_fd(frames, count, 2); throw std::bad_alloc(); }')
s=s.replace('const EntityReadShape topology{};','const EntityReadShape topology{.include_labels=true, .all_properties=true};');source.write_text(s)
target='CMakeFiles/zyx_test_suite.dir/tests/src/storage/relocatable/backend/test_RelocatableQueryResources.cpp.o'
command=shlex.split(subprocess.check_output(['ninja','-C','buildDir','-t','commands',target],cwd=root,text=True).strip().splitlines()[-1])
for flag,value in [('-o','/tmp/zyx-trace-full-property-allocation.o'),('-MF','/tmp/zyx-trace-full-property-allocation.d')]:command[command.index(flag)+1]=value
command[command.index(str(original))]=str(source)
subprocess.run(command,cwd=root/'buildDir',check=True)
link=shlex.split((root/'buildDir/global-output-link-command.txt').read_text());link[link.index(str(root/'buildDir'/target))]='/tmp/zyx-trace-full-property-allocation.o';link[link.index('-o')+1]='/tmp/zyx-trace-full-property-allocation-tests';link.append('-rdynamic')
subprocess.run(link,cwd=root/'buildDir',check=True)
result=subprocess.run(['/tmp/zyx-trace-full-property-allocation-tests','--gtest_filter=RelocatableStorageBackendTest.CachedTopologyReadDoesNotAllocateAnUnusedAmbientFallbackSession'],cwd=root)
print('Expected diagnostic fault exit:',result.returncode)

# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 2962.14 | 2962.14 | 2894.78 | 1 | 1 |  |  | 3703.45 | 1.25026 | 0.97726 |
| aggregation_group_by | medium | zyx | 2871.44 | 2871.44 | 3036.52 | 1 | 1 |  |  | 3036.52 | 1.05749 | 1.05749 |
| all_nodes_property_filter | medium | zyx | 5455.07 | 5455.07 | 5455.07 | 1 | 1 |  |  | 5649.46 | 1.03563 | 1 |
| label_multi_property_filter | medium | zyx | 2916.01 | 2916.01 | 2916.01 | 1 | 1 |  |  | 3050.07 | 1.04597 | 1 |
| label_scan_filter | medium | zyx | 2800.21 | 2800.21 | 2704.02 | 1 | 1 |  |  | 2926.46 | 1.04509 | 0.965649 |
| one_hop_expand | medium | zyx | 17.5463 | 17.5463 | 17.0606 | 1 | 1 |  |  | 21.4632 | 1.22323 | 0.972319 |
| relationship_property_filter | medium | zyx | 6547.89 | 6547.89 | 6547.89 | 1 | 1 |  |  | 6707.87 | 1.02443 | 1 |
| relationship_type_scan | medium | zyx | 587.746 | 587.746 | 624.151 | 1 | 1 |  |  | 626.531 | 1.06599 | 1.06194 |
| topk_property_sort | medium | zyx | 3593.13 | 3593.13 | 3731.37 | 1 | 1 |  |  | 3766.25 | 1.04818 | 1.03847 |
| two_hop_expand | medium | zyx | 22.3687 | 22.3687 | 23.2381 | 1 | 1 |  |  | 23.4007 | 1.04614 | 1.03887 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 3011.51 | 2956.9 | 3091.169 | 3050.95 | 3269.25 | 3269.25 | 3269.25 | 0.3235022090348344 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 3277.02 | 2990.61 | 3109.597 | 3094.9 | 3277.02 | 3277.02 | 3277.02 | 0.3215850799958966 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5815.1 | 5403.11 | 5713.566 | 5666.09 | 6075.97 | 6075.97 | 6075.97 | 0.17502204402644514 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 2973.91 | 2973.91 | 3091.283 | 3078.1 | 3224.63 | 3224.63 | 3224.63 | 0.32349027895537225 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2816.66 | 2800.71 | 2883.614 | 2836.71 | 3018.61 | 3018.61 | 3018.61 | 0.34678705263603243 | ok | api |
| zyx | one_hop_expand | medium | 10 | 21.0791 | 19.6044 | 20.627580000000002 | 20.6263 | 21.3225 | 21.3225 | 21.3225 | 48.47878422965758 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6773.65 | 6487.29 | 6846.875 | 6789.11 | 7234.42 | 7234.42 | 7234.42 | 0.1460520310360566 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 634.511 | 633.046 | 674.2692 | 657.798 | 761.878 | 761.878 | 761.878 | 1.4830871705247697 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3275.51 | 3081.39 | 3189.674 | 3198.18 | 3313.76 | 3313.76 | 3313.76 | 0.3135116629473733 | ok | api |
| zyx | two_hop_expand | medium | 10 | 28.655 | 25.333 | 27.8171 | 26.7881 | 33.9159 | 33.9159 | 33.9159 | 35.949110439262185 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

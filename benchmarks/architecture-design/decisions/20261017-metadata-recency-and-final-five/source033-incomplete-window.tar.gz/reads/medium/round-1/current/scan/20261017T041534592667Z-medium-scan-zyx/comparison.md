# 横向性能差距分析

## ZYX vs Best

| workload | scale | best | best_p50_ms | zyx_p50_ms | zyx_first_ms | zyx_rank | zyx_vs_best | fastest_non_zyx | zyx_vs_fastest_non_zyx | zyx_p95_ms | zyx_p95/p50 | zyx_first/p50 |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| aggregation_count_by_group | medium | zyx | 3050.95 | 3050.95 | 3011.51 | 1 | 1 |  |  | 3269.25 | 1.07155 | 0.987073 |
| aggregation_group_by | medium | zyx | 3094.9 | 3094.9 | 3277.02 | 1 | 1 |  |  | 3277.02 | 1.05885 | 1.05885 |
| all_nodes_property_filter | medium | zyx | 5666.09 | 5666.09 | 5815.1 | 1 | 1 |  |  | 6075.97 | 1.07234 | 1.0263 |
| label_multi_property_filter | medium | zyx | 3078.1 | 3078.1 | 2973.91 | 1 | 1 |  |  | 3224.63 | 1.0476 | 0.966151 |
| label_scan_filter | medium | zyx | 2836.71 | 2836.71 | 2816.66 | 1 | 1 |  |  | 3018.61 | 1.06412 | 0.992932 |
| one_hop_expand | medium | zyx | 20.6263 | 20.6263 | 21.0791 | 1 | 1 |  |  | 21.3225 | 1.03375 | 1.02195 |
| relationship_property_filter | medium | zyx | 6789.11 | 6789.11 | 6773.65 | 1 | 1 |  |  | 7234.42 | 1.06559 | 0.997723 |
| relationship_type_scan | medium | zyx | 657.798 | 657.798 | 634.511 | 1 | 1 |  |  | 761.878 | 1.15822 | 0.964599 |
| topk_property_sort | medium | zyx | 3198.18 | 3198.18 | 3275.51 | 1 | 1 |  |  | 3313.76 | 1.03614 | 1.02418 |
| two_hop_expand | medium | zyx | 26.7881 | 26.7881 | 28.655 | 1 | 1 |  |  | 33.9159 | 1.26608 | 1.06969 |

## Reading Guide

- `zyx_vs_best` is 1 when ZYX is the fastest row for the workload; > 1 means ZYX is slower than the best row.
- `zyx_vs_fastest_non_zyx` compares ZYX with the fastest other database; < 1 means ZYX is faster than every non-ZYX competitor.
- `zyx_p95/p50` highlights tail-latency volatility for ZYX within this run.
- `zyx_first/p50` highlights first measured iteration cost; use `execution_mode=opened` for first-query-after-open samples and `execution_mode=cold-ish` for less cache-amortized query samples.
- The comparison uses p50 latency and only includes successful rows with at least one sample.

# 图数据库性能对比报告

## Summary

| database | workload | scale | samples | first_ms | min_ms | avg_ms | p50_ms | p95_ms | p99_ms | max_ms | ops_per_sec | status | equivalent_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| zyx | aggregation_count_by_group | medium | 10 | 2894.78 | 2812.1 | 3027.7200000000003 | 2962.14 | 3703.45 | 3703.45 | 3703.45 | 0.3302815319778579 | ok | api |
| zyx | aggregation_group_by | medium | 10 | 3036.52 | 2805.1 | 2896.2 | 2871.44 | 3036.52 | 3036.52 | 3036.52 | 0.3452800220979214 | ok | api |
| zyx | all_nodes_property_filter | medium | 10 | 5455.07 | 5294.69 | 5476.0470000000005 | 5455.07 | 5649.46 | 5649.46 | 5649.46 | 0.1826134801253532 | ok | api |
| zyx | label_multi_property_filter | medium | 10 | 2916.01 | 2812.03 | 2929.839 | 2916.01 | 3050.07 | 3050.07 | 3050.07 | 0.34131568321672284 | ok | api |
| zyx | label_scan_filter | medium | 10 | 2704.02 | 2704.02 | 2803.822 | 2800.21 | 2926.46 | 2926.46 | 2926.46 | 0.3566560216732731 | ok | api |
| zyx | one_hop_expand | medium | 10 | 17.0606 | 16.6649 | 18.499090000000002 | 17.5463 | 21.4632 | 21.4632 | 21.4632 | 54.0567130599397 | ok | api |
| zyx | relationship_property_filter | medium | 10 | 6547.89 | 6235.24 | 6506.125 | 6547.89 | 6707.87 | 6707.87 | 6707.87 | 0.15370131991008473 | ok | api |
| zyx | relationship_type_scan | medium | 10 | 624.151 | 574.098 | 595.2284999999999 | 587.746 | 626.531 | 626.531 | 626.531 | 1.6800270820365624 | ok | api |
| zyx | topk_property_sort | medium | 10 | 3731.37 | 3496.98 | 3618.143 | 3593.13 | 3766.25 | 3766.25 | 3766.25 | 0.27638487478245055 | ok | api |
| zyx | two_hop_expand | medium | 10 | 23.2381 | 21.0107 | 22.382849999999998 | 22.3687 | 23.4007 | 23.4007 | 23.4007 | 44.67706301923124 | ok | api |

## Limitations

- Benchmarks run through adapter-defined equivalent Cypher workloads and may not cover every engine-specific optimization.
- Results depend on local hardware, dataset scale, cache state, and runtime configuration captured in environment.json.

from pathlib import Path
import subprocess,shutil,json
r=Path('/workspace/zyx');p=r/'src/storage/relocatable/entity/PageBackedLogicalGraphReadAdapter.cpp';original=p.read_text();negative=original.replace('return materializeNode(snapshot, std::move(raw), active);','return materializeNode(snapshot, raw, active);').replace('return materializeEdge(snapshot, std::move(raw), active);','return materializeEdge(snapshot, raw, active);');assert negative!=original
records=[]
try:
 p.write_text(negative)
 with open('/tmp/zyx-source-copy-negative-build.log','w') as log:
  subprocess.run(['cmake','--build','buildDir','--target','zyx_transaction_resource_fault_worker','-j4'],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copy2(r/'buildDir/zyx_transaction_resource_fault_worker','/tmp/zyx-source-copy-negative-worker')
 db=Path('/tmp/zyx-source-copy-negative.zyx');db.unlink(missing_ok=True)
 cp=subprocess.run(['/tmp/zyx-source-copy-negative-worker','source-materialization-copy-accounting',str(db)],capture_output=True,text=True)
 records.append({'variant':'copy_owned_local_raw','returncode':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr})
 if cp.returncode==0 or 'node=2, edge=2' not in cp.stderr:raise RuntimeError('counterfactual did not duplicate each complete payload')
finally:
 p.write_text(original)
 Path('/tmp/zyx-source-copy-negative-evidence.json').write_text(json.dumps(records,indent=2)+'\n')

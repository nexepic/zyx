/**
 * @file ScopedPropertyBuffers.hpp
 * @brief Pre-admission of unmanaged property-reader backing buffers.
 * Copyright (c) 2026 Nexepic. Licensed under the Apache License, Version 2.0.
 */
#pragma once
#include <limits>
#include <stdexcept>
#include <vector>
#include "graph/core/PropertyDecodeAllocationScope.hpp"
#include "graph/query/execution/StandardContainerHeapBytes.hpp"

namespace graph::storage::detail {
// Standard-vector backing storage only. PMR/OwnedVector requests have their own
// allocator authority; callers must not charge them through this helper too.
template<class T>
void admitScopedPropertyVectorStorage(size_t count, size_t capacity = 0U) {
    auto *scope = property_decode::AllocationScope::current();
    if (!scope || count <= capacity) return;
    if (count > (std::numeric_limits<size_t>::max)()/sizeof(T))
        throw std::length_error("property reader vector exceeds addressable backing storage");
    scope->admit(query::execution::detail::standardAllocatorRequestBytes(count * sizeof(T), alignof(T)));
}

template<class T>
void admitScopedPropertyVectorGrowth(const std::vector<T> &values, size_t count) {
    admitScopedPropertyVectorStorage<T>(count, values.capacity());
}
} // namespace graph::storage::detail

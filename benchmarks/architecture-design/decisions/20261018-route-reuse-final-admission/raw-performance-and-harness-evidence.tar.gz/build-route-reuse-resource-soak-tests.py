from pathlib import Path
import subprocess,shlex,json,hashlib,sys
root=Path('/workspace/zyx');b=root/'buildDir';r=Path('/workspace/zyx-resume-evaluation-20261018');sys.path.insert(0,str(root/'scripts'));import test_resource_recovery_soak as contracts
paths=[root/'tests/src/storage/relocatable'/p for p in ['backend/test_RelocatableQueryResources.cpp','backend/test_RelocatableQueryScratch.cpp','maintenance/test_RelocatableMaintenanceService.cpp']]
commands=subprocess.check_output(['ninja','-C',str(b),'-t','commands','zyx_test_suite'],text=True).splitlines();objects=[]
for p in paths:
 args=shlex.split(next(v for v in commands if ' -c '+str(p) in v));objects.append(args[args.index('-o')+1])
subprocess.run(['ninja','-C',str(b),'-j','2',*objects],check=True)
link=shlex.split(commands[-1].removeprefix(': && ').removesuffix(' && :'));link=[v for v in link if not v.endswith('.cpp.o')];index=link.index('-o');binary=r/'route-reuse-resource-soak-tests';link[index:index]=objects;link[link.index('-o')+1]=str(binary);link.append('/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libgtest_main.a');subprocess.run(link,cwd=b,check=True)
selected=subprocess.check_output([str(binary),'--gtest_filter='+':'.join(contracts.CASES),'--gtest_list_tests'],text=True);assert len([v for v in selected.splitlines() if v.startswith('  ') and not v.startswith('    ')])==6,selected
h=hashlib.sha256()
with (b/'libzyx_core.a').open('rb') as f:
 for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
(r/'route-reuse-resource-soak-test-provenance.json').write_text(json.dumps({'source_commit':'c28794a7c92434e809f9bbb17d48e8c457a70263','modules':[str(p.relative_to(root)) for p in paths],'selected_cases':contracts.CASES,'module_source_sha256':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'core_sha256':h.hexdigest(),'link':link,'full_unit_suite':False,'selected_cases_only':True,'list_tests':selected},indent=2)+'\n');print(binary)

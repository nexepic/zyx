from pathlib import Path
import difflib
r=Path('/workspace/zyx-resume-evaluation-20261018');root=Path('/workspace/zyx');p=root/'src/storage/relocatable/metadata/MetadataPageRouteDirectory.cpp';original=p.read_text();s=(r/'MetadataPageRouteDirectory-reuse-draft.cpp').read_text()
start=s.index('\tsize_t MetadataPageRouteDirectory::nextBootstrapFrameCount(');end=s.index('\n\tPhysicalPageRef MetadataPageRouteDirectory::buildInitialRouteBranch',start);a=original.index('\tsize_t MetadataPageRouteDirectory::nextBootstrapFrameCount(');b=original.index('\n\tPhysicalPageRef MetadataPageRouteDirectory::buildInitialRouteBranch',a);s=s[:start]+original[a:b]+s[end:]
start=s.index('\t\tstruct RouteBranchBuild final');end=s.index('\n\tPhysicalPageRef MetadataPageRouteDirectory::buildFromCompleteRouteSet',start)
replacement='''		PhysicalPageRef buildRouteBranch(MetadataPageFile &pages, MetadataWriteBatch &batch,
			std::span<const MetadataPageRoute> routes, const RouteBranchReuse *reuse) {
			if (routes.empty()) throwRouteDirectoryError(FormatError::FERR_INVALID_STATE,
				"metadata PageId route branch requires a nonempty complete route set");
			uint64_t previousId = 0U;
			for (const auto &route : routes) {
				validateRoute(route, batch.candidate());
				if (route.page_id.value() <= previousId) throwRouteDirectoryError(FormatError::FERR_INVALID_HEADER,
					"metadata PageId route set must be strictly ordered and unique");
				previousId = route.page_id.value();
			}
			const auto writeOrReuse = [&](uint16_t level, uint64_t ordinal,
				std::span<const Child> children, bool rootNode) -> Child {
				PhysicalPageRef previous;
				if (reuse != nullptr && reuse->enabled &&
					std::ranges::none_of(children, [](const Child &child) { return child.changed; })) {
					if (rootNode) previous = reuse->root;
					else if (const auto found = reuse->nodes.find({level, ordinal}); found != reuse->nodes.end())
						previous = found->second;
				}
				if (previous.isValid()) {
					const auto old = pages.readMetadataRadix(previous);
					std::array<PhysicalPageRef, RSS_CATALOG_RADIX_FANOUT> expected{};
					for (const auto &child : children) expected[child.ordinal % RSS_CATALOG_RADIX_FANOUT] = child.reference;
					if (old.kind == (rootNode ? CatalogRadixPageKind::CRPK_ROOT : CatalogRadixPageKind::CRPK_INTERNAL) &&
						old.directory_type == MetadataDirectoryType::MDT_METADATA_PAGE_ROUTE && old.level == level &&
						!old.logical_children_enabled && old.children == expected) {
						debug::PerfTrace::addValue("native_graph.route.reused_radix_nodes", 1);
						return {ordinal, previous, false};
					}
				}
				return {ordinal, writeNode(pages, batch, level, children, rootNode), true};
			};
			std::vector<Child> children;
			for (size_t begin = 0U; begin < routes.size();) {
				const uint64_t ordinal = leafOrdinal(routes[begin].page_id);
				size_t end = begin;
				while (end < routes.size() && leafOrdinal(routes[end].page_id) == ordinal) ++end;
				PhysicalPageRef reference;
				bool changed = true;
				if (reuse != nullptr && reuse->enabled) {
					const auto found = reuse->leaves.find(ordinal);
					if (found != reuse->leaves.end() && found->second.unchanged && found->second.entries == end - begin) {
						reference = found->second.reference; changed = false;
						debug::PerfTrace::addValue("native_graph.route.reused_leaves", 1);
					}
				}
				if (changed) {
					MetadataPageRouteLeafPage leaf;
					leaf.page_id = batch.allocateMetadataPageId();
					leaf.generation = batch.generation(); leaf.committed_lsn = batch.checkpointLsn();
					leaf.routes.assign(routes.begin() + static_cast<std::ptrdiff_t>(begin),
						routes.begin() + static_cast<std::ptrdiff_t>(end));
					reference = batch.allocatePage(); pages.writeMetadataPageRouteLeaf(reference, leaf);
				}
				children.push_back({ordinal, reference, changed});
				begin = end;
			}
			uint16_t level = 0U;
			while (children.size() > 1U) {
				std::vector<Child> parents;
				for (size_t begin = 0U; begin < children.size();) {
					const uint64_t ordinal = children[begin].ordinal / RSS_CATALOG_RADIX_FANOUT;
					size_t end = begin;
					while (end < children.size() && children[end].ordinal / RSS_CATALOG_RADIX_FANOUT == ordinal) ++end;
					parents.push_back(writeOrReuse(level, ordinal,
						std::span<const Child>(children).subspan(begin, end - begin), false));
					begin = end;
				}
				children = std::move(parents);
				if (level == RSS_CATALOG_RADIX_MAX_LEVEL) throwRouteDirectoryError(FormatError::FERR_ARITHMETIC_OVERFLOW,
					"metadata PageId route set exceeds the radix identity domain");
				++level;
			}
			return writeOrReuse(level, 0U, children, true).reference;
		}
	}
'''
s=s[:start]+replacement+s[end:];s=s.replace('buildRouteBranch(pages_, batch, &batch, routes, nullptr).root','buildRouteBranch(pages_, batch, routes, nullptr)').replace('buildRouteBranch(pages_, batch, &batch, complete, &reuse).root','buildRouteBranch(pages_, batch, complete, &reuse)');(r/'MetadataPageRouteDirectory-reuse-draft.cpp').write_text(s)
patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/src/storage/relocatable/metadata/MetadataPageRouteDirectory.cpp',tofile='b/src/storage/relocatable/metadata/MetadataPageRouteDirectory.cpp'));(r/'route-branch-reuse-draft.patch').write_text(patch)
(r/'route-reuse-capacity-review.md').write_text('The draft keeps the existing full-rewrite capacity preflight as a conservative bound, even when publication reuses old pages. This guarantees that optional reuse-index admission denial during writing can safely fall back to the original full rewrite, regardless of whether an earlier count had more free WORK credit. No reserved capacity or quota is raised. The nextBootstrapFrameCount header comment must say conservative capacity rather than exact new allocation count if this draft is applied. Exact changed-frame planning was rejected because optional admission could diverge between count and write, under-reserving fallback. No production patch applied.\n')
print('Saved safer draft with unchanged conservative capacity; optional reuse denial cannot under-reserve fallback')

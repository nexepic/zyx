from pathlib import Path
import json,subprocess,os,time,sys,hashlib,resource
r=Path('/workspace/zyx-resume-evaluation-20261018');w=r/'route-reuse-final-window';state=r/'route-reuse-post-contract-status.json';logs=r/'route-reuse-post-contract-logs';logs.mkdir(exist_ok=True)
def save(d):state.write_text(json.dumps(d,indent=2)+'\n')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(6442450944,6442450944));resource.setrlimit(resource.RLIMIT_FSIZE,(2147483648,2147483648))
def run(phase,command,timeout,limited=False):
 save({'phase':phase,'automatic_acceptance':False,'pid':os.getpid(),'command':command});print(json.dumps({'phase':phase}),flush=True)
 with (logs/(phase+'.log')).open('x') as stream:subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=timeout,preexec_fn=limits if limited else None)
save({'phase':'waiting_for_all_formal_contract_processes','automatic_acceptance':False,'pid':os.getpid()})
while not (w/'independent-read-write-completed.json').exists():
 try:args=Path('/proc/18933/cmdline').read_bytes()
 except FileNotFoundError:args=b''
 if b'run-route-reuse-final-evaluation.py' not in args:
  save({'phase':'blocked_formal_driver_returned_without_completion_marker','automatic_acceptance':False});raise SystemExit(1)
 time.sleep(5)
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison');from runner.workload_preflight import NATIVE_FAMILY_ORDER
cases=[]
for n in range(1,4):
 for family in NATIVE_FAMILY_ORDER:
  folder=w/'contract'/f'round-{n}'/'current'/family;marker=folder/'campaign-case-completed.json';assert marker.exists(),(n,family,'no completed marker');v=json.loads(marker.read_text());assert v['status'] in ['completed','completed_correctness_external_no_performance'],v
  report=v['outcome'] if v['status']=='completed_correctness_external_no_performance' else json.loads((folder/'report.json').read_text());assert report['full_results_checked'],(n,family)
  cases.append({'round':n,'family':family,'marker':str(marker),'status':v['status'],'report_sha256':digest(folder/'report.json') if (folder/'report.json').exists() else None,'full_results_checked':True,'harness_returncode':v.get('harness_returncode',v.get('returncode'))})
(r/'route-reuse-current-full-contract-guard.json').write_text(json.dumps({'source':'c28794a7c92434e809f9bbb17d48e8c457a70263','families':list(NATIVE_FAMILY_ORDER),'cases':cases,'all_current_supported_results_checked':True,'original_control_and_Kuzu_failures_not_waived':True,'automatic_acceptance':False},indent=2)+'\n')
run('native_memory_attribution',[sys.executable,str(r/'diagnose-read-process-memory.py')],1500)
run('build_readonly_endpoint_inspector',[sys.executable,str(r/'build-route-reuse-endpoint-inspector.py')],300)
endpoints=[]
for n in [2,3]:
 path=w/f'diagnostic-maintenance-round{n}-current.zyx';before=digest(path);target=r/f'route-reuse-endpoint-round-{n}.json';command=[str(r/'route-reuse-readonly-endpoint-inspector'),str(path)]
 save({'phase':'readonly_closed_endpoint_inspection','round':n,'automatic_acceptance':False})
 with target.open('x') as stream:subprocess.run(command,stdout=stream,check=True,timeout=120,preexec_fn=limits)
 d=json.loads(target.read_text());after=digest(path);assert before==after,(n,'readonly changed file');assert d['retire_queue_entries']==0 and d['routes_without_current_directory_reference']==0,(n,d)
 endpoints.append({'round':n,'path':str(path),'bytes':path.stat().st_size,'before_sha256':before,'after_sha256':after,'retire_queue_entries':d['retire_queue_entries'],'routes_without_current_directory_reference':d['routes_without_current_directory_reference'],'report':str(target)})
(r/'route-reuse-closed-endpoint-summary.json').write_text(json.dumps({'source':'c28794a7c92434e809f9bbb17d48e8c457a70263','read_only':True,'endpoints':endpoints,'first_round_endpoint_not_retained_due_post_close_EXDEV':True},indent=2)+'\n')
run('build_three_resource_test_modules',[sys.executable,str(r/'build-route-reuse-resource-soak-tests.py')],600)
run('six_resource_contracts_sixteen_same_process_rounds',[sys.executable,'/workspace/zyx/scripts/test_resource_recovery_process_soak.py','--test-binary',str(r/'route-reuse-resource-soak-tests'),'--output',str(r/'route-reuse-same-process-resource-soak.json'),'--rounds','16'],600,True)
run('targeted_thirtytwo_crash_recovery_cycles',[sys.executable,'/workspace/zyx/scripts/test_transaction_resource_faults.py','--worker',str(r/'frozen-route-reuse-binaries/zyx-workload-contract-worker'),'--output',str(r/'route-reuse-targeted-crash-recovery.json'),'--crash-recovery','--crash-cycles','32','--progress-every','8'],600,True)
save({'phase':'all_post_contract_checks_completed_requires_manual_resource_gate_review','automatic_acceptance':False,'current_full_contract_slots':len(cases),'native_memory_attribution':str(r/'read-process-memory-diagnosis/summary.json'),'endpoints':str(r/'route-reuse-closed-endpoint-summary.json'),'same_process_resource_contracts':str(r/'route-reuse-same-process-resource-soak.json'),'recovery':str(r/'route-reuse-targeted-crash-recovery.json')});print('Post-contract evidence complete; manual admission and publication remain',flush=True)

from pathlib import Path
import shlex,subprocess,json,hashlib
r=Path('/workspace/zyx-resume-evaluation-20261018');build=Path('/workspace/zyx/buildDir_final');source=r/'route-reuse-readonly-endpoint-inspector.cpp';obj=r/'route-reuse-readonly-endpoint-inspector.o';binary=r/'route-reuse-readonly-endpoint-inspector'
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','zyx_workload_contract_worker'],text=True).splitlines();compile=shlex.split(next(v for v in commands if ' -c ' in v and 'native-worker.cpp' in v))
for flag,value in [('-o',str(obj)),('-MF',str(obj)+'.d'),('-MT',str(obj))]:
 if flag in compile:compile[compile.index(flag)+1]=value
compile[compile.index('-c')+1]=str(source);link=shlex.split(commands[-1].removeprefix(': && ').removesuffix(' && :'));old=next(v for v in link if v.endswith('native-worker.cpp.o'));link[link.index(old)]=str(obj);link[link.index('-o')+1]=str(binary)
if '-Xlinker' in link:i=link.index('-Xlinker');del link[i:i+2]
h=hashlib.sha256()
with (build/'libzyx_core.a').open('rb') as f:
 for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
core=h.hexdigest();assert core==json.loads((r/'mature-diagnostic-worker-provenance.json').read_text())['core_sha256']
subprocess.run(compile,cwd=build,check=True);subprocess.run(link,cwd=build,check=True)
(r/'route-reuse-endpoint-inspector-provenance.json').write_text(json.dumps({'source_commit':'c28794a7c92434e809f9bbb17d48e8c457a70263','scope':'Read-only closed-endpoint liveness/retirement inspection, no performance samples or production changes','core_sha256':core,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'compile':compile,'link':link},indent=2)+'\n');print(binary)

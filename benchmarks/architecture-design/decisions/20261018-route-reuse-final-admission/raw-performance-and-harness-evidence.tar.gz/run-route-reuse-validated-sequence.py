from pathlib import Path
import json,subprocess,time,sys,os
r=Path('/workspace/zyx-resume-evaluation-20261018');state=r/'route-reuse-validated-sequence-status.json';status=r/'route-reuse-contract-status.json'
state.write_text(json.dumps({'phase':'waiting_for_all_six_required_correctness_cases','performance_started':False,'pid':os.getpid()},indent=2)+'\n')
while True:
 if status.exists():
  d=json.loads(status.read_text())
  if any(v['returncode']!=0 for v in d['cases']):
   state.write_text(json.dumps({'phase':'blocked_by_actual_required_correctness_failure','performance_started':False,'correctness':d},indent=2)+'\n');raise SystemExit(1)
  if d['all_six_completed']:break
 time.sleep(5)
state.write_text(json.dumps({'phase':'final_registered_evaluation','performance_started':True,'source':'c28794a7c92434e809f9bbb17d48e8c457a70263','pid':os.getpid()},indent=2)+'\n')
with (r/'route-reuse-final-evaluation-driver.log').open('w') as stream:
 result=subprocess.run(['/workspace/zyx-benchmark-venv/bin/python',str(r/'run-route-reuse-final-evaluation.py')],stdout=stream,stderr=subprocess.STDOUT)
state.write_text(json.dumps({'phase':'final_evaluation_returned_requires_gate_review','performance_started':True,'returncode':result.returncode,'automatic_acceptance':False},indent=2)+'\n');raise SystemExit(result.returncode)

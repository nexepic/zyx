import sys
_original_excepthook = sys.excepthook
def _selected_excepthook(kind, value, traceback):
    if kind.__name__ == 'CalledProcessError':
        print('Selected verification failed, exit:', value.returncode, file=sys.stderr)
    else:
        _original_excepthook(kind, value, traceback)
sys.excepthook = _selected_excepthook
import pathlib, subprocess, shlex, os
root=pathlib.Path('/workspace/zyx')
sources=[
 'tests/src/storage/relocatable/entity/test_PageBackedGraphReadAdapter.cpp',
 'tests/src/storage/relocatable/entity/test_PageBackedGraphReadAdapterBatchReuse.cpp',
 'tests/src/storage/relocatable/property/test_PropertyValueCodec_Inspection.cpp',
 'tests/src/storage/relocatable/property/test_PropertyValueCodec_Bytes.cpp',
 'tests/src/storage/test_LogicalGraphPropertyPatch.cpp',
 'tests/src/storage/relocatable/backend/test_RelocatablePropertyPatches.cpp',
 'tests/src/storage/relocatable/backend/test_RelocatablePropertyPatchStaging.cpp',
 'tests/src/storage/test_LogicalGraphTransactionOverlayUndo.cpp',
 'tests/src/storage/relocatable/backend/test_RelocatableQueryResources.cpp']
objects=['CMakeFiles/zyx_test_suite.dir/'+s+'.o' for s in sources]
subprocess.run(['cmake','--build','buildDir','--target','zyx_core',*objects,'-j','4'],cwd=root,check=True)
lines=(root/'buildDir/build.ninja').read_text().splitlines()
start=next(i for i,v in enumerate(lines) if v.startswith('build zyx_test_suite:'))
libs=next(v.split(' = ',1)[1] for v in lines[start:start+14] if v.strip().startswith('LINK_LIBRARIES = '))
command=['/workspace/zyx-sysroot/usr/bin/clang++-19','-fprofile-instr-generate','-fcoverage-mapping','-pthread',*[str(root/'buildDir'/o) for o in objects],'/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libgtest_main.a',*shlex.split(libs),'-o','/tmp/zyx-global-output-regression-tests']
(root/'buildDir/global-output-link-command.txt').write_text(shlex.join(command)+'\n')
subprocess.run(command,cwd=root/'buildDir',check=True)
subprocess.run(['/tmp/zyx-global-output-regression-tests','--gtest_output=xml:/tmp/zyx-global-output-regression-tests.xml','--gtest_filter='+os.environ.get('ZYX_TARGETED_GTEST_FILTER','*')],cwd=root,check=True)

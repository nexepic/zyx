/**
 * @file TransactionResourceFaultWorker.cpp
 * @brief Isolated allocation-failure and terminal transaction retention checks.
 * Copyright (c) 2026 Nexepic. Licensed under the Apache License, Version 2.0.
 */
#include "graph/storage/relocatable/backend/RelocatableStorageBackend.hpp"
#include "graph/storage/LogicalQueryScratch.hpp"
#include "graph/storage/LogicalGraphTransactionOverlay.hpp"
#include "graph/storage/StorageIO.hpp"
#include "graph/query/execution/RetainedPropertyBytes.hpp"
#include "graph/query/api/QueryResult.hpp"
#include "graph/query/api/QueryEngine.hpp"
#include "graph/storage/relocatable/metadata/RelocatableMetadataStore.hpp"
#include <algorithm>
#include <array>
#include <atomic>
#include <cstddef>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <limits>
#include <memory>
#include <new>
#include <string>

namespace {
std::atomic<bool> denyAllocations{false};
std::atomic<size_t> liveBytes{0U};
std::atomic<size_t> allocationAttempts{0U};
std::atomic<size_t> faultRemaining{(std::numeric_limits<size_t>::max)()};
std::atomic<bool> faultTriggered{false};
struct alignas(std::max_align_t) AllocationHeader { void *base; size_t bytes; };

void *allocate(size_t bytes, size_t alignment = alignof(std::max_align_t)) {
    allocationAttempts.fetch_add(1U, std::memory_order_relaxed);
    if (denyAllocations.load(std::memory_order_relaxed)) throw std::bad_alloc();
    size_t remaining = faultRemaining.load(std::memory_order_relaxed);
    while (remaining != (std::numeric_limits<size_t>::max)()) {
        if (remaining == 0U) {
            if (faultRemaining.compare_exchange_weak(remaining, (std::numeric_limits<size_t>::max)(), std::memory_order_relaxed)) {
                faultTriggered.store(true, std::memory_order_relaxed);
                throw std::bad_alloc();
            }
        } else if (faultRemaining.compare_exchange_weak(remaining, remaining - 1U, std::memory_order_relaxed)) break;
    }
    bytes = std::max(size_t{1U}, bytes);
    alignment = std::max(alignment, alignof(AllocationHeader));
    if (bytes > (std::numeric_limits<size_t>::max)() - sizeof(AllocationHeader) - alignment)
        throw std::bad_alloc();
    const size_t total = bytes + sizeof(AllocationHeader) + alignment;
    void *base = std::malloc(total);
    if (!base) throw std::bad_alloc();
    void *result = static_cast<std::byte *>(base) + sizeof(AllocationHeader);
    size_t available = total - sizeof(AllocationHeader);
    if (!std::align(alignment, bytes, result, available)) { std::free(base); throw std::bad_alloc(); }
    auto *header = static_cast<AllocationHeader *>(result) - 1;
    std::construct_at(header, AllocationHeader{base, bytes});
    liveBytes.fetch_add(bytes, std::memory_order_relaxed);
    return result;
}
void deallocate(void *pointer) noexcept {
    if (!pointer) return;
    auto *header = static_cast<AllocationHeader *>(pointer) - 1;
    liveBytes.fetch_sub(header->bytes, std::memory_order_relaxed);
    std::free(header->base);
}
struct RejectAllocations {
    RejectAllocations() { denyAllocations.store(true, std::memory_order_relaxed); }
    ~RejectAllocations() { denyAllocations.store(false, std::memory_order_relaxed); }
};
} // namespace

// Only this independently selected executable replaces allocation. The normal
// test suite, production binaries and benchmark binaries retain their allocators.
void *operator new(size_t bytes) { return allocate(bytes); }
void *operator new[](size_t bytes) { return allocate(bytes); }
void operator delete(void *pointer) noexcept { deallocate(pointer); }
void operator delete[](void *pointer) noexcept { deallocate(pointer); }
void operator delete(void *pointer, size_t) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, size_t) noexcept { deallocate(pointer); }
void *operator new(size_t bytes, std::align_val_t alignment) { return allocate(bytes, static_cast<size_t>(alignment)); }
void *operator new[](size_t bytes, std::align_val_t alignment) { return allocate(bytes, static_cast<size_t>(alignment)); }
void operator delete(void *pointer, std::align_val_t) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, std::align_val_t) noexcept { deallocate(pointer); }
void operator delete(void *pointer, size_t, std::align_val_t) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, size_t, std::align_val_t) noexcept { deallocate(pointer); }
void *operator new(size_t bytes, const std::nothrow_t &) noexcept { try { return allocate(bytes); } catch (...) { return nullptr; } }
void *operator new[](size_t bytes, const std::nothrow_t &) noexcept { try { return allocate(bytes); } catch (...) { return nullptr; } }
void operator delete(void *pointer, const std::nothrow_t &) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, const std::nothrow_t &) noexcept { deallocate(pointer); }
void *operator new(size_t bytes, std::align_val_t alignment, const std::nothrow_t &) noexcept {
    try { return allocate(bytes, static_cast<size_t>(alignment)); } catch (...) { return nullptr; }
}
void *operator new[](size_t bytes, std::align_val_t alignment, const std::nothrow_t &) noexcept {
    try { return allocate(bytes, static_cast<size_t>(alignment)); } catch (...) { return nullptr; }
}
void operator delete(void *pointer, std::align_val_t, const std::nothrow_t &) noexcept { deallocate(pointer); }
void operator delete[](void *pointer, std::align_val_t, const std::nothrow_t &) noexcept { deallocate(pointer); }

using namespace graph;
using namespace graph::storage;
namespace {
uint64_t stageNodes(LogicalGraphTransaction &transaction, size_t count, size_t payloadBytes = 0U) {
    LogicalGraphMutationBatch batch;
    batch.node_creates.resize(count);
    if (payloadBytes) batch.node_creates.front().properties.push_back({"payload", PropertyValue(std::string(payloadBytes, 'q'))});
    const auto result = transaction.stageMutationBatch(std::move(batch));
    if (result.created_node_ids.size() != count) throw std::runtime_error("staged identity count changed");
    return result.created_node_ids.back();
}
size_t destroyClosed(std::unique_ptr<LogicalGraphTransaction> &transaction) {
    const size_t before = liveBytes.load(std::memory_order_relaxed);
    transaction.reset();
    const size_t after = liveBytes.load(std::memory_order_relaxed);
    if (after > before) throw std::runtime_error("closed transaction destruction allocated memory");
    const size_t retained = before - after;
    // The closed object itself is expected; payloads, ID arrays and their spare
    // capacity must already have been released. This is not an RSS measurement.
    if (retained >= 16U * 1024U) throw std::runtime_error("closed transaction retained payload or ID capacity");
    return retained;
}

LogicalGraphMutationBatch propertyReplacement(uint64_t id, int64_t value) {
    LogicalGraphMutationBatch batch;
    batch.property_replacements = {{{LogicalGraphMutationEntityKind::LGMK_NODE,
        LogicalGraphMutationReferenceKind::LGRK_PERSISTED, id},
        {{"value", PropertyValue(value)}, {"payload", PropertyValue(std::string(4096U, 'p'))}}}};
    return batch;
}
void allocationFaultCase(const std::string &mode, RelocatableStorageBackend &backend, size_t fault) {
    const uint64_t id = backend.createLogicalNodes({{{}, {{"value", PropertyValue(int64_t{0})}}}}).front();
    auto transaction = backend.beginLogicalGraphTransaction(false);
    const bool useOverlay = mode == "overlay-stage-allocation-fault";
    const bool stage = mode == "stage-allocation-fault" || useOverlay;
    std::unique_ptr<LogicalGraphTransactionOverlay> overlay;
    if (useOverlay) {
        overlay = std::make_unique<LogicalGraphTransactionOverlay>(*transaction);
        (void)overlay->executeLogicalGraphMutationBatch(propertyReplacement(id, 1));
    } else {
        (void)transaction->stageMutationBatch(propertyReplacement(id, 1));
    }
    auto candidate = stage ? propertyReplacement(id, 2) : LogicalGraphMutationBatch{};
    bool threw = false;
    faultTriggered.store(false, std::memory_order_relaxed);
    const size_t before = allocationAttempts.load(std::memory_order_relaxed);
    faultRemaining.store(fault, std::memory_order_relaxed);
    try {
        if (useOverlay) (void)overlay->executeLogicalGraphMutationBatch(candidate);
        else if (stage) (void)transaction->stageMutationBatch(std::move(candidate));
        else (void)transaction->commit();
    } catch (const std::exception &) { threw = true; }
    faultRemaining.store((std::numeric_limits<size_t>::max)(), std::memory_order_relaxed);
    const size_t attempts = allocationAttempts.load(std::memory_order_relaxed) - before;
    const bool triggered = faultTriggered.load(std::memory_order_relaxed);
    const auto state = transaction->state();
    if (!triggered && threw) throw std::runtime_error("normal allocation probe failed");
    if (stage) {
        if (state != LogicalGraphTransactionState::LGTTS_ACTIVE)
            throw std::runtime_error("Property staging allocation fault finished its transaction");
        if (useOverlay) {
            auto visible = overlay->openLogicalGraphReadSnapshot();
            if (visible->readNodeProperty(id, "value") != PropertyValue(int64_t{threw ? 1 : 2}) ||
                visible->readNodeProperty(id, "payload") != PropertyValue(std::string(4096U, 'p')))
                throw std::runtime_error("failed overlay allocation changed the visible statement prefix");
        }
        (void)transaction->commit();
    } else if (state == LogicalGraphTransactionState::LGTTS_ACTIVE) {
        throw std::runtime_error("commit allocation fault left a reusable transaction");
    }
    overlay.reset();
    const size_t retained = destroyClosed(transaction);
    backend.close(); backend.open();
    int64_t value = -1;
    {
        auto snapshot = backend.openLogicalGraphReadSnapshot();
        const auto observed = snapshot->readNodeProperty(id, "value");
        for (int64_t expected = 0; expected <= 2; ++expected)
            if (observed == PropertyValue(expected)) value = expected;
        const auto payload = snapshot->readNodeProperty(id, "payload");
        if (value == 0 ? payload != PropertyValue() : payload != PropertyValue(std::string(4096U, 'p')))
            throw std::runtime_error("allocation fault published an incomplete Property replacement");
    }
    if (stage) {
        if (value != (threw ? 1 : 2)) throw std::runtime_error("failed Property statement changed its prior staged prefix");
    } else {
        if (value != 0 && value != 1) throw std::runtime_error("commit allocation fault published a partial Property value");
        if (!threw && value != 1) throw std::runtime_error("successful commit lost its Property replacement");
        if (threw && state != LogicalGraphTransactionState::LGTTS_INDETERMINATE && value != 0)
            throw std::runtime_error("definite failed commit nevertheless published its Property replacement");
    }
    (void)backend.verifyIntegrity(); backend.close();
    std::cout << "{\"mode\":\"" << mode << "\",\"allocation_attempts\":" << attempts
        << ",\"fault_triggered\":" << (triggered ? "true" : "false")
        << ",\"operation_threw\":" << (threw ? "true" : "false")
        << ",\"selected_fault\":";
    if (fault == (std::numeric_limits<size_t>::max)()) std::cout << "null";
    else std::cout << fault;
    std::cout << ",\"observed_value\":" << value << ",\"closed_object_bytes\":" << retained << ",\"passed\":true}\n";
}

void creationAllocationFaultCase(const std::string &mode, RelocatableStorageBackend &backend, size_t fault) {
    const auto creation = [](int64_t value) {
        LogicalGraphMutationBatch batch;
        batch.node_creates = {{{}, {{"value", PropertyValue(value)},
            {"payload", PropertyValue(std::string(4096U, 'c'))}}}};
        return batch;
    };
    auto transaction = backend.beginLogicalGraphTransaction(false);
    const bool useOverlay = mode == "overlay-creation-stage-allocation-fault";
    auto overlay = useOverlay ? std::make_unique<LogicalGraphTransactionOverlay>(*transaction) : nullptr;
    const auto first = useOverlay ? overlay->executeLogicalGraphMutationBatch(creation(1))
                                  : transaction->stageMutationBatch(creation(1));
    if (first.created_node_ids.size() != 1U) throw std::runtime_error("creation fault seed count changed");
    const auto firstId = first.created_node_ids.front();
    auto candidate = creation(2);
    const auto preview = transaction->previewMutationBatch(candidate);
    if (preview.created_node_ids.size() != 1U) throw std::runtime_error("creation fault preview count changed");
    const auto candidateId = preview.created_node_ids.front();
    bool threw = false;
    faultTriggered.store(false, std::memory_order_relaxed);
    const auto before = allocationAttempts.load(std::memory_order_relaxed);
    faultRemaining.store(fault, std::memory_order_relaxed);
    try {
        if (useOverlay) (void)overlay->executeLogicalGraphMutationBatch(candidate);
        else (void)transaction->stageMutationBatch(std::move(candidate));
    }
    catch (const std::exception &) { threw = true; }
    faultRemaining.store((std::numeric_limits<size_t>::max)(), std::memory_order_relaxed);
    const auto attempts = allocationAttempts.load(std::memory_order_relaxed) - before;
    const bool triggered = faultTriggered.load(std::memory_order_relaxed);
    if (!triggered && threw) throw std::runtime_error("normal creation allocation probe failed");
    if (transaction->state() != LogicalGraphTransactionState::LGTTS_ACTIVE)
        throw std::runtime_error("creation statement allocation fault finished its transaction");
    if (useOverlay) {
        auto visible = overlay->openLogicalGraphReadSnapshot();
        if (!visible->containsNode(firstId) || visible->containsNode(candidateId) == threw)
            throw std::runtime_error("creation allocation fault changed the visible overlay prefix");
    }
    (void)transaction->commit();
    overlay.reset();
    const size_t retained = destroyClosed(transaction);
    backend.close(); backend.open();
    {
        auto snapshot = backend.openLogicalGraphReadSnapshot();
        if (!snapshot->containsNode(firstId) || snapshot->readNodeProperty(firstId, "value") != PropertyValue(int64_t{1}) ||
            snapshot->readNodeProperty(firstId, "payload") != PropertyValue(std::string(4096U, 'c')))
            throw std::runtime_error("creation allocation fault changed its earlier statement");
        if (snapshot->containsNode(candidateId) == threw)
            throw std::runtime_error("failed creation receipt nevertheless changed the staged prefix");
        if (!threw && (snapshot->readNodeProperty(candidateId, "value") != PropertyValue(int64_t{2}) ||
            snapshot->readNodeProperty(candidateId, "payload") != PropertyValue(std::string(4096U, 'c'))))
            throw std::runtime_error("creation allocation fault published incomplete data");
    }
    (void)backend.verifyIntegrity(); backend.close();
    std::cout << "{\"mode\":\"" << mode << "\",\"allocation_attempts\":" << attempts
        << ",\"fault_triggered\":" << (triggered ? "true" : "false")
        << ",\"operation_threw\":" << (threw ? "true" : "false")
        << ",\"selected_fault\":";
    if (fault == (std::numeric_limits<size_t>::max)()) std::cout << "null";
    else std::cout << fault;
    std::cout << ",\"closed_object_bytes\":" << retained << ",\"passed\":true}\n";
}

void mixedStatementAllocationFaultCase(const std::string &mode, RelocatableStorageBackend &backend, size_t fault) {
    const auto persisted = backend.createLogicalNodes({{{"Seed"}, {{"rank", PropertyValue(0)}}}}).front();
    auto transaction = backend.beginLogicalGraphTransaction(false);
    LogicalGraphMutationBatch seed;
    seed.node_creates = {{{"Original"}, {{"rank", PropertyValue(0)}}},
                         {{"Original"}, {{"rank", PropertyValue(0)}}}};
    const auto first = transaction->stageMutationBatch(std::move(seed));
    if (first.created_node_ids.size() != 2U) throw std::runtime_error("mixed statement seed count changed");
    const std::array<uint64_t, 3U> ids{first.created_node_ids[0], persisted, first.created_node_ids[1]};
    LogicalGraphMutationBatch candidate;
    for (size_t index = 0U; index < ids.size(); ++index) {
        const LogicalGraphMutationEntityReference entity{LogicalGraphMutationEntityKind::LGMK_NODE,
            LogicalGraphMutationReferenceKind::LGRK_PERSISTED, ids[index]};
        candidate.property_replacements.push_back({entity, {{"rank", PropertyValue(int64_t{10} + static_cast<int64_t>(index))}}});
        candidate.node_label_replacements.push_back({entity, {"Changed-" + std::to_string(index)}});
    }
    bool threw = false;
    faultTriggered.store(false, std::memory_order_relaxed);
    const auto before = allocationAttempts.load(std::memory_order_relaxed);
    faultRemaining.store(fault, std::memory_order_relaxed);
    try { (void)transaction->stageMutationBatch(std::move(candidate)); }
    catch (const std::exception &) { threw = true; }
    faultRemaining.store((std::numeric_limits<size_t>::max)(), std::memory_order_relaxed);
    const auto attempts = allocationAttempts.load(std::memory_order_relaxed) - before;
    const bool triggered = faultTriggered.load(std::memory_order_relaxed);
    if (!triggered && threw) throw std::runtime_error("normal mixed statement allocation probe failed");
    if (transaction->state() != LogicalGraphTransactionState::LGTTS_ACTIVE)
        throw std::runtime_error("mixed statement allocation fault finished its transaction");
    (void)transaction->commit();
    const size_t retained = destroyClosed(transaction);
    backend.close(); backend.open();
    {
        auto snapshot = backend.openLogicalGraphReadSnapshot();
        for (size_t index = 0U; index < ids.size(); ++index) {
            const auto node = snapshot->readNodeShaped(ids[index], {.include_labels = true, .all_properties = true});
            const auto rank = std::ranges::find(node.properties, std::string("rank"), &LogicalGraphPropertyEntry::key);
            const auto expectedRank = threw ? int64_t{0} : int64_t{10} + static_cast<int64_t>(index);
            const std::vector<std::string> expectedLabels{threw ? (index == 1U ? "Seed" : "Original")
                : "Changed-" + std::to_string(index)};
            if (rank == node.properties.end() || rank->value != PropertyValue(expectedRank) || node.labels != expectedLabels)
                throw std::runtime_error("failed mixed statement changed its Property or label prefix");
        }
    }
    (void)backend.verifyIntegrity(); backend.close();
    std::cout << "{\"mode\":\"" << mode << "\",\"allocation_attempts\":" << attempts
        << ",\"fault_triggered\":" << (triggered ? "true" : "false")
        << ",\"operation_threw\":" << (threw ? "true" : "false") << ",\"selected_fault\":";
    if (fault == (std::numeric_limits<size_t>::max)()) std::cout << "null";
    else std::cout << fault;
    std::cout << ",\"closed_object_bytes\":" << retained << ",\"passed\":true}\n";
}

void propertyHeapAccountingCase(const std::string &mode) {
    using namespace graph::query::execution::detail;
    size_t cases = 0U, maximumObserved = 0U;
    const auto verify = [&](auto make) {
        // Warm any standard-library process metadata before measuring ownership.
        { auto warm = make(); static_cast<void>(warm); }
        const auto baseline = liveBytes.load(std::memory_order_relaxed);
        {
            const auto value = make();
            const auto observed = liveBytes.load(std::memory_order_relaxed) - baseline;
            const auto estimated = propertyHeapBufferBytes(value);
            const auto guarded = propertyBufferEstimates(value, [] {});
            if (estimated < observed) throw std::runtime_error("Property heap accounting underestimates observed standard-allocator requests");
            if (guarded.heapBytes != estimated) throw std::runtime_error("guarded Property heap model disagrees with owning model");
            maximumObserved = (std::max)(maximumObserved, observed); ++cases;
        }
        if (liveBytes.load(std::memory_order_relaxed) != baseline)
            throw std::runtime_error("Property heap accounting fixture retained an allocation after destruction");
    };
    verify([] { return PropertyValue(std::string("x")); });
    verify([] { std::string text(8192U, 'q'); text.reserve(32768U); return PropertyValue(std::move(text)); });
    verify([] { PropertyValue::Bytes bytes; bytes.reserve(16384U); bytes.resize(7U); return PropertyValue(std::move(bytes)); });
    verify([] { std::vector<PropertyValue> list; list.reserve(128U); return PropertyValue(std::move(list)); });
    for (const size_t reserve : {size_t{0U}, size_t{16U}, size_t{256U}, size_t{4096U}}) {
        verify([reserve] { PropertyValue::MapType map; if (reserve) map.reserve(reserve); return PropertyValue(std::move(map)); });
        verify([reserve] {
            PropertyValue::MapType map; if (reserve) map.reserve(reserve);
            for (size_t i = 0U; i < 64U; ++i) {
                std::string key = "field-" + std::to_string(i); key.reserve(128U);
                std::vector<PropertyValue> list; list.reserve(9U);
                list.emplace_back(std::string(512U + i, 'v'));
                list.emplace_back(PropertyValue::Bytes(128U + i, std::byte{0x41}));
                map.emplace(std::move(key), PropertyValue(std::move(list)));
            }
            for (size_t i = 0U; i < 48U; ++i) map.erase("field-" + std::to_string(i));
            map.rehash(32U);
            // A fresh copy also audits normalization of legacy bucket capacity.
            auto copied = map;
            return PropertyValue(std::move(copied));
        });
    }
    verify([] {
        PropertyValue::MapType inner; inner.reserve(128U);
        inner.emplace("nested", PropertyValue(std::string(8192U, 'n')));
        std::vector<PropertyValue> list; list.reserve(64U); list.emplace_back(std::move(inner));
        PropertyValue::MapType outer; outer.reserve(256U); outer.emplace("children", PropertyValue(std::move(list)));
        return PropertyValue(std::move(outer));
    });
    const auto verifyRow = [&](auto make) {
        { auto warm = make(); static_cast<void>(warm); }
        const auto baseline = liveBytes.load(std::memory_order_relaxed);
        {
            const auto row = make();
            const auto observed = liveBytes.load(std::memory_order_relaxed) - baseline;
            if (graph::query::detail::resultRowHeapBytes(row) < observed)
                throw std::runtime_error("result row heap accounting underestimates observed standard-allocator requests");
            maximumObserved = (std::max)(maximumObserved, observed); ++cases;
        }
        if (liveBytes.load(std::memory_order_relaxed) != baseline)
            throw std::runtime_error("result row accounting fixture retained an allocation after destruction");
    };
    verifyRow([] { graph::query::QueryResult::Row row; row.reserve(4096U); return row; });
    verifyRow([] {
        graph::query::QueryResult::Row row; row.reserve(128U);
        graph::query::LogicalNodeResult node; node.node_id = 7U;
        node.labels.reserve(128U); node.labels.emplace_back("Short"); node.labels.emplace_back(std::string(4096U, 'l'));
        node.properties.reserve(128U); node.properties.emplace("body", PropertyValue(std::string(8192U, 'b')));
        row.emplace("node", graph::query::ResultValue(std::move(node)));
        row.emplace("text", graph::query::ResultValue(PropertyValue(std::string("x"))));
        return row;
    });
    verifyRow([] {
        graph::query::QueryResult::Row row; row.reserve(256U);
        for (size_t i = 0U; i < 16U; ++i)
            row.emplace(std::string(80U, 'a') + std::to_string(i),
                graph::query::ResultValue(PropertyValue(PropertyValue::Bytes(16384U + i, std::byte{0x52}))));
        return row;
    });
    std::cout << "{\"mode\":\"" << mode << "\",\"shape_cases\":" << cases
        << ",\"maximum_observed_requested_bytes\":" << maximumObserved << ",\"passed\":true}\n";
}

void scratchWriteAllocationFaultCase(const std::string &mode, const char *path, size_t fault) {
    RelocatableStorageBackendOptions options;
    options.data_path = path; options.open_mode = OpenMode::OPEN_CREATE_NEW_FILE;
    options.query_scratch_enabled = true;
    options.maximum_database_query_scratch_bytes = 2U * RSS_SEGMENT_SIZE;
    auto backend = RelocatableStorageBackend::initializeNew(options); backend->open();
    const auto node = backend->createLogicalNodes({{{"ScratchFault"}, {{"value", PropertyValue(7)}}}}).front();
    const auto fence = backend->currentNativeLogicalGraphMutationFence();
    auto graph = backend->openLogicalGraphReadSnapshot();
    auto *provider = dynamic_cast<LogicalQueryScratchProvider *>(graph.get());
    if (!provider) throw std::runtime_error("scratch allocation fault has no provider");
    auto scratch = provider->openQueryScratchSession(2U * RSS_SEGMENT_SIZE, 2U);
    const std::vector<std::byte> warmPayload(4096U, std::byte{0x21});
    const std::vector<std::byte> payload(4096U, std::byte{0x4B});
    const auto warm = scratch->write(warmPayload);
    uint64_t handle = 0U; bool threw = false;
    faultTriggered.store(false, std::memory_order_relaxed);
    const auto before = allocationAttempts.load(std::memory_order_relaxed);
    faultRemaining.store(fault, std::memory_order_relaxed);
    try { handle = scratch->write(payload); } catch (...) { threw = true; }
    const auto attempts = allocationAttempts.load(std::memory_order_relaxed) - before;
    faultRemaining.store((std::numeric_limits<size_t>::max)(), std::memory_order_relaxed);
    const bool triggered = faultTriggered.load(std::memory_order_relaxed);
    const bool recovery = backend->hasIndeterminateWriteOutcome();
    if (!threw) {
        if (!handle || scratch->read(handle) != payload || scratch->read(warm) != warmPayload)
            throw std::runtime_error("successful scratch receipt lost a complete fragment");
    }
    if (!recovery) {
        if (scratch->read(warm) != warmPayload) throw std::runtime_error("failed scratch write lost an earlier handle");
        scratch->finish();
    }
    scratch.reset(); graph.reset(); backend->close(); backend->open();
    if (backend->currentNativeLogicalGraphMutationFence() != fence)
        throw std::runtime_error("scratch allocation fault changed the graph publication fence");
    {
        auto current = backend->openLogicalGraphReadSnapshot();
        if (current->readNodeProperty(node, "value") != PropertyValue(7))
            throw std::runtime_error("scratch allocation fault changed durable user data");
        auto *retryProvider = dynamic_cast<LogicalQueryScratchProvider *>(current.get());
        auto retry = retryProvider->openQueryScratchSession(RSS_SEGMENT_SIZE, 1U);
        const auto id = retry->write(payload);
        if (retry->read(id) != payload) throw std::runtime_error("scratch allocation fault did not restore reusable quota");
        retry->finish();
    }
    static_cast<void>(backend->verifyIntegrity()); backend->close();
    std::cout << "{\"mode\":\"" << mode << "\",\"allocation_attempts\":" << attempts
        << ",\"operation_threw\":" << (threw ? "true" : "false")
        << ",\"requires_recovery\":" << (recovery ? "true" : "false")
        << ",\"fault_triggered\":" << (triggered ? "true" : "false") << ",\"selected_fault\":";
    if (fault == (std::numeric_limits<size_t>::max)()) std::cout << "null";
    else std::cout << fault;
    std::cout << ",\"passed\":true}\n";
}

void distinctAllocationFaultCase(const std::string &mode, const char *path, size_t fault) {
    using namespace graph::query;
    using namespace graph::query::execution::detail;
    RelocatableStorageBackendOptions options;
    options.data_path = path; options.open_mode = OpenMode::OPEN_CREATE_NEW_FILE;
    options.query_scratch_enabled = true;
    options.maximum_database_query_scratch_bytes = 8U * RSS_SEGMENT_SIZE;
    auto backend = RelocatableStorageBackend::initializeNew(options); backend->open();
    const auto node = backend->createLogicalNodes({{{"DistinctFault"}, {{"value", PropertyValue(7)}}}}).front();
    const auto fence = backend->currentNativeLogicalGraphMutationFence();
    LogicalReadExecutionOptions reads; reads.bounds.maximum_materialized_bytes = 8U * 1024U * 1024U;
    QueryContext context;
    context.resource_account = std::make_shared<ResourceAccount>(backend->queryResourceDomain(), ResourceClass::RCK_QUERY,
        reads.bounds.maximum_materialized_bytes);
    const std::string alias(2048U, 'a');
    const std::string text = "UNWIND range(1,800) AS x WITH DISTINCT x % 400 AS `" + alias +
        "` RETURN collect(`" + alias + "`) AS values";
    const auto validate = [](const QueryResult &result) {
        if (result.rowCount() != 1U) throw std::runtime_error("DISTINCT fault returned an incomplete output row");
        const auto &values = result.getRows()[0].at("values").asPrimitive().getList();
        if (values.size() != 400U) throw std::runtime_error("DISTINCT fault returned an incomplete collection");
        for (size_t i = 0U; i < values.size(); ++i)
            if (values[i] != PropertyValue(static_cast<int64_t>((i + 1U) % 400U)))
                throw std::runtime_error("DISTINCT fault changed equality or first-occurrence order");
    };
    bool threw = false, recovery = false, triggered = false;
    size_t attempts = 0U;
    {
        QueryEngine engine(std::static_pointer_cast<LogicalGraphReadBackend>(backend), reads);
        validate(engine.execute(text, context));
        faultTriggered.store(false, std::memory_order_relaxed);
        const auto before = allocationAttempts.load(std::memory_order_relaxed);
        faultRemaining.store(fault, std::memory_order_relaxed);
        std::optional<QueryResult> result;
        try { result.emplace(engine.execute(text, context)); }
        catch (const std::exception &) { threw = true; }
        faultRemaining.store((std::numeric_limits<size_t>::max)(), std::memory_order_relaxed);
        attempts = allocationAttempts.load(std::memory_order_relaxed) - before;
        // Validate outside the exception capture: an incomplete successful
        // result must fail the worker rather than masquerade as a rejected query.
        if (result) validate(*result);
        result.reset();
        triggered = faultTriggered.load(std::memory_order_relaxed);
        recovery = backend->hasIndeterminateWriteOutcome();
        if (context.resource_account->used() != 0U)
            throw std::runtime_error("DISTINCT fault retained a query or scratch allocation charge");
    }
    backend->close(); backend->open();
    if (backend->currentNativeLogicalGraphMutationFence() != fence)
        throw std::runtime_error("DISTINCT fault changed the graph publication fence");
    {
        auto graph = backend->openLogicalGraphReadSnapshot();
        if (graph->readNodeProperty(node, "value") != PropertyValue(7))
            throw std::runtime_error("DISTINCT fault changed durable user data");
    }
    {
        QueryEngine retry(std::static_pointer_cast<LogicalGraphReadBackend>(backend), reads);
        validate(retry.execute(text, context));
    }
    if (context.resource_account->used() != 0U)
        throw std::runtime_error("DISTINCT retry leaked query memory");
    static_cast<void>(backend->verifyIntegrity()); backend->close();
    std::cout << "{\"mode\":\"" << mode << "\",\"allocation_attempts\":" << attempts
        << ",\"operation_threw\":" << (threw ? "true" : "false")
        << ",\"requires_recovery\":" << (recovery ? "true" : "false")
        << ",\"fault_triggered\":" << (triggered ? "true" : "false") << ",\"selected_fault\":";
    if (fault == (std::numeric_limits<size_t>::max)()) std::cout << "null";
    else std::cout << fault;
    std::cout << ",\"passed\":true}\n";
}

void leaseAllocationFaultCase(const std::string &mode, const char *path, size_t fault) {
    RelocatableStorageBackendOptions options;
    options.data_path = path; options.open_mode = OpenMode::OPEN_CREATE_NEW_FILE;
    auto backend = RelocatableStorageBackend::initializeNew(options);
    backend->open(); backend->close(); backend.reset();
    auto stream = std::make_shared<std::fstream>(path, std::ios::in | std::ios::out | std::ios::binary);
    if (!stream->is_open()) throw std::runtime_error("lease fault could not open metadata file");
    auto io = std::make_shared<StorageIO>(stream, INVALID_FILE_HANDLE, INVALID_FILE_HANDLE);
    auto store = RelocatableMetadataStore::open(io);
    const auto warm = store->acquireNativeGraphLogicalIds(1U, 1U, 2U);
    if (warm.node_ranges.size() != 1U || warm.edge_ranges.size() != 1U)
        throw std::runtime_error("lease fault warm range count changed");
    Superblock beforeRoot;
    { auto pin = store->openSnapshot(); beforeRoot = pin.superblock(); }
    const bool direct = mode == "lease-reserve-allocation-fault";
    const bool fresh = mode == "lease-fresh-allocation-fault";
    NativeGraphLogicalIdReservation expected;
    if (direct) {
        expected.node_ranges = {{beforeRoot.next_logical_node_id, 1U}};
        expected.edge_ranges = {{beforeRoot.next_logical_edge_id, 1U}};
    } else {
        expected.node_ranges = {{warm.node_ranges.front().first_id + 1U, 1U}};
        expected.edge_ranges = {{warm.edge_ranges.front().first_id + 1U, 1U}};
        if (fresh) {
            expected.node_ranges.push_back({beforeRoot.next_logical_node_id, 2U});
            expected.edge_ranges.push_back({beforeRoot.next_logical_edge_id, 2U});
        }
    }
    NativeGraphLogicalIdReservation result;
    result.node_ranges.reserve(2U); result.edge_ranges.reserve(2U);
    bool threw = false;
    faultTriggered.store(false, std::memory_order_relaxed);
    const auto before = allocationAttempts.load(std::memory_order_relaxed);
    faultRemaining.store(fault, std::memory_order_relaxed);
    try {
        if (direct) {
            const auto lease = store->reserveNativeGraphLogicalIds(1U, 1U);
            result.node_ranges.push_back(lease.nodes);
            result.edge_ranges.push_back(lease.edges);
        } else {
            result = store->acquireNativeGraphLogicalIds(fresh ? 3U : 1U, fresh ? 3U : 1U, 8U);
        }
    } catch (const std::exception &) { threw = true; }
    faultRemaining.store((std::numeric_limits<size_t>::max)(), std::memory_order_relaxed);
    const auto attempts = allocationAttempts.load(std::memory_order_relaxed) - before;
    const bool triggered = faultTriggered.load(std::memory_order_relaxed);
    if (!triggered && threw) throw std::runtime_error("normal logical-ID lease allocation probe failed");
    if (!store->claimNativeGraphLogicalIdReservation(warm))
        throw std::runtime_error("failed acquisition changed an unrelated live lease capability");
    if (threw) {
        const auto rejectPhantoms = [&](const auto &ranges, bool node) {
            for (const auto &range : ranges) {
                NativeGraphLogicalIdReservation one;
                (node ? one.node_ranges : one.edge_ranges).push_back(range);
                if (store->claimNativeGraphLogicalIdReservation(one))
                    throw std::runtime_error("failed logical-ID acquisition leaked a claimable partial capability");
            }
        };
        rejectPhantoms(expected.node_ranges, true);
        rejectPhantoms(expected.edge_ranges, false);
    } else {
        if (result != expected || !store->claimNativeGraphLogicalIdReservation(result) ||
            store->claimNativeGraphLogicalIdReservation(result))
            throw std::runtime_error("successful logical-ID acquisition did not return one complete one-shot capability");
    }
    store.reset(); io.reset(); stream->close(); stream.reset();
    options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend reopened(options); reopened.open();
    (void)reopened.verifyIntegrity(); reopened.close();
    std::cout << "{\"mode\":\"" << mode << "\",\"allocation_attempts\":" << attempts
        << ",\"fault_triggered\":" << (triggered ? "true" : "false")
        << ",\"operation_threw\":" << (threw ? "true" : "false") << ",\"selected_fault\":";
    if (fault == (std::numeric_limits<size_t>::max)()) std::cout << "null";
    else std::cout << fault;
    std::cout << ",\"passed\":true}\n";
}

void scratchCrashCase(const std::string &mode, const char *path) {
    RelocatableStorageBackendOptions options;
    options.data_path = path;
    options.query_scratch_enabled = true;
    options.maximum_database_query_scratch_bytes = RSS_SEGMENT_SIZE;
    if (mode == "crash-query-scratch" || mode == "crash-existing-query-scratch") {
        const bool existing = mode == "crash-existing-query-scratch";
        options.open_mode = existing ? OpenMode::OPEN_EXISTING_FILE : OpenMode::OPEN_CREATE_NEW_FILE;
        auto backend = existing ? std::make_unique<RelocatableStorageBackend>(options)
                                : RelocatableStorageBackend::initializeNew(options);
        backend->open();
        if (!existing) {
            const auto id = backend->createLogicalNodes({{{"CrashSeed"}, {{"value", PropertyValue(int64_t{7})}}}}).front();
            if (id != 1U) throw std::runtime_error("scratch crash seed identity changed");
        } else {
            auto snapshot = backend->openLogicalGraphReadSnapshot();
            if (snapshot->readNodeProperty(1U, "value") != PropertyValue(int64_t{7}))
                throw std::runtime_error("repeated scratch crash changed user graph data");
        }
        auto scratch = backend->openNativeQueryScratchSession(RSS_SEGMENT_SIZE, 1U);
        if (!scratch) throw std::runtime_error("scratch crash could not open a private session");
        const std::vector<std::byte> bytes(4096U, std::byte{0x3A});
        const auto handle = scratch->write(bytes);
        if (scratch->read(handle) != bytes) throw std::runtime_error("scratch crash payload changed");
        // Deliberately skip every destructor and normal scratch release.
        std::_Exit(87);
    }
    const bool readonly = mode == "inspect-query-scratch-crash";
    options.open_mode = readonly ? OpenMode::OPEN_READ_ONLY_EXISTING_FILE : OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open(); backend.resetIoStats();
    {
        auto snapshot = backend.openLogicalGraphReadSnapshot();
        if (snapshot->readNodeProperty(1U, "value") != PropertyValue(int64_t{7}))
            throw std::runtime_error("scratch crash recovery changed user graph data");
    }
    if (readonly) {
        bool rejected = false;
        try { (void)backend.verifyIntegrity(); } catch (const FormatException &) { rejected = true; }
        if (!rejected) throw std::runtime_error("readonly integrity ignored orphaned scratch");
        if (backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE, 1U))
            throw std::runtime_error("physical readonly recovery permitted new scratch");
        if (backend.ioStats().data.write_bytes != 0U)
            throw std::runtime_error("readonly orphan inspection wrote database bytes");
    } else {
        (void)backend.verifyIntegrity();
        // The old one-segment per-database scratch quota must be reusable now.
        auto scratch = backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE, 1U);
        if (!scratch) throw std::runtime_error("recovered scratch quota was not reusable");
        const std::vector<std::byte> bytes(4096U, std::byte{0x6B});
        const auto handle = scratch->write(bytes);
        if (scratch->read(handle) != bytes) throw std::runtime_error("recovered scratch payload changed");
        scratch->finish(); (void)backend.verifyIntegrity();
    }
    backend.close();
    std::cout << "{\"mode\":\"" << mode << "\",\"readonly\":" << (readonly ? "true" : "false")
        << ",\"passed\":true}\n";
}
}
int main(int argc, char **argv) {
    if (argc != 3 && argc != 4) return 2;
    try {
        const std::string mode = argv[1];
        if (mode == "crash-query-scratch" || mode == "crash-existing-query-scratch" || mode == "inspect-query-scratch-crash" || mode == "recover-query-scratch-crash") {
            scratchCrashCase(mode, argv[2]);
            return 0;
        }
        if (mode == "property-heap-accounting") {
            propertyHeapAccountingCase(mode);
            return 0;
        }
        if (mode == "distinct-allocation-fault") {
            const size_t fault = argc == 4 ? static_cast<size_t>(std::stoull(argv[3])) : (std::numeric_limits<size_t>::max)();
            distinctAllocationFaultCase(mode, argv[2], fault);
            return 0;
        }
        if (mode == "scratch-write-allocation-fault") {
            const size_t fault = argc == 4 ? static_cast<size_t>(std::stoull(argv[3])) : (std::numeric_limits<size_t>::max)();
            scratchWriteAllocationFaultCase(mode, argv[2], fault);
            return 0;
        }
        if (mode == "lease-reserve-allocation-fault" || mode == "lease-cached-allocation-fault" ||
            mode == "lease-fresh-allocation-fault") {
            const size_t fault = argc == 4 ? static_cast<size_t>(std::stoull(argv[3])) : (std::numeric_limits<size_t>::max)();
            leaseAllocationFaultCase(mode, argv[2], fault);
            return 0;
        }
        const bool allocationFault = mode == "stage-allocation-fault" || mode == "commit-allocation-fault" || mode == "overlay-stage-allocation-fault" || mode == "creation-stage-allocation-fault" || mode == "overlay-creation-stage-allocation-fault" || mode == "mixed-stage-allocation-fault";
        if (!allocationFault && mode != "rollback-oom" && mode != "rollback-many-oom" && mode != "rollback-retention" && mode != "commit-retention") return 2;
        RelocatableStorageBackendOptions options;
        options.data_path = argv[2];
        options.open_mode = OpenMode::OPEN_CREATE_NEW_FILE;
        auto backend = RelocatableStorageBackend::initializeNew(options);
        backend->open();
        if (allocationFault) {
            const size_t fault = argc == 4 ? static_cast<size_t>(std::stoull(argv[3])) : (std::numeric_limits<size_t>::max)();
            if (mode == "mixed-stage-allocation-fault") mixedStatementAllocationFaultCase(mode, *backend, fault);
            else if (mode == "creation-stage-allocation-fault" || mode == "overlay-creation-stage-allocation-fault") creationAllocationFaultCase(mode, *backend, fault);
            else allocationFaultCase(mode, *backend, fault);
            return 0;
        }
        auto transaction = backend->beginLogicalGraphTransaction(false);
        size_t retained = 0U;
        if (mode == "commit-retention") {
            const auto id = stageNodes(*transaction, 1U, 1024U * 1024U);
            const auto result = transaction->commit();
            if (transaction->state() != LogicalGraphTransactionState::LGTTS_COMMITTED || result.created_node_ids != std::vector<uint64_t>{id}) return 3;
            retained = destroyClosed(transaction);
            auto snapshot = backend->openLogicalGraphReadSnapshot();
            if (snapshot->readNodeProperty(id, "payload") != PropertyValue(std::string(1024U * 1024U, 'q'))) return 4;
        } else {
            const size_t statements = mode == "rollback-many-oom" ? 40U : 1U;
            uint64_t abandoned = 0U;
            for (size_t statement = 0U; statement < statements; ++statement)
                abandoned = stageNodes(*transaction, mode == "rollback-retention" ? 8192U : 1U);
            {
                RejectAllocations rejection;
                transaction->rollback();
            }
            if (transaction->state() != LogicalGraphTransactionState::LGTTS_ROLLED_BACK) return 5;
            retained = destroyClosed(transaction);
            auto next = backend->beginLogicalGraphTransaction(false);
            const uint64_t nextId = stageNodes(*next, 1U);
            if (nextId <= abandoned) return 6;
            const auto result = next->commit();
            if (result.created_node_ids != std::vector<uint64_t>{nextId}) return 7;
            next.reset();
            auto snapshot = backend->openLogicalGraphReadSnapshot();
            if (snapshot->readNodeShaped(nextId, {}).node_id != nextId) return 8;
        }
        static_cast<void>(backend->verifyIntegrity());
        backend->close();
        backend->open();
        static_cast<void>(backend->verifyIntegrity());
        backend->close();
        std::cout << "{\"mode\":\"" << mode << "\",\"closed_object_bytes\":" << retained << ",\"passed\":true}\n";
        return 0;
    } catch (const std::exception &error) {
        denyAllocations.store(false, std::memory_order_relaxed);
        std::cerr << error.what() << '\n';
        return 10;
    }
}

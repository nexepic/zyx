from pathlib import Path
from collections import Counter,defaultdict
import subprocess,json
r=Path('/workspace/zyx/benchmarks/architecture-design/results/20261022-core-cost/post-endpoint-metadata-stages');out={}
for case in ['edge_batch_1000','property_set']:
 pc=defaultdict(Counter)
 for line in (r/(case+'-final-sampled.pcs')).read_text().splitlines()[1:]:
  path,addr,w,stage=line.split('\t');pc[(int(stage),path)][addr]+=int(w)
 groups=defaultdict(Counter)
 for (stage,path),addresses in pc.items():
  if stage not in [6,10,22,23,24,25]:continue
  names=['unresolved '+path]*len(addresses)
  if Path(path).is_file() and not path.endswith('libc.so.6'):
   p=subprocess.run(['addr2line','-f','-C','-e',path],input=''.join('0x'+a+'\n' for a in addresses),capture_output=True,text=True,check=True);names=p.stdout.splitlines()[::2];assert len(names)==len(addresses)
  for addr,name in zip(addresses,names):groups[stage][name]+=addresses[addr]
 out[case]={str(stage):{'ticks':sum(c.values()),'leaf_pcs':[{'function':f,'ticks':w,'percent':100*w/sum(c.values())} for f,w in c.most_common(14)]} for stage,c in groups.items()}
(r/'exclusive-leaf-functions.json').write_text(json.dumps(out,indent=2)+'\n')
for case,g in out.items():
 for stage,c in g.items():
  print(case,stage,c['ticks']);print('\n'.join(str(round(e['percent'],1))+' '+e['function'][:200] for e in c['leaf_pcs'][:8]))

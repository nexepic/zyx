from pathlib import Path
import json,subprocess,hashlib,shutil
repo=Path('/workspace/zyx');root=repo/'benchmarks/architecture-design/results/20261022-core-cost';old=root/'post-btree-graph-cpu';dest=root/'post-endpoint-metadata-stages';dest.mkdir(exist_ok=True);shutil.copyfile(old/'cpu-phase.hpp',dest/'cpu-phase.hpp')
s=(repo/'src/storage/relocatable/entity/NativeGraphWritePlanner.cpp').read_text();signature='NativeGraphWriteTransaction::commit(';start=s.index(signature);brace=s.index('{',start);s=s[:brace+1]+'\n cpu_phase::ForcedScope commitPhase(6);'+s[brace+1:]
changes={
'debug::ScopedPerfTimer adjacencyPlanTimer("native_graph.commit.adjacency_plan");':'cpu_phase::ForcedScope adjacencyPhase(11);',
'\t\tstd::vector<EntityPageBatchMutation> mutations;':'cpu_phase::current=12;',
'\t\tstd::vector<uint64_t> nodeMutationIds;':'cpu_phase::current=13;',
'\t\tfor (const auto &[nodeId, change]: nodes_) {\n\t\t\tif (change.inserted && !change.erased) {\n\t\t\t\tinsertNew':'cpu_phase::current=14;',
'        std::shared_ptr<query::execution::MaterializedByteBudget> pendingFieldsMemory;':'cpu_phase::current=15;',
'debug::ScopedPerfTimer propertyPlanTimer("native_graph.commit.property_plan");':'cpu_phase::ForcedScope propertyPhase(10);',
'\t\tstruct PendingDerivedIndexBinding {':'cpu_phase::current=16;'
}
for needle,injection in changes.items():
 assert s.count(needle)==1,(needle,s.count(needle))
 s=s.replace(needle,(needle+'\n'+injection) if needle.startswith('debug::') else (injection+'\n'+needle))
source=dest/'NativeGraphWritePlanner.cpp';source.write_text('#include "cpu-phase.hpp"\n'+s)
base=json.loads((old/'build.json').read_text());cmd=base['compile'][1][:]
for flag in ['-o','-MT','-MF']:cmd[cmd.index(flag)+1]=str(dest/('NativeGraphWritePlanner.d' if flag=='-MF' else 'NativeGraphWritePlanner.o'))
cmd[-1]=str(source)
link=[a for a in base['link'] if not a.endswith('/post-buffer-cpu/PropertyCollectionRootStore.o')];link=[str(dest/'NativeGraphWritePlanner.o') if a==str(old/'NativeGraphWritePlanner.o') else a for a in link];link[link.index('-o')+1]=str(dest/'cpu-probe');link=[a.replace('--dependency-file='+str(old/'cpu-link.d'),'--dependency-file='+str(dest/'cpu-link.d')) for a in link]
meta=(repo/'src/storage/relocatable/metadata/RelocatableMetadataStoreGraphMutation.cpp').read_text()
signature='RelocatableMetadataStore::mutateNativeGraphPagesWithLargeValues(';start=meta.index(signature);brace=meta.index('{',start);meta=meta[:brace+1]+'\n cpu_phase::ForcedScope metadataPhase(7);'+meta[brace+1:]
marks={
 'MetadataWriteGuard writer = beginWrite(':'cpu_phase::current=21;',
 '\t\tstd::vector<EntityPageReplacementMaterialization> materializations;':'cpu_phase::current=22;',
 'debug::ScopedPerfTimer preparationTimer("native_graph.mutation.prepare_materializations");':'cpu_phase::ForcedScope preparePhase(23);',
 'debug::ScopedPerfTimer materializationTimer("native_graph.mutation.finalize_materializations");':'cpu_phase::current=24;',
 'debug::ScopedPerfTimer publishTimer("native_graph.mutation.batch_publish");':'cpu_phase::ForcedScope publicationPhase(25);'
}
for n,inj in marks.items():
 assert meta.count(n)==1,(n,meta.count(n))
 meta=meta.replace(n,(n+'\n'+inj) if n.startswith('debug::') else inj+'\n'+n)
ms=dest/'RelocatableMetadataStoreGraphMutation.cpp';ms.write_text('#include "cpu-phase.hpp"\n'+meta);mc=base['compile'][2][:]
for flag in ['-o','-MT','-MF']:mc[mc.index(flag)+1]=str(dest/('RelocatableMetadataStoreGraphMutation.d' if flag=='-MF' else 'RelocatableMetadataStoreGraphMutation.o'))
mc[-1]=str(ms);link=[str(dest/'RelocatableMetadataStoreGraphMutation.o') if a==str(old/'RelocatableMetadataStoreGraphMutation.o') else a for a in link]
with (dest/'build.log').open('w') as log:
 for c in [cmd,mc,link]:subprocess.run(c,cwd=base['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True)
(dest/'build.json').write_text(json.dumps({'compile':[cmd,mc],'link':link,'cwd':base['cwd'],'source_sha256':hashlib.file_digest(source.open('rb'),'sha256').hexdigest(),'library_sha256':hashlib.file_digest(Path('/workspace/zyx-build-core-candidate/libzyx_core.a').open('rb'),'sha256').hexdigest(),'note':'old PropertyCollectionRootStore shadow explicitly removed: actual current archive supplies new batch implementation; other reused shadows unchanged source'},indent=2)+'\n')

from pathlib import Path
import json,subprocess,os,signal,sys,hashlib,time,importlib
sys.path.insert(0,'/workspace/zyx-resume-evaluation-20261018/final31fa-harness');owned=importlib.import_module('zyx-final-five-owned-case');r=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-window');assert(r/'read-campaign-completed.json').exists();subprocess.run([sys.executable,'/workspace/zyx-resume-evaluation-20261018/final31fa-harness/report-zyx-final-name-batch-reads.py'],check=True)
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.acceptance_sampling import select_read_supplements
report=json.loads((r/'read-comparison-progress.json').read_text())
primary={'label_scan_filter','all_nodes_property_filter','label_multi_property_filter','aggregation_count_by_group','aggregation_group_by','topk_property_sort'}
selected,reasons=select_read_supplements(report,primary)
partitions={}
for (scale,profile),items in selected.items():
 groups=[]
 for name,seconds in sorted(items,key=lambda v:(-v[1],v[0])):
  compatible=[i for i,p in enumerate(groups) if sum(v[1] for v in p)+seconds<=1200]
  if compatible:groups[min(compatible,key=lambda i:sum(v[1] for v in groups[i]))].append((name,seconds))
  else:groups.append([(name,seconds)])
 partitions[f'{scale}/{profile}']=[{'workloads':[v[0] for v in p],'expected_control_query_seconds':sum(v[1] for v in p),'minimum_launch_budget_seconds':sum(v[1] for v in p)+30} for p in groups]
plan={'status':'registered_before_any_supplement','source':'31faef71','rule':'Original controlP50range>5% or within5percentage points of gate, at most2independent100sample processes/source/workload. No Kuzu rerun.','cases':reasons,'partitions':partitions,'rounds':[4,5],'samples':100,'warmups':3,'maximum_seconds_per_process':1800,'maximum_total_seconds_per_original_profile_and_source':3600,'partition_target_expected_query_seconds':1200,'stop_rule':'Do not launch a shard if its preregistered control estimate+30s exceeds1800s or cannot fit that source/profile remaining3600s; mark unrun budget-exhausted. A failed/exhausted shard is never retried on that source. Successful processcounts stay explicit, no poolingwithbase.','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'case_script_sha256':hashlib.sha256(Path('/workspace/zyx-resume-evaluation-20261018/final31fa-harness/zyx-final-name-batch-extended-read.py').read_bytes()).hexdigest()};(r/'bounded-read-extension-registration.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'extension_plan':plan}),flush=True);results=[]
for (scale,profile),items in selected.items():
 spent={'control':0.,'current':0.};groups=partitions[f'{scale}/{profile}']
 for number,order in [(4,['control','current']),(5,['current','control'])]:
  for partition,part in enumerate(groups,1):
   for engine in order:
    names=part['workloads'];entry={'scale':scale,'profile':profile,'round':number,'engine':engine,'partition':partition,'workloads':names};prior=next((v for v in results if v['scale']==scale and v['profile']==profile and v['engine']==engine and set(v['workloads'])&set(names) and v['status']!='completed'),None);remaining=3600-spent[engine]
    if prior:entry.update(status='unmeasurable_previous_failure',reference=prior)
    elif part['minimum_launch_budget_seconds']>1800:entry.update(status='not_started_registered_estimate_exceeds_process_budget',maximum_process_seconds=1800,minimum_launch_budget_seconds=part['minimum_launch_budget_seconds'])
    elif remaining<part['minimum_launch_budget_seconds']:entry.update(status='not_started_original_profile_budget_insufficient',remaining_budget_seconds=remaining,minimum_launch_budget_seconds=part['minimum_launch_budget_seconds'])
    else:
     log=r/'logs'/f'extended-{scale}-{profile}-{number}-{engine}-part{partition}.log';env=dict(os.environ,ZYX_FINAL_EXTENDED_WORKLOADS=json.dumps(names));begin=time.monotonic();print(json.dumps({'event':'bounded-extension-start',**entry}),flush=True)
     with log.open('w') as output:
      p=subprocess.Popen([sys.executable,'/workspace/zyx-resume-evaluation-20261018/final31fa-harness/zyx-final-name-batch-extended-read.py','--engine',engine,'--round',str(number),'--profile',profile,'--scale',scale],env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True);timed=False
      try:p.wait(timeout=min(1800,remaining))
      except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
      except BaseException:
       if p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait()
       raise
     elapsed=time.monotonic()-begin;spent[engine]+=elapsed;cleanup_begin=time.monotonic();owned.cleanup_read(r,scale,number,engine,profile);entry.update(cleanup_seconds=time.monotonic()-cleanup_begin);entry.update(status='inconclusive_timeout' if timed else ('completed' if p.returncode==0 else 'failed'),returncode=p.returncode,log=str(log),elapsed_seconds=elapsed,spent_profile_source_seconds=spent[engine])
    target=r/'extended-read-case-status'/scale/profile/f'round-{number}'/f'{engine}-part{partition}.json';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(entry,indent=2)+'\n');results.append(entry);print(json.dumps(entry),flush=True)
(r/'bounded-read-extensions-completed.json').write_text(json.dumps({'cases':results,'no_additional_repeat_allowed':True},indent=2)+'\n')

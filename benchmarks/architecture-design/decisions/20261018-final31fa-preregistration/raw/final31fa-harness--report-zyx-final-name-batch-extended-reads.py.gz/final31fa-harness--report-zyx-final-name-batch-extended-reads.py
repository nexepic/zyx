from pathlib import Path
from collections import defaultdict
import json,statistics,math
r=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-window');groups=defaultdict(lambda:defaultdict(list));processes=[];failures=[]
def q(v,p):
 v=sorted(v);x=(len(v)-1)*p;a=math.floor(x);b=math.ceil(x);return v[a]+(v[b]-v[a])*(x-a)
for p in sorted((r/'extended-read-case-status').rglob('*.json')):
 case=json.loads(p.read_text())
 if case['status']!='completed':failures.append(case);continue
 raw=[]
 for f in (r/'reads'/case['scale']/f"round-{case['round']}"/case['engine']/case['profile']).rglob('raw.jsonl'):
  if not(f.parent/'correctness.json').exists():continue
  values=defaultdict(list)
  for line in f.open():
   x=json.loads(line)
   if x.get('event')=='sample' and x.get('status')=='ok':values[x['workload']].append(x['latency_ms'])
  if set(values)==set(case['workloads']):raw.append((f,values))
 assert len(raw)==1,(case,raw)
 f,values=raw[0];checks=json.loads((f.parent/'correctness.json').read_text());assert not checks['scalar']['failures'] and not checks['full_results']['failures']
 for name,v in values.items():
  assert len(v)==100
  item={'scale':case['scale'],'profile':case['profile'],'workload':name,'engine':case['engine'],'round':case['round'],'partition':case['partition'],'samples':100,'p50_ms':statistics.median(v),'p95_ms':q(v,.95),'full_results_verified':True};processes.append(item);groups[(case['scale'],name)][case['engine']].append(item)
rows=[]
for (scale,name),engines in sorted(groups.items()):
 x={'scale':scale,'workload':name,'processes':dict(engines),'automatic_acceptance':False}
 for e in ['control','current']:
  vv=engines.get(e,[]);x[e+'_processes']=len(vv)
  for field in ['p50_ms','p95_ms']:x[e+'_'+field]=statistics.median(v[field] for v in vv) if vv else None
 if x['control_processes'] and x['current_processes']:
  x['p50_reduction_vs_control']=1-x['current_p50_ms']/x['control_p50_ms'];x['p95_change_vs_control']=x['current_p95_ms']/x['control_p95_ms']-1
 rows.append(x)
payload={'source':'31faef71','status':'finite_budget_finished_requires_gate_review' if(r/'bounded-read-extensions-completed.json').exists() else 'in_progress_no_acceptance','processes':processes,'rows':rows,'failures':failures,'samples':sum(x['samples'] for x in processes),'no_base_or_source_sample_pooling':True,'no_skipped_or_partial_case_as_pass':True,'automatic_acceptance':False};(r/'extended-read-comparison.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps({'status':payload['status'],'samples':payload['samples'],'workloads':len(rows)}))

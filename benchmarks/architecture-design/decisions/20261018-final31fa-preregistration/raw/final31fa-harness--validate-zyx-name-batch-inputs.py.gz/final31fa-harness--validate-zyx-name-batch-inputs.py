from pathlib import Path
import json,hashlib,subprocess,sys,os,resource
root=Path('/workspace/zyx');r=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-window');sys.path.insert(0,str(root/'benchmarks/graphdb-comparison'));from runner.workload_preflight import compare_rows
out=r/'consumer-readonly-validation';out.mkdir(exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def restrict():
 os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3))
for scale in ['medium','holdout']:
 trace=Path('/workspace/zyx-optimization-final-window-20261016/bounded-preparation')/('completed-input-validation-'+scale)/'trace.json';cases=json.loads(trace.read_text())[:6];assert len(cases)==6 and all(v['command'][0]=='QUERY' and v['expected'] is not None for v in cases)
 db=r/'prepared-inputs'/scale/'current.zyx';before=digest(db);commands=''.join('\t'.join(v['command'])+'\n' for v in cases)+'STATS\n';proc=subprocess.run(['/tmp/zyx-dynamic-read-diagnostic',str(db)],input=commands,capture_output=True,text=True,timeout=120,preexec_fn=restrict);assert proc.returncode==0,proc.stderr;events=[json.loads(v) for v in proc.stdout.splitlines()];assert len(events)==7 and all(x['ok'] for x in events)
 for case,event in zip(cases,events):compare_rows(event['rows'],case['expected'])
 assert events[-1]['write_bytes']==0 and digest(db)==before
 record={'scale':scale,'queries':cases,'responses':events,'source_database_sha256':before,'binary_sha256':digest('/tmp/zyx-dynamic-read-diagnostic'),'shared_core_sha256':digest(root/'buildDir_perf_control/libzyx_core.a'),'purpose':'Physical readonly fullsixcounts, no formal timing samples or freshimport claim','formal_timing_samples':0,'source_bytes_unchanged':True};(out/f'{scale}.json').write_text(json.dumps(record,indent=2)+'\n')
 for engine in ['current','control']:
  p=r/'prepared-inputs'/scale/f'{engine}.zyx.json';meta=json.loads(p.read_text());meta['consumer_validation']='Current new64eeCore exactfullsixcounts physicallyreadonly passed onbyteidenticalsharedinput; originalcontrol prior readonlyvalidation remains sourceversioned. Everyformalresult stillfulloracle verified.';meta['new_core_six_counts_validation']=str(out/f'{scale}.json');p.write_text(json.dumps(meta,indent=2)+'\n')
 print(scale,'six exact counts passed,0writes, immutablehashunchanged',flush=True)

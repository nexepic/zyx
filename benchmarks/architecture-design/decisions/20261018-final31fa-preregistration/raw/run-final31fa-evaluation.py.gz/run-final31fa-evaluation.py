from pathlib import Path
import json,subprocess
r=Path('/workspace/zyx-resume-evaluation-20261018')
correctness=json.loads((r/'bounded-reclaim-contract-status.json').read_text())
assert correctness['all_six_completed'], 'Full required correctness must pass before final performance'
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python',str(r/'final31fa-harness/run-zyx-final-name-batch-contract-campaign.py'),'--phase','maintenance'],check=True)
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python',str(r/'final31fa-harness/report-zyx-final-name-batch-maintenance.py')],check=True)
from pathlib import Path
import subprocess,json,os,signal,hashlib
root=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-window')
orders=[['control','current','kuzu'],['current','kuzu','control'],['kuzu','control','current']]
import importlib,sys
sys.path.insert(0, '/workspace/zyx-resume-evaluation-20261018/final31fa-harness')
owned_case=importlib.import_module('zyx-final-five-owned-case')
results=[]
for scale,profile in [('medium','scan'),('medium','retrieval'),('medium','indexed'),('holdout','scan'),('holdout','retrieval')]:
 for number,order in enumerate(orders,1):
  for engine in order:
   previous=next((v for v in results if v['scale']==scale and v['profile']==profile and v['engine']==engine and v['status']!='completed'),None)
   case=root/'read-case-status'/scale/profile/f'round-{number}'/engine;case.mkdir(parents=True)
   entry={'scale':scale,'profile':profile,'round':number,'engine':engine}
   if previous:entry.update(status='unmeasurable_previous_failure',source=previous)
   else:
    log=root/'logs'/f'read-{scale}-{profile}-{number}-{engine}.log';print(json.dumps({'event':'read-start',**entry}),flush=True)
    command=['/workspace/zyx-benchmark-venv/bin/python','/workspace/zyx-resume-evaluation-20261018/final31fa-harness/zyx-final-name-batch-window.py','read','--engine',engine,'--scale',scale,'--profile',profile,'--round',str(number)]
    with log.open('w') as stream:
     process=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True);timeout=False
     try:process.wait(timeout=1800)
     except subprocess.TimeoutExpired:timeout=True;os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
     except BaseException:
      if process.poll() is None:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
      raise
    owned_case.cleanup_read(root,scale,number,engine,profile)
    entry.update(status='inconclusive_timeout' if timeout else ('completed' if process.returncode==0 else 'failed'),returncode=process.returncode,log=str(log))
   (case/'outcome.json').write_text(json.dumps(entry,indent=2)+'\n');results.append(entry);print(json.dumps(entry),flush=True)
(root/'read-campaign-completed.json').write_text(json.dumps({'cases':results,'all_slots_accounted':True,'all_passed':all(v['status']=='completed' for v in results)},indent=2)+'\n')
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python','/workspace/zyx-resume-evaluation-20261018/final31fa-harness/zyx-final-name-batch-bounded-extensions.py'],check=True)
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python','/workspace/zyx-resume-evaluation-20261018/final31fa-harness/report-zyx-final-name-batch-extended-reads.py'],check=True)
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python','/workspace/zyx-resume-evaluation-20261018/final31fa-harness/run-zyx-final-name-batch-write-campaign.py'],check=True)
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python','/workspace/zyx-resume-evaluation-20261018/final31fa-harness/report-zyx-final-name-batch-writes.py'],check=True)
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python','/workspace/zyx-resume-evaluation-20261018/final31fa-harness/zyx-final-name-batch-bounded-write-extensions.py'],check=True)
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python','/workspace/zyx-resume-evaluation-20261018/final31fa-harness/report-zyx-final-name-batch-extended-writes.py'],check=True)
subprocess.run(['/workspace/zyx-benchmark-venv/bin/python',str(r/'final31fa-harness/run-zyx-final-name-batch-contract-campaign.py'),'--phase','rest'],check=True)
(root/'independent-read-write-completed.json').write_text(json.dumps({'status':'read_write_slots_accounted_requires_gate_review','automatic_acceptance':False,'remaining_contracts':'all remaining family slots accounted; required31fa wide/dynamic correctness retained separately'},indent=2)+'\n')

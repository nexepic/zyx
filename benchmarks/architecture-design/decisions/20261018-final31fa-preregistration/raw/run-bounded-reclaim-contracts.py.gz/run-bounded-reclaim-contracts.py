from pathlib import Path
import json,subprocess,os,signal,sys,hashlib,shutil,datetime
r=Path('/workspace/zyx-resume-evaluation-20261018');root=Path('/workspace/zyx');source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no','--','src','include','apps','tests'],cwd=root,text=True).strip()
freeze=r/'frozen-bounded-reclaim-binaries';freeze.mkdir(exist_ok=False)
for name in ['zyx-workload-contract-worker','zyx-compare-bench']:shutil.copy2(root/'buildDir_final'/name,freeze/name)
worker=freeze/'zyx-workload-contract-worker';registration={'status':'registered_before_first_full_case','source_commit':source,'worker':str(worker),'worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'benchmark_sha256':hashlib.sha256((freeze/'zyx-compare-bench').read_bytes()).hexdigest(),'cases':{'rounds':[1,2,3],'families':['wide_large','dynamic']},'case_wrapper_sha256':hashlib.sha256((r/'run-bounded-reclaim-contract-case.py').read_bytes()).hexdigest(),'unchanged_limits':{'family_seconds':1800,'AS_bytes':6*1024**3,'file_bytes':2*1024**3,'query_bytes':64*1024**2},'stop_on_first_required_family_failure':True,'same_failed_source_family_not_retried':True,'formal_performance_samples':0,'dynamic_deadline_amendment_not_applied':True};(r/'bounded-reclaim-freeze.json').write_text(json.dumps(registration,indent=2)+'\n');results=[]
for number in [1,2,3]:
 for family in ['wide_large','dynamic']:
  print(json.dumps({'event':'full-correctness-start','round':number,'family':family,'source':source}),flush=True);log=r/f'bounded-reclaim-contract-{number}-{family}.log'
  with log.open('w') as output:
   process=subprocess.Popen([sys.executable,str(r/'run-bounded-reclaim-contract-case.py'),'--round',str(number),'--family',family],stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=process.wait(timeout=1860)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait();code=-9
   except BaseException:
    if process.poll() is None:os.killpg(process.pid,signal.SIGKILL);process.wait()
    raise
  result={'round':number,'family':family,'returncode':code,'status':'completed' if code==0 else 'failed','log':str(log)};results.append(result);(r/'bounded-reclaim-contract-status.json').write_text(json.dumps({'cases':results,'all_six_completed':len(results)==6 and all(v['returncode']==0 for v in results),'automatic_acceptance':False},indent=2)+'\n');print(json.dumps(result),flush=True)
  if code:raise SystemExit(code if code>0 else 1)

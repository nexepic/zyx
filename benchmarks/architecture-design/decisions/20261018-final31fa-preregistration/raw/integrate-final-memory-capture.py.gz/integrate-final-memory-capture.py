from pathlib import Path
import ast
r=Path('/workspace/zyx-resume-evaluation-20261018');h=r/'final31fa-harness'
helper='''from pathlib import Path
import os,json,hashlib

def configure_native_report(out,engine,scale,profile,number,workloads):
 os.environ.pop('ZYX_COMPARE_PROCESS_MEMORY_REPORT',None)
 if engine=='kuzu':return
 key=hashlib.sha256(json.dumps(list(workloads),separators=(',',':')).encode()).hexdigest()[:16]
 target=out/'native-process-resources'/scale/profile/f'round-{number}'/engine/(key+'.json')
 target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():raise ValueError('Refuse to overwrite prior native memory observation')
 os.environ['ZYX_COMPARE_PROCESS_MEMORY_REPORT']=str(target)

def capture_worker_peak(worker,target):
 # Read after all observations, before worker close; never in an operation timer.
 # VmHWM excludes the forked Python parent's pre-exec memory image.
 status=Path(f'/proc/{worker.process.pid}/status').read_text()
 line=next(line for line in status.splitlines() if line.startswith('VmHWM:'))
 peak=int(line.split()[1])*1024
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_text(json.dumps({'peak_rss_bytes':peak,'source':'linux_post_exec_VmHWM','scope':'native worker high-water through final validation, sampled before close; close peak not covered','capture':'outside operation/query timers','legacy_child_rusage_not_used_as_isolated_engine_peak':True},indent=2)+'\\n')
'''
(h/'native_process_memory.py').write_text(helper)
for name in ['zyx-final-name-batch-window.py','zyx-final-name-batch-extended-read.py']:
 p=h/name;s=p.read_text();needle=" result=run_benchmark([actual],scale,314159 if scale=='holdout' else 42,folder,3,iterations,profile=profile,threads=1,observe_result_rows=True)";assert needle in s;s=s.replace(needle," from native_process_memory import configure_native_report\n configure_native_report(OUT,engine,scale,profile,round_number,workloads)\n"+needle);p.write_text(s)
p=h/'zyx-final-name-batch-window.py';s=p.read_text();s=s.replace("if file_limit not in [2*1024**3,4*1024**3] or (file_limit==4*1024**3 and os.environ.get('ZYX_FINAL_CASE_FAMILY')!='wide_large')",'if file_limit!=2*1024**3');p.write_text(s)
p=h/'zyx-final-name-batch-write-case.py';s=p.read_text();needle='from runner.workload_preflight import NativeWorker,compare_rows';assert needle in s;s=s.replace(needle,needle+'''
from native_process_memory import capture_worker_peak
_original_worker_close=NativeWorker.close
def _close_with_peak(self):
 if self.process.poll() is None:
  capture_worker_peak(self,root/'native-process-memory-before-close.json')
 return _original_worker_close(self)
NativeWorker.close=_close_with_peak
''');s=s.replace("'resource_scope':'whole profile including baseline creation and validation; native launches exactly one worker and no Git helper'","'resource_scope':'Legacy rusage may include pre-exec parent memory; native-process-memory-before-close.json reports engine VmHWM through validation separately'");p.write_text(s)
p=h/'zyx-final-name-batch-contract-case.py';s=p.read_text();needle="   stats=self.call('STATS')";assert needle in s;s=s.replace(needle,needle+"\n   from native_process_memory import capture_worker_peak\n   capture_worker_peak(self,window.OUT/'contract'/f'round-{a.round}'/a.engine/a.family/'native-process-memory-before-close.json')");s=s.replace("'native worker child peak; one worker per isolated case'","'legacy child rusage may include parent pre-exec peak; use separately captured native VmHWM through final validation'");p.write_text(s)
for p in h.glob('*.py'):ast.parse(p.read_text())
print('Local read/worker memory capture added outside timers; no engine or workload change; not measured yet')

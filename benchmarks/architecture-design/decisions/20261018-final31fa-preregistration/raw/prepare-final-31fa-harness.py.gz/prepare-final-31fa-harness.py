from pathlib import Path
import json,ast,hashlib,os
r=Path('/workspace/zyx-resume-evaluation-20261018');old=r/'harness';new=r/'final31fa-harness';out=r/'final31fa-window';new.mkdir(exist_ok=False);out.mkdir(exist_ok=False);(out/'logs').mkdir();mapping={str(r/'harness'):str(new),str(r/'window'):str(out),"Path('/workspace/zyx-control-d09fc467/build')":repr(str(r/'frozen-control-resource-report-binaries')),"Path('/workspace/zyx/buildDir_final')":repr(str(r/'frozen-bounded-reclaim-binaries'))};records=[]
for p in old.glob('*.py'):
 s=p.read_text()
 for a,b in mapping.items():s=s.replace(a,b)
 # Binary locations remain Paths, even after relocation.
 s=s.replace("CONTROL='", "CONTROL=Path('").replace("binaries';CURRENT=", "binaries');CURRENT=") if False else s
 s=s.replace("CONTROL="+repr(str(r/'frozen-control-resource-report-binaries')),"CONTROL=Path("+repr(str(r/'frozen-control-resource-report-binaries'))+")").replace("CURRENT="+repr(str(r/'frozen-bounded-reclaim-binaries')),"CURRENT=Path("+repr(str(r/'frozen-bounded-reclaim-binaries'))+")")
 s=s.replace('648e60ff/5fc768cb','31faef71').replace('648e60ff','31faef71')
 ast.parse(s);(new/p.name).write_text(s);records.append({'file':p.name,'original_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'adapted_sha256':hashlib.sha256(s.encode()).hexdigest()})
# Reuse immutable physical inputs. Each consumer receives a new manifest, never
# modify either the historical database or its historical consumer manifest.
for scale in ['medium','holdout']:
 folder=out/'prepared-inputs'/scale;folder.mkdir(parents=True)
 for engine in ['current','control']:
  src=r/'window/prepared-inputs'/scale/(engine+'.zyx');dst=folder/src.name;os.link(src,dst);d=json.loads(Path(str(src)+'.json').read_text());binary=r/('frozen-bounded-reclaim-binaries' if engine=='current' else 'frozen-control-resource-report-binaries')/'zyx-compare-bench';d['consumer_binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest();d['consumer_manifest_refresh_only']=True;d['original_manifest']=str(src)+'.json';d['original_physical_input_unchanged']=True;Path(str(dst)+'.json').write_text(json.dumps(d,indent=2)+'\n')
(out/'path-adaptation.json').write_text(json.dumps({'status':'prepared_not_measured_or_accepted','source':'31faef71179c295bbfd5b204be6c87b3a2481040','records':records,'limits_unchanged':True,'formal_runs_started':False,'native_memory_report_integration':'pending_before_registration','full_required_correctness':'running_separately_must_pass_before_performance'},indent=2)+'\n');print('Prepared local harness and immutable input links only; no benchmark started')

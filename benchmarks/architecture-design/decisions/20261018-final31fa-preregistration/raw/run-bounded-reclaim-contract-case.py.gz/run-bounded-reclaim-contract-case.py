from pathlib import Path
import argparse,os,sys,json,resource,hashlib,shutil,time,subprocess
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
import runner.workload_preflight as wf
r=Path('/workspace/zyx-resume-evaluation-20261018');root=Path('/workspace/zyx');p=argparse.ArgumentParser();p.add_argument('--family',choices=['wide_large','dynamic'],required=True);p.add_argument('--round',type=int,choices=[1,2,3],required=True);a=p.parse_args();out=r/'bounded-reclaim-contracts'/f'round-{a.round}'/'current'/a.family;assert not out.exists()
freeze=json.loads((r/'bounded-reclaim-freeze.json').read_text());binary=Path(freeze['worker']);assert hashlib.sha256(binary.read_bytes()).hexdigest()==freeze['worker_sha256'];assert 'ZYX_APPROVED_DYNAMIC_TIMEOUT_SECONDS' not in os.environ
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3));os.environ['ZYX_CONTRACT_OPERATION_TIMEOUT_SECONDS']='1800';begin=time.monotonic()
registration={'source_commit':freeze['source_commit'],'family':a.family,'round':a.round,'worker_sha256':freeze['worker_sha256'],'runner_sha256':hashlib.sha256(Path(wf.__file__).read_bytes()).hexdigest(),'scope':'Full correctness only, zero performance samples','family_seconds':1800,'address_space_bytes':6*1024**3,'file_bytes':2*1024**3,'query_bytes':64*1024**2,'threads':1,'extra_observation':'write progress after every100verified existing operations; no extra database queries','keep_failed_endpoint_for_diagnosis':True,'prior_frozen_648_source_failure_not_retried':True}
record=r/'bounded-reclaim-contract-registration'/f'round-{a.round}-{a.family}.json';record.parent.mkdir(exist_ok=True);assert not record.exists();record.write_text(json.dumps(registration,indent=2)+'\n')
BaseWorker=wf.NativeWorker
class ProgressWorker(BaseWorker):
 def call(self,*args,**kwargs):
  result=super().call(*args,**kwargs)
  if len(self.trace)%100==0:
   (out/'observed-progress.json').write_text(json.dumps({'verified_operations':len(self.trace),'elapsed_seconds':time.monotonic()-begin,'last_command':str(args[:2])[:180],'performance_samples':0},indent=2)+'\n')
  return result
wf.NativeWorker=ProgressWorker
BaseDirectory=wf.tempfile.TemporaryDirectory
class SaveFailureDirectory(BaseDirectory):
 def __exit__(self,kind,value,traceback):
  if kind is not None:
   db=Path(self.name)/'database.zyx'
   if db.exists():
    saved=out/'failed-endpoint.zyx';shutil.copy2(db,saved);(out/'failed-endpoint.json').write_text(json.dumps({'bytes':saved.stat().st_size,'sha256':hashlib.sha256(saved.read_bytes()).hexdigest(),'status':'incomplete_family_failure_endpoint_not_success','error':str(value)},indent=2)+'\n')
  return super().__exit__(kind,value,traceback)
wf.tempfile.TemporaryDirectory=SaveFailureDirectory
try:
 report=wf.run_native(binary,out,profile='contract',seed=42,family=a.family)
 outcome={'status':'completed_full_correctness','family':a.family,'round':a.round,'operations':report['operations'],'full_results_checked':report['full_results_checked'],'elapsed_seconds':time.monotonic()-begin,'formal_performance_samples':0}
except BaseException as error:
 outcome={'status':'failed_full_correctness','family':a.family,'round':a.round,'error':str(error),'elapsed_seconds':time.monotonic()-begin,'formal_performance_samples':0}
 (out/'case-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True);raise
(out/'case-outcome.json').write_text(json.dumps(outcome,indent=2)+'\n');print(json.dumps(outcome),flush=True)

from pathlib import Path
import json,statistics,math,re
r=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-window')
def q(values,p):
 s=sorted(values);v=(len(s)-1)*p;a=math.floor(v);b=math.ceil(v);return s[a]+(s[b]-s[a])*(v-a)
rows=[];groups={};unmeasurable=[]
for marker in sorted((r/'contract').glob('round-*/*/maintenance/campaign-case-*.json')):
 case=json.loads(marker.read_text());e=case['engine'];n=case['round']
 if case['status']!='completed':unmeasurable.append(case);continue
 folder=marker.parent;records=json.loads((folder/'ipc-operation-timings.json').read_text())['operations'];values=[];windows={};costs={}
 for x in records:
  if x.get('sampling_phase')!='measure':continue
  query=x.get('query','');ms=x['ns']/1e6
  if query.startswith('CREATE ') and ':Churn' in query:
   values.append(ms);match=re.search(r'id:\s*(\d+)',query)
   if match:windows.setdefault(int(match.group(1))//10000,[]).append(ms)
  if x.get('command')=='MAINTAIN':costs.setdefault('explicit_maintenance_ms',[]).append(ms)
  if query.startswith('MATCH (n:Churn) DELETE'):costs.setdefault('delete10000_nodes_ms',[]).append(ms)
 assert len(values)==1000,(e,n,len(values));report=json.loads((folder/'report.json').read_text());ww=report['maintenance_windows'];assert len(ww)==10 and report['full_results_checked'];elapsed=json.loads((folder/'elapsed.json').read_text())
 row={'engine':e,'round':n,'insert_samples':1000,'nodes_per_insert_batch':100,'insert_p50_ms':statistics.median(values),'insert_p95_ms':q(values,.95),'per_window_insert':[{'window':k+1,'samples':len(v),'p50_ms':statistics.median(v),'p95_ms':q(v,.95)} for k,v in sorted(windows.items())],'full13window_correctness':True,'file_bytes':[x['file_bytes'] for x in ww],'file_growth_fraction':ww[-1]['file_bytes']/ww[0]['file_bytes']-1,'peak_whole_case_rss_kib':elapsed['maxrss_kib'],'whole_case_seconds_including_setup_warmups_checks':elapsed['wall_seconds'],'raw_window_resources':ww,'separate_operation_costs':{k:{'samples':len(v),'total_ms':sum(v),'p50_ms':statistics.median(v),'descriptive_p95_ms':q(v,.95)} for k,v in costs.items()},'automatic_acceptance':False};rows.append(row);groups.setdefault(e,[]).append(row)
summary={}
for e,values in groups.items():
 summary[e]={'independent_processes':len(values),'insert_samples':sum(v['insert_samples'] for v in values),'median_process_insert_p50_ms':statistics.median(v['insert_p50_ms'] for v in values),'median_process_insert_p95_ms':statistics.median(v['insert_p95_ms'] for v in values),'file_growth_fractions':[v['file_growth_fraction'] for v in values],'peak_whole_case_rss_kib':[v['peak_whole_case_rss_kib'] for v in values]}
payload={'source':'31faef71','scope':'Process-level summaries, never pool1000correlated samples as independent processes. NativeIPC vs KuzuPython and implicitCREATEoutput/durability differ; no strict cross-engine win or ratio inferred. Whole-case wall/RSS includes setup,warmups,checks,close. WindowIO counters reset atREOPEN; preserve per-window deltas separately.','automatic_acceptance':False,'processes':rows,'summary':summary,'unmeasurable':unmeasurable,'baseline_note':'Frozen originalcontrol has the exact retained deterministic deletion failure,0valid steady processes/samples/ratios. Kuzu file growth and memory are observations, not optimization-candidate gate waivers.'};(r/'maintenance-comparison-progress.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(summary))

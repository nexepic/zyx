from pathlib import Path
import json,subprocess,signal,os,sys,importlib,hashlib,ast,shutil
sys.path.insert(0,'/workspace/zyx-resume-evaluation-20261018/final31fa-harness');owned=importlib.import_module('zyx-final-five-owned-case');r=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-window');assert (r/'write-campaign-completed.json').exists()
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.acceptance_sampling import select_write_supplements
m=json.loads((r/'write-comparison-progress.json').read_text());reasons=select_write_supplements(m)
s=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-harness/zyx-final-name-batch-write-case.py').read_text().replace("'sampling_unit':'one native worker or Kuzu in-process engine per independent round, each workload has3warmup+10measured restored-baseline samples; backend opens and validation outside timer'","'sampling_unit':f'one native worker or Kuzu in-process engine per independent round, each workload has3warmup+{a.samples}measured restored-baseline samples; backend opens and validation outside timer'");ast.parse(s);case=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-harness/zyx-final-name-batch-extended-write.py');case.write_text(s)
plan={'status':'registered_before_supplement','source':'31faef71','cases':reasons,'rounds':[4,5],'warmups':3,'samples':100,'finite_rule':'Original controlP50range>5%, unstableP95range>5% or near5% gate; at most2processes/source/workload, no Kuzu or further same-source repeats.','maintenance_failure_not_waived':True,'source_binaries_timers_quotas_changed':False,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'case_sha256':hashlib.sha256(case.read_bytes()).hexdigest()};(r/'bounded-write-extension-registration.json').write_text(json.dumps(plan,indent=2)+'\n');(r/'followup-harness').mkdir();shutil.copy2(case,r/'followup-harness'/case.name);shutil.copy2(__file__,r/'followup-harness'/Path(__file__).name)
if not reasons:
 (r/'bounded-write-extensions-completed.json').write_text(json.dumps({'cases':[],'no_triggered_workloads':True,'same_source_repeat_budget_exhausted':False},indent=2)+'\n');raise SystemExit(0)
results=[]
for number,order in [(4,['control','current']),(5,['current','control'])]:
 for engine in order:
  key=f'write-extended-{number}-{engine}';log=r/'logs'/(key+'.log');command=[sys.executable,str(case),'--engine',engine,'--round',str(number),'--samples','100']
  for x in reasons:command.extend(['--workload',x['workload']])
  print(json.dumps({'event':'bounded-write-start','round':number,'engine':engine,'workloads':len(reasons)}),flush=True)
  with log.open('w') as output:
   p=subprocess.Popen(command,stdout=output,stderr=subprocess.STDOUT,start_new_session=True);timeout=False
   try:p.wait(timeout=1800)
   except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   except BaseException:
    if p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
    raise
  owned.cleanup_contract(r,f'write-round-{number}-{engine}');entry={'round':number,'engine':engine,'status':'inconclusive_timeout' if timeout else ('completed' if p.returncode==0 else 'failed'),'log':str(log),'returncode':p.returncode};results.append(entry);target=r/'extended-write-case-status'/f'{number}-{engine}.json';target.parent.mkdir(exist_ok=True);target.write_text(json.dumps(entry,indent=2)+'\n');print(json.dumps(entry),flush=True)
(r/'bounded-write-extensions-completed.json').write_text(json.dumps({'cases':results,'same_source_repeat_budget_exhausted':True},indent=2)+'\n')

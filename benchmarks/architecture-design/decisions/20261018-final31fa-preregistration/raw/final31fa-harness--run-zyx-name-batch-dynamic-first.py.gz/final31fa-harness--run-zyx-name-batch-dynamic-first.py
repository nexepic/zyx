from pathlib import Path
import json,subprocess,sys,os,signal,time,hashlib,importlib
sys.path.insert(0,'/workspace/zyx-resume-evaluation-20261018/final31fa-harness');owned=importlib.import_module('zyx-final-five-owned-case');r=Path('/workspace/zyx-resume-evaluation-20261018/final31fa-window');reg=json.loads((r/'registration.json').read_text());os.environ.update(ZYX_FROZEN_BASELINE_WORKER=reg['current_frozen_worker'],ZYX_FROZEN_BASELINE_HARNESS=reg['frozen_harness']);case=r/'contract/round-1/current/dynamic';assert not case.exists();log=r/'logs/contract-1-current-dynamic-first.log';start=time.monotonic();timed=False
print(json.dumps({'event':'first_actual_dynamic_gate_start','source':'31faef71','full_entities':10000,'same1800sec_cap':True}),flush=True)
with log.open('w') as out:
 p=subprocess.Popen([sys.executable,'/workspace/zyx-resume-evaluation-20261018/final31fa-harness/zyx-final-name-batch-contract-case.py','--engine','current','--round','1','--seed','42','--family','dynamic'],stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 try:p.wait(timeout=1800)
 except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 except BaseException:
  if p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait()
  raise
case.mkdir(parents=True,exist_ok=True);status='inconclusive_timeout' if timed else ('completed' if p.returncode==0 else 'failed');entry={'round':1,'engine':'current','family':'dynamic','status':status,'returncode':p.returncode,'log':str(log),'elapsed_seconds':time.monotonic()-start,'sampling_scope':'Full-size semantic/capability firstgate, not invented warmlatency distribution or a ratio to the timedoutoriginalcontrol.'};(case/('campaign-case-completed.json' if status=='completed' else 'campaign-case-failed.json')).write_text(json.dumps(entry,indent=2)+'\n')
if status!='completed':
 ledger=r/'owned-temporaries/round-1-current-dynamic.json'
 if ledger.exists():
  for x in json.loads(ledger.read_text()):
   folder=Path(x['path'])
   if folder.exists():
    st=folder.stat();assert(st.st_dev,st.st_ino)==(x['device'],x['inode'])
    for db in folder.glob('*.zyx'):
     target=r/'diagnostic-dynamic-round1-current.zyx'
     if not target.exists():os.link(db,target)
owned.cleanup_contract(r,'round-1-current-dynamic');print(json.dumps(entry),flush=True)
if status!='completed':
 (r/'stopped-after-dynamic-first-gate.json').write_text(json.dumps(entry,indent=2)+'\n');raise SystemExit(1)
report=json.loads((case/'report.json').read_text());assert report['full_results_checked'];(r/'dynamic-first-gate-completed.json').write_text(json.dumps(entry,indent=2)+'\n')
subprocess.run([sys.executable,'/workspace/zyx-resume-evaluation-20261018/final31fa-harness/run-zyx-final-name-batch-acceptance.py'],check=True)

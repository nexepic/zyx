#!/usr/bin/env python3
"""Run explicitly selected transaction OOM/retention cases in isolated processes."""
import argparse
import concurrent.futures
import json
import hashlib
import pathlib
import subprocess
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", required=True, type=pathlib.Path)
    parser.add_argument("--output", type=pathlib.Path)
    parser.add_argument("--crash-recovery", action="store_true")
    parser.add_argument("--allocation-sweep", choices=("none", "stage", "commit", "both"), default="none")
    parser.add_argument("--jobs", type=int, default=4)
    parser.add_argument("--progress-every", type=int, default=0)
    parser.add_argument("--max-sweep-points", type=int, default=0,
                        help="zero tests every allocation in the normal operation; positive values sample evenly")
    args = parser.parse_args()
    if args.jobs < 1 or args.max_sweep_points < 0 or args.progress_every < 0:
        parser.error("jobs must be positive and max-sweep-points nonnegative")
    worker = args.worker.resolve(strict=True)
    results = []
    sweeps = {}
    crash_recovery = None
    with tempfile.TemporaryDirectory(prefix="zyx-transaction-resource-") as temporary:
        def run(mode, fault=None, database_path=None):
            suffix = "probe" if fault is None else str(fault)
            path = database_path or pathlib.Path(temporary) / (mode + "-" + suffix + ".zyx")
            command = [str(worker), mode, str(path)]
            if fault is not None:
                command.append(str(fault))
            completed = subprocess.run(command, text=True, capture_output=True, timeout=120, check=False)
            if completed.returncode:
                raise RuntimeError(f"{mode} fault={fault} exited {completed.returncode}: {completed.stderr.strip()}")
            evidence = json.loads(completed.stdout)
            if evidence.get("mode") != mode or evidence.get("passed") is not True:
                raise RuntimeError(f"{mode} fault={fault} returned invalid evidence: {evidence!r}")
            if fault is not None and evidence.get("fault_triggered") is not True:
                raise RuntimeError(f"{mode} fault={fault} did not reach the selected allocation")
            if database_path is None:
                path.unlink(missing_ok=True)
            return evidence

        for mode in ("rollback-oom", "rollback-many-oom", "rollback-retention", "commit-retention"):
            results.append(run(mode))
        if args.crash_recovery:
            path = pathlib.Path(temporary) / "crashed-scratch.zyx"
            crashed = subprocess.run([str(worker), "crash-query-scratch", str(path)],
                                     text=True, capture_output=True, timeout=120, check=False)
            if crashed.returncode != 87:
                raise RuntimeError(f"scratch crash exited {crashed.returncode}: {crashed.stderr.strip()}")
            before = hashlib.sha256(path.read_bytes()).hexdigest()
            readonly = run("inspect-query-scratch-crash", database_path=path)
            after = hashlib.sha256(path.read_bytes()).hexdigest()
            if before != after:
                raise RuntimeError("physical readonly orphan inspection changed database bytes")
            recovered = run("recover-query-scratch-crash", database_path=path)
            crash_recovery = {"crash_exit": crashed.returncode, "readonly": readonly,
                              "readonly_before_sha256": before, "readonly_after_sha256": after,
                              "recovered": recovered, "passed": True}
        for phase in ("stage", "commit"):
            if args.allocation_sweep not in (phase, "both"):
                continue
            mode = phase + "-allocation-fault"
            probe = run(mode)
            count = probe["allocation_attempts"]
            if not isinstance(count, int) or count < 1:
                raise RuntimeError(f"{mode} has no allocation probe")
            if args.max_sweep_points and args.max_sweep_points < count:
                selected = sorted({index * (count - 1) // max(1, args.max_sweep_points - 1)
                                   for index in range(args.max_sweep_points)})
            else:
                selected = list(range(count))
            cases = []
            executor = concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs)
            pending = {executor.submit(run, mode, fault): fault for fault in selected}
            try:
                for future in concurrent.futures.as_completed(pending):
                    cases.append(future.result())
                    if args.progress_every and len(cases) % args.progress_every == 0:
                        print(f"{mode}: {len(cases)}/{len(selected)} allocation faults passed", file=sys.stderr, flush=True)
            except BaseException:
                for future in pending:
                    future.cancel()
                executor.shutdown(wait=True, cancel_futures=True)
                raise
            else:
                executor.shutdown(wait=True)
            cases.sort(key=lambda item: item["selected_fault"])
            sweeps[phase] = {"probe": probe, "baseline_allocations": count,
                             "tested_allocations": len(cases), "exhaustive": len(cases) == count,
                             "cases": cases}
    report = {"cases": results, "allocation_sweeps": sweeps, "crash_recovery": crash_recovery,
              "passed": len(results) + sum(item["tested_allocations"] for item in sweeps.values()) + int(crash_recovery is not None),
              "failures": 0, "full_suite": False}
    encoded = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")


if __name__ == "__main__":
    main()

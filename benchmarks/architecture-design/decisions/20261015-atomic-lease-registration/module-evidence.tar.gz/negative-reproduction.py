from pathlib import Path
import subprocess,shlex,json
root=Path('/workspace/zyx');build=root/'buildDir'
original=root/'src/storage/relocatable/metadata/RelocatableMetadataStore.cpp';old=Path('/tmp/zyx-lease-registration-old-metadata.cpp')
target='CMakeFiles/zyx_core.dir/src/storage/relocatable/metadata/RelocatableMetadataStore.cpp.o'
command=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],cwd=root,text=True).strip().splitlines()[-1])
for flag,value in [('-o','/tmp/zyx-old-lease-registration.o'),('-MF','/tmp/zyx-old-lease-registration.d')]:command[command.index(flag)+1]=value
command[command.index(str(original))]=str(old)
subprocess.run(command,cwd=build,check=True)
tokens=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','zyx_transaction_resource_fault_worker'],cwd=root,text=True).strip().splitlines()[-1]);start=tokens.index('&&')+1;end=tokens.index('&&',start) if '&&' in tokens[start:] else len(tokens);link=tokens[start:end];index=0
while index<len(link):
 if link[index]=='-Xlinker' and index+1<len(link) and link[index+1].startswith('--dependency-file='):del link[index:index+2]
 else:index+=1
link.insert(link.index('libzyx_core.a'),'/tmp/zyx-old-lease-registration.o');link[link.index('-o')+1]='/tmp/zyx-old-lease-registration-worker';subprocess.run(link,cwd=build,check=True)
for phase in ('lease-reserve','lease-cached','lease-fresh'):
 prefix='/tmp/zyx-negative-'+phase
 with open(prefix+'.log','w') as log:result=subprocess.run(['python3','scripts/test_transaction_resource_faults.py','--worker','/tmp/zyx-old-lease-registration-worker','--allocation-sweep',phase,'--max-sweep-points','2','--output',prefix+'.json'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 evidence=Path(prefix+'.log').read_text();print(phase,'negative exit',result.returncode,flush=True)
 if result.returncode==0 or 'failed logical-ID acquisition leaked a claimable partial capability' not in evidence:
  raise RuntimeError('old logical-ID registration did not reproduce partial capability leakage: '+phase)

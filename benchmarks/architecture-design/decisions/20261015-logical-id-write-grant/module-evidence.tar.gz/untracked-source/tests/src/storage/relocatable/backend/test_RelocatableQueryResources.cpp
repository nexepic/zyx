#include "storage/relocatable/backend/RelocatableStorageBackendTestFixture.hpp"
#include "query/execution/ProcessResourceDomains.hpp"
#include "graph/utils/OwnedPmrAllocator.hpp"

using namespace relocatable_storage_backend_test;

TEST_F(RelocatableStorageBackendTest, NativeQueryOutputRetainsItsMemoryDomainAfterClose) {
	materializeNativeDatabase();
	auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
	auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
	(void)backend->createLogicalNodes({{{"Memory"}, {{"payload", PropertyValue(std::string(4000U, 'x'))}}}});
	std::weak_ptr<execution::detail::DatabaseResourceBudget> domain = backend->queryResourceDomain();
	query::QueryEngine engine(backend);
	auto result = engine.execute("MATCH (n:Memory) RETURN n");
	ASSERT_EQ(result.rowCount(), 1U); ASSERT_GT(result.retainedResourceBytes(), 4000U);
	EXPECT_EQ(backend->queryResourceDomain()->usage().classes[static_cast<size_t>(execution::detail::ResourceClass::RCK_QUERY)], result.retainedResourceBytes());
	backend->close();
	ASSERT_FALSE(domain.expired());
	EXPECT_EQ(result.getRows()[0].at("n").asNode().getProperties().at("payload"), PropertyValue(std::string(4000U, 'x')));
	result = query::QueryResult{};
	EXPECT_TRUE(domain.expired());
}

TEST_F(RelocatableStorageBackendTest, NativeReadOnlyQueriesShareTheFileDomainWithoutWriting) {
	materializeNativeDatabase();
	auto writerOptions = backendOptions(); writerOptions.open_mode = OpenMode::OPEN_EXISTING_FILE;
	auto writer = std::make_shared<RelocatableStorageBackend>(writerOptions); writer->open();
	(void)writer->createLogicalNodes({{{"Memory"}, {{"value", PropertyValue(7)}}}});
	auto reader = std::make_shared<RelocatableStorageBackend>(backendOptions()); reader->open();
	EXPECT_EQ(writer->queryResourceDomain(), reader->queryResourceDomain());
	const auto generation = reader->currentNativeMetadataGeneration(); reader->resetIoStats();
	query::QueryEngine engine(reader); auto result = engine.execute("MATCH (n:Memory) RETURN n.value AS value");
	ASSERT_EQ(result.rowCount(), 1U); EXPECT_GT(result.retainedResourceBytes(), 0U);
	EXPECT_EQ(reader->ioStats().data.write_bytes, 0U);
	EXPECT_EQ(reader->currentNativeMetadataGeneration(), generation);
	reader->close(); writer->close();
}

TEST_F(RelocatableStorageBackendTest, ReopenReusesTheDomainWhileAnOldResultRetainsItsCharge) {
	materializeNativeDatabase();
	auto backend = std::make_shared<RelocatableStorageBackend>(backendOptions()); backend->open();
	query::QueryEngine engine(backend);
	auto first = engine.execute("RETURN 42 AS value");
	const auto bytes = first.retainedResourceBytes(); ASSERT_GT(bytes, 0U);
	auto domain = backend->queryResourceDomain(); backend->close(); backend->open();
	EXPECT_EQ(backend->queryResourceDomain(), domain);
	auto second = engine.execute("RETURN 43 AS value");
	EXPECT_EQ(domain->usage().classes[static_cast<size_t>(execution::detail::ResourceClass::RCK_QUERY)], bytes + second.retainedResourceBytes());
	first = query::QueryResult{};
	EXPECT_EQ(domain->usage().classes[static_cast<size_t>(execution::detail::ResourceClass::RCK_QUERY)], second.retainedResourceBytes());
	backend->close();
}

TEST_F(RelocatableStorageBackendTest, HardLinkAliasesCannotCreateIndependentMemoryDomains) {
	materializeNativeDatabase();
	const auto alias = std::filesystem::path(data_path_.string() + ".memory-alias");
	struct Cleanup { std::filesystem::path path; ~Cleanup() { std::error_code error; std::filesystem::remove(path, error); } } cleanup{alias};
	std::error_code error; std::filesystem::create_hard_link(data_path_, alias, error);
	if (error) GTEST_SKIP() << "hard links unavailable: " << error.message();
	auto options = backendOptions(); RelocatableStorageBackend first(options);
	options.data_path = alias; RelocatableStorageBackend second(options);
	first.open(); second.open();
	EXPECT_EQ(first.queryResourceDomain(), second.queryResourceDomain());
	second.close(); first.close();
}

TEST_F(RelocatableStorageBackendTest, NativeEngineRejectsForeignQueryAccountsInsteadOfBypassingTheDomain) {
	using namespace execution::detail;
	materializeNativeDatabase();
	auto backend = std::make_shared<RelocatableStorageBackend>(backendOptions()); backend->open();
	query::QueryEngine engine(backend);
	auto process = std::make_shared<ProcessResourceBudget>(ResourceLimits::uniform(10000U));
	auto foreign = std::make_shared<DatabaseResourceBudget>(process, ResourceLimits::uniform(10000U));
	query::QueryContext context; context.resource_account = std::make_shared<ResourceAccount>(foreign, ResourceClass::RCK_QUERY, 10000U);
	EXPECT_THROW((void)engine.execute("RETURN 42 AS value", context), std::invalid_argument);
	EXPECT_EQ(context.resource_account->used(), 0U);
	EXPECT_EQ(backend->queryResourceDomain()->usage().classes[static_cast<size_t>(execution::detail::ResourceClass::RCK_QUERY)], 0U);
	backend->close();
}

TEST_F(RelocatableStorageBackendTest, TransactionOverlayOutputUsesTheNativeDomainAndSurvivesRollback) {
	materializeNativeDatabase();
	auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
	auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
	query::QueryEngine engine(backend, backend);
	auto transaction = backend->beginLogicalGraphTransaction(true);
	LogicalGraphTransactionOverlay overlay(*transaction);
	query::QueryContext context;
	auto result = engine.executePlanWithLogicalTransactionOverlay(engine.buildPlan("RETURN 42 AS value"), context, overlay, overlay);
	EXPECT_GT(result.retainedResourceBytes(), 0U);
	transaction->rollback(); backend->close();
	ASSERT_EQ(result.rowCount(), 1U);
	EXPECT_EQ(result.getRows()[0].at("value").asPrimitive(), PropertyValue(42));
}

TEST_F(RelocatableStorageBackendTest, NativeCacheGrantIsChargedOnceAcrossReadOnlyAliases) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto first = std::make_shared<RelocatableStorageBackend>(backendOptions());
    auto second = std::make_shared<RelocatableStorageBackend>(backendOptions());
    first->open();
    auto domain = first->queryResourceDomain();
    const auto before = domain->usage();
    const size_t cacheClass = static_cast<size_t>(ResourceClass::RCK_CACHE);
    EXPECT_EQ(before.classes[cacheClass], 64U * 1024U * 1024U);
    second->open();
    EXPECT_EQ(second->queryResourceDomain(), domain);
    EXPECT_EQ(domain->usage().classes[cacheClass], before.classes[cacheClass]);
    first->close();
    EXPECT_EQ(domain->usage().classes[cacheClass], before.classes[cacheClass]);
    second->close();
    EXPECT_EQ(domain->usage().total, 0U);
}

TEST_F(RelocatableStorageBackendTest, RepeatedNativeReopenReturnsCacheAndOutputChargesToTheirOwners) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto backend = std::make_shared<RelocatableStorageBackend>(backendOptions());
    const auto process = ProcessResourceDomains::defaultOwner();
    const size_t initialUsage = process->usage().total;
    query::QueryResult retained;
    std::weak_ptr<DatabaseResourceBudget> weak;
    for (size_t iteration = 0U; iteration < 64U; ++iteration) {
        SCOPED_TRACE(iteration);
        backend->open();
        auto domain = backend->queryResourceDomain();
        if (iteration != 0U) EXPECT_EQ(domain, weak.lock());
        weak = domain;
        query::QueryEngine engine(backend);
        auto result = engine.execute("RETURN 42 AS value");
        retained = std::move(result);
        EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_QUERY)], retained.retainedResourceBytes());
        backend->close();
        EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_CACHE)], 0U);
        EXPECT_EQ(process->usage().total, initialUsage + retained.retainedResourceBytes());
    }
    retained = query::QueryResult{};
    EXPECT_TRUE(weak.expired());
    EXPECT_EQ(process->usage().total, initialUsage);
}

TEST_F(RelocatableStorageBackendTest, CoordinatedSortJoinAndOptionalQuotaFailuresRefundBeforeRetry) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions();
    options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options);
    backend->open();
    for (char value : {'c', 'a', 'b'}) {
        static_cast<void>(backend->createLogicalNodes({{{"Batch"}, {{"payload", PropertyValue(std::string(1000U, value))}}}}));
    }
    query::QueryEngine engine(backend);
    const auto domain = backend->queryResourceDomain();
    const std::vector<std::pair<std::string, size_t>> cases{
        {"MATCH (n:Batch) WITH n ORDER BY n.payload RETURN n.payload AS payload", 3U},
        {"MATCH (n:Batch), (m:Batch) RETURN n.payload AS left_value, m.payload AS right_value", 9U},
        {"MATCH (n:Batch) OPTIONAL MATCH (m:Batch) RETURN n.payload AS left_value, m.payload AS right_value", 9U}};
    for (const auto &[cypher, rows] : cases) {
        SCOPED_TRACE(cypher);
        query::QueryContext context;
        auto limited = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_QUERY, 1024U);
        context.resource_account = limited;
        EXPECT_THROW(static_cast<void>(engine.execute(cypher, context)), ResourceAdmissionDenied);
        EXPECT_EQ(limited->used(), 0U);
        auto admitted = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_QUERY, 128U * 1024U);
        context.resource_account = admitted;
        {
            auto result = engine.execute(cypher, context);
            ASSERT_EQ(result.rowCount(), rows);
            EXPECT_GT(result.retainedResourceBytes(), 1000U);
            EXPECT_EQ(admitted->used(), result.retainedResourceBytes());
        }
        EXPECT_EQ(admitted->used(), 0U);
        EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_QUERY)], 0U);
    }
    backend->close();
    EXPECT_EQ(domain->usage().total, 0U);
}

TEST_F(RelocatableStorageBackendTest, CoordinatedPropertyPrefetchReleasesSelectedAndRejectedRowsBeforeClose) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions();
    options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options);
    backend->open();
    for (char value : {'c', 'a', 'b'}) {
        static_cast<void>(backend->createLogicalNodes({{{"Prefetch"}, {{"payload", PropertyValue(std::string(1000U, value))}}}}));
    }
    query::QueryEngine engine(backend);
    auto domain = backend->queryResourceDomain();
    auto account = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_QUERY, 32U * 1024U);
    query::QueryContext context;
    context.resource_account = account;
    const std::string cypher = "MATCH (n:Prefetch) WHERE n.payload = $wanted RETURN n.payload AS payload";
    for (const bool matches : {true, false, true}) {
        SCOPED_TRACE(matches);
        context.parameters.insert_or_assign("wanted", PropertyValue(std::string(1000U, matches ? 'a' : 'z')));
        {
            auto result = engine.execute(cypher, context);
            ASSERT_EQ(result.rowCount(), matches ? 1U : 0U);
            if (matches) EXPECT_EQ(result.getRows()[0].at("payload").asPrimitive(), PropertyValue(std::string(1000U, 'a')));
            EXPECT_EQ(account->used(), result.retainedResourceBytes());
        }
        EXPECT_EQ(account->used(), 0U);
    }
    backend->close();
    EXPECT_EQ(domain->usage().total, 0U);
}

TEST_F(RelocatableStorageBackendTest, NativeReadFallbackInheritsTheSnapshotGrantWithoutAllocatingForExistingSessions) {
    materializeNativeDatabase();
    auto backend = std::make_shared<RelocatableStorageBackend>(backendOptions()); backend->open();
    auto snapshot = backend->openSnapshot();
    const auto &pin = snapshot.metadataSnapshot();
    auto memory = std::dynamic_pointer_cast<execution::detail::PrepaidMemoryResource>(pin.readContext()->memoryOwner());
    ASSERT_NE(memory, nullptr);
    NativeReadSession existing(pin);
    const size_t baseline = memory->used();
    {
        std::optional<NativeReadSession> fallback;
        for (size_t index = 0U; index < 100U; ++index)
            EXPECT_EQ(&selectNativeReadSession(pin, &existing, fallback), &existing);
        EXPECT_FALSE(fallback.has_value());
        EXPECT_EQ(memory->used(), baseline);
        auto &created = selectNativeReadSession(pin, nullptr, fallback);
        EXPECT_TRUE(fallback.has_value());
        EXPECT_GT(memory->used(), baseline);
        const size_t createdBytes = memory->used();
        EXPECT_EQ(&selectNativeReadSession(pin, nullptr, fallback), &created);
        EXPECT_EQ(memory->used(), createdBytes);
        created.putPropertyToken(std::string(4096U, 'p'), 1U);
        EXPECT_GT(memory->used(), createdBytes + 8192U);
    }
    EXPECT_EQ(memory->used(), baseline);
    snapshot.release();
    backend->close();
}

TEST_F(RelocatableStorageBackendTest, NativeTransactionWrappersRetainOnlyTheirLiveWriteClassObjectCharge) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    auto domain = backend->queryResourceDomain();
    const size_t kind = static_cast<size_t>(ResourceClass::RCK_WRITE);
    EXPECT_EQ(domain->usage().classes[kind], idleBytes);
    for (bool readOnly : {false, true}) {
        auto transaction = backend->beginLogicalGraphTransaction(readOnly);
        const size_t objectBytes = domain->usage().classes[kind];
        EXPECT_GT(objectBytes, idleBytes); EXPECT_LT(objectBytes - idleBytes, 16U * 1024U);
        transaction->rollback();
        EXPECT_EQ(domain->usage().classes[kind], objectBytes);
        transaction.reset();
        EXPECT_EQ(domain->usage().classes[kind], idleBytes);
    }
    auto committed = backend->beginLogicalGraphTransaction(true);
    const size_t objectBytes = domain->usage().classes[kind];
    (void)committed->commit();
    EXPECT_EQ(domain->usage().classes[kind], objectBytes);
    committed.reset();
    EXPECT_EQ(domain->usage().classes[kind], idleBytes);
    backend->close();
}

TEST_F(RelocatableStorageBackendTest, DeniedTransactionObjectAdmissionLeaksNoSnapshotOrWriteCharge) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    auto domain = backend->queryResourceDomain();
    const size_t maximum = ProcessResourceDomains::databaseDefaults().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)];
    auto pressureAccount = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_WRITE, maximum);
    ResourceLease pressure(pressureAccount); pressure.set(maximum - idleBytes);
    const auto generation = backend->currentNativeMetadataGeneration();
    EXPECT_THROW((void)backend->beginLogicalGraphTransaction(false), ResourceAdmissionDenied);
    EXPECT_THROW((void)backend->beginLogicalGraphTransaction(true), ResourceAdmissionDenied);
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], maximum);
    EXPECT_EQ(backend->currentNativeMetadataGeneration(), generation);
    pressure.reset();
    auto retry = backend->beginLogicalGraphTransaction(false); retry->rollback(); retry.reset();
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], idleBytes);
    EXPECT_NO_THROW(backend->close());
}

TEST_F(RelocatableStorageBackendTest, IssuedIdBuffersUseWriteQuotaAndDeniedStageKeepsPriorStatement) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    auto domain = backend->queryResourceDomain();
    const size_t kind = static_cast<size_t>(ResourceClass::RCK_WRITE);
    auto transaction = backend->beginLogicalGraphTransaction(false);
    const size_t objectBytes = domain->usage().classes[kind];
    LogicalGraphMutationBatch first; first.node_creates.resize(1U);
    const auto firstResult = transaction->stageMutationBatch(std::move(first));
    ASSERT_EQ(firstResult.created_node_ids.size(), 1U);
    EXPECT_EQ(domain->usage().classes[kind], objectBytes + sizeof(uint64_t) + sizeof(NativeGraphLogicalIdLeaseRange) + sizeof(LogicalGraphNodeCreateRequest));
    const size_t retained = domain->usage().classes[kind];
    const size_t maximum = ProcessResourceDomains::databaseDefaults().classes[kind];
    auto pressureAccount = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_WRITE, maximum);
    ResourceLease pressure(pressureAccount); pressure.set(maximum - retained);
    LogicalGraphMutationBatch denied; denied.node_creates.resize(1U);
    EXPECT_THROW((void)transaction->stageMutationBatch(std::move(denied)), ResourceAdmissionDenied);
    EXPECT_EQ(transaction->state(), LogicalGraphTransactionState::LGTTS_ACTIVE);
    EXPECT_EQ(domain->usage().classes[kind], maximum);
    pressure.reset();
    EXPECT_EQ(domain->usage().classes[kind], retained);
    LogicalGraphMutationBatch retry; retry.node_creates.resize(1U);
    const auto nextResult = transaction->stageMutationBatch(std::move(retry));
    ASSERT_EQ(nextResult.created_node_ids.size(), 1U);
    EXPECT_GT(nextResult.created_node_ids.front(), firstResult.created_node_ids.front() + 1U);
    EXPECT_EQ(domain->usage().classes[kind], objectBytes + 2U * (sizeof(uint64_t) + sizeof(NativeGraphLogicalIdLeaseRange) + sizeof(LogicalGraphNodeCreateRequest)));
    const auto committed = transaction->commit();
    EXPECT_EQ(committed.created_node_ids, (std::vector<uint64_t>{firstResult.created_node_ids.front(), nextResult.created_node_ids.front()}));
    EXPECT_EQ(domain->usage().classes[kind], objectBytes);
    transaction.reset();
    EXPECT_EQ(domain->usage().classes[kind], idleBytes);
    backend->close();
}

TEST_F(RelocatableStorageBackendTest, ClosedTransactionObjectKeepsItsWriteDomainAfterBackendDestruction) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    std::weak_ptr<DatabaseResourceBudget> domain = backend->queryResourceDomain();
    auto transaction = backend->beginLogicalGraphTransaction(false);
    transaction->rollback();
    backend->close(); backend.reset();
    ASSERT_FALSE(domain.expired());
    EXPECT_GT(domain.lock()->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], 0U);
    EXPECT_EQ(domain.lock()->usage().classes[static_cast<size_t>(ResourceClass::RCK_CACHE)], 0U);
    transaction.reset();
    EXPECT_TRUE(domain.expired());
}

TEST_F(RelocatableStorageBackendTest, PreviewRangeQuotaFailureDoesNotPublishAnIncompletePreviewOrConsumeItsRetry) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    auto domain = backend->queryResourceDomain();
    const size_t kind = static_cast<size_t>(ResourceClass::RCK_WRITE);
    auto transaction = backend->beginLogicalGraphTransaction(false);
    const size_t objectBytes = domain->usage().classes[kind];
    const size_t maximum = ProcessResourceDomains::databaseDefaults().classes[kind];
    auto pressureAccount = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_WRITE, maximum);
    ResourceLease pressure(pressureAccount); pressure.set(maximum - objectBytes);
    LogicalGraphMutationBatch batch; batch.node_creates.resize(1U);
    EXPECT_THROW((void)transaction->previewMutationBatch(batch), ResourceAdmissionDenied);
    pressure.reset();
    const auto preview = transaction->previewMutationBatch(batch);
    ASSERT_EQ(preview.created_node_ids.size(), 1U);
    EXPECT_EQ(domain->usage().classes[kind], objectBytes + sizeof(NativeGraphLogicalIdLeaseRange));
    pressure.set(maximum - domain->usage().classes[kind]);
    EXPECT_THROW((void)transaction->stageMutationBatch(batch), ResourceAdmissionDenied);
    EXPECT_EQ(transaction->previewMutationBatch(batch), preview);
    pressure.reset();
    const auto staged = transaction->stageMutationBatch(batch);
    EXPECT_EQ(staged, preview);
    EXPECT_EQ(domain->usage().classes[kind], objectBytes + sizeof(uint64_t) + sizeof(NativeGraphLogicalIdLeaseRange) + sizeof(LogicalGraphNodeCreateRequest));
    transaction->rollback();
    EXPECT_EQ(domain->usage().classes[kind], objectBytes);
    transaction.reset(); backend->close();
}

TEST_F(RelocatableStorageBackendTest, TerminalRangeCleanupDoesNotCaptureAnUnrelatedAmbientAllocationOwner) {
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    auto transaction = backend->beginLogicalGraphTransaction(false);
    LogicalGraphMutationBatch batch; batch.node_creates.resize(1U);
    (void)transaction->stageMutationBatch(std::move(batch));
    auto ambient = std::make_shared<std::pmr::monotonic_buffer_resource>();
    std::weak_ptr<std::pmr::memory_resource> weak = ambient;
    {
        graph::utils::OwnedAllocationScope scope(ambient);
        transaction->rollback();
    }
    ambient.reset();
    EXPECT_TRUE(weak.expired());
    transaction.reset(); backend->close();
}

namespace {
class NativeReadDeniedAmbientResource final : public std::pmr::memory_resource {
    void *do_allocate(size_t, size_t) override { throw std::bad_alloc(); }
    void do_deallocate(void *, size_t, size_t) override {}
    bool do_is_equal(const std::pmr::memory_resource &other) const noexcept override { return this == &other; }
};
}
TEST_F(RelocatableStorageBackendTest, CachedTopologyReadDoesNotAllocateAnUnusedAmbientFallbackSession) {
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    const auto ids = backend->createLogicalNodes({{{"Cached"}, {{"value", PropertyValue(int64_t{7})}}}});
    auto snapshot = backend->openLogicalGraphReadSnapshot();
    // Topology-only hits need no Property materialization workspace.
    const EntityReadShape topology{};
    const auto original = snapshot->readNodeShaped(ids.front(), topology);
    std::optional<LogicalGraphNode> repeated;
    {
        NativeReadDeniedAmbientResource denied;
        struct RestoreDefault {
            std::pmr::memory_resource *previous;
            ~RestoreDefault() { std::pmr::set_default_resource(previous); }
        } restore{std::pmr::set_default_resource(&denied)};
        EXPECT_NO_THROW(repeated = snapshot->readNodeShaped(ids.front(), topology));
    }
    ASSERT_TRUE(repeated.has_value());
    EXPECT_EQ(repeated->node_id, original.node_id);
    EXPECT_EQ(repeated->labels, original.labels);
    EXPECT_EQ(repeated->properties, original.properties);
    snapshot.reset(); backend->close();
}

TEST_F(RelocatableStorageBackendTest, FullPropertyReadRestoresTheLazyDirectoryAllocationContext) {
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    const auto ids = backend->createLogicalNodes({{{"Cached"}, {{"value", PropertyValue(int64_t{7})}}}});
    auto snapshot = backend->openLogicalGraphReadSnapshot();
    // Deferred directory initialization must keep its snapshot allocation domain.
    const EntityReadShape topology{.include_labels = true, .all_properties = true};
    const auto original = snapshot->readNodeShaped(ids.front(), topology);
    std::optional<LogicalGraphNode> repeated;
    {
        NativeReadDeniedAmbientResource denied;
        struct RestoreDefault {
            std::pmr::memory_resource *previous;
            ~RestoreDefault() { std::pmr::set_default_resource(previous); }
        } restore{std::pmr::set_default_resource(&denied)};
        EXPECT_NO_THROW(repeated = snapshot->readNodeShaped(ids.front(), topology));
    }
    ASSERT_TRUE(repeated.has_value());
    EXPECT_EQ(repeated->node_id, original.node_id);
    EXPECT_EQ(repeated->labels, original.labels);
    EXPECT_EQ(repeated->properties, original.properties);
    snapshot.reset(); backend->close();
}

TEST_F(RelocatableStorageBackendTest, RetainedPropertyPatchSlotsUseWriteBudgetAndReleaseAtRollback) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    std::vector<LogicalGraphNodeCreateRequest> nodes(32U);
    const auto ids = backend.createLogicalNodes(nodes);
    auto domain = backend.queryResourceDomain();
    const size_t kind = static_cast<size_t>(ResourceClass::RCK_WRITE);
    auto transaction = backend.beginLogicalGraphTransaction(false);
    const auto wrapper = domain->usage().classes[kind];
    std::vector<LogicalGraphPropertyPatchRequest> patches;
    for (const auto id : ids)
        patches.push_back({{LogicalGraphMutationEntityKind::LGMK_NODE,
            LogicalGraphMutationReferenceKind::LGRK_PERSISTED, id}, {{"rank", PropertyValue(1)}}, {}});
    (void)transaction->stageMutationBatchWithPropertyPatches({}, std::move(patches), ids.size());
    EXPECT_GE(domain->usage().classes[kind] - wrapper, ids.size() * sizeof(LogicalGraphPropertyPatchRequest));
    transaction->rollback();
    EXPECT_EQ(domain->usage().classes[kind], wrapper);
    transaction.reset();
    EXPECT_EQ(domain->usage().classes[kind], idleBytes);
    backend.close();
}

TEST_F(RelocatableStorageBackendTest, DeniedPropertyPatchSlotCopyPreservesPriorStatementAndCanCommit) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    std::vector<LogicalGraphNodeCreateRequest> nodes(32U);
    for (auto &node : nodes) node.properties.push_back({"rank", PropertyValue(0)});
    const auto ids = backend.createLogicalNodes(nodes);
    const auto id = ids.front();
    auto transaction = backend.beginLogicalGraphTransaction(false);
    const LogicalGraphMutationEntityReference entity{LogicalGraphMutationEntityKind::LGMK_NODE,
        LogicalGraphMutationReferenceKind::LGRK_PERSISTED, id};
    std::vector<LogicalGraphPropertyPatchRequest> patches;
    for (const auto target : ids)
        patches.push_back({{LogicalGraphMutationEntityKind::LGMK_NODE,
            LogicalGraphMutationReferenceKind::LGRK_PERSISTED, target}, {{"rank", PropertyValue(1)}}, {}});
    // Entry bound includes each persisted source field and each patch field.
    (void)transaction->stageMutationBatchWithPropertyPatches({}, std::move(patches), 2U * ids.size());
    auto domain = backend.queryResourceDomain();
    auto account = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_WRITE, 128U * 1024U * 1024U);
    ResourceLease pressure(account);
    // Leave room for validating the new one-target request, but not for copying
    // the retained 32-target slot buffer. Do not reject at the earlier validator.
    constexpr size_t validationHeadroom = 512U;
    ASSERT_GT(account->available(), validationHeadroom);
    pressure.set(account->available() - validationHeadroom);
    EXPECT_THROW((void)transaction->stageMutationBatchWithPropertyPatches(
        {}, {{entity, {{"rank", PropertyValue(2)}}, {}}}, 2U), ResourceAdmissionDenied);
    EXPECT_EQ(transaction->state(), LogicalGraphTransactionState::LGTTS_ACTIVE);
    pressure.reset();
    EXPECT_NO_THROW((void)transaction->commit());
    transaction.reset();
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], idleBytes);
    auto snapshot = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(snapshot->readNodeProperty(id, "rank"), PropertyValue(1));
    snapshot.reset(); backend.close();
}

TEST_F(RelocatableStorageBackendTest, DeniedCanonicalCreationWorkspaceRollsBackWithoutPublishingNodes) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto transaction = backend.beginLogicalGraphTransaction(false);
    LogicalGraphMutationBatch batch; batch.node_creates.resize(32U);
    const auto staged = transaction->stageMutationBatch(std::move(batch));
    ASSERT_EQ(staged.created_node_ids.size(), 32U);
    auto domain = backend.queryResourceDomain();
    auto account = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_WRITE, 128U * 1024U * 1024U);
    ResourceLease pressure(account); pressure.set(account->available());
    EXPECT_THROW((void)transaction->commit(), ResourceAdmissionDenied);
    EXPECT_EQ(transaction->state(), LogicalGraphTransactionState::LGTTS_ROLLED_BACK);
    pressure.reset(); transaction.reset();
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], idleBytes);
    auto snapshot = backend.openLogicalGraphReadSnapshot();
    for (const auto id : staged.created_node_ids) EXPECT_FALSE(snapshot->containsNode(id));
    snapshot.reset();
    EXPECT_NO_THROW((void)backend.verifyIntegrity());
    auto retry = backend.beginLogicalGraphTransaction(false);
    LogicalGraphMutationBatch next; next.node_creates.resize(1U);
    const auto ids = retry->stageMutationBatch(std::move(next)).created_node_ids;
    EXPECT_GT(ids.front(), staged.created_node_ids.back());
    EXPECT_NO_THROW((void)retry->commit());
    retry.reset(); backend.close();
}

TEST_F(RelocatableStorageBackendTest, RetainedMutationSlotsAreChargedToWriteBeforeStagingAndFreedAtRollback) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto domain = backend.queryResourceDomain();
    const size_t kind = static_cast<size_t>(ResourceClass::RCK_WRITE);
    auto transaction = backend.beginLogicalGraphTransaction(false);
    const auto wrapper = domain->usage().classes[kind];
    LogicalGraphMutationBatch batch; batch.node_creates.resize(64U);
    const auto ids = transaction->stageMutationBatch(std::move(batch)).created_node_ids;
    EXPECT_GE(domain->usage().classes[kind] - wrapper, 64U * sizeof(LogicalGraphNodeCreateRequest));
    transaction->rollback();
    EXPECT_EQ(domain->usage().classes[kind], wrapper);
    transaction.reset();
    EXPECT_EQ(domain->usage().classes[kind], idleBytes);
    auto snapshot = backend.openLogicalGraphReadSnapshot();
    for (const auto id : ids) EXPECT_FALSE(snapshot->containsNode(id));
    snapshot.reset(); backend.close();
}

TEST_F(RelocatableStorageBackendTest, OverlayNodesKeepWriteOwnershipAfterRollbackUntilOverlayDestruction) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    const auto id = backend.createLogicalNodes({{{}, {{"rank", PropertyValue(0)}}}}).front();
    auto domain = backend.queryResourceDomain();
    const size_t kind = static_cast<size_t>(ResourceClass::RCK_WRITE);
    auto transaction = backend.beginLogicalGraphTransaction(false);
    const auto wrapper = domain->usage().classes[kind];
    {
        LogicalGraphTransactionOverlay overlay(*transaction);
        overlay.replaceLogicalNodeProperties({{id, {{"rank", PropertyValue(1)}}}});
        EXPECT_GT(domain->usage().classes[kind], wrapper);
        transaction->rollback();
        // The overlay still owns its retained node even though native staging
        // has released its request slots and base snapshot.
        EXPECT_GT(domain->usage().classes[kind], wrapper);
    }
    EXPECT_EQ(domain->usage().classes[kind], wrapper);
    transaction.reset();
    EXPECT_EQ(domain->usage().classes[kind], idleBytes);
    backend.close();
}

TEST_F(RelocatableStorageBackendTest, DeniedOverlayUndoMetadataPreservesThePriorVisibleStatement) {
    using namespace execution::detail;
    constexpr size_t idleBytes = ProcessResourceDomains::LOGICAL_ID_CAPABILITY_GRANT_BYTES;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    const auto id = backend.createLogicalNodes({{{}, {{"rank", PropertyValue(0)}}}}).front();
    auto domain = backend.queryResourceDomain();
    auto transaction = backend.beginLogicalGraphTransaction(false);
    {
        LogicalGraphTransactionOverlay overlay(*transaction);
        overlay.replaceLogicalNodeProperties({{id, {{"rank", PropertyValue(1)}}}});
        auto account = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_WRITE, 128U * 1024U * 1024U);
        ResourceLease pressure(account); pressure.set(account->available());
        EXPECT_THROW(overlay.replaceLogicalNodeProperties({{id, {{"rank", PropertyValue(2)}}}}), ResourceAdmissionDenied);
        EXPECT_EQ(transaction->state(), LogicalGraphTransactionState::LGTTS_ACTIVE);
        pressure.reset();
        auto visible = overlay.openLogicalGraphReadSnapshot();
        EXPECT_EQ(visible->readNodeProperty(id, "rank"), PropertyValue(1));
        visible.reset();
        EXPECT_NO_THROW((void)transaction->commit());
    }
    transaction.reset();
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], idleBytes);
    auto durable = backend.openLogicalGraphReadSnapshot();
    EXPECT_EQ(durable->readNodeProperty(id, "rank"), PropertyValue(1));
    durable.reset(); backend.close();
}

TEST_F(RelocatableStorageBackendTest, DeniedOverlayCreationUndoPreservesItsPreviewIdentityForRetry) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto transaction = backend.beginLogicalGraphTransaction(false);
    uint64_t created = 0U;
    {
        LogicalGraphTransactionOverlay overlay(*transaction);
        LogicalGraphMutationBatch batch; batch.node_creates.resize(1U);
        const auto preview = transaction->previewMutationBatch(batch);
        auto domain = backend.queryResourceDomain();
        auto account = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_WRITE, 128U * 1024U * 1024U);
        ResourceLease pressure(account); pressure.set(account->available());
        EXPECT_THROW((void)overlay.executeLogicalGraphMutationBatch(batch), ResourceAdmissionDenied);
        EXPECT_EQ(transaction->state(), LogicalGraphTransactionState::LGTTS_ACTIVE);
        pressure.reset();
        const auto retried = overlay.executeLogicalGraphMutationBatch(batch);
        EXPECT_EQ(retried, preview);
        ASSERT_EQ(retried.created_node_ids.size(), 1U);
        created = retried.created_node_ids.front();
        EXPECT_NO_THROW((void)transaction->commit());
    }
    transaction.reset();
    auto snapshot = backend.openLogicalGraphReadSnapshot();
    EXPECT_TRUE(snapshot->containsNode(created));
    snapshot.reset();
    EXPECT_NO_THROW((void)backend.verifyIntegrity());
    backend.close();
}

TEST_F(RelocatableStorageBackendTest, LogicalIdCapabilityGrantIsSharedAcrossWritableFileAliases) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend first(options), second(options); first.open(); second.open();
    auto domain = first.queryResourceDomain();
    auto memory = ProcessResourceDomains::defaultOwner()->logicalIdGrant(domain);
    EXPECT_EQ(domain, second.queryResourceDomain());
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], memory->capacity());
    const auto baseline = memory->used();
    auto one = first.reserveLogicalGraphCreationIds(1U, 1U);
    auto two = second.reserveLogicalGraphCreationIds(1U, 1U);
    EXPECT_GT(memory->used(), baseline);
    first.abandonLogicalGraphCreationIds(one); second.abandonLogicalGraphCreationIds(two);
    EXPECT_EQ(memory->used(), baseline);
    first.close(); second.close();
    EXPECT_EQ(memory->used(), 0U);
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], memory->capacity());
    memory.reset();
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], 0U);
}

TEST_F(RelocatableStorageBackendTest, LogicalIdCapabilityQuotaRejectsBeforePublicationAndCanRetry) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto domain = backend.queryResourceDomain();
    auto memory = ProcessResourceDomains::defaultOwner()->logicalIdGrant(domain);
    auto warm = backend.reserveLogicalGraphCreationIds(1U, 1U);
    backend.abandonLogicalGraphCreationIds(warm);
    const auto baseline = memory->used();
    const auto bytes = memory->capacity() - baseline;
    auto release = [memory, bytes](void *pointer) { memory->deallocate(pointer, bytes); };
    std::unique_ptr<void, decltype(release)> pressure(memory->allocate(bytes), release);
    const auto generation = backend.currentNativeMetadataGeneration();
    backend.resetIoStats();
    EXPECT_THROW((void)backend.reserveLogicalGraphCreationIds(1U, 1U), ResourceAdmissionDenied);
    EXPECT_EQ(backend.ioStats().data.write_bytes, 0U);
    EXPECT_EQ(backend.currentNativeMetadataGeneration(), generation);
    EXPECT_FALSE(backend.hasIndeterminateWriteOutcome());
    pressure.reset();
    EXPECT_EQ(memory->used(), baseline);
    auto retry = backend.reserveLogicalGraphCreationIds(1U, 1U);
    backend.abandonLogicalGraphCreationIds(retry);
    EXPECT_EQ(memory->used(), baseline);
    EXPECT_NO_THROW((void)backend.verifyIntegrity());
    backend.close();
}

TEST_F(RelocatableStorageBackendTest, PhysicalReadonlyOpenDoesNotPrepayAWriteCapabilityGrant) {
    using namespace execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_READ_ONLY_EXISTING_FILE;
    RelocatableStorageBackend backend(options); backend.open();
    auto domain = backend.queryResourceDomain();
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_WRITE)], 0U);
    backend.close();
}

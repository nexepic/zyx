from pathlib import Path
import os,sys,argparse,json,hashlib,resource,shutil,time
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.workload_preflight import NativeWorker
p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--binary',type=Path);p.add_argument('--retain-clone',action='store_true');a=p.parse_args();r=Path('/workspace/zyx-resume-evaluation-20261018');source=r/'bounded-reclaim-contracts/round-1/current/wide_large';db=source/'failed-endpoint.zyx';out=r/f'mature-route-diagnosis-{a.label}';out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3));before=hashlib.sha256(db.read_bytes()).hexdigest();clone=out/'private.zyx';shutil.copy2(db,clone)
trace=json.loads((source/'partial-trace.json').read_text());entry=next(v for v in reversed(trace) if v['command'][0]=='QUERY' and 'RETURN properties(n)' in v['command'][1]);props=entry['expected'][0][0]
for key,value in list(props.items()):
 if isinstance(value,dict) and 'utf8_blob' in value:
  data=(source/value['utf8_blob']).read_bytes();assert hashlib.sha256(data).hexdigest()==value['sha256'];props[key]=data.decode()
identifier=props['id'];query=f'MATCH (n:Wide {{id:{identifier}}}) ';binary=a.binary or r/'mature-diagnostic-worker';w=NativeWorker(binary,clone,out)
try:
 w.call('QUERY',query+'RETURN properties(n) AS fields',expected=[[props]])
 stats0=w.call('STATS');w.call('TRACE_ON');begin=time.monotonic();w.call('QUERY',query+'SET n.field_0 = 78 RETURN n.id AS id',expected=[[identifier]]);elapsed=time.monotonic()-begin;counters=w.call('TRACE_OFF')['trace'];stats1=w.call('STATS');props['field_0']=78
 w.call('QUERY',query+'RETURN properties(n) AS fields',expected=[[props]]);w.close()
except BaseException:w.process.kill();w.process.wait();raise
assert hashlib.sha256(db.read_bytes()).hexdigest()==before
result={'status':'instrumented_single_update_diagnosis_passed','scope':'Actual1800-second failed mature128-field endpoint; separate identical private clone per source. No unchanged full-family retry, performance sample or gate acceptance.','label':a.label,'source_endpoint_sha256':before,'source_endpoint_bytes':db.stat().st_size,'source_endpoint_unchanged':True,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'closed_output_database_sha256':hashlib.sha256(clone.read_bytes()).hexdigest(),'identifier':identifier,'exact_full_properties_checked_before_and_after':True,'read_bytes':stats1['read_bytes']-stats0['read_bytes'],'write_bytes':stats1['write_bytes']-stats0['write_bytes'],'elapsed_diagnostic_seconds':elapsed,'trace':counters};(out/'proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['label','read_bytes','write_bytes','elapsed_diagnostic_seconds']}));print('top timers',sorted([(k,round(v[0]/1e6,3),v[1]) for k,v in counters.items()],key=lambda x:-x[1])[:12]);print('metadata cache hits',counters.get('native_graph.read.decoded_metadata_cache_hits'))
if not a.retain_clone:clone.unlink()

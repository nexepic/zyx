/**
 * @file test_PropertyValueCodec_Inspection.cpp
 * @brief Allocation-free validation and pre-decode admission contracts.
 * Copyright (c) 2026 Nexepic. Licensed under the Apache License, Version 2.0.
 */
#include <gtest/gtest.h>
#include <optional>
#include "graph/storage/relocatable/property/PropertyValueCodec.hpp"

using namespace graph;
using namespace graph::storage;
namespace {
PropertyValue inspectionValue() {
    PropertyValue::MapType map;
    map.emplace("a", PropertyValue(std::vector<PropertyValue>{PropertyValue("abc"),
        PropertyValue(PropertyValue::Bytes(4U, std::byte{0x5a}))}));
    map.emplace("z", PropertyValue(7)); return PropertyValue(std::move(map));
}
}

TEST(RelocatablePropertyValueInspectionTest, CountsNestedShapeAndConsumesOnlyOneOuterValue) {
    std::vector<std::byte> encoded{std::byte{0xff}};
    const auto value = inspectionValue(); CanonicalPropertyValueCodec::append(encoded, value);
    const auto end = encoded.size(); CanonicalPropertyValueCodec::append(encoded, PropertyValue(9));
    size_t offset = 1U, checkpoints = 0U;
    const auto shape = CanonicalPropertyValueCodec::inspectNext(encoded, offset, [&] { ++checkpoints; });
    EXPECT_EQ(offset, end); EXPECT_EQ(shape.encoded_bytes, end - 1U);
    EXPECT_EQ(shape.value_count, 5U); EXPECT_EQ(shape.list_elements, 2U); EXPECT_EQ(shape.map_entries, 2U);
    EXPECT_EQ(shape.string_bytes, 3U); EXPECT_EQ(shape.map_key_bytes, 2U); EXPECT_EQ(shape.binary_bytes, 4U);
    EXPECT_EQ(shape.maximum_depth, 2U); EXPECT_GE(checkpoints, 2U);
    offset = 1U; bool admitted = false;
    const auto decoded = CanonicalPropertyValueCodec::decodeNextWithAdmission(encoded, offset, [&](const auto &plan) {
        admitted = true; EXPECT_EQ(plan.encoded_bytes, shape.encoded_bytes);
    });
    EXPECT_TRUE(admitted); EXPECT_EQ(decoded, value); EXPECT_EQ(offset, end);
}

TEST(RelocatablePropertyValueInspectionTest, RejectionAndCancellationKeepTheOriginalCursorAndDoNotCallLaterAdmission) {
    std::vector<std::byte> encoded;
    CanonicalPropertyValueCodec::append(encoded, PropertyValue(std::vector<PropertyValue>(1024U, PropertyValue(7))));
    size_t offset = 0U, checkpoints = 0U; bool admitted = false;
    EXPECT_THROW(static_cast<void>(CanonicalPropertyValueCodec::decodeNextWithAdmission(encoded, offset,
        [&](const auto &) { admitted = true; }, [&] {
            if (++checkpoints == 2U) throw std::runtime_error("cancel inspection");
        })), std::runtime_error);
    EXPECT_FALSE(admitted); EXPECT_EQ(offset, 0U);
    EXPECT_THROW(static_cast<void>(CanonicalPropertyValueCodec::decodeNextWithAdmission(encoded, offset,
        [](const auto &) { throw std::runtime_error("deny decode"); })), std::runtime_error);
    EXPECT_EQ(offset, 0U);
    EXPECT_THROW(static_cast<void>(CanonicalPropertyValueCodec::decodeNextWithAdmission(encoded, offset, {})), std::invalid_argument);
    EXPECT_EQ(offset, 0U);
}

TEST(RelocatablePropertyValueInspectionTest, ValidationMatchesDecoderForEverySingleBitWireMutation) {
    std::vector<std::byte> encoded; CanonicalPropertyValueCodec::append(encoded, inspectionValue());
    for (size_t index = 0U; index < encoded.size(); ++index) {
        for (unsigned bit = 0U; bit < 8U; ++bit) {
            auto changed = encoded; changed[index] ^= std::byte{static_cast<unsigned char>(1U << bit)};
            size_t inspected = 0U, decoded = 0U;
            std::optional<FormatError> inspectionError, decodeError;
            try { static_cast<void>(CanonicalPropertyValueCodec::inspectNext(changed, inspected)); }
            catch (const FormatException &error) { inspectionError = error.error(); }
            try { static_cast<void>(CanonicalPropertyValueCodec::decodeNext(changed, decoded)); }
            catch (const FormatException &error) { decodeError = error.error(); }
            EXPECT_EQ(inspectionError, decodeError) << index << ":" << bit;
            EXPECT_EQ(inspected, decoded) << index << ":" << bit;
        }
    }
}

from pathlib import Path
import json,collections,statistics,hashlib
r=Path('/workspace/zyx-resume-evaluation-20261018');out=[];groups=[]
for name in ['property-path-diagnosis','property-path-diagnosis-after-superblock-repair']:
 p=r/name/'operations.jsonl';v=[json.loads(s) for s in p.read_text().splitlines()];g=collections.defaultdict(list)
 for x in v:g[x['kind']].append(x)
 groups.append(g)
for kind,rows in groups[0].items():
 current=groups[1][kind];assert len(rows)==len(current)
 row={'kind':kind,'operations_per_source':len(rows)}
 for label,vs in [('before',rows),('after',current)]:
  row[label]={'checksum_calls':sum(x['trace'].get('storage.checksum.crc',[0,0])[1] for x in vs),'checksum_bytes':sum(x['trace'].get('storage.checksum.bytes',[0,0,0])[2] for x in vs),'logical_read_bytes':sum(x['read_bytes'] for x in vs),'logical_write_bytes':sum(x['write_bytes'] for x in vs)}
 row['checksum_calls_reduction']=1-row['after']['checksum_calls']/row['before']['checksum_calls'] if row['before']['checksum_calls'] else None;out.append(row)
summary={'status':'mechanism_diagnosis_only_no_performance_acceptance','operations_per_source':578,'same_queries_and_exact_typed_value_oracles':True,'instrumentation_enabled':True,'concurrent_test_build_for_after_run':True,'no_duration_comparison_or_new_score':True,'no_file_format_or_budget_change':True,'rows':out}
(r/'superblock-validation-mechanism-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
for v in out:
 if v['kind'] in ['dynamic-64-create','dynamic-64-update','wide-128-1048576-update']:print(v['kind'],'checksum calls',v['before']['checksum_calls'],'->',v['after']['checksum_calls'],'read bytes',v['before']['logical_read_bytes'],'->',v['after']['logical_read_bytes'])
p=r/'property-path-diagnosis-after-superblock-repair/completed.json';x=json.loads(p.read_text());x.pop('production_core_unchanged');x['production_core_unchanged_during_run']=True;x['same_production_core_as_before_repair']=False;x['instrumented_binary_sha256']=hashlib.sha256((r/'diagnostic-worker').read_bytes()).hexdigest();p.write_text(json.dumps(x,indent=2)+'\n')

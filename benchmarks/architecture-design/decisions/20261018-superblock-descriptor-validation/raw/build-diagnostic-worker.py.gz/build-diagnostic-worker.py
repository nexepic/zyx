from pathlib import Path
import shlex,subprocess,json,hashlib
r=Path('/workspace/zyx-resume-evaluation-20261018');build=Path('/workspace/zyx/buildDir_final')
s=Path('/workspace/zyx/benchmarks/graphdb-comparison/workload-contract/native-worker.cpp').read_text().replace('#include <cmath>','#include <cmath>\n#include "graph/debug/PerfTrace.hpp"')
needle='} else if (command == "FORMAT") {'
replacement='''} else if (command == "TRACE_ON") {
                    debug::PerfTrace::reset(); debug::PerfTrace::setEnabled(true);
                } else if (command == "TRACE_OFF") {
                    const auto snapshot = debug::PerfTrace::snapshotAndReset(); debug::PerfTrace::setEnabled(false);
                    std::ostringstream trace; trace << "{\\"ok\\":true,\\"trace\\":{"; bool first = true;
                    for (const auto &[key, entry] : snapshot) {
                        if (!first) trace << ','; first = false;
                        trace << quoted(key) << ":[" << entry.totalNs << ',' << entry.calls << ',' << entry.totalValue << ',' << entry.valueCalls << ',' << entry.maximumValue << ']';
                    }
                    trace << "}}"; response = trace.str();
                } else if (command == "FORMAT") {'''
assert needle in s;s=s.replace(needle,replacement);source=r/'diagnostic-worker.cpp';source.write_text(s)
commands=subprocess.check_output(['ninja','-C',str(build),'-t','commands','zyx_workload_contract_worker'],text=True).splitlines();compile=shlex.split(next(v for v in commands if ' -c ' in v and 'native-worker.cpp' in v));obj=r/'diagnostic-worker.o';binary=r/'diagnostic-worker'
for flag,value in [('-o',str(obj)),('-MF',str(obj)+'.d'),('-MT',str(obj))]:
 if flag in compile:compile[compile.index(flag)+1]=value
compile[compile.index('-c')+1]=str(source);link=shlex.split(commands[-1].removeprefix(': && ').removesuffix(' && :'));old=next(v for v in link if v.endswith('native-worker.cpp.o'));link[link.index(old)]=str(obj);link[link.index('-o')+1]=str(binary)
if '-Xlinker' in link:i=link.index('-Xlinker');del link[i:i+2]
subprocess.run(compile,cwd=build,check=True);subprocess.run(link,cwd=build,check=True)
(r/'diagnostic-worker-provenance.json').write_text(json.dumps({'scope':'instrumented diagnosis only, never formal performance evidence','production_core_unchanged':True,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'compile':compile,'link':link},indent=2)+'\n');print(binary)

from pathlib import Path
import os,sys,time,json,resource
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from runner.workload_preflight import NativeWorker,cypher
r=Path('/workspace/zyx-resume-evaluation-20261018');out=r/os.environ.get('ZYX_PROPERTY_DIAGNOSTIC_OUTPUT','property-path-diagnosis');out.mkdir(exist_ok=False)
os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3));begin=time.monotonic();records=[]
w=NativeWorker(r/'diagnostic-worker',out/'diagnostic.zyx',out)
def call(kind,*args,**kw):
 if time.monotonic()-begin>120:raise RuntimeError('diagnostic whole-run120s budget exhausted')
 before=w.call('STATS');w.call('TRACE_ON');start=time.monotonic();result=w.call(*args,**kw);elapsed=time.monotonic()-start;trace=w.call('TRACE_OFF')['trace'];after=w.call('STATS');entry={'kind':kind,'elapsed_diagnostic_seconds':elapsed,'read_bytes':after['read_bytes']-before['read_bytes'],'write_bytes':after['write_bytes']-before['write_bytes'],'file_bytes':after['file_bytes'],'trace':trace};records.append(entry)
 with (out/'operations.jsonl').open('a') as f:f.write(json.dumps(entry)+'\n')
 return result
try:
 call('schema','QUERY','CREATE INDEX diag_wide_id FOR (n:Wide) ON (n.id)')
 for width in (8,128):
  for size in (32768,1048576):
   for i in range(8):
    identifier=(width+size)*1000+i;props={'id':identifier,**{f'field_{k}':k for k in range(width)}};body='x'*size;kind=f'wide-{width}-{size}'
    call(kind+'-create','PARAM',f'CREATE (n:Wide {cypher(props)}) SET n.body = $body RETURN n.id AS id','body','string',body,expected=[[identifier]])
    call(kind+'-update','QUERY',f'MATCH (n:Wide {{id:{identifier}}}) SET n.field_0 = 77 RETURN n.id AS id',expected=[[identifier]]);props['field_0']=77;props['body']=body
    call(kind+'-point','QUERY',f'MATCH (n:Wide {{id:{identifier}}}) RETURN n.field_0 AS value',expected=[[77]])
    call(kind+'-full','QUERY',f'MATCH (n:Wide {{id:{identifier}}}) RETURN properties(n) AS fields',expected=[[props]])
 call('schema','QUERY','CREATE INDEX diag_dynamic_id FOR (n:Dynamic) ON (n.id)')
 for i in range(96):
  width=(1,8,64)[i%3];props={'id':i,**{f'field_{k}':k+i for k in range(width)},f'unique_{i}':i};kind=f'dynamic-{width}'
  call(kind+'-create','QUERY',f'CREATE (:Dynamic {cypher(props)})');w.call('BEGIN','old','read');old=dict(props)
  call(kind+'-update','QUERY',f"MATCH (n:Dynamic {{id:{i}}}) SET n.field_0 = 'changed' REMOVE n.unique_{i} RETURN n.id AS id",expected=[[i]]);props['field_0']='changed';del props[f'unique_{i}']
  if width>1:
   call(kind+'-null','QUERY',f'MATCH (n:Dynamic {{id:{i}}}) SET n.field_1 = null RETURN n.field_1 AS value',expected=[[None]]);del props['field_1']
  call(kind+'-full','QUERY',f'MATCH (n:Dynamic {{id:{i}}}) RETURN properties(n) AS fields',expected=[[props]])
  call(kind+'-snapshot','TXQUERY','old',f'MATCH (n:Dynamic {{id:{i}}}) RETURN properties(n) AS fields',expected=[[old]]);w.call('ROLLBACK','old')
 w.close();(out/'completed.json').write_text(json.dumps({'status':'diagnosis_completed','operations':len(records),'elapsed_seconds':time.monotonic()-begin,'performance_samples':0,'exact_results_verified':True,'instrumentation_enabled':True,'production_core_unchanged':True},indent=2)+'\n');print('diagnostic complete',len(records),flush=True)
except BaseException:
 w.process.kill();w.process.wait();(out/'partial-trace.json').write_text(json.dumps(w.trace));raise

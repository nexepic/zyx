from pathlib import Path
import subprocess,shlex,json
root=Path('/workspace/zyx');b=root/'buildDir';r=Path('/workspace/zyx-resume-evaluation-20261018')
names={'test_Superblock.cpp','test_SuperblockFile.cpp','test_SuperblockPair.cpp','test_AllocatorDirectory.cpp','test_CatalogTree.cpp','test_CatalogRadix.cpp','test_MetadataSnapshotRegistry.cpp','test_MetadataWriteBatch.cpp','test_MetadataStoreLifecycle.cpp','test_MetadataRetirement.cpp','test_RelocatableMetadataStoreIdentity.cpp','test_RelocatableMetadataStoreTokenFloors.cpp','test_RelocatableMetadataStoreRecoveryResources.cpp','test_RelocatableStorageBackend_LifecycleContracts.cpp','test_RelocatableStorageBackend_DirectReadContracts.cpp','test_RelocatablePropertyRowChunkLifecycle.cpp','test_RelocatablePropertyRowChunkFaults.cpp','test_RelocatableStorageBackend_TransactionAtomicity.cpp'}
paths=[p for p in (root/'tests/src/storage/relocatable').rglob('test_*.cpp') if p.name in names or p.name.startswith(('test_LocationDirectory','test_MetadataPage','test_RelocatableMetadataStoreValidation','test_RelocatableMetadataStoreGraphMutation'))]
commands=subprocess.check_output(['ninja','-C',str(b),'-t','commands','zyx_test_suite'],text=True).splitlines();objects=[]
for p in sorted(paths):
 line=next(v for v in commands if ' -c '+str(p) in v);args=shlex.split(line);objects.append(args[args.index('-o')+1])
manifest={'scope':'Affected storage metadata/allocator/backend modules only; not full unit suite','modules':[str(p.relative_to(root)) for p in sorted(paths)],'module_count':len(paths),'new_validation_tests':3}
(r/'superblock-repair-test-registration.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Building',len(paths),'necessary modules',flush=True)
subprocess.run(['ninja','-C',str(b),'-j','4','libzyx_core.a',*objects],check=True)
link=shlex.split(commands[-1].removeprefix(': && ').removesuffix(' && :'));link=[v for v in link if not v.endswith('.cpp.o')];index=link.index('-o');binary=r/'superblock-repair-tests';link[index:index]=objects;link[link.index('-o')+1]=str(binary);link.append('/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu/libgtest_main.a');subprocess.run(link,cwd=b,check=True);(r/'superblock-repair-test-link.json').write_text(json.dumps(link,indent=2)+'\n')
subprocess.run([str(binary),'--gtest_output=json:'+str(r/'superblock-repair-tests.json')],cwd=r,check=True)

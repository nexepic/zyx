#include <cstdio>
#include <cstring>
#include <typeinfo>
#include <execinfo.h>
extern "C" [[noreturn]] void __real___cxa_throw(void *, void *, void (*)(void *));
extern "C" [[noreturn]] void __wrap___cxa_throw(void *exception, void *type, void (*destroy)(void *)) {
    if (std::strstr(static_cast<std::type_info *>(type)->name(), "MaterializedByteLimitExceeded")) {
        std::fprintf(stderr, "MATERIALIZATION_DENIAL_THROW\n");
        void *frames[36]; const auto count = ::backtrace(frames, 36); ::backtrace_symbols_fd(frames, count, 2);
    }
    __real___cxa_throw(exception, type, destroy);
}

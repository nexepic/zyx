#pragma once

#include <cstddef>
#include <limits>
#include <new>
#include <stdexcept>
#include <vector>
#include <unordered_map>

namespace graph::query::execution::detail {

// MSVC STL's iterator-debug proxy contains two pointers. Default-allocator
// strings/vectors own one; its hash table owns separate list/vector proxies.
[[nodiscard]] inline constexpr size_t standardContainerProxyBytes() noexcept {
#if defined(_MSVC_STL_VERSION) && _ITERATOR_DEBUG_LEVEL > 0
    return 2U * sizeof(void *);
#else
    return 0U;
#endif
}

[[nodiscard]] inline size_t addStandardHeapBytes(size_t left, size_t right) {
    if (right > (std::numeric_limits<size_t>::max)() - left)
        throw std::overflow_error("standard container heap size overflowed");
    return left + right;
}

// Account default std::allocator requests, including MSVC's manually aligned
// large-allocation prefix. This is separate from malloc metadata and RSS.
[[nodiscard]] inline size_t standardAllocatorRequestBytes(size_t bytes, size_t alignment) {
#if defined(_MSVC_STL_VERSION) && (defined(_M_IX86) || defined(_M_X64))
#ifdef __STDCPP_DEFAULT_NEW_ALIGNMENT__
    constexpr size_t defaultAlignment = __STDCPP_DEFAULT_NEW_ALIGNMENT__;
#else
    constexpr size_t defaultAlignment = alignof(std::max_align_t);
#endif
    if (bytes >= 4096U && alignment <= defaultAlignment) {
#ifdef _DEBUG
        constexpr size_t prefix = 2U * sizeof(void *) + 31U;
#else
        constexpr size_t prefix = sizeof(void *) + 31U;
#endif
        return addStandardHeapBytes(bytes, prefix);
    }
#else
    static_cast<void>(alignment);
#endif
    return bytes;
}

template<class T>
[[nodiscard]] inline size_t standardVectorHeapBufferBytes(const std::vector<T> &values) {
    if (values.capacity() > (std::numeric_limits<size_t>::max)() / sizeof(T))
        throw std::overflow_error("standard vector heap size overflowed");
    return addStandardHeapBytes(standardContainerProxyBytes(),
        standardAllocatorRequestBytes(values.capacity() * sizeof(T), alignof(T)));
}

// Structural storage only; callers account key/value heap payloads separately.
// The default allocator is intentional: PMR containers account their requests
// through their owning resource instead of this observed-capacity model.
template<class Key, class Value, class Hash, class Equal>
[[nodiscard]] inline size_t standardUnorderedMapStructuralHeapBytes(
        const std::unordered_map<Key, Value, Hash, Equal> &map) {
    using Entry = typename std::unordered_map<Key, Value, Hash, Equal>::value_type;
    constexpr size_t nodeBytes = sizeof(Entry) + 2U * sizeof(void *) + alignof(Entry) - 1U;
#if defined(_MSVC_STL_VERSION)
    const size_t nodes = addStandardHeapBytes(map.size(), 1U);
    constexpr size_t bucketWidth = 2U * sizeof(void *);
    constexpr size_t proxyBytes = 2U * standardContainerProxyBytes();
#else
    const size_t nodes = map.size();
    constexpr size_t bucketWidth = sizeof(void *);
    constexpr size_t proxyBytes = 0U;
#endif
    if (map.bucket_count() > (std::numeric_limits<size_t>::max)() / bucketWidth)
        throw std::overflow_error("standard map bucket heap size overflowed");
    const size_t buckets = standardAllocatorRequestBytes(map.bucket_count() * bucketWidth, alignof(void *));
    const size_t nodeRequest = standardAllocatorRequestBytes(nodeBytes, alignof(Entry));
    if (nodes > (std::numeric_limits<size_t>::max)() / nodeRequest)
        throw std::overflow_error("standard map node heap size overflowed");
    return addStandardHeapBytes(proxyBytes, addStandardHeapBytes(buckets, nodes * nodeRequest));
}

} // namespace graph::query::execution::detail

from pathlib import Path
import subprocess,shutil,json
root=Path('/workspace/zyx');backend=root/'src/storage/relocatable/backend/RelocatableStorageBackend.cpp';worker=root/'tests/support/TransactionResourceFaultWorker.cpp'
s=backend.read_text();needle='''\t\t\t\t\tfoldStagedPropertyPatches(nextAccumulated, nextPatches, normalizedPatches,
\t\t\t\t\t\tpatchEntries, maximumPropertyEntries, control);''';assert needle in s;s=s.replace(needle,needle+'\n                    if (control.checkpoint) control.checkpoint();');backend.write_text(s)
w=worker.read_text();needle='''                observedWriteBudget = budget.get(); observing = true;
            }
        };''';assert needle in w;w=w.replace(needle,'''                observedWriteBudget = budget.get(); observing = true;
            } else observeWriteOwnership(liveBytes.load(std::memory_order_relaxed));
        };''');worker.write_text(w)
# A counterfactual build retains the consumed incoming payload until stage end.
negative=s
for name in ('patch','next'):
 for field,typ in [('sets','LogicalGraphWriteProperty'),('removals','std::string')]:
  line=f'                std::vector<{typ}>().swap({name}.{field});\n'
  assert line in negative;negative=negative.replace(line,'')
records=[]
try:
 backend.write_text(negative)
 with open('/tmp/zyx-private-peak-negative-build.log','w') as log:
  subprocess.run(['cmake','--build','buildDir','--target','zyx_transaction_resource_fault_worker','-j4'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 shutil.copy2(root/'buildDir/zyx_transaction_resource_fault_worker','/tmp/zyx-private-peak-negative-worker')
 path=Path('/tmp/zyx-private-peak-negative.zyx');path.unlink(missing_ok=True)
 completed=subprocess.run(['/tmp/zyx-private-peak-negative-worker','native-stage-heap-accounting',str(path)],capture_output=True,text=True)
 records.append({'variant':'retained_consumed_input','returncode':completed.returncode,'stdout':completed.stdout,'stderr':completed.stderr})
 if completed.returncode==0 or 'uncovered live allocator requests' not in completed.stderr:
  raise RuntimeError('counterfactual did not expose premature workspace refund')
finally:
 backend.write_text(s)
 Path('/tmp/zyx-private-peak-negative-evidence.json').write_text(json.dumps(records,indent=2)+'\n')
with open('/tmp/zyx-private-peak-fixed-build.log','w') as log:
 subprocess.run(['cmake','--build','buildDir','--target','zyx_transaction_resource_fault_worker','-j4'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
shutil.copy2(root/'buildDir/zyx_transaction_resource_fault_worker','/tmp/zyx-private-peak-fixed-worker')
with open('/tmp/zyx-private-peak-fixed-evidence.log','w') as log:
 subprocess.run(['python3','scripts/test_transaction_resource_faults.py','--worker','/tmp/zyx-private-peak-fixed-worker','--property-heap-accounting','--native-stage-heap-accounting','--output','/tmp/zyx-private-peak-fixed-evidence.json'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)

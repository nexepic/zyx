#include <gtest/gtest.h>
#include "graph/core/Node.hpp"
#include "graph/storage/relocatable/property/HybridPropertyValueReader.hpp"
#include "graph/storage/relocatable/property/HybridPropertyPageImage.hpp"
#include "graph/storage/relocatable/property/HybridPropertyDirectoryIntegrity.hpp"
#include "graph/storage/relocatable/entity/NativeGraphWritePlanner.hpp"
#include "storage/relocatable/entity/NativeGraphWritePlannerTestFixture.hpp"
#include "storage/relocatable/property/HybridPropertyReadContextTestAccess.hpp"
#include "storage/relocatable/property/HybridPropertyDescriptorStoreTestAccess.hpp"

using namespace graph::storage;
using graph::PropertyValue;
using graph::query::execution::MaterializedByteBudget;
#if ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT
namespace {
constexpr auto NODE = EntityPropertyOwnerKind::EPOK_NODE;
struct Trace {
    bool enabled = graph::debug::PerfTrace::areValuesEnabled();
    Trace() { graph::debug::PerfTrace::setValueCollectionEnabled(true); graph::debug::PerfTrace::reset(); }
    ~Trace() { graph::debug::PerfTrace::setValueCollectionEnabled(enabled); }
};
}
// Actual authenticated native field/index pages with an in-memory candidate
// descriptor, as in the existing read-context fixture. This does NOT enable a
// production converter or claim cold-ROW publication/ownership acceptance.
class HybridPropertyColdRowRoutingTest : public graph::storage::test::NativeGraphWritePlannerTestFixture {
protected:
    HybridPropertyDescriptor descriptor_;
    std::unique_ptr<LargeValueStore> values_;
    bool competing_row_ = false, competing_selector_ = false, bad_cold_crc_ = false, hot_in_cold_ = false;
    void seed(bool large = false) {
        NativeGraphWritePlannerOptions options;
        options.first_slot = PhysicalSlotId(40); options.last_slot = PhysicalSlotId(80);
        options.entity_pool_owner_id = 901; options.logical_id_lease_block_size = 1;
        options.property_roots = {PhysicalSlotId(40), PhysicalSlotId(80), 902};
        NativeGraphWritePlanner planner(*metadata_, *entities_, *labels_, *properties_, *btree_pages_, options);
        auto tx = planner.beginTransaction(); tx.reserveNodeIds(64);
        for (uint64_t id = 1; id <= 64; ++id) tx.createNodeWithReservedId(id, {});
        if (competing_row_) tx.replaceNodeProperty({1, graph::Node::typeId, {{7, PropertyValue("competing")}}});
        ASSERT_TRUE(tx.commit().committed());
        std::vector<std::byte> first;
        if (large) {
            values_ = std::make_unique<LargeValueStore>(io_, *metadata_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
            const auto payload = EntityPropertyLargeValuePayloadCodec::encode(std::vector<PropertyCollectionRootEntry>{
                {2, PropertyValue("user-000000")}, {4, PropertyValue(std::string(8193, 'x'))}});
            LargeValueWriteOptions placement;
            placement.first_data_slot = placement.first_manifest_slot = PhysicalSlotId(40);
            placement.last_data_slot = placement.last_manifest_slot = PhysicalSlotId(80);
            placement.media_type = RSS_ENTITY_PROPERTY_LARGE_VALUE_MEDIA_TYPE;
            const auto ref = values_->write(payload, placement,
                LogSequenceNumber(metadata_->openSnapshot().superblock().checkpoint_lsn.value() + 1)).reference;
            first = EntityPropertyLargeValueReferenceCodec::encode({1, graph::Node::typeId, ref});
        } else first = EntityPropertyCollectionRootCodec::encode({1, graph::Node::typeId,
            {{2, PropertyValue("user-000000")}, {4, PropertyValue()}}});
        const auto last = EntityPropertyCollectionRootCodec::encode({64, graph::Node::typeId,
            {{hot_in_cold_ ? 1U : 2U, PropertyValue("user-000063")}}});
        const auto current = metadata_->openSnapshot().superblock();
        const auto pageId = PageId((std::max)(UINT64_C(41), current.next_logical_page_id));
        auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
        auto image = HybridPropertyPageImage::create(pageId, Generation(99), current.generation, memory);
        HybridPropertyGroupRecord group{NODE, HybridPropertyGroupMode::HPGM_HYBRID,
            1, current.generation, UINT64_MAX, 51, 1};
        HybridPropertyColumnRecord column;
        column.identity = {NODE, HybridPropertyScalarKind::HPSK_INT64, 1, 1, current.generation};
        column.live = UINT64_MAX; column.presence = (UINT64_C(1) << 48) - 1; column.nulls = UINT64_C(1) << 2;
        for (unsigned slot = 0; slot < 48; ++slot) column.words[slot] = slot == 2 ? 0 : slot + 100;
        const auto hot = image.appendColumn(column, group, current.generation);
        const std::array<HybridColdRowInput, 2> rows{{{0, 2, large, first}, {63, 1, false, last}}};
        auto encoded = HybridPropertyColdRowBlock::encode(NODE, 1, current.generation, rows, memory);
        const auto cold = image.appendColdRows(encoded, NODE, 1);
        auto matrix = HybridPropertyColumnMembership::fromColumns(group, std::span(&column, 1));
        matrix.row_remainder = true; matrix.locators[0] = hot; matrix.cold_fields = 3;
        matrix.cold_rows.owners = UINT64_C(1) | (UINT64_C(1) << 63);
        matrix.cold_rows.roots[0] = matrix.cold_rows.roots[63] = cold;
        group.column_membership = image.appendColumnMembership(matrix, group, current.generation);
        group.mode = HybridPropertyGroupMode::HPGM_COLUMN_ROW_REMAINDER;
        const auto groupSlot = image.appendGroup(group);
        SharedPagePoolAllocationRequest request;
        request.segment_id = SegmentId(31); request.pool_kind = SegmentKind::SGK_PROPERTY_PAGE_POOL;
        request.pool_owner_id = 902; request.generation = Generation(99); request.page_id = pageId;
        request.page_owner_id = 902; request.page_owner_kind = PageOwnerKind::POK_PROPERTY;
        const auto neutral = image.serialize(); request.payload.assign(neutral.begin(), neutral.end());
        request.page_free_bytes = image.stats().contiguous_free_bytes;
        const auto lsn = LogSequenceNumber(current.checkpoint_lsn.value() + 1);
        SharedPagePoolAllocator pools(io_, *metadata_, SharedPagePoolOpenMode::SPPOM_READ_ONLY);
        const auto allocation = pools.allocateNewPoolPage(std::move(request), PhysicalSlotId(40), PhysicalSlotId(80), lsn);
        ASSERT_TRUE(allocation);
        PageOwnerHeader owner{pageId, 902, PageOwnerKind::POK_HYBRID_PROPERTY, 0,
            RSS_PAGE_OWNER_MAX_PAYLOAD_BYTES, Generation(99), lsn};
        auto bound = std::move(image).bindPrivateOwner(owner, allocation->pool, lsn);
        if (bad_cold_crc_) { encoded.back() ^= std::byte{1}; bound.overwrite(cold, encoded); }
        const auto payload = bound.serializeOwned(memory);
        std::array<std::byte, RSS_PAGE_SIZE> frame{};
        const auto header = PageOwnerHeaderCodec::encode(owner);
        std::copy(header.begin(), header.end(), frame.begin());
        std::copy(payload.begin(), payload.end(), frame.begin() + RSS_PAGE_OWNER_HEADER_BYTES);
        const auto offset = PhysicalSegmentAllocator::checkedSlotOffset(current.data_region_offset, allocation->pool.physical_slot) +
            uint64_t(allocation->location.page_index) * RSS_PAGE_SIZE;
        io_->writeAt({offset, 99}, frame.data(), frame.size());
        std::vector<IndexRootLocation> roots;
        for (unsigned role : {0U, 3U}) {
            if (role == 0 && !competing_selector_) continue;
            const auto index = hybridPropertyIndexId(static_cast<HybridPropertyRootOrdinal>(role));
            const auto treePage = PageId(pageId.value() + 60 + role);
            const auto next = LogSequenceNumber(metadata_->openSnapshot().superblock().checkpoint_lsn.value() + 1);
            PageOwnerHeader treeOwner{treePage, index, PageOwnerKind::POK_INDEX, 0,
                RSS_PAGE_OWNER_MAX_PAYLOAD_BYTES, Generation(99), next};
            BTreePageHeader treeHeader; treeHeader.index_id = index; treeHeader.page_id = treePage;
            treeHeader.generation = Generation(99); treeHeader.leaf_value_layout = BTreeLeafValueLayout::BLVL_EMPTY;
            auto tree = BTreePage::create(treeOwner, treeHeader);
            std::vector<std::byte> entry;
            if (role == 3) {
                const auto bytes = HybridPropertyGroupDirectoryMap::encode(HybridPropertyDirectoryCodec::groupKey(1),
                    HybridPropertyDirectoryCodec::locatorValue(groupSlot)); entry.assign(bytes.begin(), bytes.end());
            } else {
                const auto bytes = HybridPropertyOwnerMap::encode(HybridPropertyDirectoryCodec::ownerKey({NODE, 64}, 1),
                    HybridPropertyDirectoryCodec::sourceValue(HybridPropertySource::HPS_EXTENSION)); entry.assign(bytes.begin(), bytes.end());
            }
            tree.insert({entry, 0});
            SlottedPagePoolAllocationRequest placement;
            placement.segment_id = SegmentId(71 + role); placement.pool_kind = SegmentKind::SGK_INDEX_PAGE_POOL;
            placement.pool_owner_id = index; placement.generation = Generation(99); placement.page_id = treePage;
            placement.page_owner_id = index; placement.page_owner_kind = PageOwnerKind::POK_INDEX;
            ASSERT_TRUE(btree_pages_->allocate(placement, tree, PhysicalSlotId(40), PhysicalSlotId(80), next));
            roots.push_back({index, treePage, Generation(99)}); descriptor_.roots[role] = {treePage, Generation(99)};
        }
        static_cast<void>(btree_pages_->publishRoots(roots, {},
            LogSequenceNumber(metadata_->openSnapshot().superblock().checkpoint_lsn.value() + 1)));
        static_cast<void>(HybridPropertyDescriptorStoreTestAccess::enableCompactReadFixture(*metadata_));
        const auto final = metadata_->openSnapshot().superblock();
        descriptor_.database_id = final.database_id; descriptor_.semantic_generation = final.generation;
    }
};
TEST_F(HybridPropertyColdRowRoutingTest, PointValuesPresenceCountsAndFullCollectionsShareExactHotColdAuthority) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    graph::utils::OwnedAllocationScope scope(memory);
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    const auto read = [&](uint64_t id, uint32_t token) { return HybridPropertyValueReader::read(context, pin, {NODE, id}, token); };
    EXPECT_EQ(read(1, 1).value->value, PropertyValue(int64_t(100)));
    EXPECT_EQ(read(1, 2).value->value, PropertyValue("user-000000"));
    EXPECT_EQ(read(3, 1).value->value, PropertyValue());
    EXPECT_EQ(read(64, 2).value->value, PropertyValue("user-000063"));
    EXPECT_FALSE(read(64, 1).value); EXPECT_FALSE(read(49, 2).value); EXPECT_FALSE(read(1, 99).value);
    EXPECT_EQ(HybridPropertyValueReader::exists(context, pin, {NODE, 1}, 4), true);
    EXPECT_EQ(HybridPropertyValueReader::exists(context, pin, {NODE, 1}, 4, true), false);
    EXPECT_EQ(HybridPropertyValueReader::exists(context, pin, {NODE, 64}, 1), false);
    EXPECT_EQ(context.count({NODE, 1}), 3U); EXPECT_EQ(context.count({NODE, 2}), 1U);
    EXPECT_EQ(context.count({NODE, 49}), 0U); EXPECT_EQ(context.count({NODE, 64}), 1U);
    const auto full = HybridPropertyValueReader::readCollection(context, pin, {NODE, 1}, graph::Node::typeId);
    ASSERT_TRUE(full.routed); ASSERT_TRUE(full.value);
    EXPECT_EQ(full.value->entries, (std::vector<PropertyCollectionRootEntry>{{1, PropertyValue(int64_t(100))},
        {2, PropertyValue("user-000000")}, {4, PropertyValue()}}));
    const auto empty = HybridPropertyValueReader::readCollection(context, pin, {NODE, 49}, graph::Node::typeId);
    EXPECT_TRUE(empty.routed); EXPECT_FALSE(empty.value);
    EXPECT_THROW(context.groupRecord({NODE, 1}), FormatException);
    EXPECT_THROW(HybridPropertyDirectoryIntegrity::verify(context, pin, memory), FormatException);
}
TEST_F(HybridPropertyColdRowRoutingTest, WholeRootLargeValuesKeepTheSamePointEnumerationAndFullReadBoundary) {
    seed(true); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    graph::utils::OwnedAllocationScope scope(memory);
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    EXPECT_EQ(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 2, values_.get()).value->value, PropertyValue("user-000000"));
    EXPECT_EQ(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 4, values_.get()).value->value, PropertyValue(std::string(8193, 'x')));
    EXPECT_EQ(context.count({NODE, 1}), 3U);
    EXPECT_EQ(HybridPropertyValueReader::exists(context, pin, {NODE, 1}, 4, true, values_.get()), true);
    EXPECT_EQ(HybridPropertyValueReader::readCollection(context, pin, {NODE, 1}, graph::Node::typeId, values_.get()).value->entries.size(), 3U);
}
TEST_F(HybridPropertyColdRowRoutingTest, HotReadsDoNotTouchCorruptUnvisitedColdBlockAndColdReadsFailClosed) {
    bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); graph::utils::OwnedAllocationScope scope(memory);
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    EXPECT_EQ(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 1).value->value, PropertyValue(int64_t(100)));
    EXPECT_FALSE(HybridPropertyValueReader::read(context, pin, {NODE, 64}, 1).value);
    EXPECT_THROW(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 2), FormatException);
}
TEST_F(HybridPropertyColdRowRoutingTest, CompetingOrdinaryRowStillRejectsEvenAnOtherwiseValidHotRead) {
    competing_row_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    EXPECT_THROW(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 1), FormatException);
}
TEST_F(HybridPropertyColdRowRoutingTest, CompetingExplicitSelectorCannotOverrideAGroupGlobalMissingHotCell) {
    competing_selector_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    EXPECT_THROW(HybridPropertyValueReader::read(context, pin, {NODE, 64}, 1), FormatException);
}
TEST_F(HybridPropertyColdRowRoutingTest, ColdEnumerationRejectsGloballyHotTokenEvenWhereThatOwnerHasNoHotMembership) {
    hot_in_cold_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); graph::utils::OwnedAllocationScope scope(memory);
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    EXPECT_FALSE(HybridPropertyValueReader::read(context, pin, {NODE, 64}, 1).value);
    EXPECT_THROW(context.count({NODE, 64}), FormatException);
    EXPECT_THROW(HybridPropertyValueReader::read(context, pin, {NODE, 64}, 2), FormatException);
}
TEST_F(HybridPropertyColdRowRoutingTest, ColdRepresentationHandoffRunsBeforeDecodeAndLeaseRestoresParentOnFailure) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    graph::utils::OwnedAllocationScope scope(memory);
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    std::optional<graph::utils::OwnedVector<std::byte>> old;
    old.emplace(graph::utils::OwnedPmrAllocator<std::byte>(memory)); old->resize(RSS_PAGE_SIZE);
    unsigned parentCalls = 0, childCalls = 0;
    const std::function<void()> parent = [&] { ++parentCalls; old.reset(); };
    auto parentLease = context.borrowColdRowRepresentation(&parent);
    EXPECT_EQ(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 1).value->value, PropertyValue(int64_t(100)));
    EXPECT_EQ(parentCalls, 0U); ASSERT_TRUE(old);
    {
        const std::function<void()> child = [&] { ++childCalls; throw std::runtime_error("handoff refused"); };
        auto lease = context.borrowColdRowRepresentation(&child);
        EXPECT_THROW(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 2), std::runtime_error);
        EXPECT_EQ(childCalls, 1U); EXPECT_TRUE(old);
    }
    EXPECT_EQ(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 2).value->value, PropertyValue("user-000000"));
    EXPECT_EQ(parentCalls, 1U); EXPECT_FALSE(old);
}

TEST_F(HybridPropertyColdRowRoutingTest, GroupedHotRunsAuthenticateAllOwnersWithoutReadingAnyColdRoot) {
    bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); graph::utils::OwnedAllocationScope scope(memory);
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    std::array<EntityPropertyKey, 64> owners{};
    for (unsigned i = 0; i < owners.size(); ++i) owners[i] = {NODE, i + 1};
    const std::array<uint32_t, 1> tokens{1}; size_t scalarCount = 0, missing = 0, runs = 0;
    const std::function<void(size_t, size_t, std::optional<PropertyCollectionRootEntry>)> owning =
        [&](size_t row, size_t column, auto value) { EXPECT_GE(row, 48U); EXPECT_EQ(column, 0U); EXPECT_FALSE(value); ++missing; };
    const PropertyScalarReadSink scalar = [&](size_t row, size_t column, auto type, uint64_t word) {
        EXPECT_LT(row, 48U); EXPECT_EQ(column, 0U);
        if (row == 2) { EXPECT_EQ(type, graph::PropertyType::NULL_TYPE); EXPECT_EQ(word, 0U); }
        else { EXPECT_EQ(type, graph::PropertyType::INTEGER); EXPECT_EQ(word, row + 100U); }
        ++scalarCount;
    };
    const PropertyTextReadSink text = [](auto, auto, auto) { ADD_FAILURE() << "integer column emitted text"; };
    PropertyColumnBatchReadSinks batches;
    batches.scalars = [&](auto rows, size_t column, auto type, auto words) {
        ++runs; ASSERT_EQ(rows.size(), words.size());
        for (size_t i = 0; i < rows.size(); ++i) scalar(rows[i], column, type, words[i]);
    };
    batches.texts = [](auto, auto, auto) { ADD_FAILURE() << "integer column emitted text run"; };
    struct Work { int64_t cold = 0, routes = 0; } work;
    graph::debug::PerfTrace::ScopedObserver observer(&work, [](void *owner, std::string_view key, int64_t value, bool) noexcept {
        auto &w = *static_cast<Work *>(owner);
        if (key == "native_graph.hybrid.cold_block_decodes") w.cold += value;
        if (key == "native_graph.hybrid.grouped_owner_route_checks") w.routes += value;
    });
    EXPECT_TRUE(HybridPropertyValueReader::readSelected(context, pin, owners, tokens, {}, {}, nullptr,
        nullptr, &owning, &scalar, &text, &batches));
    EXPECT_EQ(scalarCount, 48U); EXPECT_EQ(missing, 16U); EXPECT_EQ(runs, 3U);
    EXPECT_EQ(work.cold, 0); EXPECT_EQ(work.routes, 64);
}
TEST_F(HybridPropertyColdRowRoutingTest, TypedColdTextBorrowAndMutationRefusalNeverMaterializeAnOwningValue) {
    seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); graph::utils::OwnedAllocationScope scope(memory);
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    const std::array<EntityPropertyKey, 2> owners{{{NODE, 1}, {NODE, 64}}};
    const std::array<uint32_t, 1> tokens{2}; size_t texts = 0, mutations = 0;
    const std::function<void(size_t, size_t, std::optional<PropertyCollectionRootEntry>)> owning =
        [](auto, auto, auto) { ADD_FAILURE() << "cold primitive escaped through an owning fallback"; };
    const PropertyScalarReadSink scalar = [](auto, auto, auto, auto) { ADD_FAILURE() << "text emitted as scalar"; };
    const PropertyTextReadSink text = [&](size_t row, size_t column, std::string_view value) {
        EXPECT_EQ(column, 0U); EXPECT_EQ(value, row ? "user-000063" : "user-000000"); ++texts;
    };
    graph::property_decode::AllocationScope forbid(nullptr, [](void *, size_t) {
        throw std::logic_error("typed cold text must borrow its source bytes");
    });
    EXPECT_TRUE(HybridPropertyValueReader::readSelected(context, pin, owners, tokens, {}, {}, nullptr,
        nullptr, &owning, &scalar, &text));
    EXPECT_EQ(texts, 2U);
    EXPECT_THROW(context.visitField({NODE, 1}, 1, [](const auto &) {}, [](const auto &) {}, {}, {},
        [&](const auto &, const auto &, const auto &, const auto &) { ++mutations; }), FormatException);
    EXPECT_EQ(mutations, 0U);
}

TEST_F(HybridPropertyColdRowRoutingTest, ScalarFallbackUsesMetadataPresenceAndNeverReadsAnUnrequestedColdRoot) {
    bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); graph::utils::OwnedAllocationScope scope(memory);
    auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
    const std::array<EntityPropertyKey, 2> owners{{{NODE, 1}, {NODE, 64}}};
    const std::array<uint32_t, 1> tokens{1}; size_t delivered = 0, missing = 0;
    const std::function<void(size_t, size_t, std::optional<PropertyCollectionRootEntry>)> owning =
        [&](size_t row, size_t column, auto value) { EXPECT_EQ(row, 1U); EXPECT_EQ(column, 0U); EXPECT_FALSE(value); ++missing; };
    const PropertyScalarReadSink scalar = [&](size_t row, size_t column, auto type, uint64_t word) {
        EXPECT_EQ(row, 0U); EXPECT_EQ(column, 0U); EXPECT_EQ(type, graph::PropertyType::INTEGER); EXPECT_EQ(word, 100U); ++delivered;
    };
    EXPECT_TRUE(HybridPropertyValueReader::readSelected(context, pin, owners, tokens, {}, {}, nullptr, nullptr, &owning, &scalar));
    EXPECT_EQ(delivered, 1U); EXPECT_EQ(missing, 1U);
    // Asking for exact counts really does access the cold directory, so its
    // corruption must then be discovered rather than inferred from a bitmap.
    std::array<std::optional<size_t>, 2> counts;
    EXPECT_THROW(HybridPropertyValueReader::readSelected(context, pin, owners, tokens, {}, counts,
        nullptr, nullptr, &owning, &scalar), FormatException);
}
#endif

#include "storage/relocatable/property/HybridPropertyColdRowRoutingTestFixture.hpp"
#include "graph/storage/relocatable/metadata/HybridPropertyDemotionPreparation.hpp"
#include <algorithm>
#if ZYX_EXPERIMENTAL_HYBRID_PROPERTY_FORMAT
using namespace graph::storage;
using graph::PropertyValue;
using graph::query::execution::MaterializedByteBudget;
namespace {
class RejectColdHotPhysicalAllocation final : public MetadataPageAllocator {
    MetadataPageId allocateMetadataPageId() override { throw std::logic_error("hot preparation allocated metadata"); }
    MetadataPageAllocation allocatePage(Generation, LogSequenceNumber, std::span<const PhysicalSlotId>) override {
        throw std::logic_error("hot preparation allocated physical storage");
    }
    void abandonPage(PhysicalPageRef) noexcept override {}
};
class HybridPropertyColdCompatibleHotTest : public graph::storage::test::HybridPropertyColdRowRoutingTest {
protected:
    const HybridPropertyPageImage &image(const HybridPropertyDemotionPreparation &prepared, PageId id) {
        for (const auto &page : prepared.pages()) if (page.pageId() == id) return page;
        throw std::logic_error("hot preparation lost its page");
    }
};
}
TEST_F(HybridPropertyColdCompatibleHotTest, CompatibleHotValuePreservesUnvisitedColdBytesAndPublicMutationGuard) {
    bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock();
    const auto epoch = io_->dataMutationEpoch(); int64_t decodes = 0;
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        EXPECT_THROW(context.groupRecord({NODE, 1}), FormatException);
        EXPECT_THROW(context.visitField({NODE, 1}, 1, [](const auto &) {}, [](const auto &) {}, {}, {},
            [](const auto &, const auto &, const auto &, const auto &) {}), FormatException);
        graph::debug::PerfTrace::ScopedObserver observer(&decodes, [](void *p, std::string_view key, int64_t value, bool) noexcept {
            if (key == "native_graph.hybrid.cold_block_decodes") *static_cast<int64_t *>(p) += value;
        });
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const PropertyValue replacement(int64_t(444));
        auto change = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, batch.generation(), memory, &replacement);
        ASSERT_TRUE(change); EXPECT_EQ(change->action(), HybridPropertyColumnDelta::Action::HCD_REPLACE_COLUMN);
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const HybridPropertyDemotionPreparation prepared(batch, pin, fields, *change, memory);
        ASSERT_EQ(prepared.pages().size(), 1U); EXPECT_TRUE(prepared.owners().empty()); EXPECT_TRUE(prepared.extensions().empty());
        EXPECT_TRUE(prepared.erasedOwners().empty());
        const auto &page = image(prepared, change->groupReference().page_id);
        const auto group = page.readGroup(change->groupReference(), NODE, 1, batch.generation());
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        const auto column = image(prepared, change->columnReference().page_id).readColumn(change->columnReference(),
            change->replacementColumn().identity, group, batch.generation());
        EXPECT_EQ(column.words[0], 444U); EXPECT_EQ(group.memberships, 51U); EXPECT_EQ(matrix.cold_fields, 3U);
        EXPECT_EQ(matrix.cold_rows.roots[0], cold_reference_);
        EXPECT_TRUE(std::ranges::equal(image(prepared, cold_reference_.page_id).readRecord(cold_reference_), cold_encoded_bytes_));
        const auto location = metadata_->findPageLocation(pin, field_page_id_);
        const auto pool = metadata_->findCatalog(pin, location.segment_id);
        const PageOwnerHeader owner{field_page_id_, pool.owner_id, PageOwnerKind::POK_HYBRID_PROPERTY, 0,
            RSS_PAGE_OWNER_MAX_PAYLOAD_BYTES, pool.generation, batch.checkpointLsn()};
        // Only an actual FieldPageStore clone carries source provenance. A
        // public serialized reopen cannot use it to bypass corrupt cold bytes.
        auto untrusted = HybridPropertyPageImage::open(page.serialize(), field_page_id_, pool.generation, batch.generation(), memory);
        EXPECT_THROW(std::move(untrusted).bindPrivateOwner(owner, pool, batch.checkpointLsn()), FormatException);
        auto trusted = page.clone(batch.generation(), memory);
        const auto bound = std::move(trusted).bindPrivateOwner(owner, pool, batch.checkpointLsn());
        EXPECT_TRUE(std::ranges::equal(bound.read(cold_reference_), cold_encoded_bytes_));
        EXPECT_THROW(HybridPropertyColdRowBlock::decode(bound.read(cold_reference_), NODE, 1, batch.generation(), memory), FormatException);
        EXPECT_EQ(batch.candidate().next_logical_page_id, before.next_logical_page_id); EXPECT_EQ(batch.allocatedPageCount(), 0U);
        EXPECT_EQ(HybridPropertyValueReader::read(context, pin, {NODE, 1}, 1).value->value, PropertyValue(int64_t(100)));
    }
    EXPECT_EQ(decodes, 0); EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before);
    EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, MissingHotNullInsertionOnEdgeKeepsColdBindingAndExactTotals) {
    owner_kind_ = EntityPropertyOwnerKind::EPOK_EDGE; raw_cold_ = true; seed(); auto pin = metadata_->openSnapshot();
    auto memory = std::make_shared<MaterializedByteBudget>(1U << 20); const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        const PropertyValue null;
        auto change = HybridPropertyColumnDelta::planMissingColumnMember(context, pin, {owner_kind_, 64}, 1, batch.generation(), memory, null);
        ASSERT_TRUE(change); EXPECT_EQ(change->effects().memberships, 1);
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const HybridPropertyDemotionPreparation prepared(batch, pin, fields, *change, memory);
        const auto &page = image(prepared, change->groupReference().page_id);
        const auto group = page.readGroup(change->groupReference(), owner_kind_, 1, batch.generation());
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        const auto column = image(prepared, change->columnReference().page_id).readColumn(change->columnReference(),
            change->replacementColumn().identity, group, batch.generation());
        EXPECT_EQ(group.memberships, 52U); EXPECT_EQ(matrix.totalMemberships(), 52U); EXPECT_EQ(matrix.cold_fields, 3U);
        EXPECT_TRUE(matrix.contains({owner_kind_, 64}, 1)); EXPECT_TRUE(column.nulls & (UINT64_C(1) << 63)); EXPECT_EQ(column.words[63], 0U);
        EXPECT_EQ(matrix.cold_rows.roots[0], cold_reference_);
        EXPECT_TRUE(std::ranges::equal(image(prepared, cold_reference_.page_id).readRecord(cold_reference_), cold_encoded_bytes_));
        EXPECT_TRUE(prepared.owners().empty()); EXPECT_TRUE(prepared.erasedOwners().empty()); EXPECT_TRUE(prepared.extensions().empty());
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, NoopAndColdOrUnsupportedChangesCannotEscapeAsMutationAuthority) {
    bad_cold_crc_ = true; seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const Generation next(before.generation.value() + 1); const PropertyValue same(int64_t(100)), text("incompatible-hot");
        auto unchanged = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, &same);
        ASSERT_TRUE(unchanged); EXPECT_EQ(unchanged->action(), HybridPropertyColumnDelta::Action::HCD_NO_CHANGE);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const HybridPropertyDemotionPreparation prepared(batch, pin, fields, *unchanged, memory); EXPECT_TRUE(prepared.pages().empty());
        EXPECT_THROW(HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, &text), FormatException);
        EXPECT_THROW(HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, nullptr), FormatException);
        EXPECT_THROW(HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, nullptr, true), FormatException);
        EXPECT_FALSE(HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 2, next, memory, &same));
        EXPECT_FALSE(HybridPropertyColumnDelta::planMissingColumnMember(context, pin, {NODE, 1}, 9, next, memory, same));
        EXPECT_EQ(batch.candidate().next_logical_page_id, before.next_logical_page_id);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before); EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
TEST_F(HybridPropertyColdCompatibleHotTest, MergedIndividuallyCompatibleRemovalsCannotBecomeUnsupportedDemotion) {
    hot_owner_count_ = 64; seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock();
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const Generation next(before.generation.value() + 1);
        std::vector<HybridPropertyColumnDelta> plans; plans.reserve(17);
        for (uint64_t id = 1; id <= 17; ++id) {
            auto change = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, id}, 1, next, memory, nullptr);
            ASSERT_TRUE(change); EXPECT_EQ(change->action(), HybridPropertyColumnDelta::Action::HCD_REPLACE_COLUMN);
            plans.push_back(std::move(*change));
        }
        std::array<const HybridPropertyColumnDelta *, 17> inputs{};
        for (size_t i = 0; i < plans.size(); ++i) inputs[i] = &plans[i];
        auto merged = HybridPropertyColumnDelta::mergeExistingColumnChanges(std::span(inputs).first(16), memory);
        EXPECT_EQ(merged.action(), HybridPropertyColumnDelta::Action::HCD_REPLACE_COLUMN);
        EXPECT_EQ(std::popcount(merged.replacementColumn().presence), 48);
        RejectColdHotPhysicalAllocation allocator; MetadataWriteBatch batch(allocator, before, LogSequenceNumber(before.checkpoint_lsn.value() + 1));
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        const HybridPropertyDemotionPreparation prepared(batch, pin, fields, merged, memory);
        const auto &page = image(prepared, merged.groupReference().page_id);
        const auto group = page.readGroup(merged.groupReference(), NODE, 1, batch.generation());
        const auto matrix = page.readColumnMembership(group.column_membership, group, batch.generation());
        EXPECT_EQ(group.memberships, 51U); EXPECT_EQ(matrix.totalMemberships(), 51U); EXPECT_EQ(matrix.cold_fields, 3U);
        EXPECT_TRUE(prepared.owners().empty()); EXPECT_TRUE(prepared.erasedOwners().empty());
        EXPECT_TRUE(std::ranges::equal(image(prepared, cold_reference_.page_id).readRecord(cold_reference_), cold_encoded_bytes_));
        const auto retained = memory->used();
        EXPECT_THROW(HybridPropertyColumnDelta::mergeExistingColumnChanges(inputs, memory), FormatException);
        EXPECT_EQ(memory->used(), retained);
    }
    EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before);
}
TEST_F(HybridPropertyColdCompatibleHotTest, FreshAndReusedColdSlotsCannotInheritUnchangedSourceProof) {
    seed(); auto pin = metadata_->openSnapshot(); auto memory = std::make_shared<MaterializedByteBudget>(1U << 20);
    const auto before = pin.superblock(); const auto epoch = io_->dataMutationEpoch(); int64_t skipped = 0;
    {
        graph::utils::OwnedAllocationScope scope(memory);
        auto context = HybridPropertyReadContextTestAccess::open(io_, *slotted_pages_, *metadata_, pin, descriptor_);
        const Generation next(before.generation.value() + 1); const PropertyValue same(int64_t(100));
        const auto change = HybridPropertyColumnDelta::planExistingColumn(context, pin, {NODE, 1}, 1, next, memory, &same);
        ASSERT_TRUE(change);
        HybridPropertyFieldPageStore fields(io_, *metadata_, pin);
        for (const bool fresh : {false, true}) {
        auto page = fields.cloneForMutation(pin, field_page_id_, next, memory);
        const auto previous = change->sourceGroup(); auto replacement = previous; replacement.semantic_generation = next;
        auto matrix = page.readColumnMembership(previous.column_membership, previous, next); matrix.semantic_generation = next;
        if (!fresh) page.erase(cold_reference_);
        const auto inserted = page.appendColdRows(cold_encoded_bytes_, NODE, 1);
        if (fresh) page.erase(cold_reference_);
        EXPECT_NE(inserted, cold_reference_);
        matrix.cold_rows.roots[0] = matrix.cold_rows.roots[63] = inserted;
        page.replaceColumnMembership(previous.column_membership, matrix, previous, replacement, next);
        page.replaceGroup(change->groupReference(), replacement, next);
        const auto location = metadata_->findPageLocation(pin, field_page_id_); const auto pool = metadata_->findCatalog(pin, location.segment_id);
        const LogSequenceNumber lsn(before.checkpoint_lsn.value() + 1);
        const PageOwnerHeader owner{field_page_id_, pool.owner_id, PageOwnerKind::POK_HYBRID_PROPERTY, 0,
            RSS_PAGE_OWNER_MAX_PAYLOAD_BYTES, pool.generation, lsn};
        graph::debug::PerfTrace::ScopedObserver observer(&skipped, [](void *p, std::string_view key, int64_t value, bool) noexcept {
            if (key == "native_graph.hybrid.unchanged_cold_bindings") *static_cast<int64_t *>(p) += value;
        });
        const auto bound = std::move(page).bindPrivateOwner(owner, pool, lsn);
        const auto block = HybridPropertyFieldView::decodeColdRows(bound.read(inserted), inserted, replacement, matrix, next, next, memory);
        EXPECT_EQ(block.fields, 3U); EXPECT_EQ(block.owners, UINT64_C(1) | (UINT64_C(1) << 63));
        }
    }
    EXPECT_EQ(skipped, 0); EXPECT_EQ(memory->used(), 0U); EXPECT_EQ(metadata_->openSnapshot().superblock(), before);
    EXPECT_EQ(io_->dataMutationEpoch(), epoch);
}
#endif

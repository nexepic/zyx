from pathlib import Path
import sys,os,subprocess,json,resource,hashlib
sys.path.insert(0,'/workspace/zyx/benchmarks/graphdb-comparison')
from dataset.generate import SCALES,generate_graph,write_dataset
r=Path('/workspace/zyx-resume-evaluation-20261018');out=r/os.environ.get('ZYX_MEMORY_TEST_OUTPUT','native-process-memory-report-check');out.mkdir(exist_ok=False);data=out/'dataset';write_dataset(generate_graph(SCALES['smoke'],seed=42),data)
resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,6*1024**3));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024**3,2*1024**3));pressure=bytearray(256*1024**2);pressure[::4096]=b'x'*(len(pressure)//4096)
parent_rss=int(next(s.split()[1] for s in Path('/proc/self/status').read_text().splitlines() if s.startswith('VmRSS:')))*1024;results=[]
def execute(label,binary,prepared=None,report=True,destination=None,negative=False):
 db=out/(label+'.zyx');target=destination or out/(label+'-memory.json');env=dict(os.environ)
 if report:env['ZYX_COMPARE_PROCESS_MEMORY_REPORT']=str(target)
 else:env.pop('ZYX_COMPARE_PROCESS_MEMORY_REPORT',None)
 cmd=[str(binary),'--dataset',str(data),'--db-path',str(db),'--scale','smoke','--profile','retrieval','--workload','point_node_fetch_by_id','--warmup','0','--iterations','1','--threads','1','--load-batch-rows','1000','--emit-result-rows']
 if prepared:cmd.extend(['--prepared-db',str(prepared)])
 p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120);(out/(label+'-stdout.jsonl')).write_text(p.stdout);(out/(label+'-stderr.jsonl')).write_text(p.stderr);events=[json.loads(s) for s in p.stdout.splitlines()+p.stderr.splitlines() if s.strip()]
 if negative:
  assert p.returncode!=0 and any(e.get('event')=='error' and 'fresh path' in e.get('error','') for e in events)
 else:
  assert p.returncode==0,(p.returncode,p.stderr,p.stdout[-1000:]);samples=[e for e in events if e.get('event')=='sample' and e.get('workload')=='point_node_fetch_by_id'];assert len(samples)==1 and samples[0]['status']=='ok';assert any(e.get('event')=='result' for e in events)
 item={'label':label,'returncode':p.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'negative_existing_path_check':negative,'formal_performance_samples':0}
 if report and not negative:
  metrics=json.loads(target.read_text());assert metrics['source']=='linux_post_exec_VmHWM';assert 0<metrics['peak_rss_bytes']<parent_rss*.75,(metrics,parent_rss);item['native_process_memory']=metrics
 elif not report:assert not target.exists()
 results.append(item);return db,target
current=Path('/workspace/zyx/buildDir_final/zyx-compare-bench');control=Path('/workspace/zyx-control-d09fc467/build/zyx-compare-bench');baseline,path=execute('current',current);baseline_hash=hashlib.sha256(baseline.read_bytes()).hexdigest();execute('control',control,baseline);execute('default-no-report',current,baseline,report=False);report_bytes=path.read_bytes();execute('existing-report-rejected',current,baseline,destination=path,negative=True);assert path.read_bytes()==report_bytes;assert hashlib.sha256(baseline.read_bytes()).hexdigest()==baseline_hash
payload={'status':'passed','scope':'Tiny CLI resource-capture integration only; not performance acceptance','deliberately_resident_parent_bytes':parent_rss,'parent_rusage_peak_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'children_rusage_maxrss_bytes':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024,'native_after_exec_rss_excludes_parent_pressure':True,'default_jsonl_protocol_unchanged':True,'existing_report_not_overwritten':True,'shared_prepared_database_hash_unchanged':True,'cases':results};(r/'native-process-memory-report-check.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(payload,indent=2))

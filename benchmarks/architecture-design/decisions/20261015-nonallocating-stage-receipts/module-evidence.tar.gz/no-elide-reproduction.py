from pathlib import Path
import concurrent.futures,subprocess,shlex,json,hashlib
root=Path('/workspace/zyx');build=root/'buildDir'
units=[('old-backend','src/storage/relocatable/backend/RelocatableStorageBackend.cpp','/tmp/zyx-const-stage-receipt-old-backend.cpp'),('new-backend','src/storage/relocatable/backend/RelocatableStorageBackend.cpp',str(root/'src/storage/relocatable/backend/RelocatableStorageBackend.cpp')),('old-overlay','src/storage/LogicalGraphTransactionOverlay.cpp','/tmp/zyx-const-stage-receipt-old-overlay.cpp'),('new-overlay','src/storage/LogicalGraphTransactionOverlay.cpp',str(root/'src/storage/LogicalGraphTransactionOverlay.cpp'))]
def compile_unit(item):
    name,original,source=item
    target='CMakeFiles/zyx_core.dir/'+original+'.o'
    command=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],cwd=root,text=True).strip().splitlines()[-1])
    for flag,value in [('-o','/tmp/zyx-no-elide-'+name+'.o'),('-MF','/tmp/zyx-no-elide-'+name+'.d')]:command[command.index(flag)+1]=value
    command[command.index(str(root/original))]=source
    command.append('-fno-elide-constructors')
    with open('/tmp/zyx-no-elide-'+name+'-build.log','w') as log:subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
    return name
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    for name in executor.map(compile_unit,units):print('compiled',name,flush=True)
tokens=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands','zyx_transaction_resource_fault_worker'],cwd=root,text=True).strip().splitlines()[-1])
start=tokens.index('&&')+1;end=tokens.index('&&',start) if '&&' in tokens[start:] else len(tokens)
base=tokens[start:end];index=0
while index<len(base):
    if base[index]=='-Xlinker' and index+1<len(base) and base[index+1].startswith('--dependency-file='):del base[index:index+2]
    else:index+=1
variants={'old-native':('old-backend','new-overlay'),'old-overlay':('new-backend','old-overlay'),'fixed':('new-backend','new-overlay')}
for name,objects in variants.items():
    link=base.copy();index=link.index('libzyx_core.a');link[index:index]=['/tmp/zyx-no-elide-'+obj+'.o' for obj in objects];link[link.index('-o')+1]='/tmp/zyx-no-elide-'+name+'-worker'
    subprocess.run(link,cwd=build,check=True)
    print('linked',name,flush=True)
manifest={'flags':['-fno-elide-constructors'],'sources':{name:hashlib.sha256(Path(source).read_bytes()).hexdigest() for name,_,source in units},'variants':variants}
Path('/tmp/zyx-no-elide-receipt-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for variant,phase,expect_failure in [('old-native','creation',True),('old-overlay','overlay-creation',True),('fixed','creation',False),('fixed','overlay-creation',False)]:
    prefix='/tmp/zyx-no-elide-'+variant+'-'+phase
    command=['python3','scripts/test_transaction_resource_faults.py','--worker','/tmp/zyx-no-elide-'+variant+'-worker','--allocation-sweep',phase,'--output',prefix+'.json']
    with open(prefix+'.log','w') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    print(variant,phase,'exit',result.returncode,'expected failure',expect_failure,flush=True)
    if expect_failure:
        evidence=Path(prefix+'.log').read_text()
        if result.returncode==0 or 'failed creation receipt nevertheless changed the staged prefix' not in evidence:
            raise RuntimeError('old no-elide receipt did not reproduce the expected atomicity defect')
    elif result.returncode:
        raise RuntimeError('fixed no-elide receipt fault sweep failed: '+prefix)

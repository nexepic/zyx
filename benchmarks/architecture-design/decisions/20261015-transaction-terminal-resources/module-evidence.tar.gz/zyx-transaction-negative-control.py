import pathlib, subprocess, shlex, shutil, tempfile, json
root=pathlib.Path('/workspace/zyx')
target='CMakeFiles/zyx_core.dir/src/storage/relocatable/backend/RelocatableStorageBackend.cpp.o'
commands=subprocess.check_output(['ninja','-C','buildDir','-t','commands',target],cwd=root,text=True).splitlines()
args=shlex.split(next(line for line in reversed(commands) if '-c /workspace/zyx/src/storage/relocatable/backend/RelocatableStorageBackend.cpp' in line))
filtered=[];i=0
while i<len(args):
 if args[i] in ('-MT','-MF'):i+=2;continue
 if args[i]=='-MD':i+=1;continue
 filtered.append(args[i]);i+=1
args=filtered
args[args.index('-o')+1]='/tmp/RelocatableStorageBackend.cpp.o'
args[args.index('-c')+1]='/tmp/zyx-backend-before-transaction-cleanup.cpp'
subprocess.run(args,cwd=root/'buildDir',check=True)
archive=pathlib.Path('/tmp/zyx-transaction-negative-control-core.a')
shutil.copyfile(root/'buildDir/libzyx_core.a',archive)
subprocess.run(['ar','rcs',str(archive),'/tmp/RelocatableStorageBackend.cpp.o'],check=True)
lines=(root/'buildDir/build.ninja').read_text().splitlines()
start=next(i for i,v in enumerate(lines) if v.startswith('build zyx_transaction_resource_fault_worker:'))
libs=shlex.split(next(v.split(' = ',1)[1] for v in lines[start:start+14] if v.strip().startswith('LINK_LIBRARIES = ')))
libs=[str(archive) if v=='libzyx_core.a' else v for v in libs]
worker=pathlib.Path('/tmp/zyx-transaction-negative-control-worker')
subprocess.run(['/workspace/zyx-sysroot/usr/bin/clang++-19','-fprofile-instr-generate','-fcoverage-mapping','-pthread','CMakeFiles/zyx_transaction_resource_fault_worker.dir/tests/support/TransactionResourceFaultWorker.cpp.o',*libs,'-o',str(worker)],cwd=root/'buildDir',check=True)
results=[]
with tempfile.TemporaryDirectory(prefix='zyx-transaction-negative-') as temporary:
 for mode in ['rollback-oom','rollback-many-oom','commit-retention']:
  p=subprocess.run([str(worker),mode,str(pathlib.Path(temporary)/(mode+'.zyx'))],text=True,capture_output=True,timeout=120)
  if p.returncode==0:raise RuntimeError('negative control unexpectedly passed '+mode)
  if mode=='commit-retention':
   if 'closed transaction retained payload or ID capacity' not in p.stderr:raise RuntimeError(p.stderr)
  elif p.returncode!=-6 or 'bad_alloc' not in p.stderr:raise RuntimeError(str(p.returncode)+':'+p.stderr)
  results.append({'mode':mode,'exit_code':p.returncode,'stderr':p.stderr.strip(),'reproduced':True})
pathlib.Path('/tmp/zyx-transaction-negative-control.json').write_text(json.dumps({'cases':results,'reproduced':len(results)},indent=2)+'\n')
print(json.dumps({'reproduced':len(results)}))

from pathlib import Path
import json,subprocess,time,os,signal,hashlib,sys,importlib
r=Path('/workspace/zyx-resume-evaluation-20261018');w=r/'route-reuse-final-window';reg=json.loads((w/'current-only-range-supplement-registration.json').read_text());state=w/'current-only-range-supplement-status.json'
def save(value):state.write_text(json.dumps(value,indent=2)+'\n')
save({'phase':'waiting_for_write_completion_engine_free_boundary','automatic_acceptance':False,'pid':os.getpid()})
while not (w/'write-tail-boundary.json').exists():time.sleep(5)
assert json.loads((w/'write-tail-boundary.json').read_text())['engine_started'] is False
assert (w/'bounded-write-extensions-completed.json').exists()
assert hashlib.sha256(Path(reg['case_script']).read_bytes()).hexdigest()==reg['case_sha256']
original=json.loads((w/'registration.json').read_text());assert original['source_commit']==reg['source']
for name,digest in original['binaries'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
sys.path.insert(0,str(r/'route-reuse-final-harness'));owned=importlib.import_module('zyx-final-five-owned-case');spent=reg['already_spent_current_indexed_seconds'];results=[]
for number in reg['rounds']:
 remaining=reg['maximum_total_seconds_original_profile_and_source']-spent
 assert reg['source_specific_expected_case_seconds']<=remaining and reg['source_specific_expected_case_seconds']<=reg['maximum_seconds_per_process']
 marker=w/'extended-read-case-status/medium/indexed'/f'round-{number}'/'current-range-source-estimate-amendment.json';assert not marker.exists()
 entry={'scale':'medium','profile':'indexed','engine':'current','round':number,'partition':1,'workloads':reg['workloads'],'amendment':'current-only-range-supplement-registration.json','original_skipped_marker_preserved':True,'source':reg['source']}
 save({'phase':'candidate_range_supplement_running',**entry,'completed_cases':len(results),'spent_profile_source_seconds':spent,'automatic_acceptance':False});print(json.dumps({'event':'candidate-range-start',**entry}),flush=True)
 log=w/'logs'/f'current-only-range-{number}.log';begin=time.monotonic();env=dict(os.environ,ZYX_FINAL_EXTENDED_WORKLOADS=json.dumps(reg['workloads']))
 with log.open('x') as output:
  p=subprocess.Popen([sys.executable,reg['case_script'],'--engine','current','--round',str(number),'--profile','indexed','--scale','medium'],stdout=output,stderr=subprocess.STDOUT,env=env,start_new_session=True);timed=False
  try:p.wait(timeout=min(reg['maximum_seconds_per_process'],remaining))
  except subprocess.TimeoutExpired:timed=True;os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  except BaseException:
   if p.poll() is None:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   raise
 elapsed=time.monotonic()-begin;spent+=elapsed
 receipt=w/'read-cleanups/medium/indexed'/f'round-{number}'/'current.json';old=receipt.read_bytes() if receipt.exists() else None
 owned.cleanup_read(w,'medium',number,'current','indexed')
 cleanup=w/'current-only-range-cleanups'/f'round-{number}.json';cleanup.parent.mkdir(exist_ok=True);cleanup.write_bytes(receipt.read_bytes())
 if old is not None:receipt.write_bytes(old)
 entry.update(status='inconclusive_timeout' if timed else ('completed' if p.returncode==0 else 'failed'),returncode=p.returncode,elapsed_seconds=elapsed,spent_profile_source_seconds=spent,log=str(log));marker.write_text(json.dumps(entry,indent=2)+'\n');results.append(entry);print(json.dumps(entry),flush=True)
 if entry['status']!='completed':save({'phase':'blocked_by_actual_candidate_range_failure','cases':results,'automatic_acceptance':False});raise SystemExit(1)
subprocess.run([sys.executable,str(r/'route-reuse-final-harness/report-zyx-final-name-batch-extended-reads.py')],check=True)
summary={'phase':'candidate_range_supplements_complete_requires_manual_gate_review','cases':results,'total_current_indexed_seconds_including_original_supplements':spent,'original_process_cap_seconds':1800,'original_profile_source_cap_seconds':3600,'automatic_acceptance':False};save(summary)
assert not (w/'write-tail-resolved.json').exists();(w/'write-tail-resolved.json').write_text(json.dumps({'status':'additional_candidate_range_slots_accounted_no_automatic_acceptance','evidence':'current-only-range-supplement-status.json','remaining_contracts_may_continue':True},indent=2)+'\n')

from pathlib import Path
import json,hashlib,subprocess
p=Path('/workspace/scratch/zyx-current-bottlenecks');r=Path('/workspace/zyx')
summary=json.loads((p/'summary.json').read_text())
doc={
'purpose':'当前性能瓶颈定位与后续路线优先级；不是新的优化实施或正式基准验收',
'identity':json.loads((p/'identity.json').read_text()),
'method':{'dataset':'frozen medium, 225000 nodes / 860000 edges','threads':1,'engine_format':'default 5/31; same production archive SHA as final acceptance','observations':'6 scenarios x control/sampled paired processes; 6 single-operation value-only counter checks; import control/sampled pair; Kuzu EXPLAIN for 3 reads','sampling':'thread CPU timer interrupted leaf PCs; root scope tags in shadow translation units only; nominal 1ms, actual Linux delivery often ~4ms; independent PC percentages reported, overrun-weighted percentages separate','timing_window':'only query+result consumption or write+commit; file copy/open/postchecks excluded; import window only loadDatabase','correctness':'all 6 scenario runs and count checks passed original oracle; imports checked loaded row count and reopened node/edge counts','no_engine_edits':True,'no_full_matrix_or_unit_suite':True},
'findings':[
{'priority':1,'confidence':'high for bottleneck location; proposed representation benefits not yet measured','target':'整条批量扫描路径：候选产生、实体/标签验证、属性根选读与类型列交付','evidence':'标签过滤 CPU 样本 42.62% 属性批供给、24.54% 实体标签、18.54% 索引候选；单键分组 41.99%/24.77%/19.55%；全节点过滤属性供给59.31%，其余40.69%未细分','mechanism':'标签过滤/分组100000个属性根、196批；全节点过滤225000个属性根、440批，220000个数值字段；均已使用direct runs。标签查询属性目录refill=1，不能说每行重新遍历整树。','direction':'设计并验证具有快照身份、存活/成员证明的批或字段块，减少候选、实体验证、属性定位的逐实体工作；连续类型值直接交给现有算子。保留动态属性、NULL、多标签、COW、旧pin与取消/资源合同。','gate':'在真实持久数据上证明整条生产路径采用，含更新/重开/混合类型；同输入与语义检查端到端。只减少一个局部计数不能作为通过。'},
{'priority':2,'confidence':'high for CPU dominance and repeated batch path; medium for exact subcost order','target':'生产批量导入的数据/索引构建与发布组织','evidence':'control load window42.337s, CPU40.886s(~96.6%); BTree apply23.92%+build1.51%+materialize5.08% sampled CPU; default loader slices into1000-row transactions','direction':'评估共享扫描布局的批量页/字段块构建、排序合并或自底向上索引构建、受资源约束的发布；先拆清元数据/分配/校验剩余成本。不得用取消同步或不同提交合同冒充等价提速。'},
{'priority':3,'confidence':'medium; SET samples insufficient for fine function ordering','target':'普通写入的页/元数据放大和资源管理成本','evidence':'1000边：BTree三个阶段合计29.11%，不是历史57%；一次值计数1183744写入字节/163写调用/12变化路由帧。单属性更新201472字节/28写调用/5变化路由帧。','direction':'按真实变化规模降低页写放大、重复元数据借用与分配/归还工作；单属性更新仅89 CPU样本，不据此指定一个主导函数。'},
{'priority':4,'confidence':'high that it should not precede scan pipeline','target':'过滤/聚合内核、SIMD、字符串字典及点查细节','evidence':'单键分组约86.3%处于三个上游供给阶段；部分消费者回调包含在供给阶段中，不能将剩余13.7%直接当作全部聚合成本','direction':'先验证供给链改善，再剖析剩余算子；不做全局缓存/JIT/换树式泛化工程。'}],
'corrections':['历史BTree57%不是当前数据，当前写边三个已标记阶段合计29.11%。','热读CPU主导不排除CPU缓存/内存访问停顿；本次未测硬件cache/TLB计数。','Kuzu EXPLAIN显示SCAN_NODE_TABLE+FILTER/AGGREGATE，所需country/score列；无额外属性索引算子。EXPLAIN不能证明zone-map实际跳过多少数据。','实验冷热布局未被本次medium采用；不将其功能验收当性能结论。','即使属性交付42.6%的CPU成本降为零，其他成本不变时CPU端到端上限约1.74倍；是Amdahl示意上限，不是新方案预测。'],
'limitations':['单机Linux、medium代表路径；holdout沿用既有正式性能结果，本次未做独立profile。','每场景一对控制/采样进程，百分比为粗粒度诊断，不报告虚假的精确置信区间。','root阶段包含下游回调和内存操作；不是纯I/O或纯解码占比。','libc叶符号未解析：读取约13-17%，写边28%，导入29%；没有调用栈不能把它们都归到分配、复制或某个上游调用者。','普通SET仅89个中断样本，不足以可靠排列小函数。','未单独剖析同步等待；CPU/window的差值不是fsync精确计时。','新诊断时延不替代最终正式99进程矩阵；阶段标记有观察开销，控制/采样使用同一观察器。'],
'raw_summary':summary,
'artifacts':sorted(x.name for x in p.iterdir() if x.suffix in ['.json','.jsonl','.pcs','.tsv','.py'])}
(p/'diagnosis.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2))
files=[x for x in p.iterdir() if x.suffix in ['.py','.cpp','.hpp','.json','.jsonl','.pcs','.tsv','.stderr']]
(p/'evidence-sha256.json').write_text(json.dumps({x.name:hashlib.file_digest(x.open('rb'),'sha256').hexdigest() for x in sorted(files)},indent=2))
print('diagnosis saved; git status:',subprocess.check_output(['git','status','--short'],cwd=r,text=True))

from pathlib import Path
import json,hashlib,subprocess,shutil
repo=Path('/workspace/zyx'); dest=Path('/workspace/scratch/zyx-current-bottlenecks'); cwd='/workspace/zyx-build-core-candidate'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
f=json.loads((repo/'benchmarks/architecture-design/decisions/20261023-core-cost-acceptance/freeze.json').read_text())
assert sha(Path(cwd)/'libzyx_core.a')==f['release_library_sha256']
for p,h in f['source_files'].items():
 if p.startswith(('src/','include/')): assert sha(repo/p)==h,p
old=repo/'benchmarks/architecture-design/decisions/20261022-core-cost-buffer/post-buffer-cpu'
for n in ['cpu-phase.hpp','cpu-sampler.hpp']:shutil.copyfile(old/n,dest/n)
recipe=json.loads((repo/'benchmarks/architecture-design/results/20261022-core-cost/acceptance/build.json').read_text())['public']
sources={
'src/storage/relocatable/property/PropertyCollectionRootStore.cpp':[('PropertyCollectionRootScanCursor::readEntityPropertiesOptionalSorted(',1)],
'src/storage/relocatable/entity/PageBackedGraphReadAdapter.cpp':[('PageBackedGraphReadAdapter::readNodeLabelMatchesSorted(',2)],
'src/storage/relocatable/index/BTreeIndex.cpp':[('BTreeIndex::nextRangeCursor(',3)],
'src/storage/relocatable/index/BTreePageStore.cpp':[('void apply(const BTreeScalarIndexOperation &operation)',4),('BTreeStructuralMutationPlan buildPlan()',5),('BTreePage materialize(const OverlayMutationNode &node',8)]}
commands=[];objects=[]
def compile(path):
 cmd=recipe['compile'][:]
 for flag in ['-o','-MT','-MF']:cmd[cmd.index(flag)+1]=str(path.with_suffix('.d' if flag=='-MF' else '.o'))
 cmd[-1]=str(path);commands.append(cmd);objects.append(str(path.with_suffix('.o')))
for source,tags in sources.items():
 s=(repo/source).read_text()
 for signature,phase in tags:
  start=s.index(signature);brace=s.index('{',start);s=s[:brace+1]+f'\n cpu_phase::Scope cpuPhase({phase});'+s[brace+1:]
 p=dest/Path(source).name;p.write_text('#include "cpu-phase.hpp"\n'+s);compile(p)
s=(repo/'benchmarks/architecture-design/decisions/20261022-core-cost-p0/public-probe.cpp').read_text()
s='#include "cpu-sampler.hpp"\n'+s
s=s.replace('   const auto start=timing?Clock::now():Clock::time_point{};','   cpu_sample::begin();\n   const auto start=timing?Clock::now():Clock::time_point{};',1)
s=s.replace('   const double ms=timing?std::chrono::duration<double,std::milli>(Clock::now()-start).count():0;','   const double ms=timing?std::chrono::duration<double,std::milli>(Clock::now()-start).count():0;\n   cpu_sample::end();',1)
p=dest/'cpu-probe.cpp';p.write_text(s);compile(p)
link=[str(dest/'cpu-probe.o') if a.endswith('/public.o') else str(dest/'cpu-probe') if a.endswith('/public-baseline') else '--dependency-file='+str(dest/'cpu-link.d') if a.startswith('--dependency-file=') else a for a in recipe['link']]
link[link.index('libzyx_core.a'):link.index('libzyx_core.a')]=objects[:-1];link+=['-ldl','-lrt']
with (dest/'build.log').open('w') as log:
 for cmd in commands+[link]:
  print('BUILD',cmd[-1],flush=True);subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=True)
(dest/'identity.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'library_sha256':sha(Path(cwd)/'libzyx_core.a'),'probe_sha256':sha(dest/'cpu-probe'),'production_sources_match_acceptance':True,'source_hashes':{s:sha(repo/s) for s in sources},'compile':commands,'link':link,'cwd':cwd},indent=2))
print('DONE',flush=True)

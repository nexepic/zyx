from pathlib import Path
from collections import Counter,defaultdict
import subprocess,json,re,statistics
root=Path('/workspace/scratch/zyx-current-bottlenecks')
stages={0:'remaining executor/binding/other',1:'property batch provider and delivery',2:'entity-label batch validation',3:'BTree candidate generation',4:'BTree overlay apply',5:'BTree overlay build',8:'BTree materialization'}
results=[]
for file in sorted(root.glob('*-sampled.pcs')):
 case=file.name.removesuffix('-sampled.pcs');groups=defaultdict(Counter);counts=Counter();weights=Counter()
 for l in file.read_text().splitlines()[1:]:
  p,a,w,s=l.split('\t');groups[p][a]+=1;counts[int(s)]+=1;weights[int(s)]+=int(w)
 funcs=Counter()
 for p,addresses in groups.items():
  ordered=list(addresses)
  if Path(p).is_file() and 'libc.so' not in p:
   names=subprocess.run(['addr2line','-f','-C','-e',p],input=''.join('0x'+a+'\n' for a in ordered),capture_output=True,text=True,check=True).stdout.splitlines()[::2]
  else:names=[p+' unresolved']*len(ordered)
  for a,n in zip(ordered,names): funcs[n]+=addresses[a]
 cpu={};lat={}
 for label in ['control','sampled']:
  line=(root/(case+'-'+label+'.pcs')).read_text().splitlines()[0]
  cpu[label]={k:float(v) for k,v in re.findall(r'(user_cpu_seconds|system_cpu_seconds|wall_seconds|samples) ([0-9.]+)',line)}
  events=[json.loads(l) for l in (root/(case+'-'+label+'.jsonl')).read_text().splitlines()]
  lat[label]=statistics.median(e['latency_ms'] for e in events)
 total=sum(counts.values());tw=sum(weights.values())
 result={'case':case,'independent_samples':total,'cpu':cpu,'diagnostic_p50_ms':lat,'root_stages':[{'stage':stages.get(s,str(s)),'samples':counts[s],'percent':round(counts[s]*100/total,2),'overrun_weighted_percent':round(weights[s]*100/tw,2)} for s in sorted(counts)],'top_leaf_functions':[{'name':n,'samples':c,'percent':round(c*100/total,2)} for n,c in funcs.most_common(35)]}
 results.append(result);print(case,lat,result['root_stages']);print('TOP',result['top_leaf_functions'][:8])
(root/'summary.json').write_text(json.dumps(results,indent=2))

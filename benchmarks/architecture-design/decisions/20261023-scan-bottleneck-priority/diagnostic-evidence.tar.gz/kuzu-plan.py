import kuzu,json, pathlib
root=pathlib.Path('/workspace/zyx');out=pathlib.Path('/workspace/scratch/zyx-current-bottlenecks')
db=kuzu.Database(str(root/'benchmarks/architecture-design/results/20261020-work-resume/r7-inputs/medium-r7-final.kuzu'),read_only=True,buffer_pool_size=64*1024**2,max_db_size=2*1024**3,max_num_threads=1)
c=kuzu.Connection(db,num_threads=1)
queries={'label_scan_filter':"MATCH (u:User) WHERE u.country='CN' RETURN count(u)",'all_nodes_property_filter':"MATCH (n) WHERE n.score>=900.0 RETURN count(n)",'aggregation_count_by_group':"MATCH (u:User) RETURN u.country,count(*)"}
for name,q in queries.items():
 result=c.execute('EXPLAIN '+q);rows=[]
 while result.has_next():rows.append(result.get_next())
 (out/(name+'-kuzu-plan.json')).write_text(json.dumps(rows,indent=2));print(name,rows)
c.close();db.close()

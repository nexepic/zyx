from pathlib import Path
import json,subprocess
r=Path('/workspace/zyx');d=Path('/workspace/scratch/zyx-current-bottlenecks');recipe=json.loads((r/'benchmarks/architecture-design/results/20261022-core-cost/acceptance/build.json').read_text())['public']
s=(r/'benchmarks/architecture-design/decisions/20261022-core-cost-p0/diagnostic/probe.cpp').read_text();s=s.replace('graph::debug::PerfTrace::setEnabled(iteration>=0);','graph::debug::PerfTrace::setValueCollectionEnabled(iteration>=0);')
p=d/'count-probe.cpp';p.write_text(s);cmd=recipe['compile'][:]
for flag in ['-o','-MT','-MF']:cmd[cmd.index(flag)+1]=str(p.with_suffix('.d' if flag=='-MF' else '.o'))
cmd[-1]=str(p)
link=[str(p.with_suffix('.o')) if a.endswith('/public.o') else str(d/'count-probe') if a.endswith('/public-baseline') else '--dependency-file='+str(d/'count-link.d') if a.startswith('--dependency-file=') else a for a in recipe['link']]
with (d/'count-build.log').open('w') as log:
 for c in [cmd,link]:subprocess.run(c,cwd=recipe['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True)
print('DONE')

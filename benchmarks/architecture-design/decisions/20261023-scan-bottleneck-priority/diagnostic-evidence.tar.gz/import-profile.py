from pathlib import Path
import json,subprocess,os
r=Path('/workspace/zyx');d=Path('/workspace/scratch/zyx-current-bottlenecks');recipe=json.loads((r/'benchmarks/architecture-design/results/20261022-core-cost/acceptance/build.json').read_text())['import']
s=(r/'benchmarks/architecture-design/decisions/20261022-core-cost-p0/import-probe.cpp').read_text();s='#include "cpu-sampler.hpp"\n'+s
s=s.replace('  const auto start=Clock::now();','  cpu_sample::begin();\n  const auto start=Clock::now();').replace('  if(loaded.loadedRows','  cpu_sample::end();\n  if(loaded.loadedRows')
p=d/'import-probe.cpp';p.write_text(s);cmd=recipe['compile'][:]
for flag in ['-o','-MT','-MF']:cmd[cmd.index(flag)+1]=str(p.with_suffix('.d' if flag=='-MF' else '.o'))
cmd[-1]=str(p)
link=[str(p.with_suffix('.o')) if a.endswith('/import.o') else str(d/'import-probe') if a.endswith('/import-baseline') else '--dependency-file='+str(d/'import-link.d') if a.startswith('--dependency-file=') else a for a in recipe['link']]
link.insert(link.index('libzyx_core.a'),str(d/'BTreePageStore.o'));link+=['-ldl','-lrt']
with (d/'import-build.log').open('w') as log:
 for c in [cmd,link]:subprocess.run(c,cwd=recipe['cwd'],stdout=log,stderr=subprocess.STDOUT,check=True)
for label in ['control','sampled']:
 stem=d/('fresh_import-'+label);db=d/'import-private.zyx';assert not db.exists()
 env=dict(os.environ,LD_LIBRARY_PATH='/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu',ZYX_CPU_SAMPLE_OUTPUT=str(stem.with_suffix('.pcs')));env.pop('ZYX_CPU_SAMPLE_ENABLE',None)
 if label=='sampled':env['ZYX_CPU_SAMPLE_ENABLE']='1'
 c=[str(d/'import-probe'),str(r/'benchmarks/architecture-design/results/20261020-work-resume/r7-inputs/medium'),str(db),'1085000'];print('START IMPORT',label,flush=True)
 with stem.with_suffix('.jsonl').open('w') as out,stem.with_suffix('.stderr').open('w') as err:p=subprocess.run(c,env=env,stdout=out,stderr=err,timeout=180)
 assert p.returncode==0
 result=json.loads(stem.with_suffix('.jsonl').read_text());assert (result['loaded_rows'],result['nodes'],result['edges'])==(1085000,225000,860000)
 stem.with_suffix('.command.json').write_text(json.dumps({'command':c,'validation':'loaded rows and reopened nodes/edges counts','query_window':'loadDatabase only; post-validation excluded','formal_latency':False},indent=2));db.unlink();print('DONE IMPORT',label,stem.with_suffix('.pcs').read_text().splitlines()[0],flush=True)

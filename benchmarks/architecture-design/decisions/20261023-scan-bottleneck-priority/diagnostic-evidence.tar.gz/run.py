from pathlib import Path
import os,subprocess,json,sys,hashlib
repo=Path('/workspace/zyx');dest=Path('/workspace/scratch/zyx-current-bottlenecks')
sys.path.insert(0,str(repo/'benchmarks/architecture-design/decisions/20261022-core-cost-final'));from oracle import check_event
cases=[('label_scan_filter','read',40),('all_nodes_property_filter','read',32),('aggregation_count_by_group','read',40),('multi_key_group','read',32),('edge_batch_1000','write',64),('property_set','write',100)]
for case,mode,count in cases:
 src=repo/('benchmarks/architecture-design/results/20261020-work-resume/r7-inputs/medium-r43-identity.zyx' if mode=='read' else 'benchmarks/architecture-design/results/20261022-core-cost/acceptance/inputs/medium-summary.zyx')
 for label in ['control','sampled']:
  stem=dest/(case+'-'+label);private=dest/(case+'-private.zyx');assert not private.exists()
  env=dict(os.environ,LD_LIBRARY_PATH='/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu',ZYX_CPU_SAMPLE_OUTPUT=str(stem.with_suffix('.pcs')))
  env.pop('ZYX_CPU_SAMPLE_ENABLE',None)
  if label=='sampled':env['ZYX_CPU_SAMPLE_ENABLE']='1'
  cmd=[str(dest/'cpu-probe'),mode,str(src),str(private),case,'3',str(count)]
  print('START',case,label,flush=True)
  with stem.with_suffix('.jsonl').open('w') as out,stem.with_suffix('.stderr').open('w') as err:p=subprocess.run(cmd,env=env,stdout=out,stderr=err,timeout=240)
  events=[json.loads(x) for x in stem.with_suffix('.jsonl').read_text().splitlines() if x.startswith('{')]
  assert p.returncode==0 and len(events)==count,(case,label,p.returncode,len(events))
  for e in events:check_event(case,e,'medium',mode=='write')
  stem.with_suffix('.command.json').write_text(json.dumps({'command':cmd,'oracle':'passed','source_sha256':hashlib.file_digest(src.open('rb'),'sha256').hexdigest(),'includes_3_warmup_in_CPU':True,'formal_latency':False},indent=2))
  print('DONE',case,label,stem.with_suffix('.pcs').read_text().splitlines()[0],flush=True)

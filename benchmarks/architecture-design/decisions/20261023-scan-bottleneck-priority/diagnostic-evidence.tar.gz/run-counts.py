from pathlib import Path
import subprocess,os,json,sys
r=Path('/workspace/zyx');d=Path('/workspace/scratch/zyx-current-bottlenecks');sys.path.insert(0,str(r/'benchmarks/architecture-design/decisions/20261022-core-cost-final'));from oracle import check_event
for case in ['label_scan_filter','all_nodes_property_filter','aggregation_count_by_group','multi_key_group','edge_batch_1000','property_set']:
 writing=case in ['edge_batch_1000','property_set'];src=r/('benchmarks/architecture-design/results/20261022-core-cost/acceptance/inputs/medium-summary.zyx' if writing else 'benchmarks/architecture-design/results/20261020-work-resume/r7-inputs/medium-r43-identity.zyx');private=d/(case+'-count-private.zyx');assert not private.exists()
 cmd=[str(d/'count-probe'),'check-write' if writing else 'check-read',str(src),str(private),case,'0','1']
 with (d/(case+'-counts.jsonl')).open('w') as out,(d/(case+'-counts.tsv')).open('w') as err:p=subprocess.run(cmd,env=dict(os.environ,LD_LIBRARY_PATH='/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu'),stdout=out,stderr=err,timeout=60)
 assert p.returncode==0,case
 events=[json.loads(x) for x in (d/(case+'-counts.jsonl')).read_text().splitlines()];assert len(events)==1
 check_event(case,events[0],'medium',writing);print(case,'PASS',flush=True)

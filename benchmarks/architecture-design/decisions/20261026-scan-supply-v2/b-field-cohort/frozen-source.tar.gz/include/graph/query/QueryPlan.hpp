/**
 * @file QueryPlan.hpp
 * @brief Encapsulates a logical plan with metadata flags.
 *
 * Licensed under the Apache License, Version 2.0
 **/

#pragma once

#include <memory>
#include <string>
#include "graph/query/logical/LogicalOperator.hpp"

namespace graph::query {

/// Prefix used internally for anonymous pattern variables (unnamed nodes/edges).
/// These are pipeline-internal and must never appear in user-facing output.
inline constexpr const char *ANONYMOUS_VAR_PREFIX = "__anon_";

/// Returns true if a variable name is an internal anonymous variable.
inline bool isAnonymousVariable(const std::string &name) {
	return name.compare(0, 7, ANONYMOUS_VAR_PREFIX) == 0;
}

/**
 * @struct QueryPlan
 * @brief A logical plan root plus build-time metadata flags.
 *
 * The flags are accumulated during plan construction and allow O(1)
 * read-only / schema-write checks without walking the tree.
 */
struct QueryPlan {
	std::unique_ptr<logical::LogicalOperator> root;
	bool mutatesData = false;   // CREATE, SET, DELETE, MERGE, REMOVE, FOREACH, and mutating procedures
	bool mutatesSchema = false; // CREATE INDEX, DROP INDEX, CREATE/DROP CONSTRAINT, etc.
	bool cacheable = true;      // False for DDL, transaction control, EXPLAIN, PROFILE
	bool optimizable = true;    // False for DDL, transaction control, CALL PROCEDURE, EXPLAIN, PROFILE

	/**
	 * @brief Clone the plan (deep-copies the root, copies flags).
	 */
	[[nodiscard]] QueryPlan clone() const {
		QueryPlan copy;
		if (root) {
			copy.root = root->clone();
		}
		copy.mutatesData = mutatesData;
		copy.mutatesSchema = mutatesSchema;
		copy.cacheable = cacheable;
		copy.optimizable = optimizable;
		return copy;
	}
};

} // namespace graph::query

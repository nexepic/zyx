/**
 * @file MetadataPageReadContext.hpp
 * @brief Bounded decoded metadata reuse owned by a live snapshot pin.
 */
#pragma once

#include <algorithm>
#include <list>
#include <iterator>
#include <limits>
#include <stdexcept>
#include <memory>
#include <memory_resource>
#include <type_traits>
#include "graph/utils/OwnedPmrAllocator.hpp"
#include "graph/query/execution/ResourceCoordinator.hpp"
#include <mutex>
#include <optional>
#include <typeindex>
#include <unordered_map>

#include "graph/debug/PerfTrace.hpp"
#include "graph/storage/StorageIO.hpp"
#include "graph/storage/relocatable/format/Superblock.hpp"

namespace graph::storage {
    struct CatalogLeafPage;
    struct CatalogRadixPage;
    struct AllocatorLeafPage;
    struct LocationLeafPage;
    struct MetadataPageRouteLeafPage;
    struct PageDirectoryBootstrap;

	// Immutable codec results and authenticated route targets share one bound.
	// Caller-specific data-page owner and visibility checks remain outside.
	class MetadataPageReadContext final {
		struct CachedRoute { PhysicalPageRef target; };
	public:
		static constexpr size_t MAXIMUM_ENTRIES = 128U;
		static constexpr size_t MAXIMUM_CHARGED_BYTES = 1024U * 1024U;
		static constexpr size_t MAXIMUM_ROUTE_ENTRIES = MAXIMUM_ENTRIES / 4U;

		explicit MetadataPageReadContext(Superblock snapshot,
				size_t maximumBytes = MAXIMUM_CHARGED_BYTES,
                std::shared_ptr<std::pmr::memory_resource> memoryOwner = {})
            : snapshot_(snapshot), maximum_bytes_(maximumBytes), memory_owner_(std::move(memoryOwner)) {
			SuperblockCodec::validate(snapshot_);
			if (maximumBytes > MAXIMUM_CHARGED_BYTES) throw std::invalid_argument("metadata cache exceeds its byte limit");
		}

		class Scope final {
		public:
			Scope(std::shared_ptr<MetadataPageReadContext> context, const StorageIO &io) :
				context_(std::move(context)), previous_(active_), previous_scope_(active_scope_) {
				if (!context_) throw std::invalid_argument("metadata read scope requires a live context");
				std::lock_guard lock(context_->mutex_);
				if (context_->io_ != nullptr && context_->io_ != &io) {
					throw std::invalid_argument("metadata read context cannot cross StorageIO identities");
				}
				if (context_->io_ == nullptr) context_->io_ = &io;
				context_->synchronizeWrites();
				active_ = context_.get();
				active_scope_ = this;
			}
			~Scope() { active_ = previous_; active_scope_ = previous_scope_; }
			Scope(const Scope &) = delete;
			Scope &operator=(const Scope &) = delete;
            [[nodiscard]] static std::shared_ptr<MetadataPageReadContext> currentOwner(const StorageIO &io) {
                return !StorageIO::SequentialReadScope::activeFor(io) && active_scope_ && active_scope_->context_->io_ == &io ? active_scope_->context_ : nullptr;
            }
		private:
			std::shared_ptr<MetadataPageReadContext> context_;
			MetadataPageReadContext *previous_;
            Scope *previous_scope_;
            inline static thread_local Scope *active_scope_ = nullptr;
		};

		[[nodiscard]] static MetadataPageReadContext *current(const StorageIO &io) {
			return !StorageIO::SequentialReadScope::activeFor(io) && active_ != nullptr && active_->io_ == &io ? active_ : nullptr;
		}
		[[nodiscard]] static MetadataPageReadContext *current(const StorageIO &io, const Superblock &view) {
			return !StorageIO::SequentialReadScope::activeFor(io) && active_ != nullptr && active_->io_ == &io &&
				active_->snapshot_.database_id == view.database_id &&
				active_->snapshot_.data_region_offset == view.data_region_offset ? active_ : nullptr;
		}
		[[nodiscard]] bool authenticates(const Superblock &context) const { return context == snapshot_; }

		// Route trees depend on the immutable root and visibility fence, not on
		// unrelated COW candidate roots. The physical route root is part of the key.
		[[nodiscard]] bool authenticatesRouteFence(const Superblock &view) const {
			return view.database_id == snapshot_.database_id &&
				view.data_region_offset == snapshot_.data_region_offset &&
				view.generation == snapshot_.generation && view.checkpoint_lsn == snapshot_.checkpoint_lsn;
		}
		[[nodiscard]] std::optional<PhysicalPageRef> findMetadataRoute(PhysicalPageRef root,
				MetadataPageId id, const Superblock &view) {
			if (!root.isValid() || !id.isValid() || !authenticatesRouteFence(view)) return std::nullopt;
			const auto route = find<CachedRoute>(root, id.value());
			return route ? std::optional<PhysicalPageRef>(route->target) : std::nullopt;
		}
		void putMetadataRoute(PhysicalPageRef root, MetadataPageId id, PhysicalPageRef target,
				const Superblock &view) {
			if (!root.isValid() || !id.isValid() || !target.isValid() ||
				!authenticatesRouteFence(view) || target.generation > snapshot_.generation) return;
			put(root, CachedRoute{target}, 0U, id.value());
		}

        template<typename Page>
        [[nodiscard]] std::shared_ptr<const Page> findView(PhysicalPageRef reference) {
            std::lock_guard lock(mutex_);
            synchronizeWrites();
            if (!cache_) return {};
            const auto found = cache_->entries.find(key<Page>(reference));
            if (found == cache_->entries.end()) return {};
            debug::PerfTrace::addValue("native_graph.read.decoded_metadata_cache_hits", 1);
            cache_->order.splice(cache_->order.end(), cache_->order, found->second.position);
            debug::PerfTrace::addValue("native_graph.read.decoded_metadata_borrow_fixed_bytes", sizeof(Page));
            return std::static_pointer_cast<const Page>(found->second.page);
        }

		template<typename Page>
		[[nodiscard]] std::optional<Page> find(PhysicalPageRef reference, uint64_t logicalId = 0U) {
			std::lock_guard lock(mutex_);
			synchronizeWrites();
            if (!cache_) return std::nullopt;
			const auto found = cache_->entries.find(key<Page>(reference, logicalId));
			if (found == cache_->entries.end()) return std::nullopt;
			if constexpr (std::is_same_v<Page, CachedRoute>)
				debug::PerfTrace::addValue("native_graph.read.resolved_metadata_route_cache_hits", 1);
			else debug::PerfTrace::addValue("native_graph.read.decoded_metadata_cache_hits", 1);
            utils::OwnedAllocationScope allocation(utils::OwnedAllocationScope::active()
                ? utils::OwnedAllocationScope::owner() : memory_owner_);
            try {
                Page copy = *std::static_pointer_cast<const Page>(found->second.page);
                debug::PerfTrace::addValue("native_graph.read.decoded_metadata_copy_fixed_bytes", sizeof(Page));
                cache_->order.splice(cache_->order.end(), cache_->order, found->second.position);
                return copy;
            }
            catch (const query::execution::detail::ResourceAdmissionDenied &) {
                // A private caller quota failure must not evict shared cache state.
                if (utils::OwnedAllocationScope::owner() != memory_owner_) throw;
                // A cache copy may need a second payload allocation. Drop this
                // optional entry so the caller can decode one admitted copy.
                eraseEntry(found->first);
                return std::nullopt;
            }
		}

		template<typename Page>
		void put(PhysicalPageRef reference, const Page &page, size_t variableBytes = 0U, uint64_t logicalId = 0U) {
			std::lock_guard lock(mutex_);
			synchronizeWrites();
			// Future/private COW images are never admitted to the published context.
			if (reference.generation > snapshot_.generation ||
				io_->dataMutationEpoch() == std::numeric_limits<uint64_t>::max()) return;
			const size_t fixed = sizeof(Page) + sizeof(Entry) + 2U * sizeof(Key) + 8U * sizeof(void *);
			if (fixed > maximum_bytes_ || variableBytes > maximum_bytes_ - fixed) return;
            // Coordinated caches admit only the audited native codec pages.
            // Unknown page types retain the uncoordinated embedding contract.
			if constexpr (!(std::is_same_v<Page, CachedRoute> || std::is_same_v<Page, CatalogLeafPage> || std::is_same_v<Page, CatalogRadixPage> ||
                            std::is_same_v<Page, AllocatorLeafPage> || std::is_same_v<Page, LocationLeafPage> ||
                            std::is_same_v<Page, MetadataPageRouteLeafPage> || std::is_same_v<Page, PageDirectoryBootstrap>)) {
                if (memory_owner_) return;
            }
			const size_t charge = fixed + variableBytes;
			// A raw-page cache sharing this grant must not crowd every decoded
			// root out. Bound the request by this entry's size plus bucket slack;
			// failed optional admission never drains an unrelated cache or writes
			// dirty/private pages to make room.
			size_t rawPageAttempts = charge / RSS_BUFFER_POOL_PAGE_BYTES + 2U;
			const auto reclaimRawPage = [&]() {
				if (!memory_owner_ || rawPageAttempts == 0U) return false;
				--rawPageAttempts;
				if (!io_->tryReleaseCachedPage(memory_owner_.get())) return false;
				debug::PerfTrace::addValue("native_graph.read.decoded_metadata_cache_page_evictions", 1);
				return true;
			};
            if (!cache_) {
                for (;;) {
                    try { cache_.emplace(memory_owner_ ? memory_owner_.get() : std::pmr::get_default_resource()); break; }
                    catch (const query::execution::detail::ResourceAdmissionDenied &) {
                        if (!reclaimRawPage()) return;
                    }
                }
            }
			const Key identity = key<Page>(reference, logicalId);
			if (cache_->entries.contains(identity)) return;
			// Reserve most entries for codec pages. A streaming route miss must not
			// replace the hot routing prefix; ordinary shared LRU eviction and writes
			// make room again. Both kinds still share the original byte/entry limits.
			if constexpr (std::is_same_v<Page, CachedRoute>) {
				if (cache_->route_entries >= MAXIMUM_ROUTE_ENTRIES) return;
			}
			while (!cache_->order.empty() &&
				(cache_->entries.size() == MAXIMUM_ENTRIES || charge > maximum_bytes_ - charged_bytes_)) {
				const auto found = cache_->entries.find(cache_->order.front());
				eraseEntry(found->first);
				debug::PerfTrace::addValue("native_graph.read.decoded_metadata_cache_evictions", 1);
			}
            utils::OwnedAllocationScope allocation(memory_owner_);
            for (;;) {
                try {
                    auto copy = std::allocate_shared<const Page>(utils::OwnedPmrAllocator<Page>(memory_owner_), page);
                    cache_->order.push_back(identity);
                    try { cache_->entries.emplace(identity, Entry{std::move(copy), charge, std::prev(cache_->order.end())}); }
                    catch (...) { cache_->order.pop_back(); throw; }
                    charged_bytes_ += charge;
                    if constexpr (std::is_same_v<Page, CachedRoute>) ++cache_->route_entries;
                    return;
                } catch (const query::execution::detail::ResourceAdmissionDenied &) {
                    if (reclaimRawPage()) continue;
                    if (cache_->order.empty()) return;
                    const auto oldest = cache_->entries.find(cache_->order.front());
                    eraseEntry(oldest->first);
                }
            }
		}

        [[nodiscard]] const std::shared_ptr<std::pmr::memory_resource> &memoryOwner() const noexcept { return memory_owner_; }
		[[nodiscard]] size_t chargedBytes() const { std::lock_guard lock(mutex_); return charged_bytes_; }
		[[nodiscard]] size_t size() const { std::lock_guard lock(mutex_); return cache_ ? cache_->entries.size() : 0U; }

	private:
		struct Key {
			PhysicalPageRef reference;
			std::type_index type;
			uint64_t logical_id = 0U;
			bool operator==(const Key &) const = default;
		};
		struct KeyHash {
			size_t operator()(const Key &key) const noexcept {
				return std::hash<uint64_t>{}(key.reference.physical_slot.value()) ^
					(std::hash<uint64_t>{}(key.reference.generation.value()) << 1U) ^
					(static_cast<size_t>(key.reference.frame_index) << 3U) ^ key.type.hash_code() ^
					(std::hash<uint64_t>{}(key.logical_id) << 2U);
			}
		};
		// Hits move the existing node without allocating or extending either limit.
        // Keep frequently reused directory roots while scan leaves cycle through.
        struct Entry {
            std::shared_ptr<const void> page;
            size_t charge;
            std::pmr::list<Key>::iterator position;
        };
		template<typename Page> static Key key(PhysicalPageRef ref, uint64_t logicalId = 0U) {
			return {ref, typeid(Page), logicalId};
		}
		void eraseEntry(Key identity) {
			const auto found = cache_->entries.find(identity);
			charged_bytes_ -= found->second.charge;
			if (identity.type == typeid(CachedRoute)) --cache_->route_entries;
			cache_->order.erase(found->second.position);
			cache_->entries.erase(found);
		}
		void synchronizeWrites() {
			const uint64_t epoch = io_->dataMutationEpoch();
			if (epoch != mutation_epoch_ || epoch == std::numeric_limits<uint64_t>::max()) {
				cache_.reset(); charged_bytes_ = 0U;
				mutation_epoch_ = epoch;
			}
		}

		inline static thread_local MetadataPageReadContext *active_ = nullptr;
		Superblock snapshot_;
		const size_t maximum_bytes_;
		const StorageIO *io_ = nullptr;
		uint64_t mutation_epoch_ = 0U;
		mutable std::mutex mutex_;
        std::shared_ptr<std::pmr::memory_resource> memory_owner_;
        struct PayloadCache {
            explicit PayloadCache(std::pmr::memory_resource *resource) : entries(resource), order(resource) {}
            std::pmr::unordered_map<Key, Entry, KeyHash> entries;
            std::pmr::list<Key> order;
            size_t route_entries = 0U;
        };
        // Some standard libraries allocate sentinel/proxy nodes even for empty
        // containers. Snapshot controls must never depend on CACHE headroom.
        std::optional<PayloadCache> cache_;
		size_t charged_bytes_ = 0U;
	};
} // namespace graph::storage

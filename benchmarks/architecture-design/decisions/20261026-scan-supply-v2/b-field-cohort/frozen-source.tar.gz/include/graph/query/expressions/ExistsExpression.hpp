/**
 * @file ExistsExpression.hpp
 * @date 2025/3/9
 *
 * Expression for EXISTS pattern expressions
 */

#pragma once
#include "graph/utils/OwnedStdString.hpp"

#include "graph/query/expressions/Expression.hpp"
#include "graph/query/expressions/PatternDirection.hpp"
#include <memory>
#include <string>

namespace graph::query::expressions {

/**
 * @class ExistsExpression
 * @brief Expression for EXISTS pattern existence checks
 *
 * Syntax: EXISTS((n)-[:FRIENDS]->())
 * or: exists((n)-[:FRIENDS]->())
 *
 * Checks if a pattern exists in the graph. Returns TRUE if at least one
 * match is found, FALSE otherwise.
 */
class ExistsExpression : public Expression {
public:
	/**
	 * @brief Constructor for EXISTS with structured pattern info
	 */
	ExistsExpression(
		utils::OwnedStdString pattern,
		utils::OwnedStdString sourceVar,
		utils::OwnedStdString relType,
		utils::OwnedStdString targetLabel,
		PatternDirection direction,
		std::unique_ptr<Expression> whereExpr = nullptr,
		utils::OwnedStdString targetVar = ""
	);

	/**
	 * @brief Backward-compatible constructor with pattern string only
	 */
	ExistsExpression(
		utils::OwnedStdString pattern,
		std::unique_ptr<Expression> whereExpr = nullptr
	);

	[[nodiscard]] ExpressionType getExpressionType() const override {
		return ExpressionType::EXPR_EXISTS;
	}

	void accept(ExpressionVisitor &visitor) override;
	void accept(ConstExpressionVisitor &visitor) const override;

	[[nodiscard]] std::string toString() const override;

	[[nodiscard]] std::unique_ptr<Expression> clone() const override;

	[[nodiscard]] const std::string& getPattern() const { return pattern_; }
	[[nodiscard]] const std::string& getSourceVar() const { return sourceVar_; }
	[[nodiscard]] const std::string& getRelType() const { return relType_; }
	[[nodiscard]] const std::string& getTargetLabel() const { return targetLabel_; }
	[[nodiscard]] const std::string& getTargetVar() const { return targetVar_; }
	[[nodiscard]] PatternDirection getDirection() const { return direction_; }
	[[nodiscard]] bool hasStructuredPattern() const { return !sourceVar_.empty(); }

	[[nodiscard]] Expression* getWhereExpression() const { return whereExpr_.get(); }
	[[nodiscard]] bool hasWhereClause() const { return whereExpr_ != nullptr; }

private:
	utils::OwnedStdString pattern_;
	utils::OwnedStdString sourceVar_;
	utils::OwnedStdString relType_;
	utils::OwnedStdString targetLabel_;
	utils::OwnedStdString targetVar_;
	PatternDirection direction_ = PatternDirection::PAT_OUTGOING;
	std::unique_ptr<Expression> whereExpr_;
};

} // namespace graph::query::expressions

/**
 * @file StorageTypes.hpp
 * @author Nexepic
 * @date 2025/12/18
 *
 * @copyright Copyright (c) 2025 Nexepic
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/

#pragma once

namespace graph::storage {

	enum class OpenMode {
		OPEN_CREATE_NEW_FILE, // Create new file. Fail if exists.
		OPEN_EXISTING_FILE, // Open existing file. Fail if missing.
		OPEN_CREATE_OR_OPEN_FILE, // Open if it exists; otherwise create a native database.
		// Opens an existing native database without writable file handles.
		OPEN_READ_ONLY_EXISTING_FILE
	};

}

/**
 * @file InitialBTreeBuilder.hpp
 * @brief Bounded in-memory planning for an initially materialized relocatable B+Tree.
 *
 * @copyright Copyright (c) 2026 Nexepic
 * @license Apache-2.0
 **/

#pragma once

#include <cstddef>
#include <cstdint>
#include <deque>
#include <span>
#include <optional>
#include "graph/utils/OwnedFunction.hpp"
#include <vector>

#include "graph/storage/relocatable/index/BTreePage.hpp"

namespace graph::storage {

	enum class InitialBTreeLeafStorage { IBLS_ENTRIES, IBLS_PACKED };

	struct InitialBTreePlanNode {
		uint16_t level = 0U;
		std::vector<std::byte> first_key;
		utils::OwnedStdVector<BTreePageEntry> leaf_entries;
		std::vector<size_t> children;
        utils::OwnedStdVector<std::byte> packed_leaf_entries;
	};

	struct InitialBTreePlan {
		BTreeLeafValueLayout leaf_value_layout = BTreeLeafValueLayout::BLVL_U64;
		// Append without relocating owned leaf payloads. Their portable moves may
		// require iterator-proxy credit, so vector growth otherwise deep-copies.
		std::deque<InitialBTreePlanNode, utils::OwnedPmrAllocator<InitialBTreePlanNode>> nodes;
		size_t leaf_count = 0U;
		size_t root_ordinal = 0U;
	};

	// Plans and materializes a complete immutable B+Tree from a bounded,
	// strictly ordered entry set. Planning has no storage side effects, so a
	// compound transaction can allocate all logical page IDs before any page
	// becomes durable or reachable.
	class InitialBTreeBuilder final {
	public:
		[[nodiscard]] static InitialBTreePlan
		plan(uint64_t indexId, std::span<const BTreePageEntry> entries,
			 BTreeLeafValueLayout leafValueLayout = BTreeLeafValueLayout::BLVL_U64);
        // Consumes one ordered private entry at a time; no complete input vector
        // overlaps the immutable output plan. A failing source publishes nothing.
        [[nodiscard]] static InitialBTreePlan planFromCursor(uint64_t indexId,
            const utils::OwnedFunction<std::optional<BTreePageEntry>()> &next,
            BTreeLeafValueLayout leafValueLayout = BTreeLeafValueLayout::BLVL_U64,
            InitialBTreeLeafStorage leafStorage = InitialBTreeLeafStorage::IBLS_ENTRIES);

		[[nodiscard]] static std::vector<BTreePage> materialize(uint64_t indexId, const InitialBTreePlan &plan,
																std::span<const PageId> pageIds,
																std::span<const Generation> generations,
																LogSequenceNumber checkpointLsn);
	};

} // namespace graph::storage

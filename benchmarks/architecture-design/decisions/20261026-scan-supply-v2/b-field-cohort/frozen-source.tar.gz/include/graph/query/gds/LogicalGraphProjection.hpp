/**
 * @file LogicalGraphProjection.hpp
 * @brief Storage-neutral immutable graph projection built from a logical snapshot.
 *
 * Copyright (c) 2026 Nexepic
 * Licensed under the Apache License, Version 2.0.
 */

#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include "graph/storage/LogicalGraphRead.hpp"
#include "graph/utils/OwnedStdVector.hpp"
#include "graph/utils/OwnedPmrAllocator.hpp"
#include "graph/utils/OwnedSharedPtr.hpp"
#include "graph/utils/OwnedStdString.hpp"
#include "graph/utils/OwnedStringVector.hpp"

namespace graph::query::gds {

	enum class LogicalProjectionOrientation : uint8_t {
		LPO_NATURAL,
		LPO_REVERSE,
		LPO_UNDIRECTED,
	};

	enum class LogicalProjectionWeightKind : uint8_t {
		LPWK_NONE,
		LPWK_CONSTANT,
		LPWK_PROPERTY,
	};

	struct LogicalProjectionWeight {
        using OwnedHeapElement = void;
		LogicalProjectionWeightKind kind = LogicalProjectionWeightKind::LPWK_NONE;
		double constant_weight = 1.0;
		utils::OwnedStdString property_name;
		double default_weight = 1.0;
	};

	struct LogicalRelationshipProjection {
        using OwnedHeapElement = void;
		// An empty type accepts every relationship type, including untyped edges.
		utils::OwnedStdString type;
		LogicalProjectionOrientation orientation = LogicalProjectionOrientation::LPO_NATURAL;
		LogicalProjectionWeight weight;
	};

	struct LogicalGraphProjectionSpec {
        using OwnedHeapElement = void;
		utils::OwnedStdString name;
		// An empty label collection accepts every Node.
		utils::OwnedStringVector node_labels;
		// An empty collection accepts every relationship with default_orientation.
		utils::OwnedStdVector<LogicalRelationshipProjection> relationships;
		LogicalProjectionOrientation default_orientation = LogicalProjectionOrientation::LPO_NATURAL;
	};

	struct LogicalProjectionBuildBounds {
		static constexpr size_t DEFAULT_MAXIMUM_PROPERTY_BYTES = 64U * 1024U * 1024U;
		size_t maximum_nodes = 0U;
		size_t maximum_metadata_pages = 0U;
		size_t maximum_edges_per_node = 0U;
		// Bounds the transient selected weight column independently from the
		// adjacency cardinality. A large Property must fail closed before the
		// projection retains an unbounded decoded column.
		size_t maximum_property_bytes = DEFAULT_MAXIMUM_PROPERTY_BYTES;
	};

	// Projection construction may scan a large graph. The callback keeps its
	// cancellation boundary storage- and executor-neutral while allowing callers
	// to stop before any partially-built projection becomes catalog-visible.
	using LogicalProjectionBuildCheckpoint = std::function<void()>;

	struct LogicalProjectionEdge {
		uint64_t target_node_id = 0U;
		double weight = 1.0;
		uint64_t relationship_id = 0U;
		bool synthetic_reverse = false;

		bool operator==(const LogicalProjectionEdge &) const = default;
	};

	// Compact immutable adjacency used by native graph algorithms. Offsets are
	// indexed by node_ids, so scanning one Node's outgoing arcs is contiguous.
	// The source projection remains the authority for semantic construction;
	// this is a lazily cached derived representation, never persisted state.
	struct LogicalProjectionCsr {
		utils::OwnedStdVector<uint64_t> node_ids;
		utils::OwnedStdVector<size_t> offsets;
		utils::OwnedStdVector<uint64_t> target_node_ids;
		utils::OwnedStdVector<double> weights;
		utils::OwnedStdVector<uint64_t> relationship_ids;
		utils::OwnedStdVector<uint8_t> synthetic_reverse;

		[[nodiscard]] size_t edgeCount() const noexcept { return target_node_ids.size(); }
		[[nodiscard]] size_t estimatedMemoryBytes() const noexcept {
			return sizeof(*this) + node_ids.capacity() * sizeof(uint64_t) + offsets.capacity() * sizeof(size_t) +
					target_node_ids.capacity() * sizeof(uint64_t) + weights.capacity() * sizeof(double) +
					relationship_ids.capacity() * sizeof(uint64_t) + synthetic_reverse.capacity() * sizeof(uint8_t);
		}
	};

	struct LogicalProjectionCsrCacheState {
		bool materialized = false;
		size_t memory_bytes = 0U;

		bool operator==(const LogicalProjectionCsrCacheState &) const = default;
	};

	class LogicalGraphProjection final {
	public:
		[[nodiscard]] static LogicalGraphProjection build(const storage::LogicalGraphReadSnapshot &snapshot,
				const LogicalGraphProjectionSpec &spec, LogicalProjectionBuildBounds bounds,
				const LogicalProjectionBuildCheckpoint &checkpoint = {});

		[[nodiscard]] const std::vector<uint64_t> &nodeIds() const noexcept { return node_ids_; }
		[[nodiscard]] const std::vector<LogicalProjectionEdge> &outgoing(uint64_t nodeId) const noexcept;
		[[nodiscard]] const std::vector<LogicalProjectionEdge> &incoming(uint64_t nodeId) const noexcept;
		[[nodiscard]] size_t nodeCount() const noexcept { return node_ids_.size(); }
		[[nodiscard]] size_t edgeCount() const noexcept { return edge_count_; }
		[[nodiscard]] bool isWeighted() const noexcept { return is_weighted_; }
		[[nodiscard]] size_t estimatedMemoryBytes() const noexcept;
		// This observes the cache atomically without forcing CSR materialization.
		[[nodiscard]] LogicalProjectionCsrCacheState csrCacheState() const;
		[[nodiscard]] std::shared_ptr<const LogicalProjectionCsr> csr() const;

	private:
		static void addArc(LogicalGraphProjection &projection, uint64_t sourceNodeId, uint64_t targetNodeId,
						   double weight, uint64_t relationshipId, bool syntheticReverse);
		static void addRelationship(LogicalGraphProjection &projection, const storage::LogicalGraphEdgeTopology &edge,
								const LogicalRelationshipProjection &relationship, double weight);

		std::shared_ptr<std::pmr::memory_resource> allocation_owner_ = utils::sharedAllocationOwner();
        using Adjacency = utils::OwnedStdVector<LogicalProjectionEdge>;
        using AdjacencyEntry = std::pair<const uint64_t, Adjacency>;
        using AdjacencyMap = std::unordered_map<uint64_t, Adjacency, std::hash<uint64_t>,
            std::equal_to<uint64_t>, utils::OwnedPmrAllocator<AdjacencyEntry>>;
        utils::OwnedStdVector<uint64_t> node_ids_;
        AdjacencyMap outgoing_{utils::OwnedPmrAllocator<AdjacencyEntry>(allocation_owner_)};
        AdjacencyMap incoming_{utils::OwnedPmrAllocator<AdjacencyEntry>(allocation_owner_)};
		size_t edge_count_ = 0U;
		bool is_weighted_ = false;
		mutable std::shared_ptr<const LogicalProjectionCsr> csr_cache_;
		// A shared mutex object preserves value semantics for projections while
		// serializing first-use CSR construction across catalog readers.
		mutable std::shared_ptr<std::mutex> csr_mutex_ = utils::makeSharedOwned<std::mutex>();
	};

} // namespace graph::query::gds

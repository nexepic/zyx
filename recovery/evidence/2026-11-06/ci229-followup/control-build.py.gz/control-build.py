import shlex,subprocess,json,os,shutil,hashlib
from pathlib import Path
root=Path('/tmp/zyx-ci229-cache-control');root.mkdir(exist_ok=True)
source=Path('/workspace/zyx-ci-fix/src/query/execution/LogicalPlanProcedureRuntime.cpp')
shutil.copy2(source,root/source.name)
shutil.copytree(source.parent/'procedure_runtime',root/'procedure_runtime',dirs_exist_ok=True)
p=root/'procedure_runtime/ExpressionsAndBindings.inc'
p.write_bytes(subprocess.check_output(['git','show','bc4d13a0:src/query/execution/procedure_runtime/ExpressionsAndBindings.inc'],cwd='/workspace/zyx-ci-fix'))
env=os.environ.copy();env['LD_LIBRARY_PATH']=env['LIBRARY_PATH']='/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu'
a=shlex.split(Path('/tmp/zyx-ci229-procedure-compile-shell.txt').read_text());clean=[];i=0
while i<len(a):
 if a[i] in ('-o','-MT','-MF'):i+=2;continue
 if a[i] in ('-MD','-MMD'):i+=1;continue
 clean.append(str(root/source.name) if a[i]==str(source) else a[i]);i+=1
obj=root/'procedure.o';clean+=['-o',str(obj)]
(root/'compile-command.json').write_text(json.dumps(clean,indent=2)+'\n')
with (root/'compile.log').open('w') as f:r=subprocess.run(clean,cwd='/workspace/zyx-ci-config',env=env,stdout=f,stderr=subprocess.STDOUT)
print('compile',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
a=shlex.split(Path('/tmp/zyx-ci229-procedure-link-shell.txt').read_text());a=a[a.index('&&')+1:];a=a[:a.index('&&')];out=[];i=0
while i<len(a):
 if a[i]=='-Xlinker' and i+1<len(a) and a[i+1].startswith('--dependency-file='):i+=2;continue
 if a[i]=='-o':out+=['-o','/workspace/zyx-ci229-cache-control-suite'];i+=2;continue
 if a[i]=='libzyx_core.a':out.append(str(obj))
 out.append(a[i]);i+=1
(root/'link-command.json').write_text(json.dumps(out,indent=2)+'\n')
with (root/'link.log').open('w') as f:r=subprocess.run(out,cwd='/workspace/zyx-ci-config',env=env,stdout=f,stderr=subprocess.STDOUT)
print('link',r.returncode,flush=True)
raise SystemExit(r.returncode)

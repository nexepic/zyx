import os,shlex,subprocess,json
from pathlib import Path
root=Path('/tmp/zyx-ci229-conversion-frontier');root.mkdir(exist_ok=True)
a=shlex.split(Path('/tmp/zyx-ci229-procedure-link-shell.txt').read_text());a=a[a.index('&&')+1:];a=a[:a.index('&&')];out=[];i=0
while i<len(a):
 if a[i]=='-Xlinker' and i+1<len(a) and a[i+1].startswith('--dependency-file='):i+=2;continue
 if a[i]=='-o':out+=['-o','/workspace/zyx-ci229-conversion-control-suite'];i+=2;continue
 if a[i]=='libzyx_core.a':out.append('/tmp/zyx-ci229-conversion-before.o')
 out.append(a[i]);i+=1
(root/'control-link.json').write_text(json.dumps(out,indent=2)+'\n');env=os.environ.copy();env['LD_LIBRARY_PATH']=env['LIBRARY_PATH']='/workspace/zyx-sysroot/usr/lib/x86_64-linux-gnu'
with (root/'control-link.log').open('w') as log:r=subprocess.run(out,cwd='/workspace/zyx-ci-config',env=env,stdout=log,stderr=subprocess.STDOUT)
print('link',r.returncode);raise SystemExit(r.returncode)

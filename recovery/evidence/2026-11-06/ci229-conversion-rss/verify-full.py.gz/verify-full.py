import xml.etree.ElementTree as ET, json, collections, hashlib
from pathlib import Path
base=Path('/tmp/zyx-ci229-frontier-final2-xml')
suite=''; discovered=[]
for line in Path('/tmp/zyx-ci229-frontier-discovery.txt').read_text().splitlines():
 if not line.strip(): continue
 if line[0].isspace(): discovered.append(suite+line.strip().split('#')[0].strip())
 else: suite=line.split('#')[0].strip()
def disabled(n): return any(s.startswith('DISABLED_') for s in n.split('.'))
enabled={n for n in discovered if not disabled(n)}
executed=[]; failed=[]; skipped=[];notrun=[]; shards=[]
for p in sorted(base.glob('*.xml')):
 r=ET.parse(p).getroot();shards.append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'attributes':r.attrib})
 for t in r.iter('testcase'):
  n=t.get('classname')+'.'+t.get('name')
  if t.get('status')!='run': notrun.append(n);continue
  executed.append(n)
  if t.find('failure') is not None: failed.append(n)
  if t.find('skipped') is not None: skipped.append(n)
c=collections.Counter(executed)
import runpy
stress=runpy.run_path('scripts/run_test_tier.py')['STRESS_TESTS']
r={'source_commit':'bd0cdff0adfb4841b5c4dec0eedba9d0a4c70111','enabled_discovered':len(enabled),'disabled_discovered':sorted(n for n in discovered if disabled(n)),'stress_counts':{n:c[n] for n in stress},'executions':len(executed),'distinct_executed':len(c),'passed':len(executed)-len(failed)-len(skipped),'failed':failed,'skipped':skipped,'missing':sorted(enabled-set(c)),'extra':sorted(set(c)-enabled),'duplicates':{k:v for k,v in c.items() if v!=1},'shards':shards}
print(json.dumps(r,indent=2));assert len(shards)==2 and not r['failed'] and not r['skipped'] and not r['missing'] and not r['extra'] and not r['duplicates']

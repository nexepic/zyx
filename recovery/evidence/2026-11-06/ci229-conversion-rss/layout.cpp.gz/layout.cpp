#include <cstdio>
#include <cstdint>
#include "graph/storage/relocatable/metadata/LocationDirectory.hpp"
struct Before { graph::storage::EntityPropertyKey key; size_t fields; };
struct After { uint64_t entity_id; size_t fields; };
int main() { std::printf("before=%zu after=%zu owners=64 saved=%zu\n",sizeof(Before),sizeof(After),64U*(sizeof(Before)-sizeof(After))); }

#include <cassert>
#include <cstdio>
#include "query/execution/ScopedScalarReadValue.hpp"
using graph::PropertyValue;
using graph::query::execution::LogicalPlanReadValue;
using graph::query::execution::detail::ScopedScalarReadValue;
int main() {
    const char *text = nullptr;
    const ScopedScalarReadValue owned([&]() -> LogicalPlanReadValue {
        LogicalPlanReadValue value(PropertyValue(std::string(4096U,'x')));
        text=std::get<std::string>(std::get<PropertyValue>(value).getVariant()).data();return value;
    });
    assert(std::get<std::string>(owned.get().getVariant()).data()==text);
    const PropertyValue parameter(std::string(8192U,'p'));
    const ScopedScalarReadValue borrowed(parameter);
    assert(borrowed.borrowed() && &borrowed.get()==&parameter);
    const PropertyValue *items = nullptr;
    const ScopedScalarReadValue list([&]() -> LogicalPlanReadValue {
        LogicalPlanReadValue value(PropertyValue(std::vector<PropertyValue>{PropertyValue(std::string(4096U,'a')),PropertyValue(int64_t{42})}));
        items=std::get<std::vector<PropertyValue>>(std::get<PropertyValue>(value).getVariant()).data();return value;
    });
    assert(std::get<std::vector<PropertyValue>>(list.get().getVariant()).data()==items);
    const ScopedScalarReadValue entity([]()->LogicalPlanReadValue { graph::storage::LogicalGraphNode n;n.node_id=7;return n; });
    assert(std::get<int64_t>(entity.get().getVariant())==7);
    std::printf("libcxx=%d string_bytes=%zu scalar ownership/borrowing/list/entity checks passed\n",_LIBCPP_VERSION,sizeof(std::string));
}

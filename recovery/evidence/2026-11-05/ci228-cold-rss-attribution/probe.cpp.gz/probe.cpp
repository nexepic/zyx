
#include <atomic>
#include <csignal>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <unistd.h>
#include <sanitizer/allocator_interface.h>
#include <sanitizer/asan_interface.h>
namespace rss_attribution {
static std::atomic<bool> enabled{false};
static std::atomic<size_t> allocations{0},requested{0},frees{0},freed{0},sampled{0};
static thread_local bool inside=false;
struct Site{void *pc[16]{};size_t frames=0,bytes=0,count=0;};
static Site sites[2048];static std::atomic_flag lock=ATOMIC_FLAG_INIT;static size_t overflow=0;
void report(const char *phase){
 char data[8192];const int fd=::open("/proc/self/status",O_RDONLY);const auto n=fd<0 ? -1 : ::read(fd,data,sizeof(data));if(fd>=0)::close(fd);
 if(n>0)for(char *p=data;p<data+n;){char *e=static_cast<char*>(std::memchr(p,'\n',static_cast<size_t>(data+n-p)));if(!e)break;
 if(std::strncmp(p,"RssAnon:",8)==0||std::strncmp(p,"RssFile:",8)==0||std::strncmp(p,"RssShmem:",9)==0)std::fprintf(stderr,"RSS_COMPONENT %s %.*s\n",phase,static_cast<int>(e-p),p);p=e+1;}
 std::fprintf(stderr,"RSS_ALLOCATOR %s live=%zu heap=%zu free=%zu total_calls=%zu requested=%zu free_calls=%zu freed=%zu\n",phase,__sanitizer_get_current_allocated_bytes(),__sanitizer_get_heap_size(),__sanitizer_get_free_bytes(),allocations.load(),requested.load(),frees.load(),freed.load());
 std::fprintf(stderr,"RSS_MAP_PAUSE phase=%s\n",phase);std::fflush(stderr);::raise(SIGSTOP);
}
struct QueryScope{QueryScope(){report("before");enabled=true;}~QueryScope(){enabled=false;report("after");__asan_print_accumulated_stats();
 std::fprintf(stderr,"SITES sample_denominator=256 overflow=%zu\n",overflow);
 for(size_t rank=0;rank<25;++rank){size_t best=0;for(size_t i=1;i<2048;++i)if(sites[i].bytes>sites[best].bytes)best=i;auto &s=sites[best];if(!s.count)break;
 std::fprintf(stderr,"SITE count=%zu bytes=%zu",s.count,s.bytes);for(size_t i=0;i<s.frames;++i)std::fprintf(stderr," pc=%p",s.pc[i]);std::fprintf(stderr,"\n");s.bytes=0;}
}};
}
extern "C" void __sanitizer_malloc_hook(const volatile void *p,size_t size){using namespace rss_attribution;if(!enabled.load()||inside)return;inside=true;allocations.fetch_add(1);requested.fetch_add(size);
 if((sampled.fetch_add(1)&255U)==0){void *pcs[16]{};int tid=0;const size_t frames=__asan_get_alloc_stack(const_cast<void*>(p),pcs,16,&tid);size_t hash=frames;for(size_t i=0;i<frames;++i)hash=hash*1099511628211ULL+reinterpret_cast<uintptr_t>(pcs[i]);while(lock.test_and_set()){};size_t slot=hash%2048,tries=0;for(;tries<2048;++tries,slot=(slot+1)%2048){auto &s=sites[slot];if(!s.count||(s.frames==frames&&std::memcmp(s.pc,pcs,frames*sizeof(void*))==0)){if(!s.count){s.frames=frames;std::memcpy(s.pc,pcs,frames*sizeof(void*));}++s.count;s.bytes+=size;break;}}if(tries==2048)++overflow;lock.clear();}
 inside=false;}
extern "C" void __sanitizer_free_hook(const volatile void *p){using namespace rss_attribution;if(!enabled.load()||inside||!p)return;inside=true;frees.fetch_add(1);freed.fetch_add(__sanitizer_get_allocated_size(const_cast<void*>(p)));inside=false;}
#include "storage/relocatable/backend/RelocatableStorageBackendTestFixture.hpp"
#include "graph/storage/LogicalQueryScratch.hpp"
#include "graph/query/execution/MaterializedByteBudget.hpp"
#include "query/execution/ProcessResourceDomains.hpp"
#include "graph/debug/SanitizerAllocationSnapshot.hpp"
#include <cstdio>
#include <cstdlib>
using namespace relocatable_storage_backend_test;
TEST_F(RelocatableStorageBackendTest, QueryScratchOwnsPrivateHandlesAndReleasesDespiteLongGraphPins) {
	materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;RelocatableStorageBackend backend(options);backend.open();
	const auto id=backend.createLogicalNodes({{{"ScratchPin"},{{"value",PropertyValue(7)}}}})[0];auto old=backend.openLogicalGraphReadSnapshot();
	auto *provider=dynamic_cast<LogicalQueryScratchProvider *>(old.get());
	ASSERT_NE(provider,nullptr);
	auto first=provider->openQueryScratchSession(2U*RSS_SEGMENT_SIZE,2U),second=provider->openQueryScratchSession(RSS_SEGMENT_SIZE,1U);
	ASSERT_NE(first,nullptr);
	ASSERT_NE(second,nullptr);const std::vector<std::byte> bytes(4096,std::byte{0x3A});
	const auto handle=first->write(bytes);
	EXPECT_EQ(first->read(handle),bytes);
	EXPECT_THROW(second->read(handle),std::invalid_argument);
	EXPECT_THROW(backend.close(),std::logic_error);
	first->release(handle);
	EXPECT_THROW(first->read(handle),std::invalid_argument);
	// An ordinary graph pin remains live while query-only slots become reusable.
	const auto again=first->write(bytes);
	EXPECT_EQ(first->read(again),bytes);first->finish();second->finish();
	EXPECT_THROW(first->write(bytes),std::logic_error);
	EXPECT_EQ(old->readNodeProperty(id,"value"),PropertyValue(7));old.reset();
	EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));backend.close();backend.open();backend.close();
}
TEST_F(RelocatableStorageBackendTest, QueryScratchEnforcesDiskFragmentsAndPhysicalReadOnlyPermissions) {
	materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;RelocatableStorageBackend backend(options);backend.open();
	const std::vector<std::byte> bytes(64,std::byte{0x11});auto scratch=backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1);(void)scratch->write(bytes);
	EXPECT_THROW(scratch->write(bytes),std::runtime_error);
	scratch->finish();backend.close();const auto size=std::filesystem::file_size(data_path_);options.open_mode=OpenMode::OPEN_READ_ONLY_EXISTING_FILE;RelocatableStorageBackend reader(options);reader.open();reader.resetIoStats();auto snapshot=reader.openLogicalGraphReadSnapshot();
	auto *provider=dynamic_cast<LogicalQueryScratchProvider *>(snapshot.get());
	ASSERT_NE(provider,nullptr);
	EXPECT_EQ(provider->openQueryScratchSession(RSS_SEGMENT_SIZE,1),nullptr);
	EXPECT_EQ(reader.ioStats().data.write_bytes,0U);snapshot.reset();reader.close();
	EXPECT_EQ(std::filesystem::file_size(data_path_),size);
}
#include "graph/query/api/QueryEngine.hpp"
#include "graph/debug/PerfTrace.hpp"
#include "graph/query/QueryGuard.hpp"
TEST_F(RelocatableStorageBackendTest, NativeLogicalReadonlySortSpillsAndPreservesCompleteDescendingCollection) {
	materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;auto backend=std::make_shared<RelocatableStorageBackend>(options);backend->open();
	graph::query::LogicalReadExecutionOptions reads;reads.bounds.maximum_materialized_bytes=8U*1024U*1024U;
	graph::query::QueryEngine engine(std::static_pointer_cast<LogicalGraphReadBackend>(backend),reads);const auto fence=backend->currentNativeLogicalGraphMutationFence();
	const bool wasEnabled=graph::debug::PerfTrace::isEnabled(),wasCollecting=graph::debug::PerfTrace::areValuesEnabled();
	struct RestoreTrace{bool enabled,collecting;~RestoreTrace(){graph::debug::PerfTrace::setValueCollectionEnabled(collecting);graph::debug::PerfTrace::setEnabled(enabled);}}restore{wasEnabled,wasCollecting};
	graph::debug::PerfTrace::setEnabled(true);graph::debug::PerfTrace::setValueCollectionEnabled(true);(void)graph::debug::PerfTrace::snapshotAndReset();
    if (std::getenv("ZYX_CI_RSS_TRACE")) {
        const auto allocator = graph::debug::captureSanitizerAllocations();
        std::fprintf(stderr, "CI_RSS_BEGIN rss=%zu asan_available=%d live=%zu heap=%zu\n",
            graph::query::QueryGuard::getCurrentRSSBytes(), allocator.available, allocator.live_bytes, allocator.heap_bytes);
    }
	rss_attribution::QueryScope attributionScope;size_t sampledBaseline=0;bool sampledFirst=true;bool reported=false;graph::query::QueryGuard guard(120000,64,[&](){const size_t now=graph::query::QueryGuard::getCurrentRSSBytes();if(sampledFirst){sampledFirst=false;sampledBaseline=now;}else if(!reported&&now>sampledBaseline+64U*1024U*1024U){reported=true;rss_attribution::report("rejection-before-unwind");__asan_print_accumulated_stats();}return now;});graph::query::QueryContext context;context.guard=&guard;
	const auto result=engine.execute("UNWIND range(1,20000) AS x WITH x ORDER BY x DESC RETURN collect(x) AS values",context);
	ASSERT_EQ(result.rowCount(),1U);
	const auto &values=std::get<std::vector<PropertyValue>>(result.getRows()[0].at("values").asPrimitive().getVariant());
	ASSERT_EQ(values.size(),20000U);
	for(size_t i=0;i<values.size();++i)EXPECT_EQ(values[i],PropertyValue(static_cast<int64_t>(20000U-i)));
	const auto trace=graph::debug::PerfTrace::snapshotAndReset();
	ASSERT_TRUE(trace.contains("logical_plan.sort.spilled"));
	EXPECT_EQ(trace.at("logical_plan.sort.spilled").totalValue,1);
	graph::debug::PerfTrace::setValueCollectionEnabled(wasCollecting);graph::debug::PerfTrace::setEnabled(wasEnabled);
	EXPECT_EQ(backend->currentNativeLogicalGraphMutationFence(),fence);
	EXPECT_NO_THROW(static_cast<void>(backend->verifyIntegrity()));backend->close();
}
TEST_F(RelocatableStorageBackendTest, QueryScratchInternalPolicyCanDenyPermissionWithoutWritingTheFile) {
	materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;options.query_scratch_enabled=false;
	RelocatableStorageBackend backend(options);backend.open();const auto before=backend.currentNativeMetadataGeneration();backend.resetIoStats();
	EXPECT_EQ(backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1),nullptr);
	EXPECT_EQ(backend.currentNativeMetadataGeneration(),before);
	EXPECT_EQ(backend.ioStats().data.write_bytes,0U);backend.close();
}

TEST_F(RelocatableStorageBackendTest, QueryScratchCleanupIoFailureImmediatelyFencesFurtherWrites) {
	for (const int operation : {0,1,2}) {
		SCOPED_TRACE(operation);
		materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;
		RelocatableStorageBackend backend(options);backend.open();
		const auto node=backend.createLogicalNodes({{{"ScratchFailure"},{{"value",PropertyValue(7)}}}}).at(0);
		auto old=backend.openLogicalGraphReadSnapshot();auto scratch=backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1);
		const std::vector<std::byte> bytes(64,std::byte{0x11});const auto handle=scratch->write(bytes);
		bool injected=false;
		{
			StorageIO::ScopedNativeWriteHookForTesting hook([&](file_handle_t,const void *,size_t,pwrite_off_t){injected=true;return static_cast<pwrite_ssize_t>(-1);});
			if(operation==2)EXPECT_THROW(scratch->finish(),std::exception);
            else if(operation==1)EXPECT_THROW(scratch->releaseBatch(std::span(&handle,1U)),std::exception);
			else EXPECT_THROW(scratch->release(handle),std::exception);
		}
		ASSERT_TRUE(injected);
	EXPECT_TRUE(backend.hasIndeterminateWriteOutcome());
		EXPECT_THROW(scratch->write(bytes),std::logic_error);
		EXPECT_THROW(scratch->read(handle),std::logic_error);
		EXPECT_THROW(backend.replaceLogicalNodeProperties({{node,{{"value",PropertyValue(99)}}}}),std::logic_error);
		EXPECT_EQ(old->readNodeProperty(node,"value"),PropertyValue(7));
		scratch.reset();old.reset();backend.close();backend.open();
		auto recovered=backend.openLogicalGraphReadSnapshot();
	EXPECT_EQ(recovered->readNodeProperty(node,"value"),PropertyValue(7));recovered.reset();
		EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));backend.close();
		std::filesystem::remove(data_path_);
	}
}

#include "storage/relocatable/backend/QueryScratchDiskBudget.hpp"
#include <barrier>
#include <thread>
#include <atomic>
TEST(QueryScratchDiskBudgetTest, ThreeLevelsRefundOnlyReclaimedExtentsAndRetainOrphans) {
	using graph::storage::detail::QueryScratchDiskBudget;
	auto process=std::make_shared<QueryScratchDiskBudget>(100);
	{
		auto first=process->open("a",80,60),second=process->open("a",80,60),other=process->open("b",80,60);
		first.acquire(60);
	EXPECT_THROW(first.acquire(1),std::runtime_error);
		second.acquire(20);
	EXPECT_THROW(second.acquire(1),std::runtime_error);
		other.acquire(20);
	EXPECT_THROW(other.acquire(1),std::runtime_error);
		EXPECT_EQ(process->usage().bytes,100U);
		first.release(10);other.acquire(10);
	EXPECT_EQ(process->usage().bytes,100U);
		EXPECT_THROW(process->recovered("a"),std::logic_error);
		second.release(20);second.close();other.release(30);other.close();
		EXPECT_EQ(process->usage().bytes,50U);
	}
	EXPECT_EQ(process->usage().orphan_bytes,50U);
	EXPECT_EQ(process->usage().sessions,0U);
	auto denied=process->open("b",80,60);
	EXPECT_THROW(denied.acquire(51),std::runtime_error);denied.close();
	process->recovered("a");
	EXPECT_EQ(process->usage().bytes,0U);
	EXPECT_EQ(process->usage().domains,0U);
}
TEST(QueryScratchDiskBudgetTest, ConcurrentDomainsCannotOverAdmitProcessQuota) {
	using graph::storage::detail::QueryScratchDiskBudget;
	auto process=std::make_shared<QueryScratchDiskBudget>(100);std::barrier ready(3);std::atomic<unsigned> admitted{0};
	auto worker=[&](const char *name){auto session=process->open(name,80,60);ready.arrive_and_wait();try{session.acquire(60);++admitted;}catch(const std::runtime_error &){};};
	std::thread first(worker,"first"),second(worker,"second");ready.arrive_and_wait();first.join();second.join();
	EXPECT_EQ(admitted,1U);
	EXPECT_EQ(process->usage().bytes,60U);
	EXPECT_EQ(process->usage().orphan_bytes,60U);
	process->recovered("first");process->recovered("second");
	EXPECT_EQ(process->usage().bytes,0U);
}
TEST(QueryScratchDiskBudgetTest, SlotsMovesAndInvalidConfigurationPreserveOwnership) {
	using graph::storage::detail::QueryScratchDiskBudget;
	auto process=std::make_shared<QueryScratchDiskBudget>(100,1);
	auto first=process->open("a",80,60);
	EXPECT_THROW(process->open("a",80,60),std::runtime_error);
	EXPECT_THROW(process->open("a",70,60),std::invalid_argument);
	first.acquire(40);auto moved=std::move(first);
	EXPECT_THROW(first.acquire(1),std::logic_error);
	moved.release(40);moved.close();
	EXPECT_EQ(process->usage().sessions,0U);
	EXPECT_THROW(process->open("a",101,60),std::invalid_argument);
	std::vector<QueryScratchDiskBudget::Session> domains;
	for(size_t i=0;i<64;++i)domains.push_back(process->open(std::to_string(i),80,60));
	EXPECT_THROW(process->open("overflow",80,60),std::runtime_error);
	domains.clear();
	EXPECT_EQ(process->usage().domains,0U);
}
TEST_F(RelocatableStorageBackendTest, QueryScratchDatabaseQuotaIsSharedAcrossSessionsAndRefundedAfterCleanup) {
	materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;
	options.maximum_database_query_scratch_bytes=RSS_SEGMENT_SIZE;
	RelocatableStorageBackend backend(options);backend.open();
	auto first=backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1),second=backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1);
	const std::vector<std::byte> bytes(64,std::byte{0x11});const auto handle=first->write(bytes);
	backend.resetIoStats();
	EXPECT_THROW(second->write(bytes),std::runtime_error);
	EXPECT_EQ(backend.ioStats().data.write_bytes,0U);
	EXPECT_FALSE(backend.hasIndeterminateWriteOutcome());
	first->release(handle);const auto admitted=second->write(bytes);
	EXPECT_EQ(second->read(admitted),bytes);
	first->finish();second->finish();
	EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));backend.close();backend.open();backend.close();
}

#include "graph/storage/relocatable/format/SuperblockFile.hpp"
#include <cerrno>
#ifdef _WIN32
#include <windows.h>
#endif
namespace {
enum class ScratchFault { QSFT_NO_SPACE, QSFT_TORN_DATA, QSFT_TORN_ROOT, QSFT_FINAL_SYNC };
void scratchIoError(bool noSpace) {
#ifdef _WIN32
	SetLastError(noSpace?ERROR_DISK_FULL:ERROR_WRITE_FAULT);
#else
	errno=noSpace?ENOSPC:EIO;
#endif
}
}
TEST_F(RelocatableStorageBackendTest, QueryScratchPublicationFaultsPreserveGraphAndRecoverOrphanQuota) {
	for(const auto fault:{ScratchFault::QSFT_NO_SPACE,ScratchFault::QSFT_TORN_DATA,ScratchFault::QSFT_TORN_ROOT,ScratchFault::QSFT_FINAL_SYNC}) {
		SCOPED_TRACE(static_cast<int>(fault));materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;
		RelocatableStorageBackend backend(options);backend.open();const auto node=backend.createLogicalNodes({{{"ScratchFault"},{{"value",PropertyValue(7)}}}}).at(0);
		auto old=backend.openLogicalGraphReadSnapshot();const auto fence=backend.currentNativeLogicalGraphMutationFence();
		auto scratch=backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1);const std::vector<std::byte> bytes(4096,std::byte{0x11});
		bool injected=false,rootWritten=false,dataWritten=false;
		{
			StorageIO::ScopedNativeWriteHookForTesting writeHook([&](file_handle_t fd,const void *buffer,size_t count,pwrite_off_t offset){
				bool root=false;
				if(count==RSS_PAGE_SIZE)try{static_cast<void>(SuperblockCodec::decode(std::span(static_cast<const std::byte *>(buffer),count)));root=true;}catch(const std::exception &){}
				bool data=false;
				if(count>=RSS_ENVELOPE_BYTES)try{data=SegmentEnvelopeCodec::decode(std::span(static_cast<const std::byte *>(buffer),count).first(RSS_ENVELOPE_BYTES)).kind==SegmentKind::SGK_QUERY_SCRATCH;}catch(const std::exception &){}
				const bool target=(data&&(fault==ScratchFault::QSFT_NO_SPACE||fault==ScratchFault::QSFT_TORN_DATA))||(root&&dataWritten&&fault==ScratchFault::QSFT_TORN_ROOT);
				if(target&&!injected){injected=true;if(fault!=ScratchFault::QSFT_NO_SPACE)EXPECT_EQ(portable_pwrite(fd,buffer,64,offset),64);scratchIoError(fault==ScratchFault::QSFT_NO_SPACE);return static_cast<pwrite_ssize_t>(-1);}
				const auto written=portable_pwrite(fd,buffer,count,offset);if(data&&written==static_cast<pwrite_ssize_t>(count))dataWritten=true;
				if(root&&dataWritten&&written==static_cast<pwrite_ssize_t>(count))rootWritten=true;return written;
			});
			StorageIO::ScopedNativeSyncHookForTesting syncHook([&](file_handle_t fd){if(fault==ScratchFault::QSFT_FINAL_SYNC&&rootWritten&&!injected){injected=true;scratchIoError(false);return -1;}return portable_fsync(fd);});
			EXPECT_THROW(scratch->write(bytes),std::exception);
		}
		ASSERT_TRUE(injected);
	EXPECT_TRUE(backend.hasIndeterminateWriteOutcome());
		EXPECT_EQ(old->readNodeProperty(node,"value"),PropertyValue(7));
	EXPECT_EQ(backend.currentNativeLogicalGraphMutationFence(),fence);
		scratch.reset();old.reset();backend.close();backend.open();
		EXPECT_EQ(backend.currentNativeLogicalGraphMutationFence(),fence);
	EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));
		auto recovered=backend.openLogicalGraphReadSnapshot();
	EXPECT_EQ(recovered->readNodeProperty(node,"value"),PropertyValue(7));recovered.reset();
		auto admitted=backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1);
	EXPECT_NO_THROW(static_cast<void>(admitted->write(bytes)));admitted->finish();backend.close();std::filesystem::remove(data_path_);
	}
}
TEST_F(RelocatableStorageBackendTest, PhysicalReadonlyOpeningCannotReclaimLiveScratchOrDeclareItHealthy) {
	materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;
	RelocatableStorageBackend writer(options);writer.open();auto scratch=writer.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1);
	const std::vector<std::byte> bytes(4096,std::byte{0x3A});const auto handle=scratch->write(bytes);
	options.open_mode=OpenMode::OPEN_READ_ONLY_EXISTING_FILE;RelocatableStorageBackend reader(options);reader.open();reader.resetIoStats();
	EXPECT_THROW(static_cast<void>(reader.verifyIntegrity()),FormatException);
	EXPECT_EQ(reader.ioStats().data.write_bytes,0U);reader.close();
	EXPECT_EQ(scratch->read(handle),bytes);
	scratch->finish();
	EXPECT_NO_THROW(static_cast<void>(writer.verifyIntegrity()));writer.close();
}

TEST_F(RelocatableStorageBackendTest, QueryScratchAllocatorPublicationInterleavesWithGraphWritesWithoutLosingRoots) {
	materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;
	RelocatableStorageBackend backend(options);backend.open();const auto node=backend.createLogicalNodes({{{"ConcurrentScratch"},{{"value",PropertyValue(0)}}}}).at(0);
	auto old=backend.openLogicalGraphReadSnapshot();auto scratch=backend.openNativeQueryScratchSession(2U*RSS_SEGMENT_SIZE,2);
	const std::vector<std::byte> bytes(4096,std::byte{0x3A});std::barrier ready(3);std::array<std::exception_ptr,2> errors{};
	std::thread scratchWriter([&]{ready.arrive_and_wait();try{for(size_t i=0;i<10;++i){const auto handle=scratch->write(bytes);if(scratch->read(handle)!=bytes)throw std::runtime_error("scratch content changed");scratch->release(handle);}}catch(...){errors[0]=std::current_exception();}});
	std::thread graphWriter([&]{ready.arrive_and_wait();try{for(int64_t i=1;i<=10;++i)backend.replaceLogicalNodeProperties({{node,{{"value",PropertyValue(i)}}}});}catch(...){errors[1]=std::current_exception();}});
	ready.arrive_and_wait();scratchWriter.join();graphWriter.join();
	ASSERT_EQ(errors[0],nullptr);
	ASSERT_EQ(errors[1],nullptr);
	scratch->finish();
	EXPECT_EQ(old->readNodeProperty(node,"value"),PropertyValue(0));old.reset();
	auto current=backend.openLogicalGraphReadSnapshot();
	EXPECT_EQ(current->readNodeProperty(node,"value"),PropertyValue(10));current.reset();
	EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));backend.close();backend.open();
	EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));backend.close();
}
TEST_F(RelocatableStorageBackendTest, CorruptScratchReadAndOrphanRecoveryNeverReclaimUserPagesOrRefundQuota) {
	materializeNativeDatabase();auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;
	RelocatableStorageBackend backend(options);backend.open();const auto node=backend.createLogicalNodes({{{"ScratchCorruption"},{{"value",PropertyValue(7)}}}}).at(0);
	auto old=backend.openLogicalGraphReadSnapshot();auto scratch=backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE,1);
	const std::vector<std::byte> bytes(4096,std::byte{0x3A});std::vector<std::byte> original;pwrite_off_t corruptedOffset=0;uint64_t handle=0;
	{
		StorageIO::ScopedNativeWriteHookForTesting hook([&](file_handle_t fd,const void *buffer,size_t count,pwrite_off_t offset){
			bool query=false;if(count>=RSS_ENVELOPE_BYTES)try{query=SegmentEnvelopeCodec::decode(std::span(static_cast<const std::byte *>(buffer),count).first(RSS_ENVELOPE_BYTES)).kind==SegmentKind::SGK_QUERY_SCRATCH;}catch(const std::exception &){}
			if(query&&original.empty()){
				original.assign(static_cast<const std::byte *>(buffer),static_cast<const std::byte *>(buffer)+count);corruptedOffset=offset;
				auto corrupt=original;corrupt.at(RSS_ENVELOPE_BYTES)^=std::byte{1};return portable_pwrite(fd,corrupt.data(),corrupt.size(),offset);
			}
			return portable_pwrite(fd,buffer,count,offset);
		});
		handle=scratch->write(bytes);
	}
	ASSERT_FALSE(original.empty());
	EXPECT_THROW(scratch->read(handle),FormatException);
	EXPECT_THROW(scratch->release(handle),FormatException);
	EXPECT_TRUE(backend.hasIndeterminateWriteOutcome());
	EXPECT_EQ(old->readNodeProperty(node,"value"),PropertyValue(7));scratch.reset();old.reset();backend.close();
	auto budget=graph::storage::detail::QueryScratchDiskBudget::processBudget();const auto quarantined=budget->usage().orphan_bytes;
	EXPECT_GE(quarantined,RSS_SEGMENT_SIZE);
	{
		options.open_mode=OpenMode::OPEN_READ_ONLY_EXISTING_FILE;RelocatableStorageBackend reader(options);reader.open();reader.resetIoStats();
		auto snapshot=reader.openLogicalGraphReadSnapshot();
	EXPECT_EQ(snapshot->readNodeProperty(node,"value"),PropertyValue(7));snapshot.reset();
		EXPECT_THROW(static_cast<void>(reader.verifyIntegrity()),FormatException);
	EXPECT_EQ(reader.ioStats().data.write_bytes,0U);reader.close();
	}
	size_t unsafeWrites=0;
	{
		StorageIO::ScopedNativeWriteHookForTesting hook([&](file_handle_t fd,const void *buffer,size_t count,pwrite_off_t offset){
			// Metadata startup may reconcile its authenticated private control bitmap.
			// It must never write data frames, graph roots or scratch-disposal state.
			bool control=false;
			if(count==RSS_METADATA_PAGE_POOL_HEADER_BYTES){
				const auto relative=static_cast<size_t>(offset)%RSS_PAGE_SIZE;
				if(relative==RSS_ENVELOPE_BYTES || relative==RSS_ENVELOPE_BYTES+RSS_METADATA_PAGE_POOL_HEADER_BYTES){
					std::array<std::byte,RSS_ENVELOPE_BYTES> envelope{};
					if(portable_pread(fd,envelope.data(),envelope.size(),offset-static_cast<pwrite_off_t>(relative))==static_cast<pwrite_ssize_t>(envelope.size())){
						try{const auto entry=SegmentEnvelopeCodec::decode(envelope);const auto header=MetadataPagePoolHeaderCodec::decode(std::span(static_cast<const std::byte *>(buffer),count));
							control=entry.kind==SegmentKind::SGK_METADATA_PAGE_POOL && header.segment_id==entry.segment_id && header.generation==entry.generation;
						}catch(const std::exception &){}
					}
				}
			}
			if(!control)++unsafeWrites;return portable_pwrite(fd,buffer,count,offset);
		});
		EXPECT_THROW(backend.open(),FormatException);
	}
	EXPECT_EQ(unsafeWrites,0U);
	EXPECT_EQ(budget->usage().orphan_bytes,quarantined);
	// Repair only the test-owned corrupt page, then require authenticated recovery.
	const auto fd=portable_open_rw(data_path_.string().c_str());
	ASSERT_NE(fd,INVALID_FILE_HANDLE);
	EXPECT_EQ(portable_pwrite(fd,original.data(),original.size(),corruptedOffset),static_cast<pwrite_ssize_t>(original.size()));
	EXPECT_EQ(portable_fsync(fd),0);portable_close(fd);
	backend.open();
	EXPECT_EQ(budget->usage().orphan_bytes,quarantined-RSS_SEGMENT_SIZE);
	EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));backend.close();
}

#include "graph/query/execution/ResourceCoordinator.hpp"
TEST_F(RelocatableStorageBackendTest, QueryScratchHandleGrantIsSharedAndRetainedUntilObjectDestruction) {
    using namespace graph::query::execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    options.query_scratch_enabled = true;
    RelocatableStorageBackend backend(options); backend.open();
    auto domain = backend.queryResourceDomain();
    const size_t kind = static_cast<size_t>(ResourceClass::RCK_QUERY);
    const auto before = domain->usage().classes[kind];
    auto first = backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE, 1U);
    const auto firstCharge = domain->usage().classes[kind] - before;
    EXPECT_GT(firstCharge, 0U);
    auto second = backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE, 1U);
    EXPECT_EQ(domain->usage().classes[kind], before + 2U * firstCharge);
    const std::vector<std::byte> payload(64U, std::byte{0x5a});
    const auto handle = first->write(payload);
    EXPECT_EQ(first->read(handle), payload);
    EXPECT_EQ(domain->usage().classes[kind], before + 2U * firstCharge);
    first->finish(); second->finish();
    EXPECT_NO_THROW(first->finish());
    EXPECT_NO_THROW(second->finish());
    EXPECT_EQ(domain->usage().classes[kind], before + 2U * firstCharge);
    first.reset();
    EXPECT_EQ(domain->usage().classes[kind], before + firstCharge);
    backend.close();
    second.reset();
    EXPECT_EQ(domain->usage().classes[kind], before);
}

TEST_F(RelocatableStorageBackendTest, QueryScratchMemoryDenialPrecedesPublicationAndDoesNotLeakDiskOrFileLease) {
    using namespace graph::query::execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    options.query_scratch_enabled = true;
    options.maximum_database_query_scratch_bytes = RSS_SEGMENT_SIZE;
    RelocatableStorageBackend backend(options); backend.open();
    auto domain = backend.queryResourceDomain();
    const size_t maximum = 192U * 1024U * 1024U;
    auto account = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_QUERY, maximum);
    ResourceLease pressure(account); pressure.set(account->available());
    const auto generation = backend.currentNativeMetadataGeneration();
    backend.resetIoStats();
    EXPECT_THROW((void)backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE, 1U), ResourceAdmissionDenied);
    EXPECT_EQ(backend.ioStats().data.write_bytes, 0U);
    EXPECT_EQ(backend.currentNativeMetadataGeneration(), generation);
    pressure.reset();
    auto session = backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE, 1U);
    ASSERT_NE(session, nullptr);
    const std::vector<std::byte> payload(64U, std::byte{0x5a});
    EXPECT_EQ(session->read(session->write(payload)), payload);
    session->finish(); session.reset(); backend.close();
}

TEST_F(RelocatableStorageBackendTest, QueryScratchFilePressureReleasesHandlesAndCanReuseQuotaWithGraphPinStillHeld) {
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    options.query_scratch_enabled = true;
    options.maximum_database_file_bytes = std::filesystem::file_size(data_path_) + 2U * RSS_SEGMENT_SIZE;
    RelocatableStorageBackend backend(options); backend.open();
    const auto fence = backend.currentNativeLogicalGraphMutationFence();
    auto graph = backend.openLogicalGraphReadSnapshot();
    auto *provider = dynamic_cast<LogicalQueryScratchProvider *>(graph.get()); ASSERT_NE(provider, nullptr);
    auto scratch = provider->openQueryScratchSession(64U * RSS_SEGMENT_SIZE, 64U); ASSERT_NE(scratch, nullptr);
    const std::vector<std::byte> bytes(4096U, std::byte{0x37});
    bool denied = false;
    for (size_t attempt = 0U; attempt < 64U; ++attempt) {
        try { (void)scratch->write(bytes); }
        catch (const std::system_error &error) {
            EXPECT_EQ(error.code(), std::make_error_code(std::errc::no_space_on_device));
            denied = true; break;
        }
        ASSERT_LE(std::filesystem::file_size(data_path_), options.maximum_database_file_bytes);
    }
    ASSERT_TRUE(denied);
    EXPECT_LE(std::filesystem::file_size(data_path_), options.maximum_database_file_bytes);
    EXPECT_EQ(backend.currentNativeLogicalGraphMutationFence(), fence);
    EXPECT_NO_THROW(scratch->finish()); scratch.reset();
    auto retry = provider->openQueryScratchSession(RSS_SEGMENT_SIZE, 1U); ASSERT_NE(retry, nullptr);
    const auto handle = retry->write(bytes); EXPECT_EQ(retry->read(handle), bytes);
    retry->finish(); retry.reset();
    EXPECT_EQ(backend.currentNativeLogicalGraphMutationFence(), fence);
    graph.reset();
    EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity())); backend.close();
}

TEST_F(RelocatableStorageBackendTest, NativeLogicalDistinctSpillsCanonicalKeysAndPreservesFirstOccurrenceOrder) {
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE;
    options.query_scratch_enabled = true;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    graph::query::LogicalReadExecutionOptions reads;
    reads.bounds.maximum_materialized_bytes = 8U * 1024U * 1024U;
    graph::query::QueryEngine engine(std::static_pointer_cast<LogicalGraphReadBackend>(backend), reads);
    const auto fence = backend->currentNativeLogicalGraphMutationFence();
    const bool enabled = graph::debug::PerfTrace::isEnabled(), collecting = graph::debug::PerfTrace::areValuesEnabled();
    struct RestoreTrace {
        bool enabled, collecting;
        ~RestoreTrace() { graph::debug::PerfTrace::setValueCollectionEnabled(collecting); graph::debug::PerfTrace::setEnabled(enabled); }
    } restore{enabled, collecting};
    graph::debug::PerfTrace::setEnabled(true); graph::debug::PerfTrace::setValueCollectionEnabled(true);
    (void)graph::debug::PerfTrace::snapshotAndReset();
    backend->resetIoStats();
    graph::query::QueryGuard guard(120000, 64); graph::query::QueryContext context; context.guard = &guard;
    // Wide canonical keys force a real spill with a small, fast input. The
    // quoted declaration must match the expression reference after decoding.
    const std::string alias(2048U, 'a');
    const std::string text = "UNWIND range(1,800) AS x WITH DISTINCT x % 400 AS `" + alias +
        "` RETURN collect(`" + alias + "`) AS values";
    const auto result = engine.execute(text, context);
    ASSERT_EQ(result.rowCount(), 1U);
    const auto &values = result.getRows()[0].at("values").asPrimitive().getList();
    ASSERT_EQ(values.size(), 400U);
    for (size_t i = 0U; i < values.size(); ++i)
        EXPECT_EQ(values[i], PropertyValue(static_cast<int64_t>((i + 1U) % 400U)));
    const auto trace = graph::debug::PerfTrace::snapshotAndReset();
    ASSERT_TRUE(trace.contains("logical_plan.distinct.spilled"));
    EXPECT_EQ(trace.at("logical_plan.distinct.spilled").totalValue, 1);
    EXPECT_GT(backend->ioStats().data.write_calls, 0U);
    EXPECT_EQ(backend->currentNativeLogicalGraphMutationFence(), fence);
    EXPECT_NO_THROW(static_cast<void>(backend->verifyIntegrity()));
    backend->close();
}

TEST_F(RelocatableStorageBackendTest, QueryScratchHandleGrantUsesTheCallingQueryAllowanceAndRefundsAfterDestruction) {
    using namespace graph::query::execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE; options.query_scratch_enabled = true;
    RelocatableStorageBackend backend(options); backend.open();
    auto snapshot = backend.openLogicalGraphReadSnapshot();
    auto *provider = dynamic_cast<LogicalQueryScratchProvider *>(snapshot.get()); ASSERT_NE(provider, nullptr);
    auto domain = backend.queryResourceDomain();
    auto small = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_QUERY, 1024U);
    const auto generation = backend.currentNativeMetadataGeneration(); backend.resetIoStats();
    EXPECT_THROW(static_cast<void>(provider->openQueryScratchSession(RSS_SEGMENT_SIZE, 1U, small)), ResourceAdmissionDenied);
    EXPECT_EQ(small->used(), 0U); EXPECT_EQ(backend.ioStats().data.write_calls, 0U);
    EXPECT_EQ(backend.currentNativeMetadataGeneration(), generation);
    EXPECT_FALSE(backend.hasIndeterminateWriteOutcome());
    auto account = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_QUERY, 65536U);
    auto scratch = provider->openQueryScratchSession(RSS_SEGMENT_SIZE, 1U, account); ASSERT_NE(scratch, nullptr);
    const auto charge = account->used(); EXPECT_EQ(charge, 4096U + 256U);
    const std::vector<std::byte> payload(64U, std::byte{0x6b});
    const auto handle = scratch->write(payload); EXPECT_EQ(scratch->read(handle), payload);
    EXPECT_EQ(account->used(), charge); scratch->finish(); EXPECT_EQ(account->used(), charge);
    scratch.reset(); EXPECT_EQ(account->used(), 0U);
    auto wrong = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_MAINTENANCE, 65536U);
    backend.resetIoStats();
    EXPECT_THROW(static_cast<void>(provider->openQueryScratchSession(RSS_SEGMENT_SIZE, 1U, wrong)), std::invalid_argument);
    EXPECT_EQ(wrong->used(), 0U); EXPECT_EQ(backend.ioStats().data.write_calls, 0U);
    snapshot.reset(); backend.close();
}

TEST_F(RelocatableStorageBackendTest, NativeUnionDistinctWithScratchPermissionPreservesNullsAndFirstOccurrenceOrder) {
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE; options.query_scratch_enabled = true;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    graph::query::QueryEngine engine(std::static_pointer_cast<LogicalGraphReadBackend>(backend));
    const auto fence = backend->currentNativeLogicalGraphMutationFence(); backend->resetIoStats();
    const auto result = engine.execute("UNWIND [null,1,1,2] AS x RETURN x AS value UNION UNWIND [2,null,3] AS y RETURN y AS value");
    ASSERT_EQ(result.rowCount(), 4U);
    const std::array<PropertyValue, 4U> expected{PropertyValue{}, PropertyValue(1), PropertyValue(2), PropertyValue(3)};
    for (size_t i = 0U; i < expected.size(); ++i) EXPECT_EQ(result.getRows()[i].at("value").asPrimitive(), expected[i]);
    EXPECT_EQ(backend->ioStats().data.write_calls, 0U);
    EXPECT_EQ(backend->currentNativeLogicalGraphMutationFence(), fence); backend->close();
}

TEST_F(RelocatableStorageBackendTest, NativeDistinctOutputBudgetDenialCleansSpillAndRefundsTheCallingQuery) {
    using namespace graph::query::execution;
    using namespace graph::query::execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE; options.query_scratch_enabled = true;
    auto backend = std::make_shared<RelocatableStorageBackend>(options); backend->open();
    graph::query::LogicalReadExecutionOptions reads; reads.bounds.maximum_materialized_bytes = 8U * 1024U * 1024U;
    graph::query::QueryEngine engine(std::static_pointer_cast<LogicalGraphReadBackend>(backend), reads);
    const auto fence = backend->currentNativeLogicalGraphMutationFence();
    const auto disk = graph::storage::detail::QueryScratchDiskBudget::processBudget();
    const auto before = disk->usage().bytes;
    graph::query::QueryContext context;
    context.resource_account = std::make_shared<ResourceAccount>(backend->queryResourceDomain(), ResourceClass::RCK_QUERY, reads.bounds.maximum_materialized_bytes);
    bool denied = false;
    try { static_cast<void>(engine.execute("UNWIND range(1,24000) AS x RETURN DISTINCT x % 12000 AS value", context)); }
    catch (const MaterializedByteLimitExceeded &) { denied = true; }
    catch (const ResourceAdmissionDenied &) { denied = true; }
    EXPECT_TRUE(denied);
    EXPECT_EQ(context.resource_account->used(), 0U);
    EXPECT_EQ(disk->usage().bytes, before);
    EXPECT_FALSE(backend->hasIndeterminateWriteOutcome());
    EXPECT_EQ(backend->currentNativeLogicalGraphMutationFence(), fence);
    {
        const auto retry = engine.execute("RETURN 42 AS value", context);
        ASSERT_EQ(retry.rowCount(), 1U); EXPECT_EQ(retry.getRows()[0].at("value").asPrimitive(), PropertyValue(42));
    }
    EXPECT_EQ(context.resource_account->used(), 0U);
    EXPECT_NO_THROW(static_cast<void>(backend->verifyIntegrity())); backend->close();
}

TEST_F(RelocatableStorageBackendTest, QueryScratchCleanupUsesProtectedMaintenanceWhenCacheCreditIsExhausted) {
    using namespace graph::query::execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE; options.query_scratch_enabled = true;
    RelocatableStorageBackend backend(options); backend.open();
    auto scratch = backend.openNativeQueryScratchSession(2U * RSS_SEGMENT_SIZE, 2U);
    const std::vector<std::byte> payload(4096U, std::byte{0x3c});
    const auto first = scratch->write(payload); static_cast<void>(scratch->write(payload));
    auto domain = backend.queryResourceDomain();
    const auto baseline = domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_MAINTENANCE)];
    auto cache = ProcessResourceDomains::defaultOwner()->cacheGrant(domain);
    const auto denials = cache->denials();
    {
        PrepaidMemoryResource::ExternalReservation pressure(cache, cache->capacity() - cache->used());
        EXPECT_NO_THROW(scratch->release(first));
        EXPECT_NO_THROW(scratch->finish());
        EXPECT_EQ(cache->denials(), denials);
    }
    EXPECT_EQ(domain->usage().classes[static_cast<size_t>(ResourceClass::RCK_MAINTENANCE)], baseline);
    EXPECT_FALSE(backend.hasIndeterminateWriteOutcome());
    scratch.reset();
    EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity())); backend.close();
}

TEST_F(RelocatableStorageBackendTest, QueryScratchCleanupAdmissionDenialPrecedesPublicationAndCanRetryTheSameHandle) {
    using namespace graph::query::execution::detail;
    materializeNativeDatabase();
    auto options = backendOptions(); options.open_mode = OpenMode::OPEN_EXISTING_FILE; options.query_scratch_enabled = true;
    RelocatableStorageBackend backend(options); backend.open();
    auto scratch = backend.openNativeQueryScratchSession(RSS_SEGMENT_SIZE, 1U);
    const std::vector<std::byte> payload(4096U, std::byte{0x4d}); const auto handle = scratch->write(payload);
    auto domain = backend.queryResourceDomain();
    constexpr auto maintenance = static_cast<size_t>(ResourceClass::RCK_MAINTENANCE);
    constexpr size_t ceiling = 32U * 1024U * 1024U;
    auto account = std::make_shared<ResourceAccount>(domain, ResourceClass::RCK_MAINTENANCE, ceiling);
    ResourceLease pressure(account); pressure.set(ceiling - domain->usage().classes[maintenance]);
    const auto generation = backend.currentNativeMetadataGeneration(); backend.resetIoStats();
    EXPECT_THROW(scratch->release(handle), ResourceAdmissionDenied);
    EXPECT_THROW(scratch->releaseBatch(std::span(&handle,1U)), ResourceAdmissionDenied);
    EXPECT_THROW(scratch->finish(), ResourceAdmissionDenied);
    EXPECT_EQ(backend.currentNativeMetadataGeneration(), generation);
    EXPECT_EQ(backend.ioStats().data.write_calls, 0U);
    EXPECT_FALSE(backend.hasIndeterminateWriteOutcome()); EXPECT_EQ(scratch->read(handle), payload);
    pressure.reset();
    EXPECT_NO_THROW(scratch->release(handle));
    EXPECT_NO_THROW(scratch->finish());
    scratch.reset();
    EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity())); backend.close();
}

TEST_F(RelocatableStorageBackendTest, QueryScratchBatchReleaseValidatesBeforePublicationAndAmortizesDurableCleanup) {
    materializeNativeDatabase();
    auto options=backendOptions();options.open_mode=OpenMode::OPEN_EXISTING_FILE;options.query_scratch_enabled=true;
    RelocatableStorageBackend backend(options);backend.open();
    const auto node=backend.createLogicalNodes({{{"ScratchBatch"},{{"value",PropertyValue(7)}}}}).front();
    auto pin=backend.openLogicalGraphReadSnapshot();const auto fence=backend.currentNativeLogicalGraphMutationFence();
    auto scratch=backend.openNativeQueryScratchSession(4U*RSS_SEGMENT_SIZE,4U);
    const std::vector<std::byte> payload(4096U,std::byte{0x67});
    std::array<uint64_t,4U> handles;for(auto &handle:handles) handle=scratch->write(payload);
    EXPECT_THROW(static_cast<void>(scratch->write(payload)),std::runtime_error);
    const auto generation=backend.currentNativeMetadataGeneration();backend.resetIoStats();
    const std::array duplicate{handles[0],handles[0]};
    const std::array stale{handles[0],UINT64_MAX};
    EXPECT_THROW(scratch->releaseBatch(duplicate),std::invalid_argument);
    EXPECT_THROW(scratch->releaseBatch(stale),std::invalid_argument);
    EXPECT_EQ(backend.currentNativeMetadataGeneration(),generation);
    EXPECT_EQ(backend.ioStats().data.write_calls,0U);
    EXPECT_EQ(scratch->read(handles[0]),payload);
    backend.resetIoStats();scratch->releaseBatch(std::span(handles).first(3U));
    const auto batchSyncs=backend.ioStats().data.sync_calls;
    RecordProperty("batch_cleanup_syncs",std::to_string(batchSyncs));
    EXPECT_GT(batchSyncs,0U);
    for(size_t i=0;i<3U;++i) EXPECT_THROW(static_cast<void>(scratch->read(handles[i])),std::invalid_argument);
    EXPECT_EQ(scratch->read(handles[3]),payload);
    backend.resetIoStats();scratch->release(handles[3]);
    RecordProperty("single_cleanup_syncs",std::to_string(backend.ioStats().data.sync_calls));
    EXPECT_EQ(batchSyncs,backend.ioStats().data.sync_calls);
    for(auto &handle:handles) handle=scratch->write(payload);
    EXPECT_EQ(pin->readNodeProperty(node,"value"),PropertyValue(7));
    EXPECT_EQ(backend.currentNativeLogicalGraphMutationFence(),fence);
    scratch->releaseBatch(handles);scratch->finish();scratch.reset();pin.reset();
    EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));backend.close();backend.open();
    EXPECT_EQ(backend.openLogicalGraphReadSnapshot()->readNodeProperty(node,"value"),PropertyValue(7));
    EXPECT_NO_THROW(static_cast<void>(backend.verifyIntegrity()));backend.close();
}

#include <gtest/gtest.h>
namespace rss_attribution {void report(const char*);}
int main(int argc,char **argv){::testing::InitGoogleTest(&argc,argv);const int result=RUN_ALL_TESTS();rss_attribution::report("after-gtest-cleanup");return result;}

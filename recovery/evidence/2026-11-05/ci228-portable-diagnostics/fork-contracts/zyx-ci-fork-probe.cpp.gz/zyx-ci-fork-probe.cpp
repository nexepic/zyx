#include "query/execution/CiDiagnosticForkSupport.hpp"
#include <thread>
#include <chrono>
#include <atomic>
#include <sys/wait.h>
int main(int argc,char **){
 namespace ci=graph::test::ci_diagnostics;
 const bool initialize=argc>1;if(initialize && !ci::initialize())return 6;
 std::atomic<bool> ready{false};
 std::thread worker([&]{graph::debug::ci_budget_detail::Lock lock;ready=true;
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(1);
  while(!ci::preparing.load() && std::chrono::steady_clock::now()<deadline)std::this_thread::yield();});
 while(!ready.load())std::this_thread::yield();
 const auto child=::fork();
 if(child==0){::alarm(3);graph::debug::ci_budget_detail::Lock lock;::_exit(0);}
 worker.join();if(child<0)return 7;int status=0;if(::waitpid(child,&status,0)!=child)return 8;
 if(WIFSIGNALED(status)){std::printf("FORK_PROBE initialized=%d child_signal=%d\n",initialize,WTERMSIG(status));return 10;}
 std::printf("FORK_PROBE initialized=%d child_exit=%d\n",initialize,WEXITSTATUS(status));return WEXITSTATUS(status);
}

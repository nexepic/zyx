#include "graph/query/execution/MaterializedByteBudget.hpp"
#include "graph/query/execution/PrepaidMemoryResource.hpp"
#include "graph/debug/ResidentMemoryDiagnostics.hpp"
#include <thread>
#include <cstdio>
#include <array>
using namespace graph::query::execution;
using namespace graph::query::execution::detail;
int main(){
 auto p=std::make_shared<ProcessResourceBudget>(ResourceLimits::uniform(100));
 auto d=std::make_shared<DatabaseResourceBudget>(p,ResourceLimits::uniform(100));
 auto a=std::make_shared<ResourceAccount>(d,ResourceClass::RCK_QUERY,100);
 {PrepaidMemoryResource memory(a,64);void *v=memory.allocate(48,8);
  try{(void)memory.allocate(32,8);return 1;}catch(const ResourceAdmissionDenied&){}
  if(memory.used()!=48)return 2;memory.deallocate(v,48,8);if(memory.used()!=0)return 3;}
 if(a->used()!=0)return 4;
 {MaterializedByteBudget budget(40,a);MaterializedByteReservation r(&budget);r.set(30);
  for(unsigned i=0;i<100;++i){try{r.set(41);return 5;}catch(const MaterializedByteLimitExceeded&){}if(budget.used()!=30)return 6;}
  r.reset();if(budget.used()!=0||a->used()!=0)return 7;}
#ifdef ZYX_ENABLE_STORAGE_TEST_HOOKS
 graph::debug::CiBudgetTrace trace("concurrent-probe");std::array<std::thread,4> threads;
 for(auto &t:threads)t=std::thread([&]{for(unsigned i=0;i<100;++i)(void)trace.allow();});
 for(auto &t:threads)t.join();trace.summary(0,64,64);
 graph::debug::traceResidentMemory("before-query");
 graph::debug::traceResidentMemory("after-backend-destruction");
#endif
#ifdef ZYX_ENABLE_STORAGE_TEST_HOOKS
 char token=0;graph::debug::CiBudgetTrace reused(&token,"reuse-probe");const auto first=reused.id();
 ::unsetenv("ZYX_CI_BUDGET_TRACE");reused.summary(0,0,1);
 ::setenv("ZYX_CI_BUDGET_TRACE","1",1);if(reused.id()==first)return 8;reused.summary(0,0,1);
 std::array<char,600> owners{};size_t missing=0;
 for(auto &owner:owners)if(graph::debug::CiBudgetTrace(&owner,"capacity-probe").id()==0)++missing;
 if(missing==0)return 9;
 for(auto &owner:owners)graph::debug::CiBudgetTrace(&owner,"capacity-probe").summary(0,0,1);
#endif
 std::printf("LAYOUT materialized=%zu prepaid=%zu account=%zu\n",sizeof(MaterializedByteBudget),sizeof(PrepaidMemoryResource),sizeof(ResourceAccount));
 return 0;
}

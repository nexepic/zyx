#define ZYX_ENABLE_STORAGE_TEST_HOOKS
#include "graph/debug/RssActivity.hpp"
#include <cassert>
#include <cstdlib>
int main() {
 setenv("ZYX_CI_RSS_ATTRIBUTION", "1", 1);
 graph::debug::reportRssActivity("before-query", true);
 void *p;
 { graph::debug::RssActivityScope scope(graph::debug::RssActivityKind::RAK_ROW_DECODE); p=malloc(1024*1024); assert(p); static_cast<volatile char*>(p)[0]=1; }
 auto &c=graph::debug::rssActivityCounters[2];
 assert(c.calls.load()==1 && c.live_increase.load()>=1024*1024);
 graph::debug::reportRssActivity("after-decode", false);
 free(p);
}
